%%%if re-running
cd(Folder_master)
load('workspace_all_recordings.mat')
kj=0
kj = exist ('recording_all')
if kj
recording = recording_all;
end
%%%%%%

excl_running = 1;
excl_whisking = 1;
excl_vis = 1;
excl_seiz=0
excl_int=0
min_length_matrix = 9660
interpolate_whisking_to_100Hz = 0;
microseiz_summary_no_run_no_whisk_no_vis = microseiz_analysis(edges,subfolders,...
    recording(1).initial,recording,widefield_recording,add_params,...
    excl_running,excl_whisking,wheel_thr,half_sec,interpolate_whisking_to_100Hz,6,...
    excl_vis,excl_seiz,excl_int,min_length_matrix)
save microseiz_summary_no_run_no_whisk_no_vis.mat microseiz_summary_no_run_no_whisk_no_vis -v7.3



ms = microseiz_summary_no_run_no_whisk_no_vis;

% %%%%% determine some basic ca-activity parameters:
this_one_serial= 0

for iii = 1:size(recording,2)
    if recording(1).initial.no_imaging(1,iii) || recording(1).initial.datedr(1,iii)==0 ||...
            isfield(recording(iii).EEG_results_nonoise,'oopsi_interp_values')==0
    else
        rec = iii
        i2 = recording(iii).initial2;
        fr = 100; %set to 0 if analyzing non-interpolated matrix!
        matrix = ms(iii).ernoiv_adj_run_and_or_whisk;
        if isempty(matrix)
            recording(iii).no_quiet_analysis_possible = 1;
        else
        curr_mat = real(matrix);
        clear ca_stats_no_run_no_whisk_no_vis
        [ca_stats_no_run_no_whisk_no_vis] = basic_ca_stats_f_epilepsy(Folder,i2,curr_mat,fr,onep,FOV,this_one_serial);
        recording(iii).ca_stats_no_run_no_whisk_no_vis_deconv = ca_stats_no_run_no_whisk_no_vis;
        ca_stats_no_vis(iii).ca_stats_no_run_no_whisk_no_vis = ca_stats_no_run_no_whisk_no_vis;
        end
    end
end
cd(Folder_master)
save ca_stats_no_vis.mat ca_stats_no_vis -v7.3
%%%%%%%%%%%%%%%%%%%%%%%


%%%%%double check these are correct
animal_ID = xxxx
L23 = 1
L4 = 0;
Cr86 = 1;
GPC6 = 0;
IGSF3 = 0;
xCT_KO = 0;
control = 0;
barea = xxxx;
brainarea = 'xxxx';


EEG_segs_not_run_yet=0
multiple_recs_in_one_day_present = 0
%here we visualize and run basic stats
%If you have multiple brain areas in one recording structure and need to
%split up:
start_w_rec = 1
barea_rec_start = start_w_rec

num_recs_to_process =1
onep_binned_twice=0

% summaries_from_tetx_no_ch_swap

%or if analyzed multiple brain areas inside one date folder
%run this part only once
recording_all = recording; %(only first time!)
% All_EEGs_all = All_EEGs;
% EEG_segs_all = EEG_segs;
%Ca_EEG_stats_all = Ca_EEG_stats;
ms_all = ms;
%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%if kj, go through these one by one

curr_barea = 1

Folder = subfolders(curr_barea).name;
cd(Folder_master)
cd(Folder)

barea_rec_start=curr_barea
recording = recording_all(barea_rec_start);
% All_EEGs = All_EEGs_all(barea_rec_start);
% EEG_segs = EEG_segs_all(barea_rec_start);
ms = ms_all(barea_rec_start);
not_a_tetx_recording = 1;

num_recs = num_recs_to_process %size(ms,2)

clear curr_summary_no_vis_DF_params
for p = 1:num_recs
    if isfield(recording(start_w_rec+p-1),'no_quiet_analysis_possible')
        if   ~isempty(intersect(start_w_rec+p-1,to_remove)) ||...
                ~isempty(recording(start_w_rec+p-1).no_quiet_analysis_possible)%p==to_remove
        else
            ii=start_w_rec+p-1
            curr_summary_no_vis_DF_params(p).tot_dur_s = ms(start_w_rec+p-1).tot_dur_s;
            if not_a_tetx_recording
                curr_summary_no_vis_DF_params(p).days_of_TeT = add_params.day_P(1,barea_rec_start+p-1);
                curr_summary_no_vis_DF_params(1).not_a_tetx_recording = 1;
            else
                curr_summary_no_vis_DF_params(p).days_of_TeT = add_params.days_of_TeT(1,barea_rec_start+p-1);
            end
            %curr_summary(p).tot_ms_dur_s = microseiz_summary(p).tot_ms_dur_s;
            curr_summary_no_vis_DF_params(p).mean_synchr = mean(ms(start_w_rec+p-1).curr_synchr);
            curr_summary_no_vis_DF_params(p).std_synchr = std(ms(start_w_rec+p-1).curr_synchr,0);
            if ms(p).no_ms_analysis_possible==0
                curr_summary_no_vis_DF_params(p).num_ms = ms(start_w_rec+p-1).num_ms;
                curr_summary_no_vis_DF_params(p).ms_per_hour = ms(start_w_rec+p-1).ms_per_hr;
                curr_summary_no_vis_DF_params(p).perc_time_in_microsz = ms(start_w_rec+p-1).perc_time_in_microsz;
                curr_summary_no_vis_DF_params(p).microseiz = ms(start_w_rec+p-1).microseiz;
            end
            
            curr_summary_no_vis_DF_params(p).no_run_no_whisk.mean_DF = recording(ii).ca_stats_no_run_no_whisk_no_vis_deconv.ROI_events(1).mean_DF;
            curr_summary_no_vis_DF_params(p).no_run_no_whisk.mean_mean_DF = mean(recording(ii).ca_stats_no_run_no_whisk_no_vis_deconv.ROI_events(1).mean_DF);
            curr_summary_no_vis_DF_params(p).no_run_no_whisk.std_mean_DF = std(recording(ii).ca_stats_no_run_no_whisk_no_vis_deconv.ROI_events(1).mean_DF,0);
            curr_summary_no_vis_DF_params(p).no_run_no_whisk.events_per_sec = recording(ii).ca_stats_no_run_no_whisk_no_vis_deconv.ROI_events(1).events_per_sec;
            curr_summary_no_vis_DF_params(p).no_run_no_whisk.mean_events_per_sec = mean(recording(ii).ca_stats_no_run_no_whisk_no_vis_deconv.ROI_events(1).events_per_sec);
            curr_summary_no_vis_DF_params(p).no_run_no_whisk.std_events_per_sec = std(recording(ii).ca_stats_no_run_no_whisk_no_vis_deconv.ROI_events(1).events_per_sec,0);
            curr_summary_no_vis_DF_params(p).no_run_no_whisk.mean_event_length_ms = recording(ii).ca_stats_no_run_no_whisk_no_vis_deconv.ROI_events(1).mean_event_length_ms;
            curr_summary_no_vis_DF_params(p).no_run_no_whisk.mean_mean_event_length_ms = mean(recording(ii).ca_stats_no_run_no_whisk_no_vis_deconv.ROI_events(1).mean_event_length_ms);
            curr_summary_no_vis_DF_params(p).no_run_no_whisk.std_mean_event_length_ms = std(recording(ii).ca_stats_no_run_no_whisk_no_vis_deconv.ROI_events(1).mean_event_length_ms,0);
            curr_summary_no_vis_DF_params(p).no_run_no_whisk.std_event_length_ms = recording(ii).ca_stats_no_run_no_whisk_no_vis_deconv.ROI_events(1).std_event_length_ms;
            curr_summary_no_vis_DF_params(p).no_run_no_whisk.mean_event_amplitude = recording(ii).ca_stats_no_run_no_whisk_no_vis_deconv.ROI_events(1).mean_event_amplitude;
            curr_summary_no_vis_DF_params(p).no_run_no_whisk.mean_mean_event_amplitude = mean(recording(ii).ca_stats_no_run_no_whisk_no_vis_deconv.ROI_events(1).mean_event_amplitude);
            curr_summary_no_vis_DF_params(p).no_run_no_whisk.std_mean_event_amplitude = std(recording(ii).ca_stats_no_run_no_whisk_no_vis_deconv.ROI_events(1).mean_event_amplitude,0);
            curr_summary_no_vis_DF_params(p).no_run_no_whisk.std_event_amplitude = recording(ii).ca_stats_no_run_no_whisk_no_vis_deconv.ROI_events(1).std_event_amplitude;
            curr_summary_no_vis_DF_params(p).no_run_no_whisk.mean_event_area = recording(ii).ca_stats_no_run_no_whisk_no_vis_deconv.ROI_events(1).mean_event_area;
            curr_summary_no_vis_DF_params(p).no_run_no_whisk.mean_mean_event_area = mean(recording(ii).ca_stats_no_run_no_whisk_no_vis_deconv.ROI_events(1).mean_event_area);
            curr_summary_no_vis_DF_params(p).no_run_no_whisk.std_mean_event_area = std(recording(ii).ca_stats_no_run_no_whisk_no_vis_deconv.ROI_events(1).mean_event_area,0);
            curr_summary_no_vis_DF_params(p).no_run_no_whisk.std_event_area = recording(ii).ca_stats_no_run_no_whisk_no_vis_deconv.ROI_events(1).std_event_area;
            
        end
    else
        ii=start_w_rec+p-1
        curr_summary_no_vis_DF_params(p).tot_dur_s = ms(start_w_rec+p-1).tot_dur_s;
        if not_a_tetx_recording
            curr_summary_no_vis_DF_params(p).days_of_TeT = add_params.day_P(1,barea_rec_start+p-1);
            curr_summary_no_vis_DF_params(1).not_a_tetx_recording = 1;
        else
            curr_summary_no_vis_DF_params(p).days_of_TeT = add_params.days_of_TeT(1,barea_rec_start+p-1);
        end
        %curr_summary(p).tot_ms_dur_s = microseiz_summary(p).tot_ms_dur_s;
        curr_summary_no_vis_DF_params(p).mean_synchr = mean(ms(start_w_rec+p-1).curr_synchr);
        curr_summary_no_vis_DF_params(p).std_synchr = std(ms(start_w_rec+p-1).curr_synchr,0);
        if ms(p).no_ms_analysis_possible==0
            curr_summary_no_vis_DF_params(p).num_ms = ms(start_w_rec+p-1).num_ms;
            curr_summary_no_vis_DF_params(p).ms_per_hour = ms(start_w_rec+p-1).ms_per_hr;
            curr_summary_no_vis_DF_params(p).perc_time_in_microsz = ms(start_w_rec+p-1).perc_time_in_microsz;
            curr_summary_no_vis_DF_params(p).microseiz = ms(start_w_rec+p-1).microseiz;
        end
        
        curr_summary_no_vis_DF_params(p).no_run_no_whisk.mean_DF = recording(ii).ca_stats_no_run_no_whisk_no_vis_deconv.ROI_events(1).mean_DF;
        curr_summary_no_vis_DF_params(p).no_run_no_whisk.mean_mean_DF = mean(recording(ii).ca_stats_no_run_no_whisk_no_vis_deconv.ROI_events(1).mean_DF);
        curr_summary_no_vis_DF_params(p).no_run_no_whisk.std_mean_DF = std(recording(ii).ca_stats_no_run_no_whisk_no_vis_deconv.ROI_events(1).mean_DF,0);
        curr_summary_no_vis_DF_params(p).no_run_no_whisk.events_per_sec = recording(ii).ca_stats_no_run_no_whisk_no_vis_deconv.ROI_events(1).events_per_sec;
        curr_summary_no_vis_DF_params(p).no_run_no_whisk.mean_events_per_sec = mean(recording(ii).ca_stats_no_run_no_whisk_no_vis_deconv.ROI_events(1).events_per_sec);
        curr_summary_no_vis_DF_params(p).no_run_no_whisk.std_events_per_sec = std(recording(ii).ca_stats_no_run_no_whisk_no_vis_deconv.ROI_events(1).events_per_sec,0);
        curr_summary_no_vis_DF_params(p).no_run_no_whisk.mean_event_length_ms = recording(ii).ca_stats_no_run_no_whisk_no_vis_deconv.ROI_events(1).mean_event_length_ms;
        curr_summary_no_vis_DF_params(p).no_run_no_whisk.mean_mean_event_length_ms = mean(recording(ii).ca_stats_no_run_no_whisk_no_vis_deconv.ROI_events(1).mean_event_length_ms);
        curr_summary_no_vis_DF_params(p).no_run_no_whisk.std_mean_event_length_ms = std(recording(ii).ca_stats_no_run_no_whisk_no_vis_deconv.ROI_events(1).mean_event_length_ms,0);
        curr_summary_no_vis_DF_params(p).no_run_no_whisk.std_event_length_ms = recording(ii).ca_stats_no_run_no_whisk_no_vis_deconv.ROI_events(1).std_event_length_ms;
        curr_summary_no_vis_DF_params(p).no_run_no_whisk.mean_event_amplitude = recording(ii).ca_stats_no_run_no_whisk_no_vis_deconv.ROI_events(1).mean_event_amplitude;
        curr_summary_no_vis_DF_params(p).no_run_no_whisk.mean_mean_event_amplitude = mean(recording(ii).ca_stats_no_run_no_whisk_no_vis_deconv.ROI_events(1).mean_event_amplitude);
        curr_summary_no_vis_DF_params(p).no_run_no_whisk.std_mean_event_amplitude = std(recording(ii).ca_stats_no_run_no_whisk_no_vis_deconv.ROI_events(1).mean_event_amplitude,0);
        curr_summary_no_vis_DF_params(p).no_run_no_whisk.std_event_amplitude = recording(ii).ca_stats_no_run_no_whisk_no_vis_deconv.ROI_events(1).std_event_amplitude;
        curr_summary_no_vis_DF_params(p).no_run_no_whisk.mean_event_area = recording(ii).ca_stats_no_run_no_whisk_no_vis_deconv.ROI_events(1).mean_event_area;
        curr_summary_no_vis_DF_params(p).no_run_no_whisk.mean_mean_event_area = mean(recording(ii).ca_stats_no_run_no_whisk_no_vis_deconv.ROI_events(1).mean_event_area);
        curr_summary_no_vis_DF_params(p).no_run_no_whisk.std_mean_event_area = std(recording(ii).ca_stats_no_run_no_whisk_no_vis_deconv.ROI_events(1).mean_event_area,0);
        curr_summary_no_vis_DF_params(p).no_run_no_whisk.std_event_area = recording(ii).ca_stats_no_run_no_whisk_no_vis_deconv.ROI_events(1).std_event_area;
        
    end
end

%only cd if not analyzing multiple bareas...
cd(Folder_master)
cd(Folder)
save curr_summary_no_vis_DF_params.mat curr_summary_no_vis_DF_params -v7.3

clear mscomb cscomb ms2 cs2 ms1 cs1
ms2 = ms;
cs2=curr_summary_no_vis_DF_params;
L23fovnum=2
ms1 = tumor_animal_no_vis_DF_params(animal_ID).L23(L23fovnum).microseiz_summary;
cs1 = tumor_animal_no_vis_DF_params(animal_ID).L23(L23fovnum).all_summary;

%if necessary
cs2.num_ms = [];
cs2.ms_per_hour = [];
cs2.perc_time_in_microseiz=[];
cs2.microseiz=[];

%if necessary
ms1.vis_inds = [];
ms1.seiz_inds = [];
%if necessary
cscomb2helper = cs2;
cscomb2helper(2) = cs2;
cscomb1helper = cs1;
cscomb1helper(2) = cs1;
%now copy&paste
cscomb = cscomb1helper;

mscomb2helper = ms2;
mscomb2helper(2) = ms2;
mscomb1helper = ms1;
mscomb1helper(2) = ms1;
%now copy&paste
mscomb = mscomb2helper;

%OR just
mscomb=ms1;
mscomb(2)=ms2;
cscomb=cs1;
cscomb(2)=cs2;
ms=mscomb;
curr_summary_no_vis_DF_params=cscomb;

%Attention: this is really only valid if i only scanned one brain area
if multiple_recs_in_one_day_present
    consolidate_all_except_ms_for_one_animal_for_tumor_excl_vis
   
    %this is only for microseizure analysis! for all animals at the end
    consolidate_ms_tumor;
end

if size(barea,2) == 1
    if isempty(tumor_animal_no_vis_DF_params(animal_ID).barea) && barea==1
        if L23
            L23fovnum=1
        else
            L4fovnum=1
        end
    else
        if L23
            L23fovnum = size(tumor_animal_no_vis_DF_params(animal_ID).L23,2)+1
        else
            L4fovnum = size(tumor_animal_no_vis_DF_params(animal_ID).L4,2)+1
        end
    end
    
    if L23==1
        tumor_animal_no_vis_DF_params(animal_ID).L23(L23fovnum).microseiz_summary = ms;
        tumor_animal_no_vis_DF_params(animal_ID).L23(L23fovnum).Cr86 = Cr86;
        tumor_animal_no_vis_DF_params(animal_ID).L23(L23fovnum).GPC6 = GPC6;
        tumor_animal_no_vis_DF_params(animal_ID).L23(L23fovnum).IGSF3 = IGSF3;
        tumor_animal_no_vis_DF_params(animal_ID).L23(L23fovnum).xCT_KO = xCT_KO;
        tumor_animal_no_vis_DF_params(animal_ID).L23(L23fovnum).control = control;
        tumor_animal_no_vis_DF_params(animal_ID).L23(L23fovnum).brainarea = brainarea';
        tumor_animal_no_vis_DF_params(animal_ID).L23(L23fovnum).all_summary = curr_summary_no_vis_DF_params;
        
    else
        tumor_animal_no_vis_DF_params(animal_ID).L4(L4fovnum).microseiz_summary = ms;
        tumor_animal_no_vis_DF_params(animal_ID).L4(L4fovnum).Cr86 = Cr86;
        tumor_animal_no_vis_DF_params(animal_ID).L4(L4fovnum).GPC6 = GPC6;
        tumor_animal_no_vis_DF_params(animal_ID).L4(L4fovnum).IGSF3 = IGSF3;
        tumor_animal_no_vis_DF_params(animal_ID).L4(L4fovnum).xCT_KO = xCT_KO;
        tumor_animal_no_vis_DF_params(animal_ID).L4(L4fovnum).control = control;
        tumor_animal_no_vis_DF_params(animal_ID).L4(L4fovnum).brainarea = brainarea;
        tumor_animal_no_vis_DF_params(animal_ID).L4(L4fovnum).all_summary = curr_summary_no_vis_DF_params;
    end
else
  
    for k = 1:size(barea,2)
        if L23
            L23fovnum=barea(1,k);
        else
            L4fovnum=barea(1,k);
        end
        if L23==1
            tumor_animal_no_vis_DF_params(animal_ID).L23(L23fovnum).init=1;
            if isfield(tumor_animal_no_vis_DF_params(animal_ID).L23(L23fovnum),'microseiz_summary')
                if ~isempty(tumor_animal_no_vis_DF_params(animal_ID).L23(L23fovnum).microseiz_summary)
                    xx = size(tumor_animal_no_vis_DF_params(animal_ID).L23(L23fovnum),2) + 1;
                end
            else
                xx=1;
            end
            tumor_animal_no_vis_DF_params(animal_ID).L23(L23fovnum).microseiz_summary(xx) = ms(k);
            tumor_animal_no_vis_DF_params(animal_ID).L23(L23fovnum).Cr86(xx) = Cr86;
            tumor_animal_no_vis_DF_params(animal_ID).L23(L23fovnum).GPC6(xx) = GPC6;
            tumor_animal_no_vis_DF_params(animal_ID).L23(L23fovnum).IGSF3(xx) = IGSF3;
            tumor_animal_no_vis_DF_params(animal_ID).L23(L23fovnum).xCT_KO(xx) = xCT_KO;
            tumor_animal_no_vis_DF_params(animal_ID).L23(L23fovnum).control(xx) = control;
            tumor_animal_no_vis_DF_params(animal_ID).L23(L23fovnum).brainarea(xx) = brainarea(1,k)'; %= brainarea{1,k}';
            tumor_animal_no_vis_DF_params(animal_ID).barea.L23(L23fovnum).all_summary{xx} = curr_summary_no_vis_DF_params(k);
            tumor_animal_no_vis_DF_params(animal_ID).barea.L23(L23fovnum).consolidated{xx} = consolidated;
            tumor_animal_no_vis_DF_params(animal_ID).barea.L23(L23fovnum).preconsolidated{xx} = fc;
        else
            tumor_animal_no_vis_DF_params(animal_ID).L4(L4fovnum).init=1;
            if isfield(tumor_animal_no_vis_DF_params(animal_ID).L4(L4fovnum),'microseiz_summary')
                if ~isempty(tumor_animal_no_vis_DF_params(animal_ID).L4(L4fovnum).microseiz_summary)
                    xx = size(tumor_animal_no_vis_DF_params(animal_ID).L4(L4fovnum),2) + 1;
                end
            else
                xx=1;
            end
            tumor_animal_no_vis_DF_params(animal_ID).L4(L4fovnum).microseiz_summary(xx) = ms(k);
            tumor_animal_no_vis_DF_params(animal_ID).L4(L4fovnum).Cr86(xx) = Cr86;
            tumor_animal_no_vis_DF_params(animal_ID).L4(L4fovnum).GPC6(xx) = GPC6;
            tumor_animal_no_vis_DF_params(animal_ID).L4(L4fovnum).IGSF3(xx) = IGSF3;
            tumor_animal_no_vis_DF_params(animal_ID).L4(L4fovnum).xCT_KO(xx) = xCT_KO;
            tumor_animal_no_vis_DF_params(animal_ID).L4(L4fovnum).control(xx) = control;
            tumor_animal_no_vis_DF_params(animal_ID).L4(L4fovnum).brainarea{xx} = brainarea{1,k}';
            tumor_animal_no_vis_DF_params(animal_ID).barea.L4(L4fovnum).all_summary(xx) = curr_summary_no_vis_DF_params(k);
            tumor_animal_no_vis_DF_params(animal_ID).barea.L4(L4fovnum).consolidated(xx) = consolidated;
            tumor_animal_no_vis_DF_params(animal_ID).barea.L4(L4fovnum).preconsolidated(xx) = fc;
        end
    end
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%chAnge to FOlder if it had multiple brain areas
%
cd(Folder_master)
%cd(Folder)
clear tumor_animal tumor_animal_no_vis_DF_params
save curr_summary_no_vis_DF_params.mat curr_summary_no_vis_DF_params -v7.3
 
%adjust file name if needed
save workspace_all_recordingss.mat -v7.3

