



ict_or_int_or_all = 'all'
%onep_binned_twice = 0;
to_remove = []

%rerun and repopulate microseizure summary
tto=0;
filelist = dir(Folder_master)

not_a_tetx_recording = 1;

num_recs = num_recs_to_process %size(ms,2)

if isfield(recording(1),'cluster_results')
    for iii = 1:num_recs %size(subfolders,2)
        cluster_summary(iii).cluster_results = recording(iii).cluster_results;
        if isempty(recording(iii).cluster_results)
            recording(iii).cluster_results(iii).too_short = 1;
            cluster_summary(iii).cluster_results(iii).too_short = 1;
        end
    end

else
    for iii = 1:num_recs %size(subfolders,2)
        cluster_summary(iii).cluster_results = cluster_results(iii);
        %  recording(iii).cluster_results = cluster_results(iii);
    end
end

clear curr_summary
for p = 1:num_recs
    if   ~isempty(intersect(start_w_rec+p-1,to_remove))%p==to_remove
    else
        ii=start_w_rec+p-1
        curr_summary(p).tot_dur_s = ms(start_w_rec+p-1).tot_dur_s;
        if not_a_tetx_recording
            curr_summary(p).days_of_TeT = add_params.day_P(1,barea_rec_start+p-1);
            curr_summary(1).not_a_tetx_recording = 1;
        else
            curr_summary(p).days_of_TeT = add_params.days_of_TeT(1,barea_rec_start+p-1);
        end
        %curr_summary(p).tot_ms_dur_s = microseiz_summary(p).tot_ms_dur_s;
        curr_summary(p).mean_synchr = mean(ms(start_w_rec+p-1).curr_synchr);
        curr_summary(p).std_synchr = std(ms(start_w_rec+p-1).curr_synchr,0);
        if ms(p).no_ms_analysis_possible==0
            curr_summary(p).num_ms = ms(start_w_rec+p-1).num_ms;
            curr_summary(p).ms_per_hour = ms(start_w_rec+p-1).ms_per_hr;
            curr_summary(p).perc_time_in_microsz = ms(start_w_rec+p-1).perc_time_in_microsz;
            curr_summary(p).microseiz = ms(start_w_rec+p-1).microseiz;
        end
        if isfield(recording(ii),'FOV')
            if ~isempty(recording(ii).FOV)
                curr_summary(p).fov_pix_area = recording(ii).FOV(1,1)*recording(ii).FOV(1,2);
            else
                if isfield(recording(ii).initial2, 'pixelsperline')
                    curr_summary(p).fov_pix_area = recording(ii).initial2.pixelsperline * recording(ii).initial2.linesperframe;
                else
                    curr_summary(p).fov_pix_area = recording(ii).initial.height * recording(ii).initial.width;
                end
            end
        else
            if isfield(recording(ii).initial2, 'pixelsperline')
                curr_summary(p).fov_pix_area = recording(ii).initial2.pixelsperline * recording(ii).initial2.linesperframe;
            else
                curr_summary(p).fov_pix_area = recording(ii).initial.height * recording(ii).initial.width;
            end
        end
        curr_summary(p).squm_p_ix = recording(ii).initial2.microns_per_pixel*recording(ii).initial2.microns_per_pixel;
        curr_summary(p).fov_umsq = curr_summary(p).fov_pix_area*curr_summary(p).squm_p_ix;
        curr_summary(p).area_mm2 = recording(ii).ca_stats_deconv.area_mm2;
        curr_summary(p).mean_DF = recording(ii).ca_stats_deconv.ROI_events(1).mean_DF;
        curr_summary(p).mean_mean_DF = mean(recording(ii).ca_stats_deconv.ROI_events(1).mean_DF);
        curr_summary(p).std_mean_DF = std(recording(ii).ca_stats_deconv.ROI_events(1).mean_DF,0);
        curr_summary(p).events_per_sec = recording(ii).ca_stats_deconv.ROI_events(1).events_per_sec;
        curr_summary(p).mean_events_per_sec = mean(recording(ii).ca_stats_deconv.ROI_events(1).events_per_sec);
        curr_summary(p).std_events_per_sec = std(recording(ii).ca_stats_deconv.ROI_events(1).events_per_sec,0);
        curr_summary(p).mean_event_length_ms = recording(ii).ca_stats_deconv.ROI_events(1).mean_event_length_ms;
        curr_summary(p).mean_mean_event_length_ms = mean(recording(ii).ca_stats_deconv.ROI_events(1).mean_event_length_ms);
        curr_summary(p).std_mean_event_length_ms = std(recording(ii).ca_stats_deconv.ROI_events(1).mean_event_length_ms,0);
        curr_summary(p).std_event_length_ms = recording(ii).ca_stats_deconv.ROI_events(1).std_event_length_ms;
        curr_summary(p).mean_event_amplitude = recording(ii).ca_stats_deconv.ROI_events(1).mean_event_amplitude;
        curr_summary(p).mean_mean_event_amplitude = mean(recording(ii).ca_stats_deconv.ROI_events(1).mean_event_amplitude);
        curr_summary(p).std_mean_event_amplitude = std(recording(ii).ca_stats_deconv.ROI_events(1).mean_event_amplitude,0);
        curr_summary(p).std_event_amplitude = recording(ii).ca_stats_deconv.ROI_events(1).std_event_amplitude;
        curr_summary(p).mean_event_area = recording(ii).ca_stats_deconv.ROI_events(1).mean_event_area;
        curr_summary(p).mean_mean_event_area = mean(recording(ii).ca_stats_deconv.ROI_events(1).mean_event_area);
        curr_summary(p).std_mean_event_area = std(recording(ii).ca_stats_deconv.ROI_events(1).mean_event_area,0);
        curr_summary(p).std_event_area = recording(ii).ca_stats_deconv.ROI_events(1).std_event_area;

        %respectively for no_run_no_whisk
        if ~isfield(recording(p),'no_quiet_analysis_possible')
            curr_summary(p).no_run_no_whisk.mean_DF = recording(ii).ca_stats_no_run_no_whisk_deconv.ROI_events(1).mean_DF;
            curr_summary(p).no_run_no_whisk.mean_mean_DF = mean(recording(ii).ca_stats_no_run_no_whisk_deconv.ROI_events(1).mean_DF);
            curr_summary(p).no_run_no_whisk.std_mean_DF = std(recording(ii).ca_stats_no_run_no_whisk_deconv.ROI_events(1).mean_DF,0);
            curr_summary(p).no_run_no_whisk.events_per_sec = recording(ii).ca_stats_no_run_no_whisk_deconv.ROI_events(1).events_per_sec;
            curr_summary(p).no_run_no_whisk.mean_events_per_sec = mean(recording(ii).ca_stats_no_run_no_whisk_deconv.ROI_events(1).events_per_sec);
            curr_summary(p).no_run_no_whisk.std_events_per_sec = std(recording(ii).ca_stats_no_run_no_whisk_deconv.ROI_events(1).events_per_sec,0);
            curr_summary(p).no_run_no_whisk.mean_event_length_ms = recording(ii).ca_stats_no_run_no_whisk_deconv.ROI_events(1).mean_event_length_ms;
            curr_summary(p).no_run_no_whisk.mean_mean_event_length_ms = mean(recording(ii).ca_stats_no_run_no_whisk_deconv.ROI_events(1).mean_event_length_ms);
            curr_summary(p).no_run_no_whisk.std_mean_event_length_ms = std(recording(ii).ca_stats_no_run_no_whisk_deconv.ROI_events(1).mean_event_length_ms,0);
            curr_summary(p).no_run_no_whisk.std_event_length_ms = recording(ii).ca_stats_no_run_no_whisk_deconv.ROI_events(1).std_event_length_ms;
            curr_summary(p).no_run_no_whisk.mean_event_amplitude = recording(ii).ca_stats_no_run_no_whisk_deconv.ROI_events(1).mean_event_amplitude;
            curr_summary(p).no_run_no_whisk.mean_mean_event_amplitude = mean(recording(ii).ca_stats_no_run_no_whisk_deconv.ROI_events(1).mean_event_amplitude);
            curr_summary(p).no_run_no_whisk.std_mean_event_amplitude = std(recording(ii).ca_stats_no_run_no_whisk_deconv.ROI_events(1).mean_event_amplitude,0);
            curr_summary(p).no_run_no_whisk.std_event_amplitude = recording(ii).ca_stats_no_run_no_whisk_deconv.ROI_events(1).std_event_amplitude;
            curr_summary(p).no_run_no_whisk.mean_event_area = recording(ii).ca_stats_no_run_no_whisk_deconv.ROI_events(1).mean_event_area;
            curr_summary(p).no_run_no_whisk.mean_mean_event_area = mean(recording(ii).ca_stats_no_run_no_whisk_deconv.ROI_events(1).mean_event_area);
            curr_summary(p).no_run_no_whisk.std_mean_event_area = std(recording(ii).ca_stats_no_run_no_whisk_deconv.ROI_events(1).mean_event_area,0);
            curr_summary(p).no_run_no_whisk.std_event_area = recording(ii).ca_stats_no_run_no_whisk_deconv.ROI_events(1).std_event_area;

            if sum(size(cluster_summary(ii).cluster_results))>2
                cc = ii
            else
                cc=1
            end
            if ~isfield(cluster_summary(ii).cluster_results(cc),'too_short') && ~isfield(cluster_summary(ii).cluster_results(cc),'donotanalze')

                recording(p).cluster_results(1).sdec_thr = cluster_summary(ii).cluster_results(cc).sdec_thr;
                recording(p).cluster_results(1).corr_results = cluster_summary(ii).cluster_results(cc).corr_results;
                if isfield(cluster_summary(ii).cluster_results(cc),'correlation_results_pre_seiz')
                    recording(p).cluster_results(1).correlation_results_pre_seiz = cluster_summary(ii).cluster_results(cc).correlation_results_pre_seiz;
                    recording(p).cluster_results(1).correlation_results_pre_seiz_a = cluster_summary(ii).cluster_results(cc).correlation_results_pre_seiz_a;
                else
                    recording(p).cluster_results(1).correlation_results_pre_seiz = cluster_summary(ii).cluster_results(cc).correlation_results_post_seiz;
                    recording(p).cluster_results(1).correlation_results_pre_seiz_a = cluster_summary(ii).cluster_results(cc).correlation_results_post_seiz_a;
                end
                recording(p).cluster_results(1).correlation_results_post_seiz = cluster_summary(ii).cluster_results(cc).correlation_results_post_seiz;
                recording(p).cluster_results(1).correlation_results_post_seiz_a = cluster_summary(ii).cluster_results(cc).correlation_results_post_seiz_a;
                if isfield(cluster_summary(ii).cluster_results(cc),'correlation_results_2_S_dec_pre_post')
                    recording(p).cluster_results(1).correlation_results_2_S_dec_pre_post = cluster_summary(ii).cluster_results(cc).correlation_results_2_S_dec_pre_post;
                end
                recording(p).cluster_results(1).clust_results = cluster_summary(ii).cluster_results(cc).clust_results;
                recording(p).cluster_results(1).num_clusts_pre_SBE = cluster_summary(ii).cluster_results(cc).num_clusts_pre_SBE;
                recording(p).cluster_results(1).num_clusts_post_SBE = cluster_summary(ii).cluster_results(cc).num_clusts_post_SBE;
                if isfield(cluster_summary(ii).cluster_results(cc),'edgewidth')
                    recording(p).cluster_results(1).edgewidth = cluster_summary(ii).cluster_results(cc).edgewidth;
                    recording(p).cluster_results(1).edgecolor = cluster_summary(ii).cluster_results(cc).edgecolor
                else
                    recording(p).cluster_results(1).edgewidth = 0;
                    recording(p).cluster_results(1).edgecolor = 0;
                end
                recording(p).cluster_results(1).movie_avg = cluster_summary(ii).cluster_results(cc).movie_avg
            end


        else
            if isempty(recording(p).no_quiet_analysis_possible)
                curr_summary(p).no_run_no_whisk.mean_DF = recording(ii).ca_stats_no_run_no_whisk_deconv.ROI_events(1).mean_DF;
                curr_summary(p).no_run_no_whisk.mean_mean_DF = mean(recording(ii).ca_stats_no_run_no_whisk_deconv.ROI_events(1).mean_DF);
                curr_summary(p).no_run_no_whisk.std_mean_DF = std(recording(ii).ca_stats_no_run_no_whisk_deconv.ROI_events(1).mean_DF,0);
                curr_summary(p).no_run_no_whisk.events_per_sec = recording(ii).ca_stats_no_run_no_whisk_deconv.ROI_events(1).events_per_sec;
                curr_summary(p).no_run_no_whisk.mean_events_per_sec = mean(recording(ii).ca_stats_no_run_no_whisk_deconv.ROI_events(1).events_per_sec);
                curr_summary(p).no_run_no_whisk.std_events_per_sec = std(recording(ii).ca_stats_no_run_no_whisk_deconv.ROI_events(1).events_per_sec,0);
                curr_summary(p).no_run_no_whisk.mean_event_length_ms = recording(ii).ca_stats_no_run_no_whisk_deconv.ROI_events(1).mean_event_length_ms;
                curr_summary(p).no_run_no_whisk.mean_mean_event_length_ms = mean(recording(ii).ca_stats_no_run_no_whisk_deconv.ROI_events(1).mean_event_length_ms);
                curr_summary(p).no_run_no_whisk.std_mean_event_length_ms = std(recording(ii).ca_stats_no_run_no_whisk_deconv.ROI_events(1).mean_event_length_ms,0);
                curr_summary(p).no_run_no_whisk.std_event_length_ms = recording(ii).ca_stats_no_run_no_whisk_deconv.ROI_events(1).std_event_length_ms;
                curr_summary(p).no_run_no_whisk.mean_event_amplitude = recording(ii).ca_stats_no_run_no_whisk_deconv.ROI_events(1).mean_event_amplitude;
                curr_summary(p).no_run_no_whisk.mean_mean_event_amplitude = mean(recording(ii).ca_stats_no_run_no_whisk_deconv.ROI_events(1).mean_event_amplitude);
                curr_summary(p).no_run_no_whisk.std_mean_event_amplitude = std(recording(ii).ca_stats_no_run_no_whisk_deconv.ROI_events(1).mean_event_amplitude,0);
                curr_summary(p).no_run_no_whisk.std_event_amplitude = recording(ii).ca_stats_no_run_no_whisk_deconv.ROI_events(1).std_event_amplitude;
                curr_summary(p).no_run_no_whisk.mean_event_area = recording(ii).ca_stats_no_run_no_whisk_deconv.ROI_events(1).mean_event_area;
                curr_summary(p).no_run_no_whisk.mean_mean_event_area = mean(recording(ii).ca_stats_no_run_no_whisk_deconv.ROI_events(1).mean_event_area);
                curr_summary(p).no_run_no_whisk.std_mean_event_area = std(recording(ii).ca_stats_no_run_no_whisk_deconv.ROI_events(1).mean_event_area,0);
                curr_summary(p).no_run_no_whisk.std_event_area = recording(ii).ca_stats_no_run_no_whisk_deconv.ROI_events(1).std_event_area;

                if sum(size(cluster_summary(ii).cluster_results))>2
                    cc = ii
                else
                    cc=1
                end
                if ~isfield(cluster_summary(ii).cluster_results(cc),'too_short') && ~isfield(cluster_summary(ii).cluster_results(cc),'donotanalze')

                    recording(p).cluster_results(1).sdec_thr = cluster_summary(ii).cluster_results(cc).sdec_thr;
                    recording(p).cluster_results(1).corr_results = cluster_summary(ii).cluster_results(cc).corr_results;
                    if isfield(cluster_summary(ii).cluster_results(cc),'correlation_results_pre_seiz')
                        recording(p).cluster_results(1).correlation_results_pre_seiz = cluster_summary(ii).cluster_results(cc).correlation_results_pre_seiz;
                        recording(p).cluster_results(1).correlation_results_pre_seiz_a = cluster_summary(ii).cluster_results(cc).correlation_results_pre_seiz_a;
                    else
                        recording(p).cluster_results(1).correlation_results_pre_seiz = cluster_summary(ii).cluster_results(cc).correlation_results_post_seiz;
                        recording(p).cluster_results(1).correlation_results_pre_seiz_a = cluster_summary(ii).cluster_results(cc).correlation_results_post_seiz_a;
                    end
                    recording(p).cluster_results(1).correlation_results_post_seiz = cluster_summary(ii).cluster_results(cc).correlation_results_post_seiz;
                    recording(p).cluster_results(1).correlation_results_post_seiz_a = cluster_summary(ii).cluster_results(cc).correlation_results_post_seiz_a;
                    if isfield(cluster_summary(ii).cluster_results(cc),'correlation_results_2_S_dec_pre_post')
                        recording(p).cluster_results(1).correlation_results_2_S_dec_pre_post = cluster_summary(ii).cluster_results(cc).correlation_results_2_S_dec_pre_post;
                    end
                    recording(p).cluster_results(1).clust_results = cluster_summary(ii).cluster_results(cc).clust_results;
                    recording(p).cluster_results(1).num_clusts_pre_SBE = cluster_summary(ii).cluster_results(cc).num_clusts_pre_SBE;
                    recording(p).cluster_results(1).num_clusts_post_SBE = cluster_summary(ii).cluster_results(cc).num_clusts_post_SBE;
                    if isfield(cluster_summary(ii).cluster_results(cc),'edgewidth')
                        recording(p).cluster_results(1).edgewidth = cluster_summary(ii).cluster_results(cc).edgewidth;
                        recording(p).cluster_results(1).edgecolor = cluster_summary(ii).cluster_results(cc).edgecolor
                    else
                        recording(p).cluster_results(1).edgewidth = 0;
                        recording(p).cluster_results(1).edgecolor = 0;
                    end
                    recording(p).cluster_results(1).movie_avg = cluster_summary(ii).cluster_results(cc).movie_avg
                end

            end
        end
    end
end



%redo cluster plots,recheck cluster results
for ii = 1:num_recs %size(subfolders,2) % start_w_rec:start_w_rec+num_recs-1 %
    if ~isfield(recording(ii).cluster_results(ii+barea_rec_start-1),'num_clusts_post_SBE')
        recording(ii).cluster_results(ii+barea_rec_start-1).num_clusts_post_SBE = [];
    else
        if ~isempty(intersect(ii,to_remove)) || isfield(cluster_summary(ii).cluster_results(ii),'too_short') || ...
                isfield(cluster_summary(ii).cluster_results(ii),'donotanalze') || length_spont(1,ii+barea_rec_start-1)<min_length_spont
            recording(ii).cluster_results(1).too_short_f_quiet_culsters = 1;
        else
            if(isempty(recording(ii).cluster_results(ii+barea_rec_start-1).num_clusts_post_SBE)&&...
                    isempty(recording(ii).cluster_results(ii+barea_rec_start-1).num_clusts_pre_SBE))

                recording(ii).cluster_results.no_clusters = 1;
            else
                if ~isempty(intersect(ii,to_remove)) || isempty(recording(ii).cluster_results)
                else
                    clear ROI_clust_mat_sorted_pre_clusterone ROI_clust_mat_sorted_post_clusterone


                    close all
                    Folder = subfolders(ii+barea_rec_start-1).name;
                    cd(Folder_master)
                    cd(Folder)

                    ROI_clust_mat_clusterone = recording(ii).cluster_results(ii+barea_rec_start-1).clust_results.ROI_clust_mat_clusterone;
                    beg_sec_prez(1,ii) = recording(ii).cluster_results(ii+barea_rec_start-1).corr_results.beg_sec_2;
                    end_sec_prez(1,ii) = recording(ii).cluster_results(ii+barea_rec_start-1).corr_results.beg_sec_2 +60; %[60,60 ,60 ,60];
                    beg_sec_pre = beg_sec_prez(1,ii);
                    end_sec_pre = end_sec_prez(1,ii);
                    beg_sec_postz(1,ii) = recording(ii).cluster_results(ii+barea_rec_start-1).corr_results.beg_sec_1; %[1302 ,1140 ,400 ,600];
                    end_sec_postz(1,ii) = recording(ii).cluster_results(ii+barea_rec_start-1).corr_results.beg_sec_1 + 60;
                    beg_sec_post = beg_sec_postz(1,ii);
                    if beg_sec_post==0
                        beg_sec_post=1
                    end
                    end_sec_post = end_sec_postz(1,ii);
                    begfr_pre = round(beg_sec_pre*recording(ii).initial2.samplingratehz);
                    endfr_pre = round(end_sec_pre*recording(ii).initial2.samplingratehz);
                    begfr_post = round(beg_sec_post*recording(ii).initial2.samplingratehz);

                    sdec_bin = recording(ii).cluster_results(ii+barea_rec_start-1).clust_results.sdec_bin;
                    endfr_post = min(size(sdec_bin,2),round(end_sec_post*recording(ii).initial2.samplingratehz));
                    %ROI_clust_mat_sorted_pre_clusterone = recording(ii).cluster_results(ii).clust_results.ROI_clust_mat_sorted_pre_clusterone;
                    %         interp = ms(ii).ernoiv_final;
                    %         endframe=size(interp,2)

                    cs_SBE = recording(ii).cluster_results(ii+barea_rec_start-1).clust_results.cs_SBE ;
                    load('colorpal_neo.mat')
                    colorpal_intz = colorpal_neo;
                    colorpal_int = cat(1,colorpal_intz,colorpal_intz);



                    %%%% plot clustered network as overlay on avg_ch1

                    if isfield(recording(ii),'movie_avg')
                        movie_avg = recording(ii).movie_avg;
                    else
                        if isfield(recording(ii),'initial1')
                            if isfield(recording(ii).initial1,'g')
                                if recording(ii).initial1.g==0
                                    movie_avg = imread('avg_ch2.tif');
                                else
                                    movie_avg = squeeze(mean(recording(ii).initial1.g,3));
                                end
                            else
                                movie_avg = imread('avg_ch2.tif');
                            end
                        else
                            movie_avg = imread('avg_ch2.tif');
                        end
                    end

                    h = size(movie_avg,1);
                    w = size(movie_avg,2);
                    clear oyt_vec p1 p2 c
                    oyt_vec = reshape(movie_avg,h*w,1);
                    p1 = prctile(oyt_vec,0.5)
                    p2 = prctile(oyt_vec,99);

                    if onep
                        RI = recording(ii).onep_results_2.RL;
                    else
                        RI = recording(ii).ROI_list;
                    end

                    if isfield(recording(ii),'Cn')
                        Cn = recording(ii).Cn;
                    else
                        Cn = recording(ii).initial.height;
                    end
                    numrois = size(ROI_clust_mat_clusterone,1)


                    if onep_binned_twice
                        movie_avg = movie_avg(round(recording(ii).crop(1,2)):round(recording(ii).crop(1,2))+round(recording(ii).crop(1,4)),...
                            round(recording(ii).crop(1,1)):round(recording(ii).crop(1,1))+round(recording(ii).crop(1,3)));
                        %add here: downsample movie_avg_for plotting!
                        movie_avg_resized = imresize(movie_avg, 0.5, 'nearest');


                        height = size(movie_avg_resized,1);
                        width = size(movie_avg_resized,2);
                        h = height;
                        w = width;
                    else
                        movie_avg_resized=movie_avg;
                        height = size(movie_avg,1);
                        width = size(movie_avg,2);
                    end

                    %         %crop this image
                    %
                    %           movie_avg_resized = movie_avg_resized(round(recording(iii).crop(1,2)):round(recording(iii).crop(1,2))+round(recording(iii).crop(1,4)),...
                    %             round(recording(iii).crop(1,1)):round(recording(iii).crop(1,1))+round(recording(iii).crop(1,3)));
                    %
                    if ~isfield(recording(ii).cluster_results(ii+barea_rec_start-1),'num_clusts_post_SBE')
                        recording(ii).cluster_results(1).clust_results.no_post_clusts=1
                    else
                        if recording(ii).cluster_results(ii+barea_rec_start-1).num_clusts_post_SBE == 0 %||...
                            % isempty(recording(ii).cluster_results(ii+barea_rec_start-1).num_clusts_post_SBE)
                            recording(ii).cluster_results(1).clust_results.no_post_clusts=1
                        else
                            %post
                            moduleid_post = recording(ii).cluster_results(ii+barea_rec_start-1).clust_results.moduleid_post_clusterone ;
                            moduleid_post(length(ROI_clust_mat_clusterone)+1:length(moduleid_post),:) = [];
                            ROI_clust_mat_clusterone(:,7) = round(cs_SBE*moduleid_post(:,1));
                            endframe = size(ROI_clust_mat_clusterone,1);
                            ROI_clust_mat_sorted_post_clusterone = sortrows(ROI_clust_mat_clusterone,3);
                            recording(ii).cluster_results(1).clust_results.ROI_clust_mat_sorted_post_clusterone_bak = ...
                                recording(ii).cluster_results(ii+barea_rec_start-1).clust_results.ROI_clust_mat_sorted_post_clusterone;
                            recording(ii).cluster_results(1).clust_results.ROI_clust_mat_sorted_post_clusterone = ROI_clust_mat_sorted_post_clusterone;

                            %ROI_clust_mat_sorted_post_clusterone = recording(ii).cluster_results(ii).clust_results.ROI_clust_mat_sorted_post_clusterone;

                            if endfr_post==0
                            else
                                figure(58912)
                                set(gcf,'color','w');
                                for iii = 1:endframe
                                    roinum = ROI_clust_mat_sorted_post_clusterone(iii,1);
                                    if ROI_clust_mat_sorted_post_clusterone(iii,7) == 0
                                        co = [0,0,0];
                                    else
                                        co = colorpal_int(ROI_clust_mat_sorted_post_clusterone(iii,7),:);
                                    end
                                    klo = recording(ii).cluster_results(ii+barea_rec_start-1).corr_results.matrix_post(roinum,:)';  %  sdec_bin(roinum,begfr_post:endfr_post)';

                                    gsu = subaxis (endframe,1,iii,'SpacingVert',0);

                                    plot(klo,'Color',co);
                                    %     gsu.XTick = [];
                                    %     gsu.YTick = [];
                                    ylim([0.3 1])
                                    set(gca,'xtick',[],'ytick',round(100*max(klo))/100)
                                    set(gca,'Yticklabel', num2str(round(100*max(klo))/100))

                                    %subaxis
                                    %set(gca,'visible', off)
                                    %ylabel(num2str(neuron_numbers(i,1)), 'FontName', 'Arial', 'FontSize', 12, 'FontWeight', 'bold');
                                    box off
                                    axis off
                                end
                                saveas(58912,[Folder 'redone_ROI_clust_mat_sorted_post_clusterone' ict_or_int_or_all '.png' ],'png');
                            end


                            if endfr_post==0
                            else
                                figure(9091)
                                ima = imagesc(movie_avg_resized,[p1 p2])
                                recording(ii).movie_avg = movie_avg;
                                colormap(gray)
                                hold on
                                clear c
                                bab=1;
                                for k = 1:size(ROI_clust_mat_clusterone,1)
                                    dx = numrois/ROI_clust_mat_clusterone(k,6);
                                    if ROI_clust_mat_clusterone(k,3) == 0
                                        c(k,:) = [17 17 17]/255;
                                        cell_alpha_mutti = 2.7
                                    else
                                        c(k,:) = colorpal_int(ROI_clust_mat_clusterone(k,3),:);
                                        cell_alpha_mutti =cell_alpha_mult
                                    end
                                    clear curr_pix curr_pix_bin si curr_color ho
                                    curr_pix = RI(k).pixel_list;




                                    if isfield(recording(ii).initial,'height')
                                        rh = recording(ii).initial.height;
                                        if onep_binned_twice
                                            rh = h;
                                        end
                                    else
                                        rh = recording(ii).initial2.linesperframe;
                                    end


                                    if rh==size(Cn,1)
                                        curr_pix_bin = zeros(h,w);
                                    else
                                        curr_pix_bin = zeros(h,w);
                                    end
                                    for j = 1:size(RI(k).pixel_list,1)
                                        curr_pix_bin(RI(k).pixel_list(j,1)) = 1;
                                    end
                                    si = size(curr_pix_bin);
                                    curr_color = cat(3,ones(si)*c(k,1),ones(si)*c(k,2),ones(si)*c(k,3));
                                    ho = imshow(curr_color);
                                    set(ho, 'AlphaData', curr_pix_bin/cell_alpha_mutti)%/dx)
                                    hold on

                                    matrix_post_nonz = recording(ii).cluster_results(ii+barea_rec_start-1).clust_results.matrix_post;

                                    %now add lines between significantly connected ROIs

                                    edgmult = 15;
                                    if onep
                                        edgmult = 2;
                                    end
                                    %transpline = 0.08; %was 0.4
                                    if onep
                                        transpline = 0.03;
                                    end
                                    fount=0;
                                    for l = k+1:size(matrix_post_nonz,2)
                                        if matrix_post_nonz(k,l)>0  && ROI_clust_mat_clusterone(k,3) == ROI_clust_mat_clusterone(l,3)...
                                                && ROI_clust_mat_clusterone(k,3) > 0 && ROI_clust_mat_clusterone(l,3) > 0
                                            %added the last 2 terms of above line 10/10/2020
                                            if matrix_post_nonz(k,l)>0 && (l-1)<length(RI)

                                                edgewidthp = ceil(matrix_post_nonz(k,l)*edgmult);
                                                if onep
                                                    x1 = RI(k).centerPos(1,2);
                                                    y1 = RI(k).centerPos(1,1);
                                                    x2 = RI(l).centerPos(1,2);
                                                    y2 = RI(l).centerPos(1,1);

                                                else
                                                    x1 = RI(k).centerPos(1,2);
                                                    y1 = RI(k).centerPos(1,1);
                                                    x2 = RI(l).centerPos(1,2);
                                                    y2 = RI(l).centerPos(1,1);
                                                end
                                                recording(ii).cluster_results(1).edgewidthp_redone(k,l) = edgewidthp;
                                                recording(ii).cluster_results(1).edgecolorp_redone(k).c = c;
                                                L =  line([x1 x2],[y1 y2],'Color',c(k,:),'LineWidth',edgewidthp);
                                                L.Color(4) = transpline;

                                                xydist = sqrt(abs(x2 - x1)^2 + abs(y2 - y1)^2);
                                                recording(ii).cluster_results(1).moduleIDs_and_pairwise_pix_dists_post(bab,1) = ROI_clust_mat_clusterone(k,2);
                                                recording(ii).cluster_results(1).moduleIDs_and_pairwise_pix_dists_post(bab,2) = xydist;
                                                %recording(ii).cluster_results(ii).moduleIDs_and_pairwise_pix_dists_post(bab,2) = xydist;
                                                bab=bab+1;
                                            end
                                            fount=fount+1;
                                        end

                                    end
                                    if  fount==0
                                        c(k,:) = [17 17 17]/255;
                                        curr_color = cat(3,ones(si)*c(k,1),ones(si)*c(k,2),ones(si)*c(k,3));
                                        ho = imshow(curr_color);
                                        set(ho, 'AlphaData', curr_pix_bin/2.7)%/dx)
                                        hold on
                                    end

                                end
                                saveas(9091,[Folder 'redone_ROIs_clusters_post_SBE' ict_or_int_or_all '.png' ],'png');
                            end
                        end
                    end

                    if recording(ii).cluster_results(1).num_clusts_pre_SBE == 0
                        recording(ii).cluster_results(1).clust_results.no_pre_clusts=1
                    else
                        %pre
                        moduleid_pre = recording(ii).cluster_results(ii+barea_rec_start-1).clust_results.moduleid_pre_clusterone ;
                        ROI_clust_mat_sorted_pre_clusterone = sortrows(ROI_clust_mat_clusterone,2);
                        recording(ii).cluster_results(1).clust_results.ROI_clust_mat_sorted_pre_clusterone_bak = ...
                            recording(ii).cluster_results(ii+barea_rec_start-1).clust_results.ROI_clust_mat_sorted_pre_clusterone;
                        recording(ii).cluster_results(1).clust_results.ROI_clust_mat_sorted_pre_clusterone =  ROI_clust_mat_sorted_pre_clusterone;
                        endframe = size(ROI_clust_mat_clusterone,1);
                        figure(5892)
                        set(gcf,'color','w');
                        for iii = 1:endframe
                            roinum = ROI_clust_mat_sorted_pre_clusterone(iii,1);
                            if ROI_clust_mat_sorted_pre_clusterone(iii,4) == 0
                                co = [0,0,0];
                            else
                                co = colorpal_int(ROI_clust_mat_sorted_pre_clusterone(iii,4),:);
                                if sum(co) == 0
                                    co = [0.3, 0.7, 0.2];
                                end
                            end
                            klo = recording(ii).cluster_results(ii+barea_rec_start-1).corr_results.matrix_pre(roinum,:)'; % sdec_bin(roinum,begfr_pre:endfr_pre)';

                            %BINARIZE klo!

                            gsu = subaxis (endframe,1,iii,'SpacingVert',0);

                            plot(klo,'Color',co);
                            %     gsu.XTick = [];
                            %     gsu.YTick = [];
                            ylim([0.3 1])
                            set(gca,'xtick',[],'ytick',round(100*max(klo))/100)
                            set(gca,'Yticklabel', num2str(round(100*max(klo))/100))

                            %subaxis
                            %set(gca,'visible', off)
                            %ylabel(num2str(neuron_numbers(i,1)), 'FontName', 'Arial', 'FontSize', 12, 'FontWeight', 'bold');
                            box off
                            axis off
                        end
                        saveas(5892,[Folder 'redone_ROI_clust_mat_sorted_pre_clusterone' ict_or_int_or_all '.png' ],'png');


                        %%%%%%%%%%%%%%%%%%%%%%%%%%%


                        figure(909)
                        ima = imagesc(movie_avg_resized,[p1 p2])
                        colormap(gray)
                        hold on
                        clear c
                        %transpline = 0.4;
                        if onep
                            transpline = 0.03;
                            for k = 1:size(ROI_clust_mat_clusterone,1)

                                %convert k into the accepted ROI number first:

                                ksz =  size(recording(ii).onep_results_2.accep_ROI_LH,2)+1;
                                if k<ksz
                                    kk = recording(ii).onep_results_2.accep_ROI_LH(1,k);

                                else

                                    kk = recording(ii).onep_results_2.accep_ROI_RH(1,1+k-ksz);

                                end


                                %c1 = recording(ii).onep_results_2.RL.ROI_info(kk,1);
                                c3 = recording(ii).onep_results_2.RL.ROI_info(kk,3);
                                c4 = recording(ii).onep_results_2.RL.ROI_info(kk,4);

                                midx = floor(c3); %floor((c1+c3)/2);
                                midy = floor(c4);
                                RI(k).centerPos(1,1) = midx;
                                RI(k).centerPos(1,2) = midy;
                                midpix = round((midy-1)*height+midx);
                                curr_pix = [midpix-1:1:midpix+1];
                                RI(k).pixel_list = curr_pix;
                            end
                        end


                        bab=1
                        for k = 1:size(ROI_clust_mat_clusterone,1)
                            dx = numrois/ROI_clust_mat_clusterone(k,5)
                            if ROI_clust_mat_clusterone(k,2) == 0
                                c(k,:) = [17 17 17]/255
                                cell_alpha_mutti =2.7
                            else
                                c(k,:) = colorpal_int(ROI_clust_mat_clusterone(k,2),:)
                                cell_alpha_mutti =cell_alpha_mult
                            end
                            clear curr_pix curr_pix_bin si curr_color ho


                            curr_pix = RI(k).pixel_list;

                            if isfield(recording(ii).initial,'height')
                                rh = recording(ii).initial.height;
                                if onep_binned_twice
                                    rh = h;
                                end
                            else
                                rh = recording(ii).initial2.linesperframe;
                            end

                            if rh==size(Cn,1)
                                curr_pix_bin = zeros(h,w);
                            else
                                curr_pix_bin = zeros(h,w);
                            end

                            for j = 1:size(RI(k).pixel_list,1)
                                prx = RI(k).pixel_list(j,1);
                                curr_pix_bin(RI(k).pixel_list(j,1)) = 1;
                            end
                            si = size(curr_pix_bin);
                            curr_color = cat(3,ones(si)*c(k,1),ones(si)*c(k,2),ones(si)*c(k,3));
                            ho = imshow(curr_color);
                            set(ho, 'AlphaData', curr_pix_bin/cell_alpha_mutti)%/dx)
                            hold on

                            edgmult = 15;
                            if onep
                                edgmult = 2;
                            end
                            matrix_pre_nonz = recording(ii).cluster_results(ii+barea_rec_start-1).clust_results.matrix_pre;
                            %now add lines between significantly connected ROIs
                            if k<size(matrix_pre_nonz,2)

                                %new approach: search for other ROIS with the same
                                %moduleID, then add them to  a vector containing all
                                %moduleID numbers and for the next one ake sure it's not
                                %already in that vector...

                                fount=0
                                for l = k+1:size(matrix_pre_nonz,2)
                                    if matrix_pre_nonz(k,l)>0  && ROI_clust_mat_clusterone(k,2) == ROI_clust_mat_clusterone(l,2)...
                                            && ROI_clust_mat_clusterone(k,2) > 0 && ROI_clust_mat_clusterone(l,2) > 0
                                        %added the last 2 terms of above line 10/10/2020
                                        if matrix_pre_nonz(k,l)>0 && (l-1)<length(RI)

                                            edgewidthy = ceil(matrix_pre_nonz(k,l)*edgmult);
                                            if onep
                                                x1 = RI(k).centerPos(1,2);
                                                y1 = RI(k).centerPos(1,1);
                                                x2 = RI(l).centerPos(1,2);
                                                y2 = RI(l).centerPos(1,1);

                                            else
                                                x1 = RI(k).centerPos(1,2);
                                                y1 = RI(k).centerPos(1,1);
                                                x2 = RI(l).centerPos(1,2);
                                                y2 = RI(l).centerPos(1,1);
                                            end
                                            recording(ii).cluster_results(1).edgewidth_redone(k,l) = edgewidthy;
                                            recording(ii).cluster_results(1).edgecolor_redone(k).c = c;
                                            L =  line([x1 x2],[y1 y2],'Color',c(k,:),'LineWidth',edgewidthy);
                                            L.Color(4) = transpline;

                                            xydist = sqrt(abs(x2 - x1)^2 + abs(y2 - y1)^2)
                                            recording(ii).cluster_results(1).moduleIDs_and_pairwise_pix_dists_pre(bab,1) = ROI_clust_mat_clusterone(k,2);
                                            recording(ii).cluster_results(1).moduleIDs_and_pairwise_pix_dists_pre(bab,2) = xydist;
                                            bab=bab+1;
                                        end
                                    end
                                    fount=fount+1
                                end
                                if fount==0

                                    c(k,:) = [17 17 17]/255
                                    curr_color = cat(3,ones(si)*c(k,1),ones(si)*c(k,2),ones(si)*c(k,3));
                                    ho = imshow(curr_color);
                                    set(ho, 'AlphaData', curr_pix_bin/2.7)%/dx)
                                    hold on
                                end

                            end
                        end
                        saveas(909,[Folder 'redone_ROIs_clusters_pre_SBE' ict_or_int_or_all '.png' ],'png');
                    end
                end
            end
        end
    end
end

%
% for iii = 1:size(subfolders,2)
%     cluster_summary(iii).cluster_results = recording(iii).cluster_results;
% end

clear area

for ii = 1:num_recs %size(cluster_summary,2)
    if  isempty(recording(ii).cluster_results)||~isempty(intersect(ii,to_remove))
    else
        %%%%%%%%%%%%% ADD: 1) average cluster span (avg distance between
        %%%%%%%%%%%%% nodes), 2) average number of nodes per cluster, 3)
        %%%%%%%%%%%%% average cluster strength, 4)samesies for post
        if length_spont(1,ii+barea_rec_start-1)>min_length_spont-1
            curr_summary(ii).cluster_summary = cluster_summary;
            if onep
                RI = recording(ii).onep_results_2.RL;
            else
                RI = recording(ii).ROI_list;
            end
            if isfield(recording(ii).cluster_results(1),'clust_results')
                ROI_clust_mat_sorted_pre_clusterone = recording(ii).cluster_results(ii).clust_results(1).ROI_clust_mat_sorted_pre_clusterone;
                a=1
                clear modules_pre
                if recording(ii).cluster_results(ii+barea_rec_start-1).num_clusts_pre_SBE>0

                    for m = 1: recording(ii).cluster_results(ii+barea_rec_start-1).num_clusts_pre_SBE

                        clear curr_module edgewidths

                        while ROI_clust_mat_sorted_pre_clusterone(a,2)==0
                            a=a+1;
                        end

                        if ROI_clust_mat_sorted_pre_clusterone(a,2)==m

                            b=0
                            curr_module(1,1:2) = ROI_clust_mat_sorted_pre_clusterone(a,1:2);
                            stop_now=0
                            if a+b+1<size(ROI_clust_mat_sorted_pre_clusterone,1)
                                while ROI_clust_mat_sorted_pre_clusterone(a+b+1,2)==ROI_clust_mat_sorted_pre_clusterone(a+b,2) && stop_now==0
                                    b=b+1
                                    if a+b+2>size(ROI_clust_mat_sorted_pre_clusterone,1)
                                        stop_now=1
                                    else

                                    end
                                end
                            end
                            if b>0
                                curr_module(2:b+1,1:2) = ROI_clust_mat_sorted_pre_clusterone(a+1:a+b,1:2)
                                pu=1
                                edgewidths=0
                                for p = 1: size(curr_module,1)
                                    curr_module(p,3) = RI(curr_module(p,1)).centerPos(1,1)             %x coor
                                    curr_module(p,4) = RI(curr_module(p,1)).centerPos(1,2)               %y coor
                                    if isfield(recording(ii).cluster_results(1),'edgewidth_redone')
                                        if curr_module(p,1)>size(recording(ii).cluster_results(1).edgewidth_redone,2)
                                        else
                                            ews = nonzeros(recording(ii).cluster_results(1).edgewidth_redone(:,curr_module(p,1)))
                                            %w = size(ews,2)
                                            edgewidths(pu:pu+length(ews)-1,1) = ews;
                                            pu=pu+length(ews);
                                        end
                                    end
                                end

                                xs = curr_module(:,3)'
                                ys = curr_module(:,4)'

                                pgon = polyshape(xs,ys)
                                %plot(pgon)
                                are = area(pgon)

                                modules_pre(m).pgon = pgon;
                                modules_pre(m).area = are;
                                modules_pre(m).num_nodes = size(curr_module,1);
                                modules_pre(m).edgewidths = edgewidths;
                                modules_pre(m).module = curr_module;
                            else
                                modules_pre(m).singular_module=1
                            end
                            a=a+b+1
                        end
                    end

                else
                    modules_pre=[];
                end

                %compute overlaps:
                totarea=0;
                totoverlap=0;
                if size(modules_pre,2)>1
                    for po1 = 1:size(modules_pre,2)-1
                        if ~isempty(modules_pre(po1).pgon)
                            if modules_pre(po1).area>0
                                poly1 = modules_pre(po1).pgon;
                                totarea = totarea+modules_pre(po1).area
                                for po2 = po1+1:size(modules_pre,2)
                                    if ~isempty(modules_pre(po2).pgon)
                                        if modules_pre(po2).area>0
                                            poly2 = modules_pre(po2).pgon;
                                            polyout = intersect(poly1,poly2)
                                            areov = area(polyout);

                                            %how mmuch overlap? divide sum of overlaps by total area.

                                            totoverlap = totoverlap+areov;
                                        end
                                    end
                                end
                            end
                        end
                    end
                end
                if totarea==0
                    overlap_index=0;
                else
                    overlap_index = totoverlap/totarea;
                end
                curr_summary(ii).cluster_summary(1).cluster_results(ii).overlap_index_pre = overlap_index;
                curr_summary(ii).cluster_summary(1).cluster_results(ii).modules_pre = modules_pre;
                cluster_summary(1).cluster_results(ii).overlap_index_pre = overlap_index;
                cluster_summary(1).cluster_results(ii).modules_pre = modules_pre;
                curr_summary(1).all_overlap_indices_pre(1,ii) = overlap_index;
                % end


                %here get avg num nodes per cluster in the FOV,
                %avg area of clusters, ...
                %num_clusts norm by FOVsize? ,
                %# of nodes per area to get the density of nodes., and then get the average density.

                gfa = cluster_summary(1).cluster_results;
                gfab = cluster_summary(ii).cluster_results;
                curr_summary(ii).cluster_summary(1).cluster_results(ii).num_clusts_norm_by_FOV_squm_pre = ...
                    recording(ii).cluster_results(ii+barea_rec_start-1).num_clusts_pre_SBE/curr_summary(ii).fov_umsq;
                %curr_summary(ii).cluster_summary(1).cluster_results(ii).num_clusts_norm_by_FOV_squm_pre;
                a=1;
                totnod=0;
                totarea=0;
                totdens = 0;
                for fre = 1:size(cluster_summary(1).cluster_results(ii).modules_pre,2)
                    if cluster_summary(1).cluster_results(ii).modules_pre(fre).num_nodes>2
                        totnod=totnod+cluster_summary(1).cluster_results(ii).modules_pre(fre).num_nodes;
                        totarea = totarea + cluster_summary(1).cluster_results(ii).modules_pre(fre).area;

                        curr_summary(ii).cluster_summary(1).cluster_results(ii).modules_pre(fre).dens = ...
                            cluster_summary(1).cluster_results(ii).modules_pre(fre).num_nodes/cluster_summary(1).cluster_results(ii).modules_pre(fre).area;
                        totdens = totdens + cluster_summary(1).cluster_results(ii).modules_pre(fre).num_nodes/cluster_summary(1).cluster_results(ii).modules_pre(fre).area;

                        a=a+1;
                    end
                end
                if a>1
                    curr_summary(ii).cluster_summary(1).cluster_results(ii).avg_nodes_per_module_pre = totnod/(a-1);
                    curr_summary(ii).cluster_summary(1).cluster_results(ii).avg_area_per_module_pre = totarea/(a-1);
                    curr_summary(ii).cluster_summary(1).cluster_results(ii).avg_dens_per_module_pre = totdens/(a-1);
                else
                    curr_summary(ii).cluster_summary(1).cluster_results(ii).avg_nodes_per_module_pre = [];
                    curr_summary(ii).cluster_summary(1).cluster_results(ii).avg_area_per_module_pre = [];
                    curr_summary(ii).cluster_summary(1).cluster_results(ii).avg_dens_per_module_pre = [];
                end

                ROI_clust_mat_sorted_post_clusterone = recording(ii).cluster_results(ii).clust_results(1).ROI_clust_mat_sorted_post_clusterone;
                a=1
                clear modules_post
                if isfield (recording(ii).cluster_results(ii+barea_rec_start-1),'num_clusts_post_SBE')
                    if ~isempty(recording(ii).cluster_results(ii+barea_rec_start-1).num_clusts_post_SBE)
                        if recording(ii).cluster_results(ii+barea_rec_start-1).num_clusts_post_SBE>0
                            for m = 1: recording(ii).cluster_results(ii+barea_rec_start-1).num_clusts_post_SBE
                                clear curr_module edgewidths
                                while ROI_clust_mat_sorted_post_clusterone(a,3)==0
                                    a=a+1;
                                end
                                if ROI_clust_mat_sorted_post_clusterone(a,3)==m
                                    b=0
                                    curr_module(1,1) = ROI_clust_mat_sorted_post_clusterone(a,1);
                                    curr_module(1,2) = ROI_clust_mat_sorted_post_clusterone(a,3);
                                    stop_now=0
                                    if a+b+1<size(ROI_clust_mat_sorted_post_clusterone,1)
                                        while ROI_clust_mat_sorted_post_clusterone(a+b+1,3)==ROI_clust_mat_sorted_post_clusterone(a+b,3) && stop_now==0
                                            b=b+1
                                            if a+b+2>size(ROI_clust_mat_sorted_post_clusterone,1)
                                                stop_now=1
                                            else
                                            end
                                        end
                                    end
                                    if b>0 %was 0 , JM 20221129
                                        curr_module(2:b+1,1) = ROI_clust_mat_sorted_post_clusterone(a+1:a+b,1)
                                        curr_module(2:b+1,2) = ROI_clust_mat_sorted_post_clusterone(a+1:a+b,3)
                                        pu=1
                                        edgewidths=0
                                        for p = 1: size(curr_module,1)
                                            curr_module(p,3) = RI(curr_module(p,1)).centerPos(1,1)             %x coor
                                            curr_module(p,4) = RI(curr_module(p,1)).centerPos(1,2)               %y coor
                                            if isfield(recording(ii).cluster_results(1),'edgewidthp_redone')
                                                if curr_module(p,1)>size(recording(ii).cluster_results(1).edgewidthp_redone,2)
                                                else
                                                    ews = nonzeros(recording(ii).cluster_results(1).edgewidthp_redone(:,curr_module(p,1)))
                                                    %w = size(ews,2)
                                                    edgewidths(pu:pu+length(ews)-1,1) = ews;
                                                    pu=pu+length(ews);
                                                end
                                            end
                                        end

                                        xs = curr_module(:,3)'
                                        ys = curr_module(:,4)'

                                        pgon = polyshape(xs,ys)
                                        %plot(pgon)
                                        are = area(pgon)

                                        modules_post(m).pgon = pgon;
                                        modules_post(m).area = are;
                                        modules_post(m).num_nodes = size(curr_module,1);
                                        modules_post(m).edgewidths = edgewidths;
                                        modules_post(m).module = curr_module;
                                    else
                                        modules_post(m).singular_module=1
                                    end
                                    a=a+b+1
                                end
                            end

                        else
                            modules_post=[];

                        end
                    else
                        modules_post=[];
                    end
                    %compute overlaps:
                    if ~isempty(modules_post)
                        totarea=0;
                        totoverlap=0;
                        if size(modules_post,2)>1
                            for po1 = 1:size(modules_post,2)-1
                                if ~isempty(modules_post(po1).pgon)
                                    if modules_post(po1).area>0
                                        poly1 = modules_post(po1).pgon;
                                        totarea = totarea+modules_post(po1).area
                                        for po2 = po1+1:size(modules_post,2)
                                            if ~isempty(modules_post(po2).pgon)
                                                if modules_post(po2).area>0
                                                    poly2 = modules_post(po2).pgon;
                                                    polyout = intersect(poly1,poly2)
                                                    areov = area(polyout);

                                                    %how mmuch overlap? divide sum of overlaps by total area.

                                                    totoverlap = totoverlap+areov;
                                                end
                                            end
                                        end
                                    end
                                end
                            end
                        end
                        if totarea==0
                            overlap_index=0;
                        else
                            overlap_index = totoverlap/totarea;
                        end
                        curr_summary(ii).cluster_summary(1).cluster_results(ii).overlap_index_post = overlap_index;
                        curr_summary(ii).cluster_summary(1).cluster_results(ii).modules_post = modules_post;
                        cluster_summary(1).cluster_results(ii).overlap_index_post = overlap_index;
                        cluster_summary(1).cluster_results(ii).modules_post = modules_post;

                        %curr_summary(ii).cluster_summary = cluster_summary;
                        curr_summary(1).all_overlap_indices_post(1,ii) = overlap_index;
                        % end


                        %here get avg num nodes per cluster in the FOV,
                        %avg area of clusters, ...
                        %num_clusts norm by FOVsize? ,
                        %# of nodes per area to get the density of nodes., and then get the average density.

                        gfa = curr_summary(ii).cluster_summary(1).cluster_results;
                        gfab = curr_summary(ii).cluster_summary(ii).cluster_results;
                        curr_summary(ii).cluster_summary(1).cluster_results(ii).num_clusts_norm_by_FOV_squm_post = ...
                            curr_summary(ii).cluster_summary(ii).cluster_results(ii+barea_rec_start-1).num_clusts_post_SBE...
                            /curr_summary(ii).fov_umsq;

                        a=1;
                        totnod=0;
                        totarea=0;
                        totdens = 0;
                        for fre = 1:size(cluster_summary(1).cluster_results(ii).modules_post,2)
                            if cluster_summary(1).cluster_results(ii).modules_post(fre).num_nodes>2
                                totnod=totnod+cluster_summary(1).cluster_results(ii).modules_post(fre).num_nodes;
                                totarea = totarea + cluster_summary(1).cluster_results(ii).modules_post(fre).area;

                                curr_summary(ii).cluster_summary(1).cluster_results(ii).modules_post(fre).dens = ...
                                    cluster_summary(1).cluster_results(ii).modules_post(fre).num_nodes/cluster_summary(1).cluster_results(ii).modules_post(fre).area;
                                totdens = totdens + cluster_summary(1).cluster_results(ii).modules_post(fre).num_nodes/cluster_summary(1).cluster_results(ii).modules_post(fre).area;

                                a=a+1;
                            end
                        end
                        if a>1
                            curr_summary(ii).cluster_summary(1).cluster_results(ii).avg_nodes_per_module_post = totnod/(a-1);
                            curr_summary(ii).cluster_summary(1).cluster_results(ii).avg_area_per_module_post = totarea/(a-1);
                            curr_summary(ii).cluster_summary(1).cluster_results(ii).avg_dens_per_module_post = totdens/(a-1);
                        else
                            curr_summary(ii).cluster_summary(1).cluster_results(ii).avg_nodes_per_module_post = [];
                            curr_summary(ii).cluster_summary(1).cluster_results(ii).avg_area_per_module_post = [];
                            curr_summary(ii).cluster_summary(1).cluster_results(ii).avg_dens_per_module_post = [];
                        end

                    end



                    %delete some large matrices we don't need to save
                    for erp=1:size(curr_summary(ii).cluster_summary,2)
                        curr_summary(ii).cluster_summary(erp).cluster_results(erp).sdec_thr = [];
                        curr_summary(ii).cluster_summary(erp).cluster_results(erp).corr_results.matrix_pre = [];
                        curr_summary(ii).cluster_summary(erp).cluster_results(erp).corr_results.matrix_post = [];
                        curr_summary(ii).cluster_summary(erp).cluster_results(erp).correlation_results_pre_seiz.invraster2cat_binned_matrix = [];
                        curr_summary(ii).cluster_summary(erp).cluster_results(erp).correlation_results_pre_seiz.invraster2cat_binned2 = [];
                        curr_summary(ii).cluster_summary(erp).cluster_results(erp).correlation_results_post_seiz.invraster2cat_binned_matrix = [];
                        curr_summary(ii).cluster_summary(erp).cluster_results(erp).correlation_results_post_seiz.invraster2cat_binned2 = [];
                        curr_summary(ii).cluster_summary(erp).cluster_results(erp).clust_results.sdec_bin = [];
                    end

                    curr_summary(ii).overlap_index_pre = curr_summary(ii).cluster_summary(1).cluster_results(ii).overlap_index_pre;
                    curr_summary(ii).num_clusts_norm_by_FOV_squm_pre = curr_summary(ii).cluster_summary(1).cluster_results(ii).num_clusts_norm_by_FOV_squm_pre;
                    curr_summary(ii).avg_nodes_per_module_pre = curr_summary(ii).cluster_summary(1).cluster_results(ii).avg_nodes_per_module_pre;
                    curr_summary(ii).avg_area_per_module_pre = curr_summary(ii).cluster_summary(1).cluster_results(ii).avg_area_per_module_pre;
                    curr_summary(ii).avg_dens_per_module_pre = curr_summary(ii).cluster_summary(1).cluster_results(ii).avg_dens_per_module_pre;
                    if isfield(curr_summary(ii).cluster_summary(1).cluster_results(ii),'num_clusts_norm_by_FOV_squm_post')
                        curr_summary(ii).overlap_index_post = curr_summary(ii).cluster_summary(1).cluster_results(ii).overlap_index_post;
                        curr_summary(ii).num_clusts_norm_by_FOV_squm_post = curr_summary(ii).cluster_summary(1).cluster_results(ii).num_clusts_norm_by_FOV_squm_post;
                        curr_summary(ii).avg_nodes_per_module_post = curr_summary(ii).cluster_summary(1).cluster_results(ii).avg_nodes_per_module_post;
                        curr_summary(ii).avg_area_per_module_post = curr_summary(ii).cluster_summary(1).cluster_results(ii).avg_area_per_module_post;
                        curr_summary(ii).avg_dens_per_module_post = curr_summary(ii).cluster_summary(1).cluster_results(ii).avg_dens_per_module_post;
                    end
                end
            end
        end

    end

    if ~isempty(intersect(ii,to_remove))|| EEG_segs_not_run_yet
    else
        %check and rerun(?) Ca_EEG_stats and integrate
        clear notathing artifactual SWD seizuree intspike other
        numsegs = size(EEG_segs(ii).segs,2)
        for pe=1:numsegs
            notathing(1,pe)=EEG_segs(ii).segs(pe).nothing;
            artifactual(1,pe) = EEG_segs(ii).segs(pe).artifact;
            SWD(1,pe)=EEG_segs(ii).segs(pe).SW;
            seizuree(1,pe) = EEG_segs(ii).segs(pe).seizure;
            intspike(1,pe) = EEG_segs(ii).segs(pe).poss_int_spike;
            other(1,pe) = EEG_segs(ii).segs(pe).other;
        end
        tot_dur_min = length(All_EEGs(ii).EEG_extrap_1000)/60000;
        curr_summary(ii).tot_dur_min = tot_dur_min;
        curr_summary(ii).EEG_segs.nothing_per_min = sum(notathing)/tot_dur_min
        curr_summary(ii).EEG_segs.artifacts_per_min = sum(artifactual)/tot_dur_min
        curr_summary(ii).EEG_segs.SW_per_min = sum(SWD)/tot_dur_min
        curr_summary(ii).EEG_segs.seizures_per_min = sum(seizuree)/tot_dur_min
        curr_summary(ii).EEG_segs.int_spikes_per_min = sum(intspike)/tot_dur_min
        curr_summary(ii).EEG_segs.others_per_min = sum(other)/tot_dur_min

        curr_summary(ii).ict_high_perc_others = Ca_EEG_stats(1).ictal_high_perc_others_over_time(1,ii+barea_rec_start-1);
        curr_summary(ii).ict_low_perc_others = Ca_EEG_stats(1).ictal_low_perc_others_over_time(1,ii+barea_rec_start-1);

        curr_summary(ii).ict_high_perc_seizures = Ca_EEG_stats(1).ictal_high_perc_seizures_over_time(1,ii+barea_rec_start-1);

        curr_summary(ii).ict_low_perc_seizures = Ca_EEG_stats(1).ictal_low_perc_seizures_over_time(1,ii+barea_rec_start-1);

        curr_summary(ii).ict_high_perc_SWs = Ca_EEG_stats(1).ictal_high_perc_SWs_over_time(1,ii+barea_rec_start-1);

        curr_summary(ii).ict_low_perc_SWs = Ca_EEG_stats(1).ictal_low_perc_SWs_over_time(1,ii+barea_rec_start-1);

        curr_summary(ii).ict_high_perc_int_spikes = Ca_EEG_stats(1).ictal_high_perc_poss_int_spikes_over_time(1,ii+barea_rec_start-1);

        curr_summary(ii).ict_low_perc_int_spikes = Ca_EEG_stats(1).ictal_low_perc_poss_int_spikes_over_time(1,ii+barea_rec_start-1);

        curr_summary(ii).microseiz = ms(ii).microseiz;
    end
end


if to_remove==0
else
    ms(to_remove) = [];
end




curr_summary_bak = curr_summary;

%remove artifactual recordings here...
if to_remove>0
    curr_summary(to_remove) = [];
end

cd(Folder_master)
%if multiple bareas
Folder = subfolders(ii+barea_rec_start-1).name;
cd(Folder_master)
cd(Folder)

save curr_summary.mat curr_summary -v7.3


%if adding new time point to already existing substructures in tumor_animal
%from teh same brain area...

L23fovnum = 1

ms2 = ms;
cs2=curr_summary_bak;

ms1 = tumor_animal(animal_ID).L23(L23fovnum).microseiz_summary;
cs1 = tumor_animal(animal_ID).L23(L23fovnum).all_summary;

clear mscomb cscomb mscomb2helper mscomb1helper

%if necessary
ms1.vis_inds=[];
ms1.seize_inds=[];
mscomb2helper = ms2;
mscomb2helper(2) = ms2;
mscomb1helper = ms1;
mscomb1helper(2) = ms1;

mscomb = mscomb2helper;

mscomb=ms1;
mscomb(2)=ms2;


%if necessary
cscomb2helper = cs2;
cscomb2helper(2) = cs2;
cscomb1helper = cs1;
cscomb1helper(2) = cs1;
cscomb = cscomb1helper;

cscomb=cs1;
cscomb(2)=cs2;

ms=mscomb;
curr_summary=cscomb;






%now compute the remaining summary values here, especiallythe ones that
%need to be normalized by baseline!

%Attention: this is really only valid if i only scanned one brain area
if multiple_recs_in_one_day_present
    consolidate_all_except_ms_for_one_animal_for_tumor

    %this is only for microseizure analysis! for all animals at the end
    consolidate_ms_tumor;
end



if size(barea,2) == 1
    if isempty(tumor_animal(animal_ID).barea) && barea==1
        if L23
            L23fovnum=1
        else
            L4fovnum=1
        end
    else
        if L23
            L23fovnum = size(tumor_animal(animal_ID).L23,2)+1
        else
            L4fovnum = size(tumor_animal(animal_ID).L4,2)+1
        end
    end

    %or put in manually:
    L23fovnum = 4

    if L23==1
        tumor_animal_single(animal_ID).L23(L23fovnum).microseiz_summary = ms;
        tumor_animal_single(animal_ID).L23(L23fovnum).Cr86 = Cr86;
        tumor_animal_single(animal_ID).L23(L23fovnum).GPC6 = GPC6;
        tumor_animal_single(animal_ID).L23(L23fovnum).IGSF3 = IGSF3;
        tumor_animal_single(animal_ID).L23(L23fovnum).xCT_KO = xCT_KO;
        tumor_animal_single(animal_ID).L23(L23fovnum).control = control;
        tumor_animal_single(animal_ID).L23(L23fovnum).brainarea = brainarea';
        tumor_animal_single(animal_ID).L23(L23fovnum).all_summary = curr_summary;

        save tumor_animal_single.mat tumor_animal_single -v7.3

    else
        tumor_animal(animal_ID).L4(L4fovnum).microseiz_summary = ms;
        tumor_animal(animal_ID).L4(L4fovnum).Cr86 = Cr86;
        tumor_animal(animal_ID).L4(L4fovnum).GPC6 = GPC6;
        tumor_animal(animal_ID).L4(L4fovnum).IGSF3 = IGSF3;
        tumor_animal(animal_ID).L4(L4fovnum).xCT_KO = xCT_KO;
        tumor_animal(animal_ID).L4(L4fovnum).control = control;
        tumor_animal(animal_ID).L4(L4fovnum).brainarea = brainarea;
        tumor_animal(animal_ID).L4(L4fovnum).all_summary = curr_summary;
    end
else

    for k = 1:size(barea,2)
        if L23
            L23fovnum=barea(1,k);
        else
            L4fovnum=barea(1,k);
        end

        if L23==1

            tumor_animal(animal_ID).L23(L23fovnum).init=1;

            if isfield(tumor_animal(animal_ID).L23(L23fovnum),'microseiz_summary')
                if ~isempty(tumor_animal(animal_ID).L23(L23fovnum).microseiz_summary)
                    xx = size(tumor_animal(animal_ID).L23(L23fovnum),2) + 1;
                end
            else
                xx=1;
            end
            tumor_animal(animal_ID).L23(L23fovnum).microseiz_summary(xx) = ms(k);
            tumor_animal(animal_ID).L23(L23fovnum).Cr86(xx) = Cr86;
            tumor_animal(animal_ID).L23(L23fovnum).GPC6(xx) = GPC6;
            tumor_animal(animal_ID).L23(L23fovnum).IGSF3(xx) = IGSF3;
            tumor_animal(animal_ID).L23(L23fovnum).xCT_KO(xx) = xCT_KO;
            tumor_animal(animal_ID).L23(L23fovnum).control(xx) = control;
            tumor_animal(animal_ID).L23(L23fovnum).brainarea(xx) = brainarea(1,k)'; %= brainarea{1,k}';
            tumor_animal(animal_ID).barea.L23(L23fovnum).all_summary{xx} = curr_summary(k);
            tumor_animal(animal_ID).barea.L23(L23fovnum).consolidated{xx} = consolidated;
            tumor_animal(animal_ID).barea.L23(L23fovnum).preconsolidated{xx} = fc;

        else

            tumor_animal(animal_ID).L4(L4fovnum).init=1;
            if isfield(tumor_animal(animal_ID).L4(L4fovnum),'microseiz_summary')
                if ~isempty(tumor_animal(animal_ID).L4(L4fovnum).microseiz_summary)
                    xx = size(tumor_animal(animal_ID).L4(L4fovnum),2) + 1;
                end
            else
                xx=1;
            end
            tumor_animal(animal_ID).L4(L4fovnum).microseiz_summary(xx) = ms(k);
            tumor_animal(animal_ID).L4(L4fovnum).Cr86(xx) = Cr86;
            tumor_animal(animal_ID).L4(L4fovnum).GPC6(xx) = GPC6;
            tumor_animal(animal_ID).L4(L4fovnum).IGSF3(xx) = IGSF3;
            tumor_animal(animal_ID).L4(L4fovnum).xCT_KO(xx) = xCT_KO;
            tumor_animal(animal_ID).L4(L4fovnum).control(xx) = control;
            tumor_animal(animal_ID).L4(L4fovnum).brainarea{xx} = brainarea{1,k}';
            tumor_animal(animal_ID).barea.L4(L4fovnum).all_summary(xx) = curr_summary(k);
            tumor_animal(animal_ID).barea.L4(L4fovnum).consolidated(xx) = consolidated;
            tumor_animal(animal_ID).barea.L4(L4fovnum).preconsolidated(xx) = fc;

        end
    end
end


