%%if re-running
load tumor_animal_ta5_only.mat 
%%%%


%%%%%run this for each animal individually after all pre-processing is
%%%%%complete
animal_ID = xxxxxx
Folder = '....\'

cd(Folder)

load('recording_ta3_new.mat')
load ('ta2_analysis.mat')

clear ta5
for u = 1:size(ta2_analysis.by_rec,2)
    if ~isnan(recording_ta3.FOV_stats.tafov_apm_all(1,u))
        ta5(u).day_P = recording_ta3.day_P_vs_tum_siz_squm_nonans(u,1);
        ta5(u).growthrate = recording_ta3.day_P_vs_tum_siz_squm_nonans(u,3);
        ta5(u).apm_near_vs_far_means_ratio= [];
        dva = ta2_analysis.by_rec(u).ta2.quiet.dist_vs_act;
        ta5(u).quiet_dist_vs_act = dva;
        ta5(u).apm_near = 0;
        ta5(u).eps_near = 0;
        ta5(u).dur_near = 0;
        ta5(u).amp_near = 0;
        ta5(u).are_near = 0;
        ta5(u).rhy_near = 0;
        ta5(u).apm_far = 0;
        ta5(u).eps_far = 0;
        ta5(u).dur_far = 0;
        ta5(u).amp_far = 0;
        ta5(u).are_far = 0;
        ta5(u).rhy_far = 0;
        a=1
        b=1
        for v = 1:size(dva,1)
            ta5(u).apm_v_all_dists_incl_zeropixs(v,1) = dva(v,4);
            ta5(u).apm_v_all_dists_incl_zeropixs(v,2) = dva(v,11);
            ta5(u).eps_v_all_dists_incl_zeropixs(v,1) = dva(v,6);
            ta5(u).eps_v_all_dists_incl_zeropixs(v,2) = dva(v,11);
            ta5(u).dur_v_all_dists_incl_zeropixs(v,1) = dva(v,7);
            ta5(u).dur_v_all_dists_incl_zeropixs(v,2) = dva(v,11);
            ta5(u).amp_v_all_dists_incl_zeropixs(v,1) = dva(v,9);
            ta5(u).amp_v_all_dists_incl_zeropixs(v,2) = dva(v,11);
            ta5(u).are_v_all_dists_incl_zeropixs(v,1) = dva(v,10);
            ta5(u).are_v_all_dists_incl_zeropixs(v,2) = dva(v,11);
            ta5(u).rhy_v_all_dists_incl_zeropixs(v,1) = dva(v,12);
            ta5(u).rhy_v_all_dists_incl_zeropixs(v,2) = dva(v,11);
            if dva(v,11)==1 || dva(v,11)==2
                ta5(u).apm_near(a,1) = dva(v,4);
                ta5(u).eps_near(a,1) = dva(v,6);
                ta5(u).dur_near(a,1) = dva(v,7);
                ta5(u).amp_near(a,1) = dva(v,9);
                ta5(u).are_near(a,1) = dva(v,10);
                ta5(u).rhy_near(a,1) = dva(v,12);
                a=a+1;
            else
                if dva(v,11)==7 || dva(v,11)==8
                    ta5(u).apm_far(b,1) = dva(v,4);
                    ta5(u).eps_far(b,1) = dva(v,6);
                    ta5(u).dur_far(b,1) = dva(v,7);
                    ta5(u).amp_far(b,1) = dva(v,9);
                    ta5(u).are_far(b,1) = dva(v,10);
                    ta5(u).rhy_far(b,1) = dva(v,12);
                    b=b+1;
                end
            end
        end
        ta5(u).apm_near(ta5(u).apm_near==0) = [];
        ta5(u).eps_near(ta5(u).eps_near==0) = [];
        ta5(u).dur_near(ta5(u).dur_near==0) = [];
        ta5(u).amp_near(ta5(u).amp_near==0) = [];
        ta5(u).are_near(ta5(u).are_near==0) = [];
        ta5(u).rhy_near(ta5(u).rhy_near==0) = [];
        ta5(u).apm_far(ta5(u).apm_far==0) = [];
        ta5(u).eps_far(ta5(u).eps_far==0) = [];
        ta5(u).dur_far(ta5(u).dur_far==0) = [];
        ta5(u).amp_far(ta5(u).amp_far==0) = [];
        ta5(u).are_far(ta5(u).are_far==0) = [];
        ta5(u).rhy_far(ta5(u).rhy_far==0) = [];
        if ~isempty(ta5(u).apm_far)
            ta5(u).apm_near_far(:,1) = ta5(u).apm_near;
            ta5(u).apm_near_far(1:size(ta5(u).apm_far,1),2) = ta5(u).apm_far;
            ta5(u).apm_near_far(ta5(u).apm_near_far==0) = NaN;
            close all
            [p1,t1,stats1] = kruskalwallis(ta5(u).apm_near_far);
            saveas(2,['boxplot_kruskalwallis_apm_near_far_rec_' num2str(u) '.svg'], 'svg');
            saveas(2,['boxplot_kruskalwallis_apm_near_far_rec_' num2str(u) '.pdf'], 'pdf');
            [comparison,means,H,gnames1] = multcompare(stats1);
            ta5(u).apm_near_far_stats.anova_p = p1;
            ta5(u).apm_near_far_stats.anova_tab = t1;
            ta5(u).apm_near_far_stats.mult_comparison = comparison;
            ta5(u).apm_near_far_stats.mult_means = means;
            ta5(u).apm_near_far_stats.stats1 = stats1;
            saveas(H,['multcomp_kruskalwallis_apm_near_far_rec_' num2str(u) '.png'], 'png')
            saveas(H,['multcomp_kruskalwallis_apm_near_far_rec_' num2str(u) '.pdf'], 'pdf')
            if ta5(u).apm_near_far_stats.mult_comparison(1,6)<0.05
                ta5(u).apm_near_far_stats.significant=1;
                ta5(u).apm_near_vs_far_means_ratio = mean(ta5(u).apm_near)/mean(ta5(u).apm_far)
            else
                ta5(u).apm_near_far_stats.significant=0;
                ta5(u).apm_near_vs_far_means_ratio = 0;
            end
        end
        if ~isempty(ta5(u).eps_far)
            ta5(u).eps_near_far(:,1) = ta5(u).eps_near;
            ta5(u).eps_near_far(1:size(ta5(u).eps_far,1),2) = ta5(u).eps_far;
            ta5(u).eps_near_far(ta5(u).eps_near_far==0) = NaN;
            close all
            [p1,t1,stats1] = kruskalwallis(ta5(u).eps_near_far);
            saveas(2,['boxplot_kruskalwallis_eps_near_far_rec_' num2str(u) '.svg'], 'svg');
            saveas(2,['boxplot_kruskalwallis_eps_near_far_rec_' num2str(u) '.pdf'], 'pdf');
            [comparison,means,H,gnames1] = multcompare(stats1);
            ta5(u).eps_near_far_stats.anova_p = p1;
            ta5(u).eps_near_far_stats.anova_tab = t1;
            ta5(u).eps_near_far_stats.mult_comparison = comparison;
            ta5(u).eps_near_far_stats.mult_means = means;
            ta5(u).eps_near_far_stats.stats1 = stats1;
            saveas(H,['multcomp_kruskalwallis_eps_near_far_rec_' num2str(u) '.png'], 'png')
            saveas(H,['multcomp_kruskalwallis_eps_near_far_rec_' num2str(u) '.pdf'], 'pdf')
            if ta5(u).eps_near_far_stats.mult_comparison(1,6)<0.05
                ta5(u).eps_near_far_stats.significant=1;
                ta5(u).eps_near_vs_far_means_ratio = mean(ta5(u).eps_near)/mean(ta5(u).eps_far)
            else
                ta5(u).eps_near_far_stats.significant=0;
                ta5(u).eps_near_vs_far_means_ratio = 0;
            end
        end
        if ~isempty(ta5(u).dur_far)
            ta5(u).dur_near_far(:,1) = ta5(u).dur_near;
            ta5(u).dur_near_far(1:size(ta5(u).dur_far,1),2) = ta5(u).dur_far;
            ta5(u).dur_near_far(ta5(u).dur_near_far==0) = NaN;
            close all
            [p1,t1,stats1] = kruskalwallis(ta5(u).dur_near_far);
            saveas(2,['boxplot_kruskalwallis_dur_near_far_rec_' num2str(u) '.svg'], 'svg');
            saveas(2,['boxplot_kruskalwallis_dur_near_far_rec_' num2str(u) '.pdf'], 'pdf');
            [comparison,means,H,gnames1] = multcompare(stats1);
            ta5(u).dur_near_far_stats.anova_p = p1;
            ta5(u).dur_near_far_stats.anova_tab = t1;
            ta5(u).dur_near_far_stats.mult_comparison = comparison;
            ta5(u).dur_near_far_stats.mult_means = means;
            ta5(u).dur_near_far_stats.stats1 = stats1;
            saveas(H,['multcomp_kruskalwallis_dur_near_far_rec_' num2str(u) '.png'], 'png')
            saveas(H,['multcomp_kruskalwallis_dur_near_far_rec_' num2str(u) '.pdf'], 'pdf')
            if ta5(u).dur_near_far_stats.mult_comparison(1,6)<0.05
                ta5(u).dur_near_far_stats.significant=1;
                ta5(u).dur_near_vs_far_means_ratio = mean(ta5(u).dur_near)/mean(ta5(u).dur_far)
            else
                ta5(u).dur_near_far_stats.significant=0;
                ta5(u).dur_near_vs_far_means_ratio = 0;
            end
        end
        if ~isempty(ta5(u).amp_far)
            ta5(u).amp_near_far(:,1) = ta5(u).amp_near;
            ta5(u).amp_near_far(1:size(ta5(u).amp_far,1),2) = ta5(u).amp_far;
            ta5(u).amp_near_far(ta5(u).amp_near_far==0) = NaN;
            close all
            [p1,t1,stats1] = kruskalwallis(ta5(u).amp_near_far);
            saveas(2,['boxplot_kruskalwallis_amp_near_far_rec_' num2str(u) '.svg'], 'svg');
            saveas(2,['boxplot_kruskalwallis_amp_near_far_rec_' num2str(u) '.pdf'], 'pdf');
            [comparison,means,H,gnames1] = multcompare(stats1);
            ta5(u).amp_near_far_stats.anova_p = p1;
            ta5(u).amp_near_far_stats.anova_tab = t1;
            ta5(u).amp_near_far_stats.mult_comparison = comparison;
            ta5(u).amp_near_far_stats.mult_means = means;
            ta5(u).amp_near_far_stats.stats1 = stats1;
            saveas(H,['multcomp_kruskalwallis_amp_near_far_rec_' num2str(u) '.png'], 'png')
            saveas(H,['multcomp_kruskalwallis_amp_near_far_rec_' num2str(u) '.pdf'], 'pdf')
            if ta5(u).amp_near_far_stats.mult_comparison(1,6)<0.05
                ta5(u).amp_near_far_stats.significant=1;
                ta5(u).amp_near_vs_far_means_ratio = mean(ta5(u).amp_near)/mean(ta5(u).amp_far)
            else
                ta5(u).amp_near_far_stats.significant=0;
                ta5(u).amp_near_vs_far_means_ratio = 0;
            end
        end
        if ~isempty(ta5(u).are_far)
            ta5(u).are_near_far(:,1) = ta5(u).are_near;
            ta5(u).are_near_far(1:size(ta5(u).are_far,1),2) = ta5(u).are_far;
            ta5(u).are_near_far(ta5(u).are_near_far==0) = NaN;
            close all
            [p1,t1,stats1] = kruskalwallis(ta5(u).are_near_far);
            saveas(2,['boxplot_kruskalwallis_are_near_far_rec_' num2str(u) '.svg'], 'svg');
            saveas(2,['boxplot_kruskalwallis_are_near_far_rec_' num2str(u) '.pdf'], 'pdf');
            [comparison,means,H,gnames1] = multcompare(stats1);
            ta5(u).are_near_far_stats.anova_p = p1;
            ta5(u).are_near_far_stats.anova_tab = t1;
            ta5(u).are_near_far_stats.mult_comparison = comparison;
            ta5(u).are_near_far_stats.mult_means = means;
            ta5(u).are_near_far_stats.stats1 = stats1;
            saveas(H,['multcomp_kruskalwallis_are_near_far_rec_' num2str(u) '.png'], 'png')
            saveas(H,['multcomp_kruskalwallis_are_near_far_rec_' num2str(u) '.pdf'], 'pdf')
            if ta5(u).are_near_far_stats.mult_comparison(1,6)<0.05
                ta5(u).are_near_far_stats.significant=1;
                ta5(u).are_near_vs_far_means_ratio = mean(ta5(u).are_near)/mean(ta5(u).are_far)
            else
                ta5(u).are_near_far_stats.significant=0;
                ta5(u).are_near_vs_far_means_ratio = 0;
            end
        end
        if ~isempty(ta5(u).rhy_far)
            ta5(u).rhy_near_far(:,1) = ta5(u).rhy_near;
            ta5(u).rhy_near_far(1:size(ta5(u).rhy_far,1),2) = ta5(u).rhy_far;
            ta5(u).rhy_near_far(ta5(u).rhy_near_far==0) = NaN;
            close all
            [p1,t1,stats1] = kruskalwallis(ta5(u).rhy_near_far);
            saveas(2,['boxplot_kruskalwallis_rhy_near_far_rec_' num2str(u) '.svg'], 'svg');
            saveas(2,['boxplot_kruskalwallis_rhy_near_far_rec_' num2str(u) '.pdf'], 'pdf');
            [comparison,means,H,gnames1] = multcompare(stats1);
            ta5(u).rhy_near_far_stats.anova_p = p1;
            ta5(u).rhy_near_far_stats.anova_tab = t1;
            ta5(u).rhy_near_far_stats.mult_comparison = comparison;
            ta5(u).rhy_near_far_stats.mult_means = means;
            ta5(u).rhy_near_far_stats.stats1 = stats1;
            saveas(H,['multcomp_kruskalwallis_rhy_near_far_rec_' num2str(u) '.png'], 'png')
            saveas(H,['multcomp_kruskalwallis_rhy_near_far_rec_' num2str(u) '.pdf'], 'pdf')

            if ta5(u).rhy_near_far_stats.mult_comparison(1,6)<0.05
                ta5(u).rhy_near_far_stats.significant=1;
                ta5(u).rhy_near_vs_far_means_ratio = mean(ta5(u).rhy_near)/mean(ta5(u).rhy_far)
            else
                ta5(u).rhy_near_far_stats.significant=0;
                ta5(u).rhy_near_vs_far_means_ratio = 0;
            end
        end
    end
end

%plot growth rate and/or day P against metrics near/far ratios for visualization
for u = 1:size(ta5,2)
    if ~isempty(ta5(u).day_P)
        ta5(1).gro_dayP_v_near_far_ratios_apm_eps_dur_amp_are_rhy(u,1) = ta5(u).day_P
        ta5(1).gro_dayP_v_near_far_ratios_apm_eps_dur_amp_are_rhy(u,2) = ta5(u).growthrate
        if ~isempty(ta5(u).apm_near_vs_far_means_ratio)
            ta5(1).gro_dayP_v_near_far_ratios_apm_eps_dur_amp_are_rhy(u,3) = ta5(u).apm_near_vs_far_means_ratio
            ta5(1).gro_dayP_v_near_far_ratios_apm_eps_dur_amp_are_rhy(u,4) = ta5(u).eps_near_vs_far_means_ratio
            ta5(1).gro_dayP_v_near_far_ratios_apm_eps_dur_amp_are_rhy(u,5) = ta5(u).dur_near_vs_far_means_ratio
            ta5(1).gro_dayP_v_near_far_ratios_apm_eps_dur_amp_are_rhy(u,6) = ta5(u).amp_near_vs_far_means_ratio
            ta5(1).gro_dayP_v_near_far_ratios_apm_eps_dur_amp_are_rhy(u,7) = ta5(u).are_near_vs_far_means_ratio
            ta5(1).gro_dayP_v_near_far_ratios_apm_eps_dur_amp_are_rhy(u,8) = ta5(u).rhy_near_vs_far_means_ratio
        else
            ta5(1).gro_dayP_v_near_far_ratios_apm_eps_dur_amp_are_rhy(u,3) = NaN
            ta5(1).gro_dayP_v_near_far_ratios_apm_eps_dur_amp_are_rhy(u,4) = NaN
            ta5(1).gro_dayP_v_near_far_ratios_apm_eps_dur_amp_are_rhy(u,5) = NaN
            ta5(1).gro_dayP_v_near_far_ratios_apm_eps_dur_amp_are_rhy(u,6) = NaN
            ta5(1).gro_dayP_v_near_far_ratios_apm_eps_dur_amp_are_rhy(u,7) = NaN
            ta5(1).gro_dayP_v_near_far_ratios_apm_eps_dur_amp_are_rhy(u,8) = NaN
        end
    end
end

close all
figure(89) 
set(gcf,'color','white')
sz = 60;
%apm
x = ta5(1).gro_dayP_v_near_far_ratios_apm_eps_dur_amp_are_rhy(:,2)
y = ta5(1).gro_dayP_v_near_far_ratios_apm_eps_dur_amp_are_rhy(:,3)
scatter(x,y,sz,'MarkerEdgeColor',[0, 0.4470, 0.7410],...
              'MarkerFaceColor',[0, 0.4470, 0.7410],...
              'LineWidth',1.5)
hold on
y = ta5(1).gro_dayP_v_near_far_ratios_apm_eps_dur_amp_are_rhy(:,4)
scatter(x,y,sz,'MarkerEdgeColor',[0.8500, 0.3250, 0.0980],...
              'MarkerFaceColor',[0.8500, 0.3250, 0.0980],...
              'LineWidth',1.5)
hold on
y = ta5(1).gro_dayP_v_near_far_ratios_apm_eps_dur_amp_are_rhy(:,5)
scatter(x,y,sz,'MarkerEdgeColor',[0.9290, 0.6940, 0.1250],...
              'MarkerFaceColor',[0.9290, 0.6940, 0.1250],...
              'LineWidth',1.5)
hold on
y = ta5(1).gro_dayP_v_near_far_ratios_apm_eps_dur_amp_are_rhy(:,6)
scatter(x,y,sz,'MarkerEdgeColor',[0.4940, 0.1840, 0.5560],...
              'MarkerFaceColor',[0.4940, 0.1840, 0.5560],...
              'LineWidth',1.5)
hold on
y = ta5(1).gro_dayP_v_near_far_ratios_apm_eps_dur_amp_are_rhy(:,7)
scatter(x,y,sz,'MarkerEdgeColor',[0.4660, 0.6740, 0.1880],...
              'MarkerFaceColor',[0.4660, 0.6740, 0.1880],...
              'LineWidth',1.5)
hold on
y = ta5(1).gro_dayP_v_near_far_ratios_apm_eps_dur_amp_are_rhy(:,8)
scatter(x,y,sz,'MarkerEdgeColor',[0.3010, 0.7450, 0.9330],...
              'MarkerFaceColor',[0.3010, 0.7450, 0.9330],...
              'LineWidth',1.5)
ax =get(gca)
set(gca, 'YScale', 'log')
set(gca, 'YLim', [0.1 10])
set(gca,'FontSize',24)
set(gca,'FontName','Arial')

saveas(89,[Folder '_metric_near_far_ratios_by_tum_gro.pdf'],'pdf')

figure(99) 
set(gcf,'color','white')
sz = 60;
%apm
x = ta5(1).gro_dayP_v_near_far_ratios_apm_eps_dur_amp_are_rhy(:,1)
y = ta5(1).gro_dayP_v_near_far_ratios_apm_eps_dur_amp_are_rhy(:,3)
scatter(x,y,sz,'MarkerEdgeColor',[0, 0.4470, 0.7410],...
              'MarkerFaceColor',[0, 0.4470, 0.7410],...
              'LineWidth',1.5)
hold on
y = ta5(1).gro_dayP_v_near_far_ratios_apm_eps_dur_amp_are_rhy(:,4)
scatter(x,y,sz,'MarkerEdgeColor',[0.8500, 0.3250, 0.0980],...
              'MarkerFaceColor',[0.8500, 0.3250, 0.0980],...
              'LineWidth',1.5)
hold on
y = ta5(1).gro_dayP_v_near_far_ratios_apm_eps_dur_amp_are_rhy(:,5)
scatter(x,y,sz,'MarkerEdgeColor',[0.9290, 0.6940, 0.1250],...
              'MarkerFaceColor',[0.9290, 0.6940, 0.1250],...
              'LineWidth',1.5)
hold on
y = ta5(1).gro_dayP_v_near_far_ratios_apm_eps_dur_amp_are_rhy(:,6)
scatter(x,y,sz,'MarkerEdgeColor',[0.4940, 0.1840, 0.5560],...
              'MarkerFaceColor',[0.4940, 0.1840, 0.5560],...
              'LineWidth',1.5)
hold on
y = ta5(1).gro_dayP_v_near_far_ratios_apm_eps_dur_amp_are_rhy(:,7)
scatter(x,y,sz,'MarkerEdgeColor',[0.4660, 0.6740, 0.1880],...
              'MarkerFaceColor',[0.4660, 0.6740, 0.1880],...
              'LineWidth',1.5)
hold on
y = ta5(1).gro_dayP_v_near_far_ratios_apm_eps_dur_amp_are_rhy(:,8)
scatter(x,y,sz,'MarkerEdgeColor',[0.3010, 0.7450, 0.9330],...
              'MarkerFaceColor',[0.3010, 0.7450, 0.9330],...
              'LineWidth',1.5)
ax =get(gca)
set(gca, 'YScale', 'log')
set(gca, 'YLim', [0.1 10])
set(gca,'FontSize',24)
set(gca,'FontName','Arial')

saveas(99,[Folder '_metric_near_far_ratios_by_day_P.pdf'],'pdf')

save ta5_in_progress.mat ta5

tumor_animal_ta5_only(animal_ID).onep.ta5 = ta5;



for animal_ID = [15 21 28 38 40 48 49 71 72 73]
    clear ta5_vnear_v_midfar
    for u = 1:size(tumor_animal_ta5_only(animal_ID).onep.ta5,2)
        if ~isnan(tumor_animal_ta5_only(animal_ID).onep.ta5(u).day_P)
            ta5_vnear_v_midfar(u).day_P =  tumor_animal_ta5_only(animal_ID).onep.ta5(u).day_P;
            ta5_vnear_v_midfar(u).growthrate = tumor_animal_ta5_only(animal_ID).onep.ta5(u).growthrate;
            ta5_vnear_v_midfar(u).apm_near_vs_far_means_ratio= [];
            dva = tumor_animal_ta5_only(animal_ID).onep.ta5(u).quiet_dist_vs_act;
            ta5_vnear_v_midfar(u).quiet_dist_vs_act = dva;
            ta5_vnear_v_midfar(u).apm_near = 0;
            ta5_vnear_v_midfar(u).eps_near = 0;
            ta5_vnear_v_midfar(u).dur_near = 0;
            ta5_vnear_v_midfar(u).amp_near = 0;
            ta5_vnear_v_midfar(u).are_near = 0;
            ta5_vnear_v_midfar(u).rhy_near = 0;
            ta5_vnear_v_midfar(u).apm_far = 0;
            ta5_vnear_v_midfar(u).eps_far = 0;
            ta5_vnear_v_midfar(u).dur_far = 0;
            ta5_vnear_v_midfar(u).amp_far = 0;
            ta5_vnear_v_midfar(u).are_far = 0;
            ta5_vnear_v_midfar(u).rhy_far = 0;
            a=1
            b=1
            for v = 1:size(dva,1)
                ta5_vnear_v_midfar(u).apm_v_all_dists_incl_zeropixs(v,1) = dva(v,4);
                ta5_vnear_v_midfar(u).apm_v_all_dists_incl_zeropixs(v,2) = dva(v,11);
                ta5_vnear_v_midfar(u).eps_v_all_dists_incl_zeropixs(v,1) = dva(v,6);
                ta5_vnear_v_midfar(u).eps_v_all_dists_incl_zeropixs(v,2) = dva(v,11);
                ta5_vnear_v_midfar(u).dur_v_all_dists_incl_zeropixs(v,1) = dva(v,7);
                ta5_vnear_v_midfar(u).dur_v_all_dists_incl_zeropixs(v,2) = dva(v,11);
                ta5_vnear_v_midfar(u).amp_v_all_dists_incl_zeropixs(v,1) = dva(v,9);
                ta5_vnear_v_midfar(u).amp_v_all_dists_incl_zeropixs(v,2) = dva(v,11);
                ta5_vnear_v_midfar(u).are_v_all_dists_incl_zeropixs(v,1) = dva(v,10);
                ta5_vnear_v_midfar(u).are_v_all_dists_incl_zeropixs(v,2) = dva(v,11);
                ta5_vnear_v_midfar(u).rhy_v_all_dists_incl_zeropixs(v,1) = dva(v,12);
                ta5_vnear_v_midfar(u).rhy_v_all_dists_incl_zeropixs(v,2) = dva(v,11);
                if dva(v,11)==1 % || dva(v,11)==2 (this was for enar v mid)
                    ta5_vnear_v_midfar(u).apm_near(a,1) = dva(v,4);
                    ta5_vnear_v_midfar(u).eps_near(a,1) = dva(v,6);
                    ta5_vnear_v_midfar(u).dur_near(a,1) = dva(v,7);
                    ta5_vnear_v_midfar(u).amp_near(a,1) = dva(v,9);
                    ta5_vnear_v_midfar(u).are_near(a,1) = dva(v,10);
                    ta5_vnear_v_midfar(u).rhy_near(a,1) = dva(v,12);
                    a=a+1;
                else
                    if dva(v,11)>4%
                        ta5_vnear_v_midfar(u).apm_far(b,1) = dva(v,4);
                        ta5_vnear_v_midfar(u).eps_far(b,1) = dva(v,6);
                        ta5_vnear_v_midfar(u).dur_far(b,1) = dva(v,7);
                        ta5_vnear_v_midfar(u).amp_far(b,1) = dva(v,9);
                        ta5_vnear_v_midfar(u).are_far(b,1) = dva(v,10);
                        ta5_vnear_v_midfar(u).rhy_far(b,1) = dva(v,12);
                        b=b+1;
                    end
                end
            end
            ta5_vnear_v_midfar(u).apm_near(ta5_vnear_v_midfar(u).apm_near==0) = [];
            ta5_vnear_v_midfar(u).eps_near(ta5_vnear_v_midfar(u).eps_near==0) = [];
            ta5_vnear_v_midfar(u).dur_near(ta5_vnear_v_midfar(u).dur_near==0) = [];
            ta5_vnear_v_midfar(u).amp_near(ta5_vnear_v_midfar(u).amp_near==0) = [];
            ta5_vnear_v_midfar(u).are_near(ta5_vnear_v_midfar(u).are_near==0) = [];
            ta5_vnear_v_midfar(u).rhy_near(ta5_vnear_v_midfar(u).rhy_near==0) = [];
            ta5_vnear_v_midfar(u).apm_far(ta5_vnear_v_midfar(u).apm_far==0) = [];
            ta5_vnear_v_midfar(u).eps_far(ta5_vnear_v_midfar(u).eps_far==0) = [];
            ta5_vnear_v_midfar(u).dur_far(ta5_vnear_v_midfar(u).dur_far==0) = [];
            ta5_vnear_v_midfar(u).amp_far(ta5_vnear_v_midfar(u).amp_far==0) = [];
            ta5_vnear_v_midfar(u).are_far(ta5_vnear_v_midfar(u).are_far==0) = [];
            ta5_vnear_v_midfar(u).rhy_far(ta5_vnear_v_midfar(u).rhy_far==0) = [];
            if ~isempty(ta5_vnear_v_midfar(u).apm_far)
                ta5_vnear_v_midfar(u).apm_near_far(:,1) = ta5_vnear_v_midfar(u).apm_near;
                ta5_vnear_v_midfar(u).apm_near_far(1:size(ta5_vnear_v_midfar(u).apm_far,1),2) = ta5_vnear_v_midfar(u).apm_far;
                ta5_vnear_v_midfar(u).apm_near_far(ta5_vnear_v_midfar(u).apm_near_far==0) = NaN;
                close all
                [p1,t1,stats1] = kruskalwallis(ta5_vnear_v_midfar(u).apm_near_far);
                saveas(2,['animal_' num2str(animal_ID) 'boxplot_kruskalwallis_apm_near_far_rec_' num2str(u) '.svg'], 'svg');
                saveas(2,['animal_' num2str(animal_ID) 'boxplot_kruskalwallis_apm_near_far_rec_' num2str(u) '.pdf'], 'pdf');
                [comparison,means,H,gnames1] = multcompare(stats1);
                ta5_vnear_v_midfar(u).apm_near_far_stats.anova_p = p1;
                ta5_vnear_v_midfar(u).apm_near_far_stats.anova_tab = t1;
                ta5_vnear_v_midfar(u).apm_near_far_stats.mult_comparison = comparison;
                ta5_vnear_v_midfar(u).apm_near_far_stats.mult_means = means;
                ta5_vnear_v_midfar(u).apm_near_far_stats.stats1 = stats1;
                saveas(H,['animal_' num2str(animal_ID) 'multcomp_kruskalwallis_apm_near_far_rec_' num2str(u) '.png'], 'png')
                saveas(H,['animal_' num2str(animal_ID) 'multcomp_kruskalwallis_apm_near_far_rec_' num2str(u) '.pdf'], 'pdf')

                if ta5_vnear_v_midfar(u).apm_near_far_stats.mult_comparison(1,6)<0.05
                    ta5_vnear_v_midfar(u).apm_near_far_stats.significant=1;
                    ta5_vnear_v_midfar(u).apm_near_vs_far_means_ratio = mean(ta5_vnear_v_midfar(u).apm_near)/mean(ta5_vnear_v_midfar(u).apm_far)
                else
                    ta5_vnear_v_midfar(u).apm_near_far_stats.significant=0;
                    ta5_vnear_v_midfar(u).apm_near_vs_far_means_ratio = mean(ta5_vnear_v_midfar(u).apm_near)/mean(ta5_vnear_v_midfar(u).apm_far);
                end
            else
                ta5_vnear_v_midfar(u).apm_near_vs_far_means_ratio = NaN
            end
            if ~isempty(ta5_vnear_v_midfar(u).eps_far)
                ta5_vnear_v_midfar(u).eps_near_far(:,1) = ta5_vnear_v_midfar(u).eps_near;
                ta5_vnear_v_midfar(u).eps_near_far(1:size(ta5_vnear_v_midfar(u).eps_far,1),2) = ta5_vnear_v_midfar(u).eps_far;
                ta5_vnear_v_midfar(u).eps_near_far(ta5_vnear_v_midfar(u).eps_near_far==0) = NaN;
                close all
                [p1,t1,stats1] = kruskalwallis(ta5_vnear_v_midfar(u).eps_near_far);
                saveas(2,['animal_' num2str(animal_ID) 'boxplot_kruskalwallis_eps_near_far_rec_' num2str(u) '.svg'], 'svg');
                saveas(2,['animal_' num2str(animal_ID) 'boxplot_kruskalwallis_eps_near_far_rec_' num2str(u) '.pdf'], 'pdf');
                [comparison,means,H,gnames1] = multcompare(stats1);
                ta5_vnear_v_midfar(u).eps_near_far_stats.anova_p = p1;
                ta5_vnear_v_midfar(u).eps_near_far_stats.anova_tab = t1;
                ta5_vnear_v_midfar(u).eps_near_far_stats.mult_comparison = comparison;
                ta5_vnear_v_midfar(u).eps_near_far_stats.mult_means = means;
                ta5_vnear_v_midfar(u).eps_near_far_stats.stats1 = stats1;
                saveas(H,['animal_' num2str(animal_ID) 'multcomp_kruskalwallis_eps_near_far_rec_' num2str(u) '.png'], 'png')
                saveas(H,['animal_' num2str(animal_ID) 'multcomp_kruskalwallis_eps_near_far_rec_' num2str(u) '.pdf'], 'pdf')
                if ta5_vnear_v_midfar(u).eps_near_far_stats.mult_comparison(1,6)<0.05
                    ta5_vnear_v_midfar(u).eps_near_far_stats.significant=1;
                    ta5_vnear_v_midfar(u).eps_near_vs_far_means_ratio = mean(ta5_vnear_v_midfar(u).eps_near)/mean(ta5_vnear_v_midfar(u).eps_far)
                else
                    ta5_vnear_v_midfar(u).eps_near_far_stats.significant=0;
                    ta5_vnear_v_midfar(u).eps_near_vs_far_means_ratio = mean(ta5_vnear_v_midfar(u).eps_near)/mean(ta5_vnear_v_midfar(u).eps_far);
                end
            else
                ta5_vnear_v_midfar(u).eps_near_vs_far_means_ratio = NaN
            end
            if ~isempty(ta5_vnear_v_midfar(u).dur_far)
                ta5_vnear_v_midfar(u).dur_near_far(:,1) = ta5_vnear_v_midfar(u).dur_near;
                ta5_vnear_v_midfar(u).dur_near_far(1:size(ta5_vnear_v_midfar(u).dur_far,1),2) = ta5_vnear_v_midfar(u).dur_far;
                ta5_vnear_v_midfar(u).dur_near_far(ta5_vnear_v_midfar(u).dur_near_far==0) = NaN;
                close all
                [p1,t1,stats1] = kruskalwallis(ta5_vnear_v_midfar(u).dur_near_far);
                saveas(2,['animal_' num2str(animal_ID) 'boxplot_kruskalwallis_dur_near_far_rec_' num2str(u) '.svg'], 'svg');
                saveas(2,['animal_' num2str(animal_ID) 'boxplot_kruskalwallis_dur_near_far_rec_' num2str(u) '.pdf'], 'pdf');
                [comparison,means,H,gnames1] = multcompare(stats1);
                ta5_vnear_v_midfar(u).dur_near_far_stats.anova_p = p1;
                ta5_vnear_v_midfar(u).dur_near_far_stats.anova_tab = t1;
                ta5_vnear_v_midfar(u).dur_near_far_stats.mult_comparison = comparison;
                ta5_vnear_v_midfar(u).dur_near_far_stats.mult_means = means;
                ta5_vnear_v_midfar(u).dur_near_far_stats.stats1 = stats1;
                saveas(H,['animal_' num2str(animal_ID) 'multcomp_kruskalwallis_dur_near_far_rec_' num2str(u) '.png'], 'png')
                saveas(H,['animal_' num2str(animal_ID) 'multcomp_kruskalwallis_dur_near_far_rec_' num2str(u) '.pdf'], 'pdf')
                if ta5_vnear_v_midfar(u).dur_near_far_stats.mult_comparison(1,6)<0.05
                    ta5_vnear_v_midfar(u).dur_near_far_stats.significant=1;
                    ta5_vnear_v_midfar(u).dur_near_vs_far_means_ratio = mean(ta5_vnear_v_midfar(u).dur_near)/mean(ta5_vnear_v_midfar(u).dur_far)
                else
                    ta5_vnear_v_midfar(u).dur_near_far_stats.significant=0;
                    ta5_vnear_v_midfar(u).dur_near_vs_far_means_ratio = mean(ta5_vnear_v_midfar(u).dur_near)/mean(ta5_vnear_v_midfar(u).dur_far);
                end
            else
                ta5_vnear_v_midfar(u).dur_near_vs_far_means_ratio = NaN
            end
            if ~isempty(ta5_vnear_v_midfar(u).amp_far)
                ta5_vnear_v_midfar(u).amp_near_far(:,1) = ta5_vnear_v_midfar(u).amp_near;
                ta5_vnear_v_midfar(u).amp_near_far(1:size(ta5_vnear_v_midfar(u).amp_far,1),2) = ta5_vnear_v_midfar(u).amp_far;
                ta5_vnear_v_midfar(u).amp_near_far(ta5_vnear_v_midfar(u).amp_near_far==0) = NaN;
                close all
                [p1,t1,stats1] = kruskalwallis(ta5_vnear_v_midfar(u).amp_near_far);
                saveas(2,['animal_' num2str(animal_ID) 'boxplot_kruskalwallis_amp_near_far_rec_' num2str(u) '.svg'], 'svg');
                saveas(2,['animal_' num2str(animal_ID) 'boxplot_kruskalwallis_amp_near_far_rec_' num2str(u) '.pdf'], 'pdf');
                [comparison,means,H,gnames1] = multcompare(stats1);
                ta5_vnear_v_midfar(u).amp_near_far_stats.anova_p = p1;
                ta5_vnear_v_midfar(u).amp_near_far_stats.anova_tab = t1;
                ta5_vnear_v_midfar(u).amp_near_far_stats.mult_comparison = comparison;
                ta5_vnear_v_midfar(u).amp_near_far_stats.mult_means = means;
                ta5_vnear_v_midfar(u).amp_near_far_stats.stats1 = stats1;
                saveas(H,['animal_' num2str(animal_ID) 'multcomp_kruskalwallis_amp_near_far_rec_' num2str(u) '.png'], 'png')
                saveas(H,['animal_' num2str(animal_ID) 'multcomp_kruskalwallis_amp_near_far_rec_' num2str(u) '.pdf'], 'pdf')
                if ta5_vnear_v_midfar(u).amp_near_far_stats.mult_comparison(1,6)<0.05
                    ta5_vnear_v_midfar(u).amp_near_far_stats.significant=1;
                    ta5_vnear_v_midfar(u).amp_near_vs_far_means_ratio = mean(ta5_vnear_v_midfar(u).amp_near)/mean(ta5_vnear_v_midfar(u).amp_far)
                else
                    ta5_vnear_v_midfar(u).amp_near_far_stats.significant=0;
                    ta5_vnear_v_midfar(u).amp_near_vs_far_means_ratio = mean(ta5_vnear_v_midfar(u).amp_near)/mean(ta5_vnear_v_midfar(u).amp_far);
                end
            else
                ta5_vnear_v_midfar(u).amp_near_vs_far_means_ratio = NaN
            end
            if ~isempty(ta5_vnear_v_midfar(u).are_far)
                ta5_vnear_v_midfar(u).are_near_far(:,1) = ta5_vnear_v_midfar(u).are_near;
                ta5_vnear_v_midfar(u).are_near_far(1:size(ta5_vnear_v_midfar(u).are_far,1),2) = ta5_vnear_v_midfar(u).are_far;
                ta5_vnear_v_midfar(u).are_near_far(ta5_vnear_v_midfar(u).are_near_far==0) = NaN;
                close all
                [p1,t1,stats1] = kruskalwallis(ta5_vnear_v_midfar(u).are_near_far);
                saveas(2,['animal_' num2str(animal_ID) 'boxplot_kruskalwallis_are_near_far_rec_' num2str(u) '.svg'], 'svg');
                saveas(2,['animal_' num2str(animal_ID) 'boxplot_kruskalwallis_are_near_far_rec_' num2str(u) '.pdf'], 'pdf');
                [comparison,means,H,gnames1] = multcompare(stats1);
                ta5_vnear_v_midfar(u).are_near_far_stats.anova_p = p1;
                ta5_vnear_v_midfar(u).are_near_far_stats.anova_tab = t1;
                ta5_vnear_v_midfar(u).are_near_far_stats.mult_comparison = comparison;
                ta5_vnear_v_midfar(u).are_near_far_stats.mult_means = means;
                ta5_vnear_v_midfar(u).are_near_far_stats.stats1 = stats1;
                saveas(H,['animal_' num2str(animal_ID) 'multcomp_kruskalwallis_are_near_far_rec_' num2str(u) '.png'], 'png')
                saveas(H,['animal_' num2str(animal_ID) 'multcomp_kruskalwallis_are_near_far_rec_' num2str(u) '.pdf'], 'pdf')
                if ta5_vnear_v_midfar(u).are_near_far_stats.mult_comparison(1,6)<0.05
                    ta5_vnear_v_midfar(u).are_near_far_stats.significant=1;
                    ta5_vnear_v_midfar(u).are_near_vs_far_means_ratio = mean(ta5_vnear_v_midfar(u).are_near)/mean(ta5_vnear_v_midfar(u).are_far)
                else
                    ta5_vnear_v_midfar(u).are_near_far_stats.significant=0;
                    ta5_vnear_v_midfar(u).are_near_vs_far_means_ratio = mean(ta5_vnear_v_midfar(u).are_near)/mean(ta5_vnear_v_midfar(u).are_far);
                end
            else
                ta5_vnear_v_midfar(u).are_near_vs_far_means_ratio = NaN
            end
            if ~isempty(ta5_vnear_v_midfar(u).rhy_far)
                ta5_vnear_v_midfar(u).rhy_near_far(:,1) = ta5_vnear_v_midfar(u).rhy_near;
                ta5_vnear_v_midfar(u).rhy_near_far(1:size(ta5_vnear_v_midfar(u).rhy_far,1),2) = ta5_vnear_v_midfar(u).rhy_far;
                ta5_vnear_v_midfar(u).rhy_near_far(ta5_vnear_v_midfar(u).rhy_near_far==0) = NaN;
                close all
                [p1,t1,stats1] = kruskalwallis(ta5_vnear_v_midfar(u).rhy_near_far);
                saveas(2,['animal_' num2str(animal_ID) 'boxplot_kruskalwallis_rhy_near_far_rec_' num2str(u) '.svg'], 'svg');
                saveas(2,['animal_' num2str(animal_ID) 'boxplot_kruskalwallis_rhy_near_far_rec_' num2str(u) '.pdf'], 'pdf');
                [comparison,means,H,gnames1] = multcompare(stats1);
                ta5_vnear_v_midfar(u).rhy_near_far_stats.anova_p = p1;
                ta5_vnear_v_midfar(u).rhy_near_far_stats.anova_tab = t1;
                ta5_vnear_v_midfar(u).rhy_near_far_stats.mult_comparison = comparison;
                ta5_vnear_v_midfar(u).rhy_near_far_stats.mult_means = means;
                ta5_vnear_v_midfar(u).rhy_near_far_stats.stats1 = stats1;
                saveas(H,['animal_' num2str(animal_ID) 'multcomp_kruskalwallis_rhy_near_far_rec_' num2str(u) '.png'], 'png')
                saveas(H,['animal_' num2str(animal_ID) 'multcomp_kruskalwallis_rhy_near_far_rec_' num2str(u) '.pdf'], 'pdf')
                if ta5_vnear_v_midfar(u).rhy_near_far_stats.mult_comparison(1,6)<0.05
                    ta5_vnear_v_midfar(u).rhy_near_far_stats.significant=1;
                    ta5_vnear_v_midfar(u).rhy_near_vs_far_means_ratio = mean(ta5_vnear_v_midfar(u).rhy_near)/mean(ta5_vnear_v_midfar(u).rhy_far)
                else
                    ta5_vnear_v_midfar(u).rhy_near_far_stats.significant=0;
                    ta5_vnear_v_midfar(u).rhy_near_vs_far_means_ratio = mean(ta5_vnear_v_midfar(u).rhy_near)/mean(ta5_vnear_v_midfar(u).rhy_far);
                end
            else
                ta5_vnear_v_midfar(u).rhy_near_vs_far_means_ratio = NaN
            end
        end
    end
    uu=0
    for u = 1:size(ta5_vnear_v_midfar,2)
        if ~isempty(ta5_vnear_v_midfar(u).day_P)
            uu=uu+1
            ta5_vnear_v_midfar(1).gro_dayP_v_near_far_ratios_apm_eps_dur_amp_are_rhy(uu,1) = ta5_vnear_v_midfar(u).day_P
            ta5_vnear_v_midfar(1).gro_dayP_v_near_far_ratios_apm_eps_dur_amp_are_rhy(uu,2) = ta5_vnear_v_midfar(u).growthrate
            if ~isempty(ta5_vnear_v_midfar(u).apm_near_vs_far_means_ratio)
                ta5_vnear_v_midfar(1).gro_dayP_v_near_far_ratios_apm_eps_dur_amp_are_rhy(uu,3) = ta5_vnear_v_midfar(u).apm_near_vs_far_means_ratio
                ta5_vnear_v_midfar(1).gro_dayP_v_near_far_ratios_apm_eps_dur_amp_are_rhy(uu,4) = ta5_vnear_v_midfar(u).eps_near_vs_far_means_ratio
                ta5_vnear_v_midfar(1).gro_dayP_v_near_far_ratios_apm_eps_dur_amp_are_rhy(uu,5) = ta5_vnear_v_midfar(u).dur_near_vs_far_means_ratio
                ta5_vnear_v_midfar(1).gro_dayP_v_near_far_ratios_apm_eps_dur_amp_are_rhy(uu,6) = ta5_vnear_v_midfar(u).amp_near_vs_far_means_ratio
                ta5_vnear_v_midfar(1).gro_dayP_v_near_far_ratios_apm_eps_dur_amp_are_rhy(uu,7) = ta5_vnear_v_midfar(u).are_near_vs_far_means_ratio
                ta5_vnear_v_midfar(1).gro_dayP_v_near_far_ratios_apm_eps_dur_amp_are_rhy(uu,8) = ta5_vnear_v_midfar(u).rhy_near_vs_far_means_ratio
            else
                ta5_vnear_v_midfar(1).gro_dayP_v_near_far_ratios_apm_eps_dur_amp_are_rhy(uu,3) = NaN
                ta5_vnear_v_midfar(1).gro_dayP_v_near_far_ratios_apm_eps_dur_amp_are_rhy(uu,4) = NaN
                ta5_vnear_v_midfar(1).gro_dayP_v_near_far_ratios_apm_eps_dur_amp_are_rhy(uu,5) = NaN
                ta5_vnear_v_midfar(1).gro_dayP_v_near_far_ratios_apm_eps_dur_amp_are_rhy(uu,6) = NaN
                ta5_vnear_v_midfar(1).gro_dayP_v_near_far_ratios_apm_eps_dur_amp_are_rhy(uu,7) = NaN
                ta5_vnear_v_midfar(1).gro_dayP_v_near_far_ratios_apm_eps_dur_amp_are_rhy(uu,8) = NaN
            end

        end
    end

    close all
    figure(89)
    set(gcf,'color','white')
    sz = 60;
    %apm
    x = ta5_vnear_v_midfar(1).gro_dayP_v_near_far_ratios_apm_eps_dur_amp_are_rhy(:,2)
    y = ta5_vnear_v_midfar(1).gro_dayP_v_near_far_ratios_apm_eps_dur_amp_are_rhy(:,3)
    scatter(x,y,sz,'MarkerEdgeColor',[0, 0.4470, 0.7410],...
        'MarkerFaceColor',[0, 0.4470, 0.7410],...
        'LineWidth',1.5)
    ax =get(gca)
    set(gca, 'YScale', 'log')
    set(gca, 'YLim', [0.2 5])
    set(gca,'FontSize',24)
    set(gca,'FontName','Arial')
    saveas(89,['animal' num2str(animal_ID) '_metric_vnear_midfar_ratios_by_tum_gro_20231106_apm.pdf'],'pdf')

    close all
    figure(99)
    set(gcf,'color','white')
    sz = 60;
    y = ta5_vnear_v_midfar(1).gro_dayP_v_near_far_ratios_apm_eps_dur_amp_are_rhy(:,4)
    scatter(x,y,sz,'MarkerEdgeColor',[0.8500, 0.3250, 0.0980],...
        'MarkerFaceColor',[0.8500, 0.3250, 0.0980],...
        'LineWidth',1.5)
    ax =get(gca)
    set(gca, 'YScale', 'log')
    set(gca, 'YLim', [0.2 5])
    set(gca,'FontSize',24)
    set(gca,'FontName','Arial')
    saveas(99,['animal' num2str(animal_ID) '_metric_vnear_midfar_ratios_by_tum_gro_20231106_eps.pdf'],'pdf')

    close all
    figure(109)
    set(gcf,'color','white')
    sz = 60;
    y = ta5_vnear_v_midfar(1).gro_dayP_v_near_far_ratios_apm_eps_dur_amp_are_rhy(:,5)
    scatter(x,y,sz,'MarkerEdgeColor',[0.9290, 0.6940, 0.1250],...
        'MarkerFaceColor',[0.9290, 0.6940, 0.1250],...
        'LineWidth',1.5)
    ax =get(gca)
    set(gca, 'YScale', 'log')
    set(gca, 'YLim', [0.2 5])
    set(gca,'FontSize',24)
    set(gca,'FontName','Arial')
    saveas(109,['animal' num2str(animal_ID) '_metric_vnear_midfar_ratios_by_tum_gro_20231106_dur.pdf'],'pdf')

    close all
    figure(119)
    set(gcf,'color','white')
    sz = 60;
    y = ta5_vnear_v_midfar(1).gro_dayP_v_near_far_ratios_apm_eps_dur_amp_are_rhy(:,6)
    scatter(x,y,sz,'MarkerEdgeColor',[0.4940, 0.1840, 0.5560],...
        'MarkerFaceColor',[0.4940, 0.1840, 0.5560],...
        'LineWidth',1.5)
    ax =get(gca)
    set(gca, 'YScale', 'log')
    set(gca, 'YLim', [0.2 5])
    set(gca,'FontSize',24)
    set(gca,'FontName','Arial')
    saveas(119,['animal' num2str(animal_ID) '_metric_vnear_midfar_ratios_by_tum_gro_20231106_amp.pdf'],'pdf')

    close all
    figure(129)
    set(gcf,'color','white')
    sz = 60;
    y = ta5_vnear_v_midfar(1).gro_dayP_v_near_far_ratios_apm_eps_dur_amp_are_rhy(:,7)
    scatter(x,y,sz,'MarkerEdgeColor',[0.4660, 0.6740, 0.1880],...
        'MarkerFaceColor',[0.4660, 0.6740, 0.1880],...
        'LineWidth',1.5)
    ax =get(gca)
    set(gca, 'YScale', 'log')
    set(gca, 'YLim', [0.2 5])
    set(gca,'FontSize',24)
    set(gca,'FontName','Arial')
    saveas(129,['animal' num2str(animal_ID) '_metric_vnear_midfar_ratios_by_tum_gro_20231106_are.pdf'],'pdf')

    close all
    figure(139)
    set(gcf,'color','white')
    sz = 60;
    y = ta5_vnear_v_midfar(1).gro_dayP_v_near_far_ratios_apm_eps_dur_amp_are_rhy(:,8)
    scatter(x,y,sz,'MarkerEdgeColor',[0.3010, 0.7450, 0.9330],...
        'MarkerFaceColor',[0.3010, 0.7450, 0.9330],...
        'LineWidth',1.5)
    ax =get(gca)
    set(gca, 'YScale', 'log')
    set(gca, 'YLim', [0.2 5])
    set(gca,'FontSize',24)
    set(gca,'FontName','Arial')
    saveas(139,['animal' num2str(animal_ID) '_metric_vnear_midfar_ratios_by_tum_gro_20231106_rhy.pdf'],'pdf')

    close all
    figure(89)
    set(gcf,'color','white')
    sz = 60;
    %apm
    x = ta5_vnear_v_midfar(1).gro_dayP_v_near_far_ratios_apm_eps_dur_amp_are_rhy(:,1)

    y = ta5_vnear_v_midfar(1).gro_dayP_v_near_far_ratios_apm_eps_dur_amp_are_rhy(:,3)
    scatter(x,y,sz,'MarkerEdgeColor',[0, 0.4470, 0.7410],...
        'MarkerFaceColor',[0, 0.4470, 0.7410],...
        'LineWidth',1.5)
    ax =get(gca)
    set(gca, 'YScale', 'log')
    set(gca, 'YLim', [0.2 5])
    set(gca, 'XLim', [40 141])
    set(gca,'FontSize',24)
    set(gca,'FontName','Arial')
    saveas(89,['animal' num2str(animal_ID) '_metric_vnear_midfar_ratios_by_dayP_20231106_apm.pdf'],'pdf')

    close all
    figure(99)
    set(gcf,'color','white')
    sz = 60;
    y = ta5_vnear_v_midfar(1).gro_dayP_v_near_far_ratios_apm_eps_dur_amp_are_rhy(:,4)
    scatter(x,y,sz,'MarkerEdgeColor',[0.8500, 0.3250, 0.0980],...
        'MarkerFaceColor',[0.8500, 0.3250, 0.0980],...
        'LineWidth',1.5)
    ax =get(gca)
    set(gca, 'YScale', 'log')
    set(gca, 'YLim', [0.2 5])
    set(gca, 'XLim', [40 141])
    set(gca,'FontSize',24)
    set(gca,'FontName','Arial')
    saveas(99,['animal' num2str(animal_ID) '_metric_vnear_midfar_ratios_by_dayP_20231106_eps.pdf'],'pdf')

    close all
    figure(109)
    set(gcf,'color','white')
    sz = 60;
    y = ta5_vnear_v_midfar(1).gro_dayP_v_near_far_ratios_apm_eps_dur_amp_are_rhy(:,5)
    scatter(x,y,sz,'MarkerEdgeColor',[0.9290, 0.6940, 0.1250],...
        'MarkerFaceColor',[0.9290, 0.6940, 0.1250],...
        'LineWidth',1.5)
    ax =get(gca)
    set(gca, 'YScale', 'log')
    set(gca, 'YLim', [0.2 5])
    set(gca, 'XLim', [40 141])
    set(gca,'FontSize',24)
    set(gca,'FontName','Arial')
    saveas(109,['animal' num2str(animal_ID) '_metric_vnear_midfar_ratios_by_dayP_20231106_dur.pdf'],'pdf')

    close all
    figure(119)
    set(gcf,'color','white')
    sz = 60;
    y = ta5_vnear_v_midfar(1).gro_dayP_v_near_far_ratios_apm_eps_dur_amp_are_rhy(:,6)
    scatter(x,y,sz,'MarkerEdgeColor',[0.4940, 0.1840, 0.5560],...
        'MarkerFaceColor',[0.4940, 0.1840, 0.5560],...
        'LineWidth',1.5)
    ax =get(gca)
    set(gca, 'YScale', 'log')
    set(gca, 'YLim', [0.2 5])
    set(gca, 'XLim', [40 141])
    set(gca,'FontSize',24)
    set(gca,'FontName','Arial')
    saveas(119,['animal' num2str(animal_ID) '_metric_vnear_midfar_ratios_by_dayP_20231106_amp.pdf'],'pdf')

    close all
    figure(129)
    set(gcf,'color','white')
    sz = 60;
    y = ta5_vnear_v_midfar(1).gro_dayP_v_near_far_ratios_apm_eps_dur_amp_are_rhy(:,7)
    scatter(x,y,sz,'MarkerEdgeColor',[0.4660, 0.6740, 0.1880],...
        'MarkerFaceColor',[0.4660, 0.6740, 0.1880],...
        'LineWidth',1.5)
    ax =get(gca)
    set(gca, 'YScale', 'log')
    set(gca, 'YLim', [0.2 5])
    set(gca, 'XLim', [40 141])
    set(gca,'FontSize',24)
    set(gca,'FontName','Arial')
    saveas(129,['animal' num2str(animal_ID) '_metric_vnear_midfar_ratios_by_dayP_20231106_are.pdf'],'pdf')

    close all
    figure(139)
    set(gcf,'color','white')
    sz = 60;
    y = ta5_vnear_v_midfar(1).gro_dayP_v_near_far_ratios_apm_eps_dur_amp_are_rhy(:,8)
    scatter(x,y,sz,'MarkerEdgeColor',[0.3010, 0.7450, 0.9330],...
        'MarkerFaceColor',[0.3010, 0.7450, 0.9330],...
        'LineWidth',1.5)
    ax =get(gca)
    set(gca, 'YScale', 'log')
    set(gca, 'YLim', [0.2 5])
    set(gca, 'XLim', [40 141])
    set(gca,'FontSize',24)
    set(gca,'FontName','Arial')
    saveas(139,['animal' num2str(animal_ID) '_metric_vnear_midfar_ratios_by_dayP_20231106_rhy.pdf'],'pdf')

    tumor_animal_ta5_only(animal_ID).onep.ta5_vnear_v_midfar = ta5_vnear_v_midfar;
end

clear fig5_rev_20231106
%make matrices for apm, eps, dur, amp, are, and rhy for all 3xCR animals
%pooled and then all GPC6 animals pooled
a=1
b=1
for animal_ID = [15 21 28 38 40]
    dva = tumor_animal_ta5_only(animal_ID).onep.ta5_vnear_v_midfar(1).gro_dayP_v_near_far_ratios_apm_eps_dur_amp_are_rhy;
    klp = size(dva,1)
    fig5_rev_20231106.Cr86.all_tum_gro_vs_near_far_ratio_apm(a:a+size(dva,1)-2,1) = dva(2:klp,2);
    fig5_rev_20231106.Cr86.all_tum_gro_vs_near_far_ratio_apm(a:a+size(dva,1)-2,2) = dva(2:klp,3);
    fig5_rev_20231106.Cr86.all_tum_gro_vs_near_far_ratio_eps(a:a+size(dva,1)-2,1) = dva(2:klp,2);
    fig5_rev_20231106.Cr86.all_tum_gro_vs_near_far_ratio_eps(a:a+size(dva,1)-2,2) = dva(2:klp,4);
    fig5_rev_20231106.Cr86.all_tum_gro_vs_near_far_ratio_dur(a:a+size(dva,1)-2,1) = dva(2:klp,2);
    fig5_rev_20231106.Cr86.all_tum_gro_vs_near_far_ratio_dur(a:a+size(dva,1)-2,2) = dva(2:klp,5);
    fig5_rev_20231106.Cr86.all_tum_gro_vs_near_far_ratio_amp(a:a+size(dva,1)-2,1) = dva(2:klp,2);
    fig5_rev_20231106.Cr86.all_tum_gro_vs_near_far_ratio_amp(a:a+size(dva,1)-2,2) = dva(2:klp,6);
    fig5_rev_20231106.Cr86.all_tum_gro_vs_near_far_ratio_are(a:a+size(dva,1)-2,1) = dva(2:klp,2);
    fig5_rev_20231106.Cr86.all_tum_gro_vs_near_far_ratio_are(a:a+size(dva,1)-2,2) = dva(2:klp,7);
    fig5_rev_20231106.Cr86.all_tum_gro_vs_near_far_ratio_rhy(a:a+size(dva,1)-2,1) = dva(2:klp,2);
    fig5_rev_20231106.Cr86.all_tum_gro_vs_near_far_ratio_rhy(a:a+size(dva,1)-2,2) = dva(2:klp,8);
    fig5_rev_20231106.Cr86.all_day_P_vs_near_far_ratio_apm(b:b+size(dva,1)-1,1) = dva(:,1);
    fig5_rev_20231106.Cr86.all_day_P_vs_near_far_ratio_apm(b:b+size(dva,1)-1,2) = dva(:,3);
    fig5_rev_20231106.Cr86.all_day_P_vs_near_far_ratio_eps(b:b+size(dva,1)-1,1) = dva(:,1);
    fig5_rev_20231106.Cr86.all_day_P_vs_near_far_ratio_eps(b:b+size(dva,1)-1,2) = dva(:,4);
    fig5_rev_20231106.Cr86.all_day_P_vs_near_far_ratio_dur(b:b+size(dva,1)-1,1) = dva(:,1);
    fig5_rev_20231106.Cr86.all_day_P_vs_near_far_ratio_dur(b:b+size(dva,1)-1,2) = dva(:,5);
    fig5_rev_20231106.Cr86.all_day_P_vs_near_far_ratio_amp(b:b+size(dva,1)-1,1) = dva(:,1);
    fig5_rev_20231106.Cr86.all_day_P_vs_near_far_ratio_amp(b:b+size(dva,1)-1,2) = dva(:,6);
    fig5_rev_20231106.Cr86.all_day_P_vs_near_far_ratio_are(b:b+size(dva,1)-1,1) = dva(:,1);
    fig5_rev_20231106.Cr86.all_day_P_vs_near_far_ratio_are(b:b+size(dva,1)-1,2) = dva(:,7);
    fig5_rev_20231106.Cr86.all_day_P_vs_near_far_ratio_rhy(b:b+size(dva,1)-1,1) = dva(:,1);
    fig5_rev_20231106.Cr86.all_day_P_vs_near_far_ratio_rhy(b:b+size(dva,1)-1,2) = dva(:,8);
    a = a+size(dva,1)-1
    b = b+size(dva,1)
end

a=1
b=1
for u = 1:size(fig5_rev_20231106.Cr86.all_tum_gro_vs_near_far_ratio_apm,1)

    if fig5_rev_20231106.Cr86.all_tum_gro_vs_near_far_ratio_apm(u,1) < 100000
        fig5_rev_20231106.Cr86.below_or_above10to5_apm(a,1) = fig5_rev_20231106.Cr86.all_tum_gro_vs_near_far_ratio_apm(u,2)
        fig5_rev_20231106.Cr86.below_or_above10to5_eps(a,1) = fig5_rev_20231106.Cr86.all_tum_gro_vs_near_far_ratio_eps(u,2)
        fig5_rev_20231106.Cr86.below_or_above10to5_dur(a,1) = fig5_rev_20231106.Cr86.all_tum_gro_vs_near_far_ratio_dur(u,2)
        fig5_rev_20231106.Cr86.below_or_above10to5_amp(a,1) = fig5_rev_20231106.Cr86.all_tum_gro_vs_near_far_ratio_amp(u,2)
        fig5_rev_20231106.Cr86.below_or_above10to5_are(a,1) = fig5_rev_20231106.Cr86.all_tum_gro_vs_near_far_ratio_are(u,2)
        fig5_rev_20231106.Cr86.below_or_above10to5_rhy(a,1) = fig5_rev_20231106.Cr86.all_tum_gro_vs_near_far_ratio_rhy(u,2)
        a=a+1
    else
        fig5_rev_20231106.Cr86.below_or_above10to5_apm(b,2) = fig5_rev_20231106.Cr86.all_tum_gro_vs_near_far_ratio_apm(u,2)
        fig5_rev_20231106.Cr86.below_or_above10to5_eps(b,2) = fig5_rev_20231106.Cr86.all_tum_gro_vs_near_far_ratio_eps(u,2)
        fig5_rev_20231106.Cr86.below_or_above10to5_dur(b,2) = fig5_rev_20231106.Cr86.all_tum_gro_vs_near_far_ratio_dur(u,2)
        fig5_rev_20231106.Cr86.below_or_above10to5_amp(b,2) = fig5_rev_20231106.Cr86.all_tum_gro_vs_near_far_ratio_amp(u,2)
        fig5_rev_20231106.Cr86.below_or_above10to5_are(b,2) = fig5_rev_20231106.Cr86.all_tum_gro_vs_near_far_ratio_are(u,2)
        fig5_rev_20231106.Cr86.below_or_above10to5_rhy(b,2) = fig5_rev_20231106.Cr86.all_tum_gro_vs_near_far_ratio_rhy(u,2)
        b=b+1
    end
end
a=a-1
b=b-1
if a<b
    m86 = b
    fig5_rev_20231106.Cr86.below_or_above10to5_apm(a+1:b,1) = NaN
    fig5_rev_20231106.Cr86.below_or_above10to5_eps(a+1:b,1) = NaN
    fig5_rev_20231106.Cr86.below_or_above10to5_dur(a+1:b,1) = NaN
    fig5_rev_20231106.Cr86.below_or_above10to5_amp(a+1:b,1) = NaN
    fig5_rev_20231106.Cr86.below_or_above10to5_are(a+1:b,1) = NaN
    fig5_rev_20231106.Cr86.below_or_above10to5_rhy(a+1:b,1) = NaN
else
    m86=a
    fig5_rev_20231106.Cr86.below_or_above10to5_apm(b+1:a,2) = NaN
    fig5_rev_20231106.Cr86.below_or_above10to5_eps(b+1:a,2) = NaN
    fig5_rev_20231106.Cr86.below_or_above10to5_dur(b+1:a,2) = NaN
    fig5_rev_20231106.Cr86.below_or_above10to5_amp(b+1:a,2) = NaN
    fig5_rev_20231106.Cr86.below_or_above10to5_are(b+1:a,2) = NaN
    fig5_rev_20231106.Cr86.below_or_above10to5_rhy(b+1:a,2) = NaN
end


a=1
for animal_ID = [48 49 71 72 73]
    dva = tumor_animal_ta5_only(animal_ID).onep.ta5_vnear_v_midfar(1).gro_dayP_v_near_far_ratios_apm_eps_dur_amp_are_rhy;
    klp = size(dva,1)
    fig5_rev_20231106.GPC6.all_tum_gro_vs_near_far_ratio_apm(a:a+size(dva,1)-2,1) = dva(2:klp,2);
    fig5_rev_20231106.GPC6.all_tum_gro_vs_near_far_ratio_apm(a:a+size(dva,1)-2,2) = dva(2:klp,3);
    fig5_rev_20231106.GPC6.all_tum_gro_vs_near_far_ratio_eps(a:a+size(dva,1)-2,1) = dva(2:klp,2);
    fig5_rev_20231106.GPC6.all_tum_gro_vs_near_far_ratio_eps(a:a+size(dva,1)-2,2) = dva(2:klp,4);
    fig5_rev_20231106.GPC6.all_tum_gro_vs_near_far_ratio_dur(a:a+size(dva,1)-2,1) = dva(2:klp,2);
    fig5_rev_20231106.GPC6.all_tum_gro_vs_near_far_ratio_dur(a:a+size(dva,1)-2,2) = dva(2:klp,5);
    fig5_rev_20231106.GPC6.all_tum_gro_vs_near_far_ratio_amp(a:a+size(dva,1)-2,1) = dva(2:klp,2);
    fig5_rev_20231106.GPC6.all_tum_gro_vs_near_far_ratio_amp(a:a+size(dva,1)-2,2) = dva(2:klp,6);
    fig5_rev_20231106.GPC6.all_tum_gro_vs_near_far_ratio_are(a:a+size(dva,1)-2,1) = dva(2:klp,2);
    fig5_rev_20231106.GPC6.all_tum_gro_vs_near_far_ratio_are(a:a+size(dva,1)-2,2) = dva(2:klp,7);
    fig5_rev_20231106.GPC6.all_tum_gro_vs_near_far_ratio_rhy(a:a+size(dva,1)-2,1) = dva(2:klp,2);
    fig5_rev_20231106.GPC6.all_tum_gro_vs_near_far_ratio_rhy(a:a+size(dva,1)-2,2) = dva(2:klp,8);
    fig5_rev_20231106.GPC6.all_day_P_vs_near_far_ratio_apm(b:b+size(dva,1)-1,1) = dva(:,1);
    fig5_rev_20231106.GPC6.all_day_P_vs_near_far_ratio_apm(b:b+size(dva,1)-1,2) = dva(:,3);
    fig5_rev_20231106.GPC6.all_day_P_vs_near_far_ratio_eps(b:b+size(dva,1)-1,1) = dva(:,1);
    fig5_rev_20231106.GPC6.all_day_P_vs_near_far_ratio_eps(b:b+size(dva,1)-1,2) = dva(:,4);
    fig5_rev_20231106.GPC6.all_day_P_vs_near_far_ratio_dur(b:b+size(dva,1)-1,1) = dva(:,1);
    fig5_rev_20231106.GPC6.all_day_P_vs_near_far_ratio_dur(b:b+size(dva,1)-1,2) = dva(:,5);
    fig5_rev_20231106.GPC6.all_day_P_vs_near_far_ratio_amp(b:b+size(dva,1)-1,1) = dva(:,1);
    fig5_rev_20231106.GPC6.all_day_P_vs_near_far_ratio_amp(b:b+size(dva,1)-1,2) = dva(:,6);
    fig5_rev_20231106.GPC6.all_day_P_vs_near_far_ratio_are(b:b+size(dva,1)-1,1) = dva(:,1);
    fig5_rev_20231106.GPC6.all_day_P_vs_near_far_ratio_are(b:b+size(dva,1)-1,2) = dva(:,7);
    fig5_rev_20231106.GPC6.all_day_P_vs_near_far_ratio_rhy(b:b+size(dva,1)-1,1) = dva(:,1);
    fig5_rev_20231106.GPC6.all_day_P_vs_near_far_ratio_rhy(b:b+size(dva,1)-1,2) = dva(:,8);
    a = a+size(dva,1)-1
    b = b+size(dva,1)
end

a=1
b=1
for u = 1:size(fig5_rev_20231106.GPC6.all_tum_gro_vs_near_far_ratio_apm,1)
    if fig5_rev_20231106.GPC6.all_tum_gro_vs_near_far_ratio_apm(u,1) < 100000
        fig5_rev_20231106.GPC6.below_or_above10to5_apm(a,1) = fig5_rev_20231106.GPC6.all_tum_gro_vs_near_far_ratio_apm(u,2)
        fig5_rev_20231106.GPC6.below_or_above10to5_eps(a,1) = fig5_rev_20231106.GPC6.all_tum_gro_vs_near_far_ratio_eps(u,2)
        fig5_rev_20231106.GPC6.below_or_above10to5_dur(a,1) = fig5_rev_20231106.GPC6.all_tum_gro_vs_near_far_ratio_dur(u,2)
        fig5_rev_20231106.GPC6.below_or_above10to5_amp(a,1) = fig5_rev_20231106.GPC6.all_tum_gro_vs_near_far_ratio_amp(u,2)
        fig5_rev_20231106.GPC6.below_or_above10to5_are(a,1) = fig5_rev_20231106.GPC6.all_tum_gro_vs_near_far_ratio_are(u,2)
        fig5_rev_20231106.GPC6.below_or_above10to5_rhy(a,1) = fig5_rev_20231106.GPC6.all_tum_gro_vs_near_far_ratio_rhy(u,2)
        a=a+1
    else
        fig5_rev_20231106.GPC6.below_or_above10to5_apm(b,2) = fig5_rev_20231106.GPC6.all_tum_gro_vs_near_far_ratio_apm(u,2)
        fig5_rev_20231106.GPC6.below_or_above10to5_eps(b,2) = fig5_rev_20231106.GPC6.all_tum_gro_vs_near_far_ratio_eps(u,2)
        fig5_rev_20231106.GPC6.below_or_above10to5_dur(b,2) = fig5_rev_20231106.GPC6.all_tum_gro_vs_near_far_ratio_dur(u,2)
        fig5_rev_20231106.GPC6.below_or_above10to5_amp(b,2) = fig5_rev_20231106.GPC6.all_tum_gro_vs_near_far_ratio_amp(u,2)
        fig5_rev_20231106.GPC6.below_or_above10to5_are(b,2) = fig5_rev_20231106.GPC6.all_tum_gro_vs_near_far_ratio_are(u,2)
        fig5_rev_20231106.GPC6.below_or_above10to5_rhy(b,2) = fig5_rev_20231106.GPC6.all_tum_gro_vs_near_far_ratio_rhy(u,2)
        b=b+1
    end
end
a=a-1
b=b-1
if a<b
    m6=b
    fig5_rev_20231106.GPC6.below_or_above10to5_apm(a+1:b,1) = NaN
    fig5_rev_20231106.GPC6.below_or_above10to5_eps(a+1:b,1) = NaN
    fig5_rev_20231106.GPC6.below_or_above10to5_dur(a+1:b,1) = NaN
    fig5_rev_20231106.GPC6.below_or_above10to5_amp(a+1:b,1) = NaN
    fig5_rev_20231106.GPC6.below_or_above10to5_are(a+1:b,1) = NaN
    fig5_rev_20231106.GPC6.below_or_above10to5_rhy(a+1:b,1) = NaN
else
    m6=a
    fig5_rev_20231106.GPC6.below_or_above10to5_apm(b+1:a,2) = NaN
    fig5_rev_20231106.GPC6.below_or_above10to5_eps(b+1:a,2) = NaN
    fig5_rev_20231106.GPC6.below_or_above10to5_dur(b+1:a,2) = NaN
    fig5_rev_20231106.GPC6.below_or_above10to5_amp(b+1:a,2) = NaN
    fig5_rev_20231106.GPC6.below_or_above10to5_are(b+1:a,2) = NaN
    fig5_rev_20231106.GPC6.below_or_above10to5_rhy(b+1:a,2) = NaN
end

if m86 > m6
    fig5_rev_20231106.both.below_or_above10to5_apm(:,1:2) = fig5_rev_20231106.Cr86.below_or_above10to5_apm
    fig5_rev_20231106.both.below_or_above10to5_apm(1:m6,3:4) = fig5_rev_20231106.GPC6.below_or_above10to5_apm
    fig5_rev_20231106.both.below_or_above10to5_apm(m6+1:m86,3:4) = NaN;
    fig5_rev_20231106.both.below_or_above10to5_eps(:,1:2) = fig5_rev_20231106.Cr86.below_or_above10to5_eps
    fig5_rev_20231106.both.below_or_above10to5_eps(1:m6,3:4) = fig5_rev_20231106.GPC6.below_or_above10to5_eps
    fig5_rev_20231106.both.below_or_above10to5_eps(m6+1:m86,3:4) = NaN;
    fig5_rev_20231106.both.below_or_above10to5_dur(:,1:2) = fig5_rev_20231106.Cr86.below_or_above10to5_dur
    fig5_rev_20231106.both.below_or_above10to5_dur(1:m6,3:4) = fig5_rev_20231106.GPC6.below_or_above10to5_dur
    fig5_rev_20231106.both.below_or_above10to5_dur(m6+1:m86,3:4) = NaN;
    fig5_rev_20231106.both.below_or_above10to5_amp(:,1:2) = fig5_rev_20231106.Cr86.below_or_above10to5_amp
    fig5_rev_20231106.both.below_or_above10to5_amp(1:m6,3:4) = fig5_rev_20231106.GPC6.below_or_above10to5_amp
    fig5_rev_20231106.both.below_or_above10to5_amp(m6+1:m86,3:4) = NaN;
    fig5_rev_20231106.both.below_or_above10to5_are(:,1:2) = fig5_rev_20231106.Cr86.below_or_above10to5_are
    fig5_rev_20231106.both.below_or_above10to5_are(1:m6,3:4) = fig5_rev_20231106.GPC6.below_or_above10to5_are
    fig5_rev_20231106.both.below_or_above10to5_are(m6+1:m86,3:4) = NaN;
    fig5_rev_20231106.both.below_or_above10to5_rhy(:,1:2) = fig5_rev_20231106.Cr86.below_or_above10to5_rhy
    fig5_rev_20231106.both.below_or_above10to5_rhy(1:m6,3:4) = fig5_rev_20231106.GPC6.below_or_above10to5_rhy
    fig5_rev_20231106.both.below_or_above10to5_rhy(m6+1:m86,3:4) = NaN;
else
    fig5_rev_20231106.both.below_or_above10to5_apm(:,1:2) = fig5_rev_20231106.Cr86.below_or_above10to5_apm
    fig5_rev_20231106.both.below_or_above10to5_apm(m86+1:m6,3:4) = NaN;
    fig5_rev_20231106.both.below_or_above10to5_apm(:,3:4) = fig5_rev_20231106.GPC6.below_or_above10to5_apm
    fig5_rev_20231106.both.below_or_above10to5_eps(:,1:2) = fig5_rev_20231106.Cr86.below_or_above10to5_eps
    fig5_rev_20231106.both.below_or_above10to5_eps(m86+1:m6,3:4) = NaN;
    fig5_rev_20231106.both.below_or_above10to5_eps(:,3:4) = fig5_rev_20231106.GPC6.below_or_above10to5_eps
    fig5_rev_20231106.both.below_or_above10to5_dur(:,1:2) = fig5_rev_20231106.Cr86.below_or_above10to5_dur
    fig5_rev_20231106.both.below_or_above10to5_dur(m86+1:m6,3:4) = NaN;
    fig5_rev_20231106.both.below_or_above10to5_dur(:,3:4) = fig5_rev_20231106.GPC6.below_or_above10to5_dur
    fig5_rev_20231106.both.below_or_above10to5_amp(:,1:2) = fig5_rev_20231106.Cr86.below_or_above10to5_amp
    fig5_rev_20231106.both.below_or_above10to5_amp(m86+1:m6,3:4) = NaN;
    fig5_rev_20231106.both.below_or_above10to5_amp(:,3:4) = fig5_rev_20231106.GPC6.below_or_above10to5_amp
    fig5_rev_20231106.both.below_or_above10to5_are(:,1:2) = fig5_rev_20231106.Cr86.below_or_above10to5_are
    fig5_rev_20231106.both.below_or_above10to5_are(m86+1:m6,3:4) = NaN;
    fig5_rev_20231106.both.below_or_above10to5_are(:,3:4) = fig5_rev_20231106.GPC6.below_or_above10to5_are
    fig5_rev_20231106.both.below_or_above10to5_rhy(:,1:2) = fig5_rev_20231106.Cr86.below_or_above10to5_rhy
    fig5_rev_20231106.both.below_or_above10to5_rhy(m86+1:m6,3:4) = NaN;
    fig5_rev_20231106.both.below_or_above10to5_rhy(:,3:4) = fig5_rev_20231106.GPC6.below_or_above10to5_rhy
end


close all
[p1,t1,stats1] = kruskalwallis(fig5_rev_20231106.both.below_or_above10to5_apm)
saveas(2,['boxplot_kruskalwallis_both_below_or_above10to5_apm_20231106' '.svg'], 'svg');
saveas(2,['boxplot_kruskalwallis_both_below_or_above10to5_apm_20231106' '.pdf'], 'pdf');
[comparison,means,H,gnames1] = multcompare(stats1);
fig5_rev_20231106.both.below_or_above10to5_apm_stats.anova_p = p1;
fig5_rev_20231106.both.below_or_above10to5_apm_stats.anova_tab = t1;
fig5_rev_20231106.both.below_or_above10to5_apm_stats.mult_comparison = comparison;
fig5_rev_20231106.both.below_or_above10to5_apm_stats.mult_means = means;
fig5_rev_20231106.both.below_or_above10to5_apm_stats.stats1 = stats1;
saveas(H,['multcomp_kruskalwallis_both_below_or_above10to5_apm_20231106' '.png'], 'png')
saveas(H,['multcomp_kruskalwallis_both_below_or_above10to5_apm_20231106' '.pdf'], 'pdf')

close all
[p1,t1,stats1] = kruskalwallis(fig5_rev_20231106.both.below_or_above10to5_eps)
saveas(2,['boxplot_kruskalwallis_both_below_or_above10to5_eps_20231106' '.svg'], 'svg');
saveas(2,['boxplot_kruskalwallis_both_below_or_above10to5_eps_20231106' '.pdf'], 'pdf');
[comparison,means,H,gnames1] = multcompare(stats1);
fig5_rev_20231106.both.below_or_above10to5_eps_stats.anova_p = p1;
fig5_rev_20231106.both.below_or_above10to5_eps_stats.anova_tab = t1;
fig5_rev_20231106.both.below_or_above10to5_eps_stats.mult_comparison = comparison;
fig5_rev_20231106.both.below_or_above10to5_eps_stats.mult_means = means;
fig5_rev_20231106.both.below_or_above10to5_eps_stats.stats1 = stats1;
saveas(H,['multcomp_kruskalwallis_both_below_or_above10to5_eps_20231106' '.png'], 'png')
saveas(H,['multcomp_kruskalwallis_both_below_or_above10to5_eps_20231106' '.pdf'], 'pdf')

close all
[p1,t1,stats1] = kruskalwallis(fig5_rev_20231106.both.below_or_above10to5_dur)
saveas(2,['boxplot_kruskalwallis_both_below_or_above10to5_dur_20231106' '.svg'], 'svg');
saveas(2,['boxplot_kruskalwallis_both_below_or_above10to5_dur_20231106' '.pdf'], 'pdf');
[comparison,means,H,gnames1] = multcompare(stats1);
fig5_rev_20231106.both.below_or_above10to5_dur_stats.anova_p = p1;
fig5_rev_20231106.both.below_or_above10to5_dur_stats.anova_tab = t1;
fig5_rev_20231106.both.below_or_above10to5_dur_stats.mult_comparison = comparison;
fig5_rev_20231106.both.below_or_above10to5_dur_stats.mult_means = means;
fig5_rev_20231106.both.below_or_above10to5_dur_stats.stats1 = stats1;
saveas(H,['multcomp_kruskalwallis_both_below_or_above10to5_dur_20231106' '.png'], 'png')
saveas(H,['multcomp_kruskalwallis_both_below_or_above10to5_dur_20231106' '.pdf'], 'pdf')

close all
[p1,t1,stats1] = kruskalwallis(fig5_rev_20231106.both.below_or_above10to5_amp)
saveas(2,['boxplot_kruskalwallis_both_below_or_above10to5_amp_20231106' '.svg'], 'svg');
saveas(2,['boxplot_kruskalwallis_both_below_or_above10to5_amp_20231106' '.pdf'], 'pdf');
[comparison,means,H,gnames1] = multcompare(stats1);
fig5_rev_20231106.both.below_or_above10to5_amp_stats.anova_p = p1;
fig5_rev_20231106.both.below_or_above10to5_amp_stats.anova_tab = t1;
fig5_rev_20231106.both.below_or_above10to5_amp_stats.mult_comparison = comparison;
fig5_rev_20231106.both.below_or_above10to5_amp_stats.mult_means = means;
fig5_rev_20231106.both.below_or_above10to5_amp_stats.stats1 = stats1;
saveas(H,['multcomp_kruskalwallis_both_below_or_above10to5_amp_20231106' '.png'], 'png')
saveas(H,['multcomp_kruskalwallis_both_below_or_above10to5_amp_20231106' '.pdf'], 'pdf')

close all
[p1,t1,stats1] = kruskalwallis(fig5_rev_20231106.both.below_or_above10to5_are)
saveas(2,['boxplot_kruskalwallis_both_below_or_above10to5_are_20231106' '.svg'], 'svg');
saveas(2,['boxplot_kruskalwallis_both_below_or_above10to5_are_20231106' '.pdf'], 'pdf');
[comparison,means,H,gnames1] = multcompare(stats1);
fig5_rev_20231106.both.below_or_above10to5_are_stats.anova_p = p1;
fig5_rev_20231106.both.below_or_above10to5_are_stats.anova_tab = t1;
fig5_rev_20231106.both.below_or_above10to5_are_stats.mult_comparison = comparison;
fig5_rev_20231106.both.below_or_above10to5_are_stats.mult_means = means;
fig5_rev_20231106.both.below_or_above10to5_are_stats.stats1 = stats1;
saveas(H,['multcomp_kruskalwallis_both_below_or_above10to5_are_20231106' '.png'], 'png')
saveas(H,['multcomp_kruskalwallis_both_below_or_above10to5_are_20231106' '.pdf'], 'pdf')

close all
[p1,t1,stats1] = kruskalwallis(fig5_rev_20231106.both.below_or_above10to5_rhy)
saveas(2,['boxplot_kruskalwallis_both_below_or_above10to5_rhy_20231106' '.svg'], 'svg');
saveas(2,['boxplot_kruskalwallis_both_below_or_above10to5_rhy_20231106' '.pdf'], 'pdf');
[comparison,means,H,gnames1] = multcompare(stats1);
fig5_rev_20231106.both.below_or_above10to5_rhy_stats.anova_p = p1;
fig5_rev_20231106.both.below_or_above10to5_rhy_stats.anova_tab = t1;
fig5_rev_20231106.both.below_or_above10to5_rhy_stats.mult_comparison = comparison;
fig5_rev_20231106.both.below_or_above10to5_rhy_stats.mult_means = means;
fig5_rev_20231106.both.below_or_above10to5_rhy_stats.stats1 = stats1;
saveas(H,['multcomp_kruskalwallis_both_below_or_above10to5_rhy_20231106' '.png'], 'png')
saveas(H,['multcomp_kruskalwallis_both_below_or_above10to5_rhy_20231106' '.pdf'], 'pdf')

