
% close all
% 
% %if macbook_pro files not there
% % 
% stim_params.contrasts=[15,40,70,100]
% stim_params.orientations=[0,45,90,135,180,225,270,315]
% stim_params.blank_time=20000
% stim_params.stim_time=10000
% stim_params.repetitions = 370

%Folder = 'P:\StimulationData 4\StimulationData\Sang_mice\GratingExperiment2PhotonbySang\2018-10-19\14-53-37\';
close all
Folder = subfolders(iii).name;
cd(Folder_master)
cd(Folder)
initial = recording(iii).initial;
%Namestim = dir(strcat(Folder,'/G*.mat'));
Namestim = dir('Gr*.mat')
initial.trig_factor = 1000/recording(iii).initial2.triggersync_hz        %0.1;

if isempty(Namestim)
    recording(iii).vis_results.no_vis_stim = 1;
    recording(iii).first_spont_fr = 1
else
    
    FileNamestim = Namestim.name
    stim = load (FileNamestim);
    % populate stimulation parameters field
    b = isfield(stim, 'stim');
    if b
        m = max(size(stim.stim.params.trials));
        %m=2
        stim_params.stim_time = stim.stim.params.trials(1,m).stimFrames*1000/(60*initial.trig_factor);
        stim_params.blank_time = stim.stim.params.trials(1,m).blankFrames*1000/(60*initial.trig_factor);
        stim_params.total_time = stim.stim.params.trials(1,m).stimulusTime*1000/initial.trig_factor;
        stim_params.repetitions = stim_params.total_time/(stim_params.stim_time+stim_params.blank_time);
        stim_params.spatial_freq = stim.stim.params.trials(1,m).spatialFreq;
        stim_params.temp_freq = stim.stim.params.trials(1,m).tempoFreq;
        stim_params.contrasts = stim.stim.params.trials(1,m).contrast;
        stim_params.orientations = stim.stim.params.trials(1,m).orientation;
    else
        m = max(size(stim.params.trials));
        %m=2
        stim_params.stim_time = stim.params.trials(1,m).stimFrames*1000/(60*initial.trig_factor);
        stim_params.blank_time = stim.params.trials(1,m).blankFrames*1000/(60*initial.trig_factor);
        stim_params.total_time = stim.params.trials(1,m).stimulusTime*1000/initial.trig_factor;
        stim_params.repetitions = stim_params.total_time/(stim_params.stim_time+stim_params.blank_time);
        stim_params.spatial_freq = stim.params.trials(1,m).spatialFreq;
        stim_params.temp_freq = stim.params.trials(1,m).tempoFreq;
        stim_params.contrasts = stim.params.trials(1,m).contrast;
        stim_params.orientations = stim.params.trials(1,m).orientation;
    end
    %Name3 = dir(strcat(Folder,'/00*.nex'));
    Name3 = dir('00*.nex')
    nex_FileName = Name3.name
    s = nex2mat(Folder,nex_FileName);
    %set the timestamp in data struct. sortStimEvent will do a length check on the ts array with event array
    timestamps = 1:stim_params.repetitions;
    s = setTimeStamp(s,timestamps);
    %retrieve the full set of stimulus events lookup table from s.
    %retrieve marker from nex file
    marker = s.nexData.markers{1};
    %stim variable set
    encode_vars = cell(1,length(marker.values));
    for j = 1 : length(marker.values)
        encode_vars{j} = marker.values{j}.name;
    end
    %keywords for event-sorting. full set of LUT returned when all variables
    %are true, i.e, '>0'
    event = struct;
    for j = 1 : length(encode_vars)
        event(j).type = encode_vars{j};
        event(j).string = '>0';
        event(j).operator = '&';
    end
    %retrive the full set of stim-event-lookup table.
    [stim_params.t_SETS,stim_params.StimEventLUT] = sortStimEvent(s,event);
    % stim_params.t_SETS = timestamps;
    % stim_params.StimEventLUT = codes;
    t_SETS = stim_params.t_SETS;
    StimEventLUT = stim_params.StimEventLUT;
    stim_params.StimEventLUT = StimEventLUT;
    %cell = results.cellnumber;
    clear smoothrawData2 flatrawData2 results
    smoothrawData2 (:,1) = smooth (recording(iii).initial.rawData2 (:,3), length(recording(iii).initial.rawData2(:,1))/(30/initial.trig_factor));
    flatrawData2 (:,1) = recording(iii).initial.rawData2 (:,3) - smoothrawData2 (:,1) ;
    results.flat_PD_trace = flatrawData2;
    
    figure(235)
    plot(results.flat_PD_trace)
    
    pause
    
    clear answer
    prompt = {'mute rest of flat PD trace (cutoff)?'};
    dlg_title = 'PD trace cutoff';
    num_lines = 1;
    def = {'15000000,0'};
    answer = inputdlg(prompt,dlg_title,num_lines,def);
    cutofff = str2num(answer{1})
    cutoff = cutofff(1,1);
    level = cutofff(1,2);
    results.flat_PD_trace(cutoff:size(results.flat_PD_trace,1),1) = level;
    initial2=recording(iii).initial2;
    prompt = {'how many ms maximum after stim offset for analysis?'};
    dlg_title = 'max. analysis ms';
    num_lines = 1;
    def = {'1500'};
    answer = inputdlg(prompt,dlg_title,num_lines,def);
    analysis_ms = str2num(answer{1});
    analysis_ms_1 = stim_params.stim_time*initial.trig_factor + analysis_ms;
    %analysis_ms_1 = stim_params.stim_time*initial.trig_factor + stim_params.blank_time*initial.trig_factor;
    analysis_period = ceil(analysis_ms_1/initial2.msperline);
    results.flat_PD_trace(1:initial2.mirror_start_time(1,1) ,:) = [];
    clear sorted_start start_thr i
    %get the stimulus onet times from teh photodiode trace
    sorted_start = sort(results.flat_PD_trace(1100/initial.trig_factor:round(110000/initial.trig_factor)),'descend');
    start_thr = mean(sorted_start(round(40/initial.trig_factor):round(80/initial.trig_factor)))*0.85
    %
    %     if PD_start_ms > 2000
    %         i = PD_start_ms;
    %     else
    if m == 1
        i = round(8000/initial.trig_factor);
    else
        i =round( 1300/initial.trig_factor)
    end
    while results.flat_PD_trace(i,1)<start_thr
        i=i+1;
    end
    % end
    results.thresh_PD = max(results.flat_PD_trace(i-round(2700/initial.trig_factor):i+round(700/initial.trig_factor),1))*0.6;
    i = round(i-round(200/initial.trig_factor));
    while results.flat_PD_trace(i,1)<results.thresh_PD
        i=i+1;
    end
    start = i
    clear  onset_time_vector ...
        onset_time_vector_deltaf stim_onset_times stim_onset_times_deltaf
    stim_onset_times(1,1) = start;
    stim_onset_times_deltaf(1,1) = round(start/(initial2.msperline/initial.trig_factor));
    onset_time_vector(1,start) = 10;
    onset_time_vector_deltaf(1,round(start/(initial2.msperline/initial.trig_factor))) = 10;
    j = round(start);
    for i = 1:stim_params.repetitions-1
        i
        if j+stim_params.stim_time+stim_params.blank_time-stim_params.blank_time/10<length(results.flat_PD_trace)
            j = round(j + stim_params.stim_time + stim_params.blank_time - round(stim_params.blank_time/6));
            while results.flat_PD_trace(j,1)<results.thresh_PD && j<length(results.flat_PD_trace)
                if j<length(results.flat_PD_trace)
                    j=j+1;
                end
            end
            stim_onset_times(1,i+1)=j;
            stim_onset_times_deltaf(1,i+1) = round(j/(initial2.msperline/initial.trig_factor));
            onset_time_vector(1,j) = 10;
            onset_time_vector_deltaf(1,round(j/(initial2.msperline/initial.trig_factor))) = 10;
        end
    end
    results.stim_onset_times_deltaf=stim_onset_times_deltaf;
    results.onset_time_vector= onset_time_vector;
    results.onset_time_vector_deltaf=onset_time_vector_deltaf;
    results.stim_onset_times= stim_onset_times;
    results.diff_stim_onset_times = diff(stim_onset_times);
    results.diff_stim_onset_times_deltaf = diff(stim_onset_times_deltaf);
    figure(909)
    plot(results.diff_stim_onset_times_deltaf)
    options.WindowStyle = 'normal';
    prompt = {'does this look right?'};
    dlg_title = 'diff_stim_frames';
    num_lines = 1;
    def = {'1'};
    answer = inputdlg(prompt,dlg_title,num_lines,def,options);
    wer = str2mat(answer);
    wer = str2num(wer);
    
    
    results.stim_params = stim_params;
    recording(iii).vis_results = results;
    block_reps = stim_params.repetitions/(length(stim_params.orientations)*length(stim_params.contrasts))
    recording(iii).vis_results.block_reps = block_reps;
    
    
    recording(iii).first_spont_fr = recording(iii).vis_results.stim_onset_times_deltaf(1,end) + ...
        round(20*recording(iii).initial2.samplingratehz)
end
