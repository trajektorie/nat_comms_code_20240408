%%% run for each animal
load('recording_ta3.mat')

animal_ID = xxxxxxxxxxxxxxx;
Cr86 = 0;
GPC6 = 0;
IGSF3 = 0;
xCT_KO = 0;
control = 0;

tumor_animal(animal_ID).onep.Cr86 = Cr86;
tumor_animal(animal_ID).onep.GPC6 = GPC6;
tumor_animal(animal_ID).onep.IGSF3 = IGSF3;
tumor_animal(animal_ID).onep.xCT_KO = xCT_KO;
tumor_animal(animal_ID).onep.control = control;
tumor_animal(animal_ID).onep.ta3_analysis = recording_ta3;
%%%%%%%%%%%%

load("ccmap_15bins.mat")
colors = cbrewer('qual', 'Set1', 15);

%combine all Cr86_unnormed recs
clear Cr86_unnormed Cr86_unnormed_by_animal
jj=1
a=1;
aa=1;
bb=1
bbi=1
bb7=1
tum_gro_or_CV_p_D = 3; %(3 = tum_gro, 10 = CV/D)
if tum_gro_or_CV_p_D==3
    tg = 'tum_gro'
else
    tg = 'CV_p_D'
end
for f =  [15 21 28 38 40]   
    if ~isempty(tumor_animal(f).onep)
        if tumor_animal(f).onep.Cr86
            close all
            s=1
            ta3pp = tumor_animal(f).onep.ta3_analysis(1).day_P_vs_other_params;
            ta3pp(:,9) = tumor_animal(f).onep.ta3_analysis(1).pval_contr;
            todelvec=0
            ta3ppfov=ta3pp;
            for h = 2:size(ta3pp,1)
                if isnan(ta3pp(h,2)) || sum(ta3pp(h,2:8))==0 || (f==21 && (h==4 || h==6 || h==9)) ||...
                        (f==28 && (h==2 || h==4 || h==5 || h==7 || h==15 || h==16 || h==17 || h==19 || h==20))
                    todelvec(s,1) = h;
                    s=s+1
                end
            end
            if todelvec==0
            else
                ta3pp(todelvec,:) = [];
                ta3ppfov(todelvec,:) = [];

            end
            tumor_animal(f).onep.ta3_analysis(1).todelvec = todelvec;
            sx = size(ta3pp,1)
            Cr86_unnormed.all_day_P_vs_amplitude(a:a+sx-2,1) = ta3pp(2:sx,1);
            Cr86_unnormed.all_day_P_vs_amplitude(a:a+sx-2,2) = ta3pp(2:sx,4);
            Cr86_unnormed.all_day_P_vs_amplitude(a:a+sx-2,3) = ta3pp(2:sx,4)<ta3pp(2:sx,9);
            Cr86_unnormed.all_day_P_vs_apm(a:a+sx-2,1) = ta3pp(2:sx,1);
            Cr86_unnormed.all_day_P_vs_apm(a:a+sx-2,2) = ta3pp(2:sx,5);
            Cr86_unnormed.all_day_P_vs_apm(a:a+sx-2,3) = ta3pp(2:sx,5)<ta3pp(2:sx,9);
            Cr86_unnormed.all_day_P_vs_area(a:a+sx-2,1) = ta3pp(2:sx,1);
            Cr86_unnormed.all_day_P_vs_area(a:a+sx-2,2) = ta3pp(2:sx,6);
            Cr86_unnormed.all_day_P_vs_area(a:a+sx-2,3) = ta3pp(2:sx,6)<ta3pp(2:sx,9);
            Cr86_unnormed.all_day_P_vs_eps(a:a+sx-2,1) = ta3pp(2:sx,1);
            Cr86_unnormed.all_day_P_vs_eps(a:a+sx-2,2) = ta3pp(2:sx,7);
            Cr86_unnormed.all_day_P_vs_eps(a:a+sx-2,3) = ta3pp(2:sx,7)<ta3pp(2:sx,9);
            Cr86_unnormed.all_day_P_vs_rhythm(a:a+sx-2,1) = ta3pp(2:sx,1);
            Cr86_unnormed.all_day_P_vs_rhythm(a:a+sx-2,2) = ta3pp(2:sx,8);
            Cr86_unnormed.all_day_P_vs_rhythm(a:a+sx-2,3) = ta3pp(2:sx,8)<ta3pp(2:sx,9);
            Cr86_unnormed.all_tum_gro_vs_amplitude(a:a+sx-2,1) = ta3pp(2:sx,3);
            Cr86_unnormed.all_tum_gro_vs_amplitude(a:a+sx-2,2) = ta3pp(2:sx,4);
            Cr86_unnormed.all_tum_gro_vs_amplitude(a:a+sx-2,3) = ta3pp(2:sx,4)<ta3pp(2:sx,9);

            Cr86_unnormed.all_tum_gro_vs_apm(a:a+sx-2,1) = ta3pp(2:sx,3);
            Cr86_unnormed.all_tum_gro_vs_apm(a:a+sx-2,2) = ta3pp(2:sx,5);
            Cr86_unnormed.all_tum_gro_vs_apm(a:a+sx-2,3) = ta3pp(2:sx,5)<ta3pp(2:sx,9);
            Cr86_unnormed.all_tum_gro_vs_area(a:a+sx-2,1) = ta3pp(2:sx,3);
            Cr86_unnormed.all_tum_gro_vs_area(a:a+sx-2,2) = ta3pp(2:sx,6);
            Cr86_unnormed.all_tum_gro_vs_area(a:a+sx-2,3) = ta3pp(2:sx,6)<ta3pp(2:sx,9);
            Cr86_unnormed.all_tum_gro_vs_eps(a:a+sx-2,1) = ta3pp(2:sx,3);
            Cr86_unnormed.all_tum_gro_vs_eps(a:a+sx-2,2) = ta3pp(2:sx,7);
            Cr86_unnormed.all_tum_gro_vs_eps(a:a+sx-2,3) = ta3pp(2:sx,7)<ta3pp(2:sx,9);
            Cr86_unnormed.all_tum_gro_vs_rhythm(a:a+sx-2,1) = ta3pp(2:sx,3);
            Cr86_unnormed.all_tum_gro_vs_rhythm(a:a+sx-2,2) = ta3pp(2:sx,8);
            Cr86_unnormed.all_tum_gro_vs_rhythm(a:a+sx-2,3) = ta3pp(2:sx,8)<ta3pp(2:sx,9);

            %whole-FOV analysis
            fovs = tumor_animal(f).onep.ta3_analysis.FOV_stats;
            if todelvec>0
                fovs.tafov_apm_all(:,todelvec) = [];
                fovs.tafov_eps_all(:,todelvec) = [];
                fovs.tafov_length_all(:,todelvec) = [];
                fovs.tafov_amp_all(:,todelvec) = [];
                fovs.tafov_area_all(:,todelvec) = [];
                fovs.tafov_IEI_all(:,todelvec) = [];
                fovs.tafov_rhythm_all(:,todelvec) = [];
                %normalize, then plot shaded errorbars?
            end
          
            rm=1
            if f==21
                rm=2;
            end
            pl1 = fovs.tafov_apm_all(:,rm);
            pl1(find(isnan(pl1))) = [];
            nn1 = mean(pl1);
            nn1=1
            pl2 = fovs.tafov_eps_all(:,rm);
            pl2(find(isnan(pl2))) = [];
            nn2 = mean(pl2);
            nn2=1
            pl3 = fovs.tafov_length_all(:,rm);
            pl3(find(isnan(pl3))) = [];
            nn3 = mean(pl3);
            nn3=1
            pl4 = fovs.tafov_amp_all(:,rm);
            pl4(find(isnan(pl4))) = [];
            nn4 = mean(pl4);
            nn4=1
            pl5 = fovs.tafov_area_all(:,rm);
            pl5(find(isnan(pl5))) = [];
            nn5 = mean(pl5);
            nn5=1
            pl6 = fovs.tafov_IEI_all(:,rm);
            pl6(find(isnan(pl6))) = [];
            nn6 = mean(pl6);
            nn6=1
            pl7 = fovs.tafov_rhythm_all(:,rm);
            pl7(find(pl7==Inf)) = NaN;
            pl7(find(isnan(pl7))) = [];

            nn7 = mean(pl7);
            nn7=1
            Cr86_unnormed_by_animal(jj).rec(1).day_P = ta3ppfov(1,1);
            for o=2:size(fovs.tafov_apm_all,2)
              
                oo=o
                plr1 = fovs.tafov_apm_all(:,o);
                plr1(find(isnan(plr1))) = [];
                plr1(find(plr1==0)) = [];    %added these to delete all zeros 20231122 JM
                plr1_norm = plr1/nn1;

                plr2 = fovs.tafov_eps_all(:,o);
                plr2(find(isnan(plr2))) = [];
                plr2(find(plr2==0)) = [];
                plr2_norm = plr2/nn2;

                plr3 = fovs.tafov_length_all(:,o);
                plr3(find(isnan(plr3))) = [];
                plr3(find(plr3==0)) = [];
                plr3_norm = plr3/nn3;

                plr4 = fovs.tafov_amp_all(:,o);
                plr4(find(isnan(plr4))) = [];
                plr4(find(plr4==0)) = [];
                plr4_norm = plr4/nn4;

                plr5 = fovs.tafov_area_all(:,o);
                plr5(find(isnan(plr5))) = [];
                plr5(find(plr5==0)) = [];
                plr5_norm = plr5/nn5;

                plr6 = fovs.tafov_IEI_all(:,o);
                plr6(find(isnan(plr6))) = [];
                plr6(find(plr6==0)) = [];
                plr6_norm = plr6/nn6;
                bbpi = length(plr6);

                plr7 = fovs.tafov_rhythm_all(:,o);
                plr7(find(plr7==Inf)) = NaN;
                plr7(find(isnan(plr7))) = [];
                plr7(find(plr7==0)) = [];
                plr7_norm = plr7/nn7;
                bbp7=length(plr7_norm);

                bbp=length(plr1);

                
                Cr86_unnormed_by_animal(jj).rec(o).length = bbp;
                %%%%%%%%%%%%%% run this whole section once with teh
                %%%%%%%%%%%%%% commented out piece, then run again with the
                %%%%%%%%%%%%%% other one after adjusting tumor growth rate
                %%%%%%%%%%%%%% using  spline fit
                %%%%%
                % Cr86_unnormed_by_animal(jj).rec(o).tum_gro =...
                % ta3ppfov(oo,tum_gro_or_CV_p_D); 
                %%%%%

                Cr86_unnormed_by_animal(jj).rec(o).day_P = ta3ppfov(oo,1);
                 
                %%%%%%%
                ber =  tumor_animal(f).onep.tum_gro_divbypoint5to6_spline_w_apm;
                inb = find(ber(:,1)==Cr86_unnormed_by_animal(jj).rec(o).day_P)
                if jj==1 && o==12
                    inb=45
                end
                if jj==2 && o==7
                    inb = 56
                end
                if jj==3 && o==10
                    inb = 53
                end
                if jj==4 && o==10
                    inb = 48
                end
                if jj==5 && o==8
                    inb = 37
                end
                Cr86_unnormed_by_animal(jj).rec(o).tum_gro = ...
                    ber(inb,3)*0.5e6;
                %%%%%%%%%   

                Cr86_unnormed.all_FOVs_pooled.apm.tum_gro_vs_all_pix_vals(bb:bb+bbp-1,1) = ta3ppfov(oo,tum_gro_or_CV_p_D); %was oo-1
                Cr86_unnormed.all_FOVs_pooled.apm.tum_gro_vs_all_pix_vals(bb:bb+bbp-1,2) = plr1_norm;
                Cr86_unnormed.all_FOVs_pooled.eps.tum_gro_vs_all_pix_vals(bb:bb+bbp-1,1) = ta3ppfov(oo,tum_gro_or_CV_p_D);
                Cr86_unnormed.all_FOVs_pooled.eps.tum_gro_vs_all_pix_vals(bb:bb+bbp-1,2) = plr2_norm;
                Cr86_unnormed.all_FOVs_pooled.length.tum_gro_vs_all_pix_vals(bb:bb+bbp-1,1) = ta3ppfov(oo,tum_gro_or_CV_p_D);
                Cr86_unnormed.all_FOVs_pooled.length.tum_gro_vs_all_pix_vals(bb:bb+bbp-1,2) = plr3_norm;
                Cr86_unnormed.all_FOVs_pooled.amp.tum_gro_vs_all_pix_vals(bb:bb+bbp-1,1) = ta3ppfov(oo,tum_gro_or_CV_p_D);
                Cr86_unnormed.all_FOVs_pooled.amp.tum_gro_vs_all_pix_vals(bb:bb+bbp-1,2) = plr4_norm;
                Cr86_unnormed.all_FOVs_pooled.area.tum_gro_vs_all_pix_vals(bb:bb+bbp-1,1) = ta3ppfov(oo,tum_gro_or_CV_p_D);
                Cr86_unnormed.all_FOVs_pooled.area.tum_gro_vs_all_pix_vals(bb:bb+bbp-1,2) = plr5_norm;
                Cr86_unnormed.all_FOVs_pooled.IEI.tum_gro_vs_all_pix_vals(bbi:bbi+bbpi-1,1) = ta3ppfov(oo,tum_gro_or_CV_p_D);
                Cr86_unnormed.all_FOVs_pooled.IEI.tum_gro_vs_all_pix_vals(bbi:bbi+bbpi-1,2) = plr6_norm;
                Cr86_unnormed.all_FOVs_pooled.rhythm.tum_gro_vs_all_pix_vals(bb7:bb7+bbp7-1,1) = ta3ppfov(oo,tum_gro_or_CV_p_D);
                Cr86_unnormed.all_FOVs_pooled.rhythm.tum_gro_vs_all_pix_vals(bb7:bb7+bbp7-1,2) = plr7_norm;
                bb=bb+bbp;
                bbi=bbi+bbpi;
                bb7=bb7+bbp7;
            end
            Cr86_unnormed.animal(f).FOV_pixel_num = bb-1;

            a=a+sx-1;
            aa=aa+ssx-1;
        end
    end
    jj=jj+1
end

if tum_gro_or_CV_p_D == 10
    ylim1 = 0
    ylim2 = 0.2
    thre = 0.018
else
    ylim1 = -4e5
    ylim2 = 5e5
    thre = 100000
end

initially_norm_by_first_rec = 1
a=1
Cr86_unnormed_anims = [15 21 28 38 40] 
for j = 1:5
    curr_anim = Cr86_unnormed_anims(1,j)
    if curr_anim>48
        a = Cr86_unnormed.animal(Cr86_unnormed_anims(1,j-1)).FOV_pixel_num+1
    end
    b = Cr86_unnormed.animal(curr_anim).FOV_pixel_num;
    Cr86_unnormed_by_animal(j).apm(1).tum_gro_vs_all_pix_vals =  Cr86_unnormed.all_FOVs_pooled.apm.tum_gro_vs_all_pix_vals(a:b,:)
    Cr86_unnormed_by_animal(j).eps(1).tum_gro_vs_all_pix_vals =  Cr86_unnormed.all_FOVs_pooled.eps.tum_gro_vs_all_pix_vals(a:b,:)
    Cr86_unnormed_by_animal(j).length(1).tum_gro_vs_all_pix_vals =  Cr86_unnormed.all_FOVs_pooled.length.tum_gro_vs_all_pix_vals(a:b,:)
    Cr86_unnormed_by_animal(j).amp(1).tum_gro_vs_all_pix_vals =  Cr86_unnormed.all_FOVs_pooled.amp.tum_gro_vs_all_pix_vals(a:b,:)
    Cr86_unnormed_by_animal(j).area(1).tum_gro_vs_all_pix_vals =  Cr86_unnormed.all_FOVs_pooled.area.tum_gro_vs_all_pix_vals(a:b,:)

    q=1
    r=1
    s=1
    tot_pixs = 1
    below_pixs=1
    for p = 2:size(Cr86_unnormed_by_animal(j).rec,2)
        curr_pixs = Cr86_unnormed_by_animal(j).rec(p).length
        Cr86_unnormed_by_animal(j).rec(p).day_P_tumgro_adjust = round((Cr86_unnormed_by_animal(j).rec(p).day_P + Cr86_unnormed_by_animal(j).rec(p-1).day_P)/2)
        if Cr86_unnormed_by_animal(j).rec(p).tum_gro>thre 
            Cr86_unnormed_by_animal(j).apm(1).all_tum_gro_vs_recs_means(s,3) = Cr86_unnormed_by_animal(j).rec(p).day_P
            Cr86_unnormed_by_animal(j).apm(1).all_tum_gro_vs_recs_means(s,4) = Cr86_unnormed_by_animal(j).rec(p).day_P_tumgro_adjust 
            Cr86_unnormed_by_animal(j).apm(1).all_tum_gro_vs_recs_means(s,1) = Cr86_unnormed_by_animal(j).rec(p).tum_gro
            Cr86_unnormed_by_animal(j).apm(1).all_tum_gro_vs_recs_means(s,2) = mean(Cr86_unnormed_by_animal(j).apm(1).tum_gro_vs_all_pix_vals(tot_pixs:tot_pixs+curr_pixs-1,2))
            Cr86_unnormed_by_animal(j).eps(1).all_tum_gro_vs_recs_means(s,1) = Cr86_unnormed_by_animal(j).rec(p).tum_gro
            Cr86_unnormed_by_animal(j).eps(1).all_tum_gro_vs_recs_means(s,2) = mean(Cr86_unnormed_by_animal(j).eps(1).tum_gro_vs_all_pix_vals(tot_pixs:tot_pixs+curr_pixs-1,2))
            Cr86_unnormed_by_animal(j).length(1).all_tum_gro_vs_recs_means(s,1) = Cr86_unnormed_by_animal(j).rec(p).tum_gro
            Cr86_unnormed_by_animal(j).length(1).all_tum_gro_vs_recs_means(s,2) = mean(Cr86_unnormed_by_animal(j).length(1).tum_gro_vs_all_pix_vals(tot_pixs:tot_pixs+curr_pixs-1,2))
            Cr86_unnormed_by_animal(j).amp(1).all_tum_gro_vs_recs_means(s,1) = Cr86_unnormed_by_animal(j).rec(p).tum_gro
            Cr86_unnormed_by_animal(j).amp(1).all_tum_gro_vs_recs_means(s,2) = mean(Cr86_unnormed_by_animal(j).amp(1).tum_gro_vs_all_pix_vals(tot_pixs:tot_pixs+curr_pixs-1,2))
            Cr86_unnormed_by_animal(j).area(1).all_tum_gro_vs_recs_means(s,1) = Cr86_unnormed_by_animal(j).rec(p).tum_gro
            Cr86_unnormed_by_animal(j).area(1).all_tum_gro_vs_recs_means(s,2) = mean(Cr86_unnormed_by_animal(j).area(1).tum_gro_vs_all_pix_vals(tot_pixs:tot_pixs+curr_pixs-1,2))
            s=s +1;
            Cr86_unnormed_by_animal(j).apm(q).above_10to5_recs = Cr86_unnormed_by_animal(j).apm(1).tum_gro_vs_all_pix_vals(tot_pixs:tot_pixs+curr_pixs-1,2);
            Cr86_unnormed_by_animal(j).apm(q).above_tum_gro = Cr86_unnormed_by_animal(j).rec(p).tum_gro
            Cr86_unnormed_by_animal(j).apm(1).above_tum_gro_means(q,1) = mean(Cr86_unnormed_by_animal(j).apm(q).above_10to5_recs)
            Cr86_unnormed_by_animal(j).eps(q).above_10to5_recs = Cr86_unnormed_by_animal(j).eps(1).tum_gro_vs_all_pix_vals(tot_pixs:tot_pixs+curr_pixs-1,2);
            Cr86_unnormed_by_animal(j).eps(q).above_tum_gro = Cr86_unnormed_by_animal(j).rec(p).tum_gro
            Cr86_unnormed_by_animal(j).eps(1).above_tum_gro_means(q,1) = mean(Cr86_unnormed_by_animal(j).eps(q).above_10to5_recs)
            Cr86_unnormed_by_animal(j).length(q).above_10to5_recs = Cr86_unnormed_by_animal(j).length(1).tum_gro_vs_all_pix_vals(tot_pixs:tot_pixs+curr_pixs-1,2);
            Cr86_unnormed_by_animal(j).length(q).above_tum_gro = Cr86_unnormed_by_animal(j).rec(p).tum_gro
            Cr86_unnormed_by_animal(j).length(1).above_tum_gro_means(q,1) = mean(Cr86_unnormed_by_animal(j).length(q).above_10to5_recs)
            Cr86_unnormed_by_animal(j).amp(q).above_10to5_recs = Cr86_unnormed_by_animal(j).amp(1).tum_gro_vs_all_pix_vals(tot_pixs:tot_pixs+curr_pixs-1,2);
            Cr86_unnormed_by_animal(j).amp(q).above_tum_gro = Cr86_unnormed_by_animal(j).rec(p).tum_gro
            Cr86_unnormed_by_animal(j).amp(1).above_tum_gro_means(q,1) = mean(Cr86_unnormed_by_animal(j).amp(q).above_10to5_recs)
            Cr86_unnormed_by_animal(j).area(q).above_10to5_recs = Cr86_unnormed_by_animal(j).area(1).tum_gro_vs_all_pix_vals(tot_pixs:tot_pixs+curr_pixs-1,2);
            Cr86_unnormed_by_animal(j).area(q).above_tum_gro = Cr86_unnormed_by_animal(j).rec(p).tum_gro
            Cr86_unnormed_by_animal(j).area(1).above_tum_gro_means(q,1) = mean(Cr86_unnormed_by_animal(j).area(q).above_10to5_recs)

            tot_pixs = tot_pixs+curr_pixs
            q=q+1;
        else
            Cr86_unnormed_by_animal(j).apm(1).all_tum_gro_vs_recs_means(s,3) = Cr86_unnormed_by_animal(j).rec(p).day_P %%new 20231127
            Cr86_unnormed_by_animal(j).apm(1).all_tum_gro_vs_recs_means(s,4) = Cr86_unnormed_by_animal(j).rec(p).day_P_tumgro_adjust %%new 20231127
            Cr86_unnormed_by_animal(j).apm(1).all_tum_gro_vs_recs_means(s,1) = Cr86_unnormed_by_animal(j).rec(p).tum_gro
            Cr86_unnormed_by_animal(j).apm(1).all_tum_gro_vs_recs_means(s,2) = mean(Cr86_unnormed_by_animal(j).apm(1).tum_gro_vs_all_pix_vals(tot_pixs:tot_pixs+curr_pixs-1,2))
            Cr86_unnormed_by_animal(j).eps(1).all_tum_gro_vs_recs_means(s,1) = Cr86_unnormed_by_animal(j).rec(p).tum_gro
            Cr86_unnormed_by_animal(j).eps(1).all_tum_gro_vs_recs_means(s,2) = mean(Cr86_unnormed_by_animal(j).eps(1).tum_gro_vs_all_pix_vals(tot_pixs:tot_pixs+curr_pixs-1,2))
            Cr86_unnormed_by_animal(j).length(1).all_tum_gro_vs_recs_means(s,1) = Cr86_unnormed_by_animal(j).rec(p).tum_gro
            Cr86_unnormed_by_animal(j).length(1).all_tum_gro_vs_recs_means(s,2) = mean(Cr86_unnormed_by_animal(j).length(1).tum_gro_vs_all_pix_vals(tot_pixs:tot_pixs+curr_pixs-1,2))
            Cr86_unnormed_by_animal(j).amp(1).all_tum_gro_vs_recs_means(s,1) = Cr86_unnormed_by_animal(j).rec(p).tum_gro
            Cr86_unnormed_by_animal(j).amp(1).all_tum_gro_vs_recs_means(s,2) = mean(Cr86_unnormed_by_animal(j).amp(1).tum_gro_vs_all_pix_vals(tot_pixs:tot_pixs+curr_pixs-1,2))
            Cr86_unnormed_by_animal(j).area(1).all_tum_gro_vs_recs_means(s,1) = Cr86_unnormed_by_animal(j).rec(p).tum_gro
            Cr86_unnormed_by_animal(j).area(1).all_tum_gro_vs_recs_means(s,2) = mean(Cr86_unnormed_by_animal(j).area(1).tum_gro_vs_all_pix_vals(tot_pixs:tot_pixs+curr_pixs-1,2))

            %pool all below 10to5 recs
            Cr86_unnormed_by_animal(j).apm(1).below_10to5_recs(below_pixs:below_pixs+curr_pixs-1,1) = ...
                Cr86_unnormed_by_animal(j).apm(1).tum_gro_vs_all_pix_vals(tot_pixs:tot_pixs+curr_pixs-1,2);
            Cr86_unnormed_by_animal(j).eps(1).below_10to5_recs(below_pixs:below_pixs+curr_pixs-1,1) = ...
                Cr86_unnormed_by_animal(j).eps(1).tum_gro_vs_all_pix_vals(tot_pixs:tot_pixs+curr_pixs-1,2);
            Cr86_unnormed_by_animal(j).length(1).below_10to5_recs(below_pixs:below_pixs+curr_pixs-1,1) = ...
                Cr86_unnormed_by_animal(j).length(1).tum_gro_vs_all_pix_vals(tot_pixs:tot_pixs+curr_pixs-1,2);
            Cr86_unnormed_by_animal(j).amp(1).below_10to5_recs(below_pixs:below_pixs+curr_pixs-1,1) = ...
                Cr86_unnormed_by_animal(j).amp(1).tum_gro_vs_all_pix_vals(tot_pixs:tot_pixs+curr_pixs-1,2);
            Cr86_unnormed_by_animal(j).area(1).below_10to5_recs(below_pixs:below_pixs+curr_pixs-1,1) = ...
                Cr86_unnormed_by_animal(j).area(1).tum_gro_vs_all_pix_vals(tot_pixs:tot_pixs+curr_pixs-1,2);

            Cr86_unnormed_by_animal(j).apm(r).below_10to5_recs_indiv = ...
                Cr86_unnormed_by_animal(j).apm(1).tum_gro_vs_all_pix_vals(tot_pixs:tot_pixs+curr_pixs-1,2);
            Cr86_unnormed_by_animal(j).apm(r).below_tum_gro = Cr86_unnormed_by_animal(j).rec(p).tum_gro
            Cr86_unnormed_by_animal(j).apm(1).below_10to5_recs_indiv_mean(r,1) = mean(Cr86_unnormed_by_animal(j).apm(r).below_10to5_recs_indiv);
            Cr86_unnormed_by_animal(j).eps(r).below_10to5_recs_indiv = ...
                Cr86_unnormed_by_animal(j).eps(1).tum_gro_vs_all_pix_vals(tot_pixs:tot_pixs+curr_pixs-1,2);
            Cr86_unnormed_by_animal(j).eps(r).below_tum_gro = Cr86_unnormed_by_animal(j).rec(p).tum_gro
            Cr86_unnormed_by_animal(j).eps(1).below_10to5_recs_indiv_mean(r,1) = mean(Cr86_unnormed_by_animal(j).eps(r).below_10to5_recs_indiv);
            Cr86_unnormed_by_animal(j).length(r).below_10to5_recs_indiv = ...
                Cr86_unnormed_by_animal(j).length(1).tum_gro_vs_all_pix_vals(tot_pixs:tot_pixs+curr_pixs-1,2);
            Cr86_unnormed_by_animal(j).length(r).below_tum_gro = Cr86_unnormed_by_animal(j).rec(p).tum_gro
            Cr86_unnormed_by_animal(j).length(1).below_10to5_recs_indiv_mean(r,1) = mean(Cr86_unnormed_by_animal(j).length(r).below_10to5_recs_indiv);
            Cr86_unnormed_by_animal(j).amp(r).below_10to5_recs_indiv = ...
                Cr86_unnormed_by_animal(j).amp(1).tum_gro_vs_all_pix_vals(tot_pixs:tot_pixs+curr_pixs-1,2);
            Cr86_unnormed_by_animal(j).amp(r).below_tum_gro = Cr86_unnormed_by_animal(j).rec(p).tum_gro
            Cr86_unnormed_by_animal(j).amp(1).below_10to5_recs_indiv_mean(r,1) = mean(Cr86_unnormed_by_animal(j).amp(r).below_10to5_recs_indiv);
            Cr86_unnormed_by_animal(j).area(r).below_10to5_recs_indiv = ...
                Cr86_unnormed_by_animal(j).area(1).tum_gro_vs_all_pix_vals(tot_pixs:tot_pixs+curr_pixs-1,2);
            Cr86_unnormed_by_animal(j).area(r).below_tum_gro = Cr86_unnormed_by_animal(j).rec(p).tum_gro
            Cr86_unnormed_by_animal(j).area(1).below_10to5_recs_indiv_mean(r,1) = mean(Cr86_unnormed_by_animal(j).area(r).below_10to5_recs_indiv);
            tot_pixs = tot_pixs+curr_pixs
            below_pixs = below_pixs+curr_pixs;
            r=r+1
            s=s+1
        end
    end

    %make scatter plots for each animal
    normlims = [0 4]
    close all
    figure(89+j)
    set(gcf,'color','white')
    sz = 60;
    tiledlayout(2,3)
    nexttile
    %apm
    w = Cr86_unnormed_by_animal(j).apm(1).all_tum_gro_vs_recs_means(:,4)
    x = Cr86_unnormed_by_animal(j).apm(1).all_tum_gro_vs_recs_means(:,3)
    z = Cr86_unnormed_by_animal(j).apm(1).all_tum_gro_vs_recs_means(:,1)/0.5e6
    y = Cr86_unnormed_by_animal(j).apm(1).all_tum_gro_vs_recs_means(:,2)
    scatter(x,y,sz,'MarkerEdgeColor',[0, 0.4470, 0.7410],...
        'MarkerFaceColor',[0, 0.4470, 0.7410],...
        'LineWidth',1.5)
    hold on
    scatter(w,z,sz/2,'MarkerEdgeColor',[0, 0, 0],...
        'MarkerFaceColor',[0, 0, 0],...
        'LineWidth',1.5)
    hold on
    xx = min(x):1:max(x);
    yy = spline(x,y,xx);
    plot(xx,yy,'Color',[0, 0.4470, 0.7410])
    hold on
    ww = min(w):1:max(w)
    zz = spline(w,z,ww);
    plot(ww,zz,'Color', [0,0,0])
    %align xx,ww and adjust lengths of all four vectors accordingly
    if min(ww)<min(xx)
        mint = find(ww==min(xx))
        ww(:,1:mint-1) = [];
        zz(:,1:mint-1) = [];
    end
    if min(xx)<min(ww)
        mint = find(xx==min(ww))
        xx(:,1:mint-1) = [];
        yy(:,1:mint-1) = [];
    end
    if max(ww)>max(xx)
        maxt = find(ww==max(xx))
        ww(:,maxt+1:length(ww)) = [];
        zz(:,maxt+1:length(zz)) = [];
    end
    if max(xx)>max(ww)
        maxt = find(xx==max(ww))
        xx(:,maxt+1:length(xx)) = [];
        yy(:,maxt+1:length(yy)) = [];
    end
    Cr86_unnormed_by_animal(j).apm(1).oneperday_x_vs_spline_and_tum_gro(:,1) = xx;
    Cr86_unnormed_by_animal(j).apm(1).oneperday_x_vs_spline_and_tum_gro(:,2) = yy;
    Cr86_unnormed_by_animal(j).apm(1).oneperday_x_vs_spline_and_tum_gro(:,3) = zz;
    Cr86_unnormed_by_animal(j).apm(1).oneperday_x_vs_spline_and_tum_gro(:,4) = ww;

    nexttile
    z = Cr86_unnormed_by_animal(j).eps(1).all_tum_gro_vs_recs_means(:,1)/0.5e6
    y = Cr86_unnormed_by_animal(j).eps(1).all_tum_gro_vs_recs_means(:,2)
    scatter(x,y,sz,'MarkerEdgeColor',[0.8500, 0.3250, 0.0980],...
        'MarkerFaceColor',[0.8500, 0.3250, 0.0980],...
        'LineWidth',1.5)
    hold on
    scatter(x,z,sz/2,'MarkerEdgeColor',[0, 0, 0],...
        'MarkerFaceColor',[0, 0, 0],...
        'LineWidth',1.5)
    hold on
    yy = spline(x,y,xx);
    plot(xx,yy,'Color',[0.8500, 0.3250, 0.0980])
    hold on
    zz = spline(w,z,ww);
    plot(ww,zz,'Color', [0,0,0])
    %align xx,ww and adjust lengths of all four vectors accordingly

     if min(ww)<min(xx)
        mint = find(ww==min(xx))
        ww(:,1:mint-1) = [];
        zz(:,1:mint-1) = [];
    end
    if min(xx)<min(ww)
        mint = find(xx==min(ww))
        xx(:,1:mint-1) = [];
        yy(:,1:mint-1) = [];
    end
    if max(ww)>max(xx)
        maxt = find(ww==max(xx))
        ww(:,maxt+1:length(ww)) = [];
        zz(:,maxt+1:length(zz)) = [];
    end
    if max(xx)>max(ww)
        maxt = find(xx==max(ww))
        xx(:,maxt+1:length(xx)) = [];
        yy(:,maxt+1:length(yy)) = [];
    end
    Cr86_unnormed_by_animal(j).eps(1).oneperday_x_vs_spline_and_tum_gro(:,1) = xx;
    Cr86_unnormed_by_animal(j).eps(1).oneperday_x_vs_spline_and_tum_gro(:,2) = yy;
    Cr86_unnormed_by_animal(j).eps(1).oneperday_x_vs_spline_and_tum_gro(:,3) = zz;
    Cr86_unnormed_by_animal(j).eps(1).oneperday_x_vs_spline_and_tum_gro(:,4) = ww;
    nexttile
    z = Cr86_unnormed_by_animal(j).length(1).all_tum_gro_vs_recs_means(:,1)/0.5e6
    y = Cr86_unnormed_by_animal(j).length(1).all_tum_gro_vs_recs_means(:,2)
    scatter(x,y,sz,'MarkerEdgeColor',[0.8500, 0.3250, 0.0980],...
        'MarkerFaceColor',[0.8500, 0.3250, 0.0980],...
        'LineWidth',1.5)
    hold on
    scatter(x,z,sz/2,'MarkerEdgeColor',[0, 0, 0],...
        'MarkerFaceColor',[0, 0, 0],...
        'LineWidth',1.5)
    hold on
    yy = spline(x,y,xx);
    plot(xx,yy,'Color',[0.8500, 0.3250, 0.0980])
    hold on
    zz = spline(w,z,ww);
    plot(ww,zz,'Color', [0,0,0])
    %align xx,ww and adjust lengths of all four vectors accordingly
    if min(ww)<min(xx)
        mint = find(ww==min(xx))
        ww(:,1:mint-1) = [];
        zz(:,1:mint-1) = [];
    end
    if min(xx)<min(ww)
        mint = find(xx==min(ww))
        xx(:,1:mint-1) = [];
        yy(:,1:mint-1) = [];
    end
    if max(ww)>max(xx)
        maxt = find(ww==max(xx))
        ww(:,maxt+1:length(ww)) = [];
        zz(:,maxt+1:length(zz)) = [];
    end
    if max(xx)>max(ww)
        maxt = find(xx==max(ww))
        xx(:,maxt+1:length(xx)) = [];
        yy(:,maxt+1:length(yy)) = [];
    end
    Cr86_unnormed_by_animal(j).length(1).oneperday_x_vs_spline_and_tum_gro(:,1) = xx;
    Cr86_unnormed_by_animal(j).length(1).oneperday_x_vs_spline_and_tum_gro(:,2) = yy;
    Cr86_unnormed_by_animal(j).length(1).oneperday_x_vs_spline_and_tum_gro(:,3) = zz;
    Cr86_unnormed_by_animal(j).length(1).oneperday_x_vs_spline_and_tum_gro(:,4) = ww;

    nexttile
    z = Cr86_unnormed_by_animal(j).amp(1).all_tum_gro_vs_recs_means(:,1)/0.5e6
    y = Cr86_unnormed_by_animal(j).amp(1).all_tum_gro_vs_recs_means(:,2)
    scatter(x,y,sz,'MarkerEdgeColor',[0.8500, 0.3250, 0.0980],...
        'MarkerFaceColor',[0.8500, 0.3250, 0.0980],...
        'LineWidth',1.5)
    hold on
    scatter(x,z,sz/2,'MarkerEdgeColor',[0, 0, 0],...
        'MarkerFaceColor',[0, 0, 0],...
        'LineWidth',1.5)
    hold on
    yy = spline(x,y,xx);
    plot(xx,yy,'Color',[0.8500, 0.3250, 0.0980])
    hold on
    zz = spline(w,z,ww);
    plot(ww,zz,'Color', [0,0,0])
    %align xx,ww and adjust lengths of all four vectors accordingly
    if min(ww)<min(xx)
        mint = find(ww==min(xx))
        ww(:,1:mint-1) = [];
        zz(:,1:mint-1) = [];
    end
    if min(xx)<min(ww)
        mint = find(xx==min(ww))
        xx(:,1:mint-1) = [];
        yy(:,1:mint-1) = [];
    end
    if max(ww)>max(xx)
        maxt = find(ww==max(xx))
        ww(:,maxt+1:length(ww)) = [];
        zz(:,maxt+1:length(zz)) = [];
    end
    if max(xx)>max(ww)
        maxt = find(xx==max(ww))
        xx(:,maxt+1:length(xx)) = [];
        yy(:,maxt+1:length(yy)) = [];
    end
    Cr86_unnormed_by_animal(j).amp(1).oneperday_x_vs_spline_and_tum_gro(:,1) = xx;
    Cr86_unnormed_by_animal(j).amp(1).oneperday_x_vs_spline_and_tum_gro(:,2) = yy;
    Cr86_unnormed_by_animal(j).amp(1).oneperday_x_vs_spline_and_tum_gro(:,3) = zz;
    Cr86_unnormed_by_animal(j).amp(1).oneperday_x_vs_spline_and_tum_gro(:,4) = ww;
    nexttile
    z = Cr86_unnormed_by_animal(j).area(1).all_tum_gro_vs_recs_means(:,1)/0.5e6
    y = Cr86_unnormed_by_animal(j).area(1).all_tum_gro_vs_recs_means(:,2)
    scatter(x,y,sz,'MarkerEdgeColor',[0.8500, 0.3250, 0.0980],...
        'MarkerFaceColor',[0.8500, 0.3250, 0.0980],...
        'LineWidth',1.5)
    hold on
    scatter(x,z,sz/2,'MarkerEdgeColor',[0, 0, 0],...
        'MarkerFaceColor',[0, 0, 0],...
        'LineWidth',1.5)
    hold on
    yy = spline(x,y,xx);
    plot(xx,yy,'Color',[0.8500, 0.3250, 0.0980])
    hold on
    zz = spline(w,z,ww);
    plot(ww,zz,'Color', [0,0,0])
    %align xx,ww and adjust lengths of all four vectors accordingly
    if min(ww)<min(xx)
        mint = find(ww==min(xx))
        ww(:,1:mint-1) = [];
        zz(:,1:mint-1) = [];
    end
    if min(xx)<min(ww)
        mint = find(xx==min(ww))
        xx(:,1:mint-1) = [];
        yy(:,1:mint-1) = [];
    end
    if max(ww)>max(xx)
        maxt = find(ww==max(xx))
        ww(:,maxt+1:length(ww)) = [];
        zz(:,maxt+1:length(zz)) = [];
    end
    if max(xx)>max(ww)
        maxt = find(xx==max(ww))
        xx(:,maxt+1:length(xx)) = [];
        yy(:,maxt+1:length(yy)) = [];
    end
    Cr86_unnormed_by_animal(j).area(1).oneperday_x_vs_spline_and_tum_gro(:,1) = xx;
    Cr86_unnormed_by_animal(j).area(1).oneperday_x_vs_spline_and_tum_gro(:,2) = yy;
    Cr86_unnormed_by_animal(j).area(1).oneperday_x_vs_spline_and_tum_gro(:,3) = zz;
    Cr86_unnormed_by_animal(j).area(1).oneperday_x_vs_spline_and_tum_gro(:,4) = ww;
    saveas(89+j,['animal_' num2str(curr_anim) 'scatter_dayP_vs_whole_FOV_' tg '_vs_apm_eps_length_amp_area' '.png'], 'png')
    saveas(89+j,['animal_' num2str(curr_anim) 'scatter_dayP_vs_whole_FOV_' tg '_vs_apm_eps_length_amp_area' '.pdf'], 'pdf')
end

a=1
Cr86_unnormed_anims = [15 21 28 38 40]
for j = 1:5
    curr_anim = Cr86_unnormed_anims(1,j)
    tumgro_diff = Cr86_unnormed_by_animal(j).apm(1).oneperday_x_vs_spline_and_tum_gro(:,3);
    apm.diff =  [diff(Cr86_unnormed_by_animal(j).apm(1).oneperday_x_vs_spline_and_tum_gro(:,2)); 0];
    eps.diff =  [diff(Cr86_unnormed_by_animal(j).eps(1).oneperday_x_vs_spline_and_tum_gro(:,2)); 0];
    lengthh.diff =  [diff(Cr86_unnormed_by_animal(j).length(1).oneperday_x_vs_spline_and_tum_gro(:,2)); 0];
    amp.diff =  [diff(Cr86_unnormed_by_animal(j).amp(1).oneperday_x_vs_spline_and_tum_gro(:,2)); 0];
    area.diff =  [diff(Cr86_unnormed_by_animal(j).area(1).oneperday_x_vs_spline_and_tum_gro(:,2)); 0];
    difflength = size(tumgro_diff,1);
    day_shifts = [-15:1:15]
    for k = 1:31
        vec2 = tumgro_diff(1+max(day_shifts(1,k),0):difflength+min(day_shifts(1,k),0),1);
        vec1 = apm.diff(1-min(day_shifts(1,k),0):difflength-max(day_shifts(1,k),0),1)
        currcorr = corrcoef(vec1,vec2)
        Cr86_unnormed_by_animal(j).apm(1).shift_corrcoeff(k,1) = (currcorr(1,2))
        Cr86_unnormed.corrshift_anal.apm(j,k) = (currcorr(1,2))
        vec1 = eps.diff(1-min(day_shifts(1,k),0):difflength-max(day_shifts(1,k),0),1)
        currcorr = corrcoef(vec1,vec2)
        Cr86_unnormed_by_animal(j).eps(1).shift_corrcoeff(k,1) = (currcorr(1,2))
        Cr86_unnormed.corrshift_anal.eps(j,k) = (currcorr(1,2))
        vec1 = lengthh.diff(1-min(day_shifts(1,k),0):difflength-max(day_shifts(1,k),0),1)
        currcorr = corrcoef(vec1,vec2)
        Cr86_unnormed_by_animal(j).length(1).shift_corrcoeff(k,1) = (currcorr(1,2))
        Cr86_unnormed.corrshift_anal.length(j,k) = (currcorr(1,2))
        vec1 = amp.diff(1-min(day_shifts(1,k),0):difflength-max(day_shifts(1,k),0),1)
        currcorr = corrcoef(vec1,vec2)
        Cr86_unnormed_by_animal(j).amp(1).shift_corrcoeff(k,1) = (currcorr(1,2))
        Cr86_unnormed.corrshift_anal.amp(j,k) = (currcorr(1,2))
        vec1 = area.diff(1-min(day_shifts(1,k),0):difflength-max(day_shifts(1,k),0),1)
        currcorr = corrcoef(vec1,vec2)
        Cr86_unnormed_by_animal(j).area(1).shift_corrcoeff(k,1) = (currcorr(1,2))
        Cr86_unnormed.corrshift_anal.area(j,k) = (currcorr(1,2))
    end
end

close all
figure(89+j)
set(gcf,'color','white')
sz = 60;
tiledlayout(2,3)
nexttile
plot(Cr86_unnormed.corrshift_anal.apm(1,:))
hold on
plot(Cr86_unnormed.corrshift_anal.apm(2,:))
hold on
plot(Cr86_unnormed.corrshift_anal.apm(3,:))
hold on
plot(Cr86_unnormed.corrshift_anal.apm(4,:))
hold on
plot(Cr86_unnormed.corrshift_anal.apm(5,:))
hold on

nexttile
plot(Cr86_unnormed.corrshift_anal.eps(1,:))
hold on
plot(Cr86_unnormed.corrshift_anal.eps(2,:))
hold on
plot(Cr86_unnormed.corrshift_anal.eps(3,:))
hold on
plot(Cr86_unnormed.corrshift_anal.eps(4,:))
hold on
plot(Cr86_unnormed.corrshift_anal.eps(5,:))

hold on
nexttile
plot(Cr86_unnormed.corrshift_anal.length(1,:))
hold on
plot(Cr86_unnormed.corrshift_anal.length(2,:))
hold on
plot(Cr86_unnormed.corrshift_anal.length(3,:))
hold on
plot(Cr86_unnormed.corrshift_anal.length(4,:))
hold on
plot(Cr86_unnormed.corrshift_anal.length(5,:))

hold on
nexttile
plot(Cr86_unnormed.corrshift_anal.amp(1,:))
hold on
plot(Cr86_unnormed.corrshift_anal.amp(2,:))
hold on
plot(Cr86_unnormed.corrshift_anal.amp(3,:))
hold on
plot(Cr86_unnormed.corrshift_anal.amp(4,:))
hold on
plot(Cr86_unnormed.corrshift_anal.amp(5,:))

hold on
nexttile
plot(Cr86_unnormed.corrshift_anal.area(1,:))
hold on
plot(Cr86_unnormed.corrshift_anal.area(2,:))
hold on
plot(Cr86_unnormed.corrshift_anal.area(3,:))
hold on
plot(Cr86_unnormed.corrshift_anal.area(4,:))
hold on
plot(Cr86_unnormed.corrshift_anal.area(5,:))
hold on


a=1
Cr86_unnormed_anims = [15 21 28 38 40]
for j = 1:5
    curr_anim = Cr86_unnormed_anims(1,j)
    a=1
    clear kur
    b=1
    clear pur
    if initially_norm_by_first_rec
        curr_below_avg = 1
    else
        curr_below_avg = mean(Cr86_unnormed_by_animal(j).apm(1).below_10to5_recs_indiv_mean);
    end
    Cr86_unnormed_by_animal(j).apm(1).all_indiv_below_recs_div_by_all_below_avg = Cr86_unnormed_by_animal(j).apm(1).below_10to5_recs_indiv_mean/curr_below_avg;
    for k = 1:size(Cr86_unnormed_by_animal(j).apm,2)
        Cr86_unnormed_by_animal(j).apm(k).above_10to5_mean = ...
            mean(Cr86_unnormed_by_animal(j).apm(k).above_10to5_recs)/curr_below_avg;
        Cr86_unnormed_by_animal(j).apm(k).below_10to5_mean = ...
            mean(Cr86_unnormed_by_animal(j).apm(k).below_10to5_recs)/curr_below_avg;
        if ~isnan(Cr86_unnormed_by_animal(j).apm(k).above_10to5_mean)
            kur(a,1) = Cr86_unnormed_by_animal(j).apm(k).above_10to5_mean
            Cr86_unnormed_by_animal(j).apm(1).all_indiv_above_recs_div_by_all_below_avg(a,1) = kur(a,1);
            a=a+1
        end
    end
    Cr86_unnormed_by_animal(j).apm(1).mean_above_recs_div_by_all_mean_below = mean(kur);
    Cr86_unnormed.apm_mean_above_recs_div_by_all_mean_below(j,1) = mean(kur)
    [p,h,stats] = ranksum(Cr86_unnormed_by_animal(j).apm(1).below_10to5_recs_indiv_mean,Cr86_unnormed_by_animal(j).apm(1).above_tum_gro_means)
    Cr86_unnormed_by_animal(j).stats.apm_indiv_rec_means_above_vs_below.p = p;
    Cr86_unnormed_by_animal(j).stats.apm_indiv_rec_means_above_vs_below.h = h;
    Cr86_unnormed_by_animal(j).stats.apm_indiv_rec_means_above_vs_below.stats = stats;
    a=1
    clear kur
    b=1
    clear pur
    if initially_norm_by_first_rec
        curr_below_avg = 1
    else
        curr_below_avg = mean(Cr86_unnormed_by_animal(j).eps(1).below_10to5_recs_indiv_mean);
    end
    Cr86_unnormed_by_animal(j).eps(1).all_indiv_below_recs_div_by_all_below_avg = Cr86_unnormed_by_animal(j).eps(1).below_10to5_recs_indiv_mean/curr_below_avg;

    for k = 1:size(Cr86_unnormed_by_animal(j).eps,2)
        Cr86_unnormed_by_animal(j).eps(k).above_10to5_mean = ...
            mean(Cr86_unnormed_by_animal(j).eps(k).above_10to5_recs)/curr_below_avg;
        Cr86_unnormed_by_animal(j).eps(k).below_10to5_mean = ...
            mean(Cr86_unnormed_by_animal(j).eps(k).below_10to5_recs)/curr_below_avg;
        if ~isnan(Cr86_unnormed_by_animal(j).eps(k).above_10to5_mean)
            kur(a,1) = Cr86_unnormed_by_animal(j).eps(k).above_10to5_mean
            Cr86_unnormed_by_animal(j).eps(1).all_indiv_above_recs_div_by_all_below_avg(a,1) = kur(a,1);
            a=a+1
        end
    end
    Cr86_unnormed_by_animal(j).eps(1).mean_above_recs_div_by_all_mean_below = mean(kur);
    Cr86_unnormed.eps_mean_above_recs_div_by_all_mean_below(j,1) = mean(kur)
    [p,h,stats] = ranksum(Cr86_unnormed_by_animal(j).eps(1).below_10to5_recs_indiv_mean,Cr86_unnormed_by_animal(j).eps(1).above_tum_gro_means)
    Cr86_unnormed_by_animal(j).stats.eps_indiv_rec_means_above_vs_below.p = p;
    Cr86_unnormed_by_animal(j).stats.eps_indiv_rec_means_above_vs_below.h = h;
    Cr86_unnormed_by_animal(j).stats.eps_indiv_rec_means_above_vs_below.stats = stats;
    a=1
    clear kur
    b=1
    clear pur
    if initially_norm_by_first_rec
        curr_below_avg = 1
    else
        curr_below_avg = mean(Cr86_unnormed_by_animal(j).length(1).below_10to5_recs_indiv_mean);
    end
    Cr86_unnormed_by_animal(j).length(1).all_indiv_below_recs_div_by_all_below_avg = Cr86_unnormed_by_animal(j).length(1).below_10to5_recs_indiv_mean/curr_below_avg;
    for k = 1:size(Cr86_unnormed_by_animal(j).length,2)
        Cr86_unnormed_by_animal(j).length(k).above_10to5_mean = ...
            mean(Cr86_unnormed_by_animal(j).length(k).above_10to5_recs)/curr_below_avg;
        Cr86_unnormed_by_animal(j).length(k).below_10to5_mean = ...
            mean(Cr86_unnormed_by_animal(j).length(k).below_10to5_recs)/curr_below_avg;
        if ~isnan(Cr86_unnormed_by_animal(j).length(k).above_10to5_mean)
            kur(a,1) = Cr86_unnormed_by_animal(j).length(k).above_10to5_mean
            Cr86_unnormed_by_animal(j).length(1).all_indiv_above_recs_div_by_all_below_avg(a,1) = kur(a,1);
            a=a+1
        end
    end
    Cr86_unnormed_by_animal(j).length(1).mean_above_recs_div_by_all_mean_below = mean(kur);
    Cr86_unnormed.length_mean_above_recs_div_by_all_mean_below(j,1) = mean(kur)
    [p,h,stats] = ranksum(Cr86_unnormed_by_animal(j).length(1).below_10to5_recs_indiv_mean,Cr86_unnormed_by_animal(j).length(1).above_tum_gro_means)
    Cr86_unnormed_by_animal(j).stats.length_indiv_rec_means_above_vs_below.p = p;
    Cr86_unnormed_by_animal(j).stats.length_indiv_rec_means_above_vs_below.h = h;
    Cr86_unnormed_by_animal(j).stats.length_indiv_rec_means_above_vs_below.stats = stats;

    a=1
    clear kur
    b=1
    clear pur
    if initially_norm_by_first_rec
        curr_below_avg = 1
    else
        curr_below_avg = mean(Cr86_unnormed_by_animal(j).amp(1).below_10to5_recs_indiv_mean);
    end
    Cr86_unnormed_by_animal(j).amp(1).all_indiv_below_recs_div_by_all_below_avg = Cr86_unnormed_by_animal(j).amp(1).below_10to5_recs_indiv_mean/curr_below_avg;
    for k = 1:size(Cr86_unnormed_by_animal(j).amp,2)
        Cr86_unnormed_by_animal(j).amp(k).above_10to5_mean = ...
            mean(Cr86_unnormed_by_animal(j).amp(k).above_10to5_recs)/curr_below_avg;
        Cr86_unnormed_by_animal(j).amp(k).below_10to5_mean = ...
            mean(Cr86_unnormed_by_animal(j).amp(k).below_10to5_recs)/curr_below_avg;
        if ~isnan(Cr86_unnormed_by_animal(j).amp(k).above_10to5_mean)
            kur(a,1) = Cr86_unnormed_by_animal(j).amp(k).above_10to5_mean
            Cr86_unnormed_by_animal(j).amp(1).all_indiv_above_recs_div_by_all_below_avg(a,1) = kur(a,1);
            a=a+1
        end
    end
    Cr86_unnormed_by_animal(j).amp(1).mean_above_recs_div_by_all_mean_below = mean(kur);
    Cr86_unnormed.amp_mean_above_recs_div_by_all_mean_below(j,1) = mean(kur)
    [p,h,stats] = ranksum(Cr86_unnormed_by_animal(j).amp(1).below_10to5_recs_indiv_mean,Cr86_unnormed_by_animal(j).amp(1).above_tum_gro_means)
    Cr86_unnormed_by_animal(j).stats.amp_indiv_rec_means_above_vs_below.p = p;
    Cr86_unnormed_by_animal(j).stats.amp_indiv_rec_means_above_vs_below.h = h;
    Cr86_unnormed_by_animal(j).stats.amp_indiv_rec_means_above_vs_below.stats = stats;

    a=1
    clear kur
    b=1
    clear pur
    if initially_norm_by_first_rec
        curr_below_avg = 1
    else
        curr_below_avg = mean(Cr86_unnormed_by_animal(j).area(1).below_10to5_recs_indiv_mean);
    end
    Cr86_unnormed_by_animal(j).area(1).all_indiv_below_recs_div_by_all_below_avg = Cr86_unnormed_by_animal(j).area(1).below_10to5_recs_indiv_mean/curr_below_avg;
    for k = 1:size(Cr86_unnormed_by_animal(j).area,2)
        Cr86_unnormed_by_animal(j).area(k).above_10to5_mean = ...
            mean(Cr86_unnormed_by_animal(j).area(k).above_10to5_recs)/curr_below_avg;
        Cr86_unnormed_by_animal(j).area(k).below_10to5_mean = ...
            mean(Cr86_unnormed_by_animal(j).area(k).below_10to5_recs)/curr_below_avg;
        if ~isnan(Cr86_unnormed_by_animal(j).area(k).above_10to5_mean)
            kur(a,1) = Cr86_unnormed_by_animal(j).area(k).above_10to5_mean

            Cr86_unnormed_by_animal(j).area(1).all_indiv_above_recs_div_by_all_below_avg(a,1) = kur(a,1);

            a=a+1
        end
    end
    Cr86_unnormed_by_animal(j).area(1).mean_above_recs_div_by_all_mean_below = mean(kur);
    Cr86_unnormed.area_mean_above_recs_div_by_all_mean_below(j,1) = mean(kur)
    [p,h,stats] = ranksum(Cr86_unnormed_by_animal(j).area(1).below_10to5_recs_indiv_mean,Cr86_unnormed_by_animal(j).area(1).above_tum_gro_means)
    Cr86_unnormed_by_animal(j).stats.area_indiv_rec_means_above_vs_below.p = p;
    Cr86_unnormed_by_animal(j).stats.area_indiv_rec_means_above_vs_below.h = h;
    Cr86_unnormed_by_animal(j).stats.area_indiv_rec_means_above_vs_below.stats = stats;

end


for j = 1:5
    Cr86_unnormed.apm.mean_below_above_means_normed(j,1) = mean(Cr86_unnormed_by_animal(j).apm(1).all_indiv_below_recs_div_by_all_below_avg)
    Cr86_unnormed.apm.mean_below_above_means_normed(j,2) = mean(Cr86_unnormed_by_animal(j).apm(1).all_indiv_above_recs_div_by_all_below_avg)
    Cr86_unnormed.eps.mean_below_above_means_normed(j,1) = mean(Cr86_unnormed_by_animal(j).eps(1).all_indiv_below_recs_div_by_all_below_avg)
    Cr86_unnormed.eps.mean_below_above_means_normed(j,2) = mean(Cr86_unnormed_by_animal(j).eps(1).all_indiv_above_recs_div_by_all_below_avg)
    Cr86_unnormed.length.mean_below_above_means_normed(j,1) = mean(Cr86_unnormed_by_animal(j).length(1).all_indiv_below_recs_div_by_all_below_avg)
    Cr86_unnormed.length.mean_below_above_means_normed(j,2) = mean(Cr86_unnormed_by_animal(j).length(1).all_indiv_above_recs_div_by_all_below_avg)
    Cr86_unnormed.amp.mean_below_above_means_normed(j,1) = mean(Cr86_unnormed_by_animal(j).amp(1).all_indiv_below_recs_div_by_all_below_avg)
    Cr86_unnormed.amp.mean_below_above_means_normed(j,2) = mean(Cr86_unnormed_by_animal(j).amp(1).all_indiv_above_recs_div_by_all_below_avg)
    Cr86_unnormed.area.mean_below_above_means_normed(j,1) = mean(Cr86_unnormed_by_animal(j).area(1).all_indiv_below_recs_div_by_all_below_avg)
    Cr86_unnormed.area.mean_below_above_means_normed(j,2) = mean(Cr86_unnormed_by_animal(j).area(1).all_indiv_above_recs_div_by_all_below_avg)
end

%%%%%%%%%%%%%%%%%%%%%%%%%%
clear GPC6_unnormed GPC6_unnormed_by_animal
jj=1
a=1;
aa=1;
bb=1
bbi=1
bb7=1
tum_gro_or_CV_p_D = 3; %(3 = tum_gro, 10 = CV/D)
if tum_gro_or_CV_p_D==3
    tg = 'tum_gro'
else
    tg = 'CV_p_D'
end

for f =  [48 49 71 72 73]   
    if ~isempty(tumor_animal(f).onep)
        if tumor_animal(f).onep.GPC6

            close all
            s=1
            ta3pp = tumor_animal(f).onep.ta3_analysis(1).day_P_vs_other_params;
            ta3pp(:,9) = tumor_animal(f).onep.ta3_analysis(1).pval_contr;
            todelvec=0
            ta3ppfov=ta3pp;
            for h = 2:size(ta3pp,1)
                if isnan(ta3pp(h,2)) || sum(ta3pp(h,2:8))==0 || (f==21 && (h==4 || h==6 || h==9)) ||...
                        (f==28 && (h==2 || h==4 || h==5 || h==7 || h==15 || h==16 || h==17 || h==19 || h==20))
                    todelvec(s,1) = h;
                    s=s+1
                end
            end
            if todelvec==0
            else
                ta3pp(todelvec,:) = [];
                ta3ppfov(todelvec,:) = [];
            end
            tumor_animal(f).onep.ta3_analysis(1).todelvec = todelvec;
            sx = size(ta3pp,1)
            GPC6_unnormed.all_day_P_vs_amplitude(a:a+sx-2,1) = ta3pp(2:sx,1);
            GPC6_unnormed.all_day_P_vs_amplitude(a:a+sx-2,2) = ta3pp(2:sx,4);
            GPC6_unnormed.all_day_P_vs_amplitude(a:a+sx-2,3) = ta3pp(2:sx,4)<ta3pp(2:sx,9);
            GPC6_unnormed.all_day_P_vs_apm(a:a+sx-2,1) = ta3pp(2:sx,1);
            GPC6_unnormed.all_day_P_vs_apm(a:a+sx-2,2) = ta3pp(2:sx,5);
            GPC6_unnormed.all_day_P_vs_apm(a:a+sx-2,3) = ta3pp(2:sx,5)<ta3pp(2:sx,9);
            GPC6_unnormed.all_day_P_vs_area(a:a+sx-2,1) = ta3pp(2:sx,1);
            GPC6_unnormed.all_day_P_vs_area(a:a+sx-2,2) = ta3pp(2:sx,6);
            GPC6_unnormed.all_day_P_vs_area(a:a+sx-2,3) = ta3pp(2:sx,6)<ta3pp(2:sx,9);
            GPC6_unnormed.all_day_P_vs_eps(a:a+sx-2,1) = ta3pp(2:sx,1);
            GPC6_unnormed.all_day_P_vs_eps(a:a+sx-2,2) = ta3pp(2:sx,7);
            GPC6_unnormed.all_day_P_vs_eps(a:a+sx-2,3) = ta3pp(2:sx,7)<ta3pp(2:sx,9);
            GPC6_unnormed.all_day_P_vs_rhythm(a:a+sx-2,1) = ta3pp(2:sx,1);
            GPC6_unnormed.all_day_P_vs_rhythm(a:a+sx-2,2) = ta3pp(2:sx,8);
            GPC6_unnormed.all_day_P_vs_rhythm(a:a+sx-2,3) = ta3pp(2:sx,8)<ta3pp(2:sx,9);
            GPC6_unnormed.all_tum_gro_vs_amplitude(a:a+sx-2,1) = ta3pp(2:sx,3);
            GPC6_unnormed.all_tum_gro_vs_amplitude(a:a+sx-2,2) = ta3pp(2:sx,4);
            GPC6_unnormed.all_tum_gro_vs_amplitude(a:a+sx-2,3) = ta3pp(2:sx,4)<ta3pp(2:sx,9);

            GPC6_unnormed.all_tum_gro_vs_apm(a:a+sx-2,1) = ta3pp(2:sx,3);
            GPC6_unnormed.all_tum_gro_vs_apm(a:a+sx-2,2) = ta3pp(2:sx,5);
            GPC6_unnormed.all_tum_gro_vs_apm(a:a+sx-2,3) = ta3pp(2:sx,5)<ta3pp(2:sx,9);

            GPC6_unnormed.all_tum_gro_vs_area(a:a+sx-2,1) = ta3pp(2:sx,3);
            GPC6_unnormed.all_tum_gro_vs_area(a:a+sx-2,2) = ta3pp(2:sx,6);
            GPC6_unnormed.all_tum_gro_vs_area(a:a+sx-2,3) = ta3pp(2:sx,6)<ta3pp(2:sx,9);

            GPC6_unnormed.all_tum_gro_vs_eps(a:a+sx-2,1) = ta3pp(2:sx,3);
            GPC6_unnormed.all_tum_gro_vs_eps(a:a+sx-2,2) = ta3pp(2:sx,7);
            GPC6_unnormed.all_tum_gro_vs_eps(a:a+sx-2,3) = ta3pp(2:sx,7)<ta3pp(2:sx,9);

            GPC6_unnormed.all_tum_gro_vs_rhythm(a:a+sx-2,1) = ta3pp(2:sx,3);
            GPC6_unnormed.all_tum_gro_vs_rhythm(a:a+sx-2,2) = ta3pp(2:sx,8);
            GPC6_unnormed.all_tum_gro_vs_rhythm(a:a+sx-2,3) = ta3pp(2:sx,8)<ta3pp(2:sx,9);
            fovs = tumor_animal(f).onep.ta3_analysis.FOV_stats;
            if todelvec>0
                fovs.tafov_apm_all(:,todelvec) = [];
                fovs.tafov_eps_all(:,todelvec) = [];
                fovs.tafov_length_all(:,todelvec) = [];
                fovs.tafov_amp_all(:,todelvec) = [];
                fovs.tafov_area_all(:,todelvec) = [];
                fovs.tafov_IEI_all(:,todelvec) = [];
                fovs.tafov_rhythm_all(:,todelvec) = [];
            end
           
            rm=1
            if f==21
                rm=2;
            end
            pl1 = fovs.tafov_apm_all(:,rm);
            pl1(find(isnan(pl1))) = [];
            nn1 = mean(pl1);
nn1=1
            pl2 = fovs.tafov_eps_all(:,rm);
            pl2(find(isnan(pl2))) = [];
            nn2 = mean(pl2);
nn2=1
            pl3 = fovs.tafov_length_all(:,rm);
            pl3(find(isnan(pl3))) = [];
            nn3 = mean(pl3);
nn3=1
            pl4 = fovs.tafov_amp_all(:,rm);
            pl4(find(isnan(pl4))) = [];
            nn4 = mean(pl4);
nn4=1
            pl5 = fovs.tafov_area_all(:,rm);
            pl5(find(isnan(pl5))) = [];
            nn5 = mean(pl5);
nn5=1
            pl6 = fovs.tafov_IEI_all(:,rm);
            pl6(find(isnan(pl6))) = [];
            nn6 = mean(pl6);
nn6=1
            pl7 = fovs.tafov_rhythm_all(:,rm);
            pl7(find(pl7==Inf)) = NaN;
            pl7(find(isnan(pl7))) = [];
            nn7 = mean(pl7);
nn7=1
            GPC6_unnormed_by_animal(jj).rec(1).day_P = ta3ppfov(1,1);
            for o=2:size(fovs.tafov_apm_all,2)
              
                oo=o
                plr1 = fovs.tafov_apm_all(:,o);
                plr1(find(isnan(plr1))) = [];
                plr1(find(plr1==0)) = [];    
                plr1_norm = plr1/nn1;

                plr2 = fovs.tafov_eps_all(:,o);
                plr2(find(isnan(plr2))) = [];
                plr2(find(plr2==0)) = [];
                plr2_norm = plr2/nn2;

                plr3 = fovs.tafov_length_all(:,o);
                plr3(find(isnan(plr3))) = [];
                plr3(find(plr3==0)) = [];
                plr3_norm = plr3/nn3;

                plr4 = fovs.tafov_amp_all(:,o);
                plr4(find(isnan(plr4))) = [];
                plr4(find(plr4==0)) = [];
                plr4_norm = plr4/nn4;

                plr5 = fovs.tafov_area_all(:,o);
                plr5(find(isnan(plr5))) = [];
                plr5(find(plr5==0)) = [];
                plr5_norm = plr5/nn5;

                plr6 = fovs.tafov_IEI_all(:,o);
                plr6(find(isnan(plr6))) = [];
                plr6(find(plr6==0)) = [];
                plr6_norm = plr6/nn6;
                bbpi = length(plr6);

                plr7 = fovs.tafov_rhythm_all(:,o);
                plr7(find(plr7==Inf)) = NaN;
                plr7(find(isnan(plr7))) = [];
                plr7(find(plr7==0)) = [];
                plr7_norm = plr7/nn7;
                bbp7=length(plr7_norm);

                bbp=length(plr1);
                GPC6_unnormed_by_animal(jj).rec(o).length = bbp;

                GPC6_unnormed_by_animal(jj).rec(o).day_P = ta3ppfov(oo,1);

                ber =  tumor_animal(f).onep.tum_gro_divbypoint5to6_spline_w_apm;
                inb = find(ber(:,1)==GPC6_unnormed_by_animal(jj).rec(o).day_P)
                if jj==1 && o==10
                    inb=69
                end
                if jj==2 && o==6
                    inb=25
                end
                if jj==3 && o==6
                    inb=20
                end
                  if jj==4 && o==6
                    inb=52
                  end

                if jj==5 && o==10
                    inb=52
                end
                GPC6_unnormed_by_animal(jj).rec(o).tum_gro = ...
                    ber(inb,3)*0.5e6;


                GPC6_unnormed.all_FOVs_pooled.apm.tum_gro_vs_all_pix_vals(bb:bb+bbp-1,1) = ta3ppfov(oo,tum_gro_or_CV_p_D); %was oo-1
                GPC6_unnormed.all_FOVs_pooled.apm.tum_gro_vs_all_pix_vals(bb:bb+bbp-1,2) = plr1_norm;

                GPC6_unnormed.all_FOVs_pooled.eps.tum_gro_vs_all_pix_vals(bb:bb+bbp-1,1) = ta3ppfov(oo,tum_gro_or_CV_p_D);
                GPC6_unnormed.all_FOVs_pooled.eps.tum_gro_vs_all_pix_vals(bb:bb+bbp-1,2) = plr2_norm;

                GPC6_unnormed.all_FOVs_pooled.length.tum_gro_vs_all_pix_vals(bb:bb+bbp-1,1) = ta3ppfov(oo,tum_gro_or_CV_p_D);
                GPC6_unnormed.all_FOVs_pooled.length.tum_gro_vs_all_pix_vals(bb:bb+bbp-1,2) = plr3_norm;

                GPC6_unnormed.all_FOVs_pooled.amp.tum_gro_vs_all_pix_vals(bb:bb+bbp-1,1) = ta3ppfov(oo,tum_gro_or_CV_p_D);
                GPC6_unnormed.all_FOVs_pooled.amp.tum_gro_vs_all_pix_vals(bb:bb+bbp-1,2) = plr4_norm;

                GPC6_unnormed.all_FOVs_pooled.area.tum_gro_vs_all_pix_vals(bb:bb+bbp-1,1) = ta3ppfov(oo,tum_gro_or_CV_p_D);
                GPC6_unnormed.all_FOVs_pooled.area.tum_gro_vs_all_pix_vals(bb:bb+bbp-1,2) = plr5_norm;

                GPC6_unnormed.all_FOVs_pooled.IEI.tum_gro_vs_all_pix_vals(bbi:bbi+bbpi-1,1) = ta3ppfov(oo,tum_gro_or_CV_p_D);
                GPC6_unnormed.all_FOVs_pooled.IEI.tum_gro_vs_all_pix_vals(bbi:bbi+bbpi-1,2) = plr6_norm;

                GPC6_unnormed.all_FOVs_pooled.rhythm.tum_gro_vs_all_pix_vals(bb7:bb7+bbp7-1,1) = ta3ppfov(oo,tum_gro_or_CV_p_D);
                GPC6_unnormed.all_FOVs_pooled.rhythm.tum_gro_vs_all_pix_vals(bb7:bb7+bbp7-1,2) = plr7_norm;

                bb=bb+bbp;
                bbi=bbi+bbpi;
                bb7=bb7+bbp7;
            end
            GPC6_unnormed.animal(f).FOV_pixel_num = bb-1;
            a=a+sx-1;
            aa=aa+ssx-1;
        end
    end
    jj=jj+1
end

if tum_gro_or_CV_p_D == 10
    ylim1 = 0
    ylim2 = 0.2
    thre = 0.018
else
    ylim1 = -4e5
    ylim2 = 5e5
    thre = 100000
end

initially_norm_by_first_rec = 1
a=1
GPC6_unnormed_anims = [48 49 71 72 73] 
for j = 1:5
    curr_anim = GPC6_unnormed_anims(1,j)
    if curr_anim>48
        a = GPC6_unnormed.animal(GPC6_unnormed_anims(1,j-1)).FOV_pixel_num+1
    end
    b = GPC6_unnormed.animal(curr_anim).FOV_pixel_num;
    GPC6_unnormed_by_animal(j).apm(1).tum_gro_vs_all_pix_vals =  GPC6_unnormed.all_FOVs_pooled.apm.tum_gro_vs_all_pix_vals(a:b,:)
    GPC6_unnormed_by_animal(j).eps(1).tum_gro_vs_all_pix_vals =  GPC6_unnormed.all_FOVs_pooled.eps.tum_gro_vs_all_pix_vals(a:b,:)
    GPC6_unnormed_by_animal(j).length(1).tum_gro_vs_all_pix_vals =  GPC6_unnormed.all_FOVs_pooled.length.tum_gro_vs_all_pix_vals(a:b,:)
    GPC6_unnormed_by_animal(j).amp(1).tum_gro_vs_all_pix_vals =  GPC6_unnormed.all_FOVs_pooled.amp.tum_gro_vs_all_pix_vals(a:b,:)
    GPC6_unnormed_by_animal(j).area(1).tum_gro_vs_all_pix_vals =  GPC6_unnormed.all_FOVs_pooled.area.tum_gro_vs_all_pix_vals(a:b,:)

    q=1
    r=1
    s=1
    tot_pixs = 1
    below_pixs=1
    for p = 2:size(GPC6_unnormed_by_animal(j).rec,2)

        curr_pixs = GPC6_unnormed_by_animal(j).rec(p).length
        GPC6_unnormed_by_animal(j).rec(p).day_P_tumgro_adjust = round((GPC6_unnormed_by_animal(j).rec(p).day_P + GPC6_unnormed_by_animal(j).rec(p-1).day_P)/2)

        if GPC6_unnormed_by_animal(j).rec(p).tum_gro>thre
            GPC6_unnormed_by_animal(j).apm(1).all_tum_gro_vs_recs_means(s,3) = GPC6_unnormed_by_animal(j).rec(p).day_P 
            GPC6_unnormed_by_animal(j).apm(1).all_tum_gro_vs_recs_means(s,4) = GPC6_unnormed_by_animal(j).rec(p).day_P_tumgro_adjust 
            GPC6_unnormed_by_animal(j).apm(1).all_tum_gro_vs_recs_means(s,1) = GPC6_unnormed_by_animal(j).rec(p).tum_gro
            GPC6_unnormed_by_animal(j).apm(1).all_tum_gro_vs_recs_means(s,2) = mean(GPC6_unnormed_by_animal(j).apm(1).tum_gro_vs_all_pix_vals(tot_pixs:tot_pixs+curr_pixs-1,2))
            GPC6_unnormed_by_animal(j).eps(1).all_tum_gro_vs_recs_means(s,1) = GPC6_unnormed_by_animal(j).rec(p).tum_gro
            GPC6_unnormed_by_animal(j).eps(1).all_tum_gro_vs_recs_means(s,2) = mean(GPC6_unnormed_by_animal(j).eps(1).tum_gro_vs_all_pix_vals(tot_pixs:tot_pixs+curr_pixs-1,2))
            GPC6_unnormed_by_animal(j).length(1).all_tum_gro_vs_recs_means(s,1) = GPC6_unnormed_by_animal(j).rec(p).tum_gro
            GPC6_unnormed_by_animal(j).length(1).all_tum_gro_vs_recs_means(s,2) = mean(GPC6_unnormed_by_animal(j).length(1).tum_gro_vs_all_pix_vals(tot_pixs:tot_pixs+curr_pixs-1,2))
            GPC6_unnormed_by_animal(j).amp(1).all_tum_gro_vs_recs_means(s,1) = GPC6_unnormed_by_animal(j).rec(p).tum_gro
            GPC6_unnormed_by_animal(j).amp(1).all_tum_gro_vs_recs_means(s,2) = mean(GPC6_unnormed_by_animal(j).amp(1).tum_gro_vs_all_pix_vals(tot_pixs:tot_pixs+curr_pixs-1,2))
            GPC6_unnormed_by_animal(j).area(1).all_tum_gro_vs_recs_means(s,1) = GPC6_unnormed_by_animal(j).rec(p).tum_gro
            GPC6_unnormed_by_animal(j).area(1).all_tum_gro_vs_recs_means(s,2) = mean(GPC6_unnormed_by_animal(j).area(1).tum_gro_vs_all_pix_vals(tot_pixs:tot_pixs+curr_pixs-1,2))

            s=s +1;
            GPC6_unnormed_by_animal(j).apm(q).above_10to5_recs = GPC6_unnormed_by_animal(j).apm(1).tum_gro_vs_all_pix_vals(tot_pixs:tot_pixs+curr_pixs-1,2);
            GPC6_unnormed_by_animal(j).apm(q).above_tum_gro = GPC6_unnormed_by_animal(j).rec(p).tum_gro
            GPC6_unnormed_by_animal(j).apm(1).above_tum_gro_means(q,1) = mean(GPC6_unnormed_by_animal(j).apm(q).above_10to5_recs)
            GPC6_unnormed_by_animal(j).eps(q).above_10to5_recs = GPC6_unnormed_by_animal(j).eps(1).tum_gro_vs_all_pix_vals(tot_pixs:tot_pixs+curr_pixs-1,2);
            GPC6_unnormed_by_animal(j).eps(q).above_tum_gro = GPC6_unnormed_by_animal(j).rec(p).tum_gro
            GPC6_unnormed_by_animal(j).eps(1).above_tum_gro_means(q,1) = mean(GPC6_unnormed_by_animal(j).eps(q).above_10to5_recs)
            GPC6_unnormed_by_animal(j).length(q).above_10to5_recs = GPC6_unnormed_by_animal(j).length(1).tum_gro_vs_all_pix_vals(tot_pixs:tot_pixs+curr_pixs-1,2);
            GPC6_unnormed_by_animal(j).length(q).above_tum_gro = GPC6_unnormed_by_animal(j).rec(p).tum_gro
            GPC6_unnormed_by_animal(j).length(1).above_tum_gro_means(q,1) = mean(GPC6_unnormed_by_animal(j).length(q).above_10to5_recs)
            GPC6_unnormed_by_animal(j).amp(q).above_10to5_recs = GPC6_unnormed_by_animal(j).amp(1).tum_gro_vs_all_pix_vals(tot_pixs:tot_pixs+curr_pixs-1,2);
            GPC6_unnormed_by_animal(j).amp(q).above_tum_gro = GPC6_unnormed_by_animal(j).rec(p).tum_gro
            GPC6_unnormed_by_animal(j).amp(1).above_tum_gro_means(q,1) = mean(GPC6_unnormed_by_animal(j).amp(q).above_10to5_recs)
            GPC6_unnormed_by_animal(j).area(q).above_10to5_recs = GPC6_unnormed_by_animal(j).area(1).tum_gro_vs_all_pix_vals(tot_pixs:tot_pixs+curr_pixs-1,2);
            GPC6_unnormed_by_animal(j).area(q).above_tum_gro = GPC6_unnormed_by_animal(j).rec(p).tum_gro
            GPC6_unnormed_by_animal(j).area(1).above_tum_gro_means(q,1) = mean(GPC6_unnormed_by_animal(j).area(q).above_10to5_recs)

            tot_pixs = tot_pixs+curr_pixs
            q=q+1;
        else
            GPC6_unnormed_by_animal(j).apm(1).all_tum_gro_vs_recs_means(s,3) = GPC6_unnormed_by_animal(j).rec(p).day_P %%new 20231127
            GPC6_unnormed_by_animal(j).apm(1).all_tum_gro_vs_recs_means(s,4) = GPC6_unnormed_by_animal(j).rec(p).day_P_tumgro_adjust %%new 20231127
            GPC6_unnormed_by_animal(j).apm(1).all_tum_gro_vs_recs_means(s,1) = GPC6_unnormed_by_animal(j).rec(p).tum_gro
            GPC6_unnormed_by_animal(j).apm(1).all_tum_gro_vs_recs_means(s,2) = mean(GPC6_unnormed_by_animal(j).apm(1).tum_gro_vs_all_pix_vals(tot_pixs:tot_pixs+curr_pixs-1,2))
            GPC6_unnormed_by_animal(j).eps(1).all_tum_gro_vs_recs_means(s,1) = GPC6_unnormed_by_animal(j).rec(p).tum_gro
            GPC6_unnormed_by_animal(j).eps(1).all_tum_gro_vs_recs_means(s,2) = mean(GPC6_unnormed_by_animal(j).eps(1).tum_gro_vs_all_pix_vals(tot_pixs:tot_pixs+curr_pixs-1,2))
            GPC6_unnormed_by_animal(j).length(1).all_tum_gro_vs_recs_means(s,1) = GPC6_unnormed_by_animal(j).rec(p).tum_gro
            GPC6_unnormed_by_animal(j).length(1).all_tum_gro_vs_recs_means(s,2) = mean(GPC6_unnormed_by_animal(j).length(1).tum_gro_vs_all_pix_vals(tot_pixs:tot_pixs+curr_pixs-1,2))
            GPC6_unnormed_by_animal(j).amp(1).all_tum_gro_vs_recs_means(s,1) = GPC6_unnormed_by_animal(j).rec(p).tum_gro
            GPC6_unnormed_by_animal(j).amp(1).all_tum_gro_vs_recs_means(s,2) = mean(GPC6_unnormed_by_animal(j).amp(1).tum_gro_vs_all_pix_vals(tot_pixs:tot_pixs+curr_pixs-1,2))
            GPC6_unnormed_by_animal(j).area(1).all_tum_gro_vs_recs_means(s,1) = GPC6_unnormed_by_animal(j).rec(p).tum_gro
            GPC6_unnormed_by_animal(j).area(1).all_tum_gro_vs_recs_means(s,2) = mean(GPC6_unnormed_by_animal(j).area(1).tum_gro_vs_all_pix_vals(tot_pixs:tot_pixs+curr_pixs-1,2))

            GPC6_unnormed_by_animal(j).apm(1).below_10to5_recs(below_pixs:below_pixs+curr_pixs-1,1) = ...
                GPC6_unnormed_by_animal(j).apm(1).tum_gro_vs_all_pix_vals(tot_pixs:tot_pixs+curr_pixs-1,2);
            GPC6_unnormed_by_animal(j).eps(1).below_10to5_recs(below_pixs:below_pixs+curr_pixs-1,1) = ...
                GPC6_unnormed_by_animal(j).eps(1).tum_gro_vs_all_pix_vals(tot_pixs:tot_pixs+curr_pixs-1,2);
            GPC6_unnormed_by_animal(j).length(1).below_10to5_recs(below_pixs:below_pixs+curr_pixs-1,1) = ...
                GPC6_unnormed_by_animal(j).length(1).tum_gro_vs_all_pix_vals(tot_pixs:tot_pixs+curr_pixs-1,2);
            GPC6_unnormed_by_animal(j).amp(1).below_10to5_recs(below_pixs:below_pixs+curr_pixs-1,1) = ...
                GPC6_unnormed_by_animal(j).amp(1).tum_gro_vs_all_pix_vals(tot_pixs:tot_pixs+curr_pixs-1,2);
            GPC6_unnormed_by_animal(j).area(1).below_10to5_recs(below_pixs:below_pixs+curr_pixs-1,1) = ...
                GPC6_unnormed_by_animal(j).area(1).tum_gro_vs_all_pix_vals(tot_pixs:tot_pixs+curr_pixs-1,2);
            GPC6_unnormed_by_animal(j).apm(r).below_10to5_recs_indiv = ...
                GPC6_unnormed_by_animal(j).apm(1).tum_gro_vs_all_pix_vals(tot_pixs:tot_pixs+curr_pixs-1,2);
            GPC6_unnormed_by_animal(j).apm(r).below_tum_gro = GPC6_unnormed_by_animal(j).rec(p).tum_gro
            GPC6_unnormed_by_animal(j).apm(1).below_10to5_recs_indiv_mean(r,1) = mean(GPC6_unnormed_by_animal(j).apm(r).below_10to5_recs_indiv);
            GPC6_unnormed_by_animal(j).eps(r).below_10to5_recs_indiv = ...
                GPC6_unnormed_by_animal(j).eps(1).tum_gro_vs_all_pix_vals(tot_pixs:tot_pixs+curr_pixs-1,2);
            GPC6_unnormed_by_animal(j).eps(r).below_tum_gro = GPC6_unnormed_by_animal(j).rec(p).tum_gro
            GPC6_unnormed_by_animal(j).eps(1).below_10to5_recs_indiv_mean(r,1) = mean(GPC6_unnormed_by_animal(j).eps(r).below_10to5_recs_indiv);
            GPC6_unnormed_by_animal(j).length(r).below_10to5_recs_indiv = ...
                GPC6_unnormed_by_animal(j).length(1).tum_gro_vs_all_pix_vals(tot_pixs:tot_pixs+curr_pixs-1,2);
            GPC6_unnormed_by_animal(j).length(r).below_tum_gro = GPC6_unnormed_by_animal(j).rec(p).tum_gro
            GPC6_unnormed_by_animal(j).length(1).below_10to5_recs_indiv_mean(r,1) = mean(GPC6_unnormed_by_animal(j).length(r).below_10to5_recs_indiv);
            GPC6_unnormed_by_animal(j).amp(r).below_10to5_recs_indiv = ...
                GPC6_unnormed_by_animal(j).amp(1).tum_gro_vs_all_pix_vals(tot_pixs:tot_pixs+curr_pixs-1,2);
            GPC6_unnormed_by_animal(j).amp(r).below_tum_gro = GPC6_unnormed_by_animal(j).rec(p).tum_gro
            GPC6_unnormed_by_animal(j).amp(1).below_10to5_recs_indiv_mean(r,1) = mean(GPC6_unnormed_by_animal(j).amp(r).below_10to5_recs_indiv);
            GPC6_unnormed_by_animal(j).area(r).below_10to5_recs_indiv = ...
                GPC6_unnormed_by_animal(j).area(1).tum_gro_vs_all_pix_vals(tot_pixs:tot_pixs+curr_pixs-1,2);
            GPC6_unnormed_by_animal(j).area(r).below_tum_gro = GPC6_unnormed_by_animal(j).rec(p).tum_gro
            GPC6_unnormed_by_animal(j).area(1).below_10to5_recs_indiv_mean(r,1) = mean(GPC6_unnormed_by_animal(j).area(r).below_10to5_recs_indiv);

            tot_pixs = tot_pixs+curr_pixs
            below_pixs = below_pixs+curr_pixs;
            r=r+1
            s=s+1
        end
    end
    normlims = [0 4]

    close all
    
    close all
    figure(89+j)
    set(gcf,'color','white')
    sz = 60;
    tiledlayout(2,3)
    nexttile
    %apm
    w = GPC6_unnormed_by_animal(j).apm(1).all_tum_gro_vs_recs_means(:,4)
    x = GPC6_unnormed_by_animal(j).apm(1).all_tum_gro_vs_recs_means(:,3)
    z = GPC6_unnormed_by_animal(j).apm(1).all_tum_gro_vs_recs_means(:,1)/0.5e6
    y = GPC6_unnormed_by_animal(j).apm(1).all_tum_gro_vs_recs_means(:,2)
    scatter(x,y,sz,'MarkerEdgeColor',[0, 0.4470, 0.7410],...
        'MarkerFaceColor',[0, 0.4470, 0.7410],...
        'LineWidth',1.5)
    hold on
    scatter(w,z,sz/2,'MarkerEdgeColor',[0, 0, 0],...
        'MarkerFaceColor',[0, 0, 0],...
        'LineWidth',1.5)
    hold on
    xx = min(x):1:max(x);
    yy = spline(x,y,xx);
    plot(xx,yy,'Color',[0, 0.4470, 0.7410])
    hold on
    ww = min(w):1:max(w)
    zz = spline(w,z,ww);
    plot(ww,zz,'Color', [0,0,0])
    %align xx,ww and adjust lengths of all four vectors accordingly
    if min(ww)<min(xx)
        mint = find(ww==min(xx))
        ww(:,1:mint-1) = [];
        zz(:,1:mint-1) = [];
    end
    if min(xx)<min(ww)
        mint = find(xx==min(ww))
        xx(:,1:mint-1) = [];
        yy(:,1:mint-1) = [];
    end
    if max(ww)>max(xx)
        maxt = find(ww==max(xx))
        ww(:,maxt+1:length(ww)) = [];
        zz(:,maxt+1:length(zz)) = [];
    end
    if max(xx)>max(ww)
        maxt = find(xx==max(ww))
        xx(:,maxt+1:length(xx)) = [];
        yy(:,maxt+1:length(yy)) = [];
    end
    GPC6_unnormed_by_animal(j).apm(1).oneperday_x_vs_spline_and_tum_gro(:,1) = xx;
    GPC6_unnormed_by_animal(j).apm(1).oneperday_x_vs_spline_and_tum_gro(:,2) = yy;
    GPC6_unnormed_by_animal(j).apm(1).oneperday_x_vs_spline_and_tum_gro(:,3) = zz;
    GPC6_unnormed_by_animal(j).apm(1).oneperday_x_vs_spline_and_tum_gro(:,4) = ww;

    nexttile
    z = GPC6_unnormed_by_animal(j).eps(1).all_tum_gro_vs_recs_means(:,1)/0.5e6
    y = GPC6_unnormed_by_animal(j).eps(1).all_tum_gro_vs_recs_means(:,2)
    scatter(x,y,sz,'MarkerEdgeColor',[0.8500, 0.3250, 0.0980],...
        'MarkerFaceColor',[0.8500, 0.3250, 0.0980],...
        'LineWidth',1.5)
    hold on
    scatter(x,z,sz/2,'MarkerEdgeColor',[0, 0, 0],...
        'MarkerFaceColor',[0, 0, 0],...
        'LineWidth',1.5)
    hold on
    yy = spline(x,y,xx);
    plot(xx,yy,'Color',[0.8500, 0.3250, 0.0980])
    hold on
    zz = spline(w,z,ww);
    plot(ww,zz,'Color', [0,0,0])
  
     if min(ww)<min(xx)
        mint = find(ww==min(xx))
        ww(:,1:mint-1) = [];
        zz(:,1:mint-1) = [];
    end
    if min(xx)<min(ww)
        mint = find(xx==min(ww))
        xx(:,1:mint-1) = [];
        yy(:,1:mint-1) = [];
    end
    if max(ww)>max(xx)
        maxt = find(ww==max(xx))
        ww(:,maxt+1:length(ww)) = [];
        zz(:,maxt+1:length(zz)) = [];
    end
    if max(xx)>max(ww)
        maxt = find(xx==max(ww))
        xx(:,maxt+1:length(xx)) = [];
        yy(:,maxt+1:length(yy)) = [];
    end
    GPC6_unnormed_by_animal(j).eps(1).oneperday_x_vs_spline_and_tum_gro(:,1) = xx;
    GPC6_unnormed_by_animal(j).eps(1).oneperday_x_vs_spline_and_tum_gro(:,2) = yy;
    GPC6_unnormed_by_animal(j).eps(1).oneperday_x_vs_spline_and_tum_gro(:,3) = zz;
    GPC6_unnormed_by_animal(j).eps(1).oneperday_x_vs_spline_and_tum_gro(:,4) = ww;
   
    nexttile
    z = GPC6_unnormed_by_animal(j).length(1).all_tum_gro_vs_recs_means(:,1)/0.5e6
    y = GPC6_unnormed_by_animal(j).length(1).all_tum_gro_vs_recs_means(:,2)
    scatter(x,y,sz,'MarkerEdgeColor',[0.8500, 0.3250, 0.0980],...
        'MarkerFaceColor',[0.8500, 0.3250, 0.0980],...
        'LineWidth',1.5)
    hold on
    scatter(x,z,sz/2,'MarkerEdgeColor',[0, 0, 0],...
        'MarkerFaceColor',[0, 0, 0],...
        'LineWidth',1.5)
    hold on
    yy = spline(x,y,xx);
    plot(xx,yy,'Color',[0.8500, 0.3250, 0.0980])
    hold on
    zz = spline(w,z,ww);
    plot(ww,zz,'Color', [0,0,0])
    if min(ww)<min(xx)
        mint = find(ww==min(xx))
        ww(:,1:mint-1) = [];
        zz(:,1:mint-1) = [];
    end
    if min(xx)<min(ww)
        mint = find(xx==min(ww))
        xx(:,1:mint-1) = [];
        yy(:,1:mint-1) = [];
    end
    if max(ww)>max(xx)
        maxt = find(ww==max(xx))
        ww(:,maxt+1:length(ww)) = [];
        zz(:,maxt+1:length(zz)) = [];
    end
    if max(xx)>max(ww)
        maxt = find(xx==max(ww))
        xx(:,maxt+1:length(xx)) = [];
        yy(:,maxt+1:length(yy)) = [];
    end
    GPC6_unnormed_by_animal(j).length(1).oneperday_x_vs_spline_and_tum_gro(:,1) = xx;
    GPC6_unnormed_by_animal(j).length(1).oneperday_x_vs_spline_and_tum_gro(:,2) = yy;
    GPC6_unnormed_by_animal(j).length(1).oneperday_x_vs_spline_and_tum_gro(:,3) = zz;
    GPC6_unnormed_by_animal(j).length(1).oneperday_x_vs_spline_and_tum_gro(:,4) = ww;

    nexttile
    z = GPC6_unnormed_by_animal(j).amp(1).all_tum_gro_vs_recs_means(:,1)/0.5e6
    y = GPC6_unnormed_by_animal(j).amp(1).all_tum_gro_vs_recs_means(:,2)
    scatter(x,y,sz,'MarkerEdgeColor',[0.8500, 0.3250, 0.0980],...
        'MarkerFaceColor',[0.8500, 0.3250, 0.0980],...
        'LineWidth',1.5)
    hold on
    scatter(x,z,sz/2,'MarkerEdgeColor',[0, 0, 0],...
        'MarkerFaceColor',[0, 0, 0],...
        'LineWidth',1.5)
    hold on
    yy = spline(x,y,xx);
    plot(xx,yy,'Color',[0.8500, 0.3250, 0.0980])
    hold on
    zz = spline(w,z,ww);
    plot(ww,zz,'Color', [0,0,0])
    if min(ww)<min(xx)
        mint = find(ww==min(xx))
        ww(:,1:mint-1) = [];
        zz(:,1:mint-1) = [];
    end
    if min(xx)<min(ww)
        mint = find(xx==min(ww))
        xx(:,1:mint-1) = [];
        yy(:,1:mint-1) = [];
    end
    if max(ww)>max(xx)
        maxt = find(ww==max(xx))
        ww(:,maxt+1:length(ww)) = [];
        zz(:,maxt+1:length(zz)) = [];
    end
    if max(xx)>max(ww)
        maxt = find(xx==max(ww))
        xx(:,maxt+1:length(xx)) = [];
        yy(:,maxt+1:length(yy)) = [];
    end
    GPC6_unnormed_by_animal(j).amp(1).oneperday_x_vs_spline_and_tum_gro(:,1) = xx;
    GPC6_unnormed_by_animal(j).amp(1).oneperday_x_vs_spline_and_tum_gro(:,2) = yy;
    GPC6_unnormed_by_animal(j).amp(1).oneperday_x_vs_spline_and_tum_gro(:,3) = zz;
    GPC6_unnormed_by_animal(j).amp(1).oneperday_x_vs_spline_and_tum_gro(:,4) = ww;

    nexttile
    z = GPC6_unnormed_by_animal(j).area(1).all_tum_gro_vs_recs_means(:,1)/0.5e6
    y = GPC6_unnormed_by_animal(j).area(1).all_tum_gro_vs_recs_means(:,2)
    scatter(x,y,sz,'MarkerEdgeColor',[0.8500, 0.3250, 0.0980],...
        'MarkerFaceColor',[0.8500, 0.3250, 0.0980],...
        'LineWidth',1.5)
    hold on
    scatter(x,z,sz/2,'MarkerEdgeColor',[0, 0, 0],...
        'MarkerFaceColor',[0, 0, 0],...
        'LineWidth',1.5)
    hold on
    yy = spline(x,y,xx);
    plot(xx,yy,'Color',[0.8500, 0.3250, 0.0980])
    hold on
    zz = spline(w,z,ww);
    plot(ww,zz,'Color', [0,0,0])
    if min(ww)<min(xx)
        mint = find(ww==min(xx))
        ww(:,1:mint-1) = [];
        zz(:,1:mint-1) = [];
    end
    if min(xx)<min(ww)
        mint = find(xx==min(ww))
        xx(:,1:mint-1) = [];
        yy(:,1:mint-1) = [];
    end
    if max(ww)>max(xx)
        maxt = find(ww==max(xx))
        ww(:,maxt+1:length(ww)) = [];
        zz(:,maxt+1:length(zz)) = [];
    end
    if max(xx)>max(ww)
        maxt = find(xx==max(ww))
        xx(:,maxt+1:length(xx)) = [];
        yy(:,maxt+1:length(yy)) = [];
    end
    GPC6_unnormed_by_animal(j).area(1).oneperday_x_vs_spline_and_tum_gro(:,1) = xx;
    GPC6_unnormed_by_animal(j).area(1).oneperday_x_vs_spline_and_tum_gro(:,2) = yy;
    GPC6_unnormed_by_animal(j).area(1).oneperday_x_vs_spline_and_tum_gro(:,3) = zz;
    GPC6_unnormed_by_animal(j).area(1).oneperday_x_vs_spline_and_tum_gro(:,4) = ww;
    saveas(89+j,['animal_' num2str(curr_anim) 'scatter_dayP_vs_whole_FOV_' tg '_vs_apm_eps_length_amp_area' '.png'], 'png')
    saveas(89+j,['animal_' num2str(curr_anim) 'scatter_dayP_vs_whole_FOV_' tg '_vs_apm_eps_length_amp_area' '.pdf'], 'pdf')
end

a=1
GPC6_unnormed_anims = [48 49 71 72 73]
for j = 1:5
    curr_anim = GPC6_unnormed_anims(1,j)
    tumgro_diff = GPC6_unnormed_by_animal(j).apm(1).oneperday_x_vs_spline_and_tum_gro(:,3);
    apm.diff =  [diff(GPC6_unnormed_by_animal(j).apm(1).oneperday_x_vs_spline_and_tum_gro(:,2)); 0];
    eps.diff =  [diff(GPC6_unnormed_by_animal(j).eps(1).oneperday_x_vs_spline_and_tum_gro(:,2)); 0];
    lengthh.diff =  [diff(GPC6_unnormed_by_animal(j).length(1).oneperday_x_vs_spline_and_tum_gro(:,2)); 0];
    amp.diff =  [diff(GPC6_unnormed_by_animal(j).amp(1).oneperday_x_vs_spline_and_tum_gro(:,2)); 0];
    area.diff =  [diff(GPC6_unnormed_by_animal(j).area(1).oneperday_x_vs_spline_and_tum_gro(:,2)); 0];
    difflength = size(tumgro_diff,1);
    day_shifts = [-15:1:15]
    for k = 1:31
        vec2 = tumgro_diff(1+max(day_shifts(1,k),0):difflength+min(day_shifts(1,k),0),1);
        vec1 = apm.diff(1-min(day_shifts(1,k),0):difflength-max(day_shifts(1,k),0),1)
        currcorr = corrcoef(vec1,vec2)
        GPC6_unnormed_by_animal(j).apm(1).shift_corrcoeff(k,1) = (currcorr(1,2))
        GPC6_unnormed.corrshift_anal.apm(j,k) = (currcorr(1,2))
        vec1 = eps.diff(1-min(day_shifts(1,k),0):difflength-max(day_shifts(1,k),0),1)
        currcorr = corrcoef(vec1,vec2)
        GPC6_unnormed_by_animal(j).eps(1).shift_corrcoeff(k,1) = (currcorr(1,2))
        GPC6_unnormed.corrshift_anal.eps(j,k) = (currcorr(1,2))
        vec1 = lengthh.diff(1-min(day_shifts(1,k),0):difflength-max(day_shifts(1,k),0),1)
        currcorr = corrcoef(vec1,vec2)
        GPC6_unnormed_by_animal(j).length(1).shift_corrcoeff(k,1) = (currcorr(1,2))
        GPC6_unnormed.corrshift_anal.length(j,k) = (currcorr(1,2))
        vec1 = amp.diff(1-min(day_shifts(1,k),0):difflength-max(day_shifts(1,k),0),1)
        currcorr = corrcoef(vec1,vec2)
        GPC6_unnormed_by_animal(j).amp(1).shift_corrcoeff(k,1) = (currcorr(1,2))
        GPC6_unnormed.corrshift_anal.amp(j,k) = (currcorr(1,2))
        vec1 = area.diff(1-min(day_shifts(1,k),0):difflength-max(day_shifts(1,k),0),1)
        currcorr = corrcoef(vec1,vec2)
        GPC6_unnormed_by_animal(j).area(1).shift_corrcoeff(k,1) = (currcorr(1,2))
        GPC6_unnormed.corrshift_anal.area(j,k) = (currcorr(1,2))
    end
end

close all
figure(89+j)
set(gcf,'color','white')
sz = 60;
tiledlayout(2,3)
nexttile
plot(GPC6_unnormed.corrshift_anal.apm(1,:))
hold on
plot(GPC6_unnormed.corrshift_anal.apm(2,:))
hold on
plot(GPC6_unnormed.corrshift_anal.apm(3,:))
hold on
plot(GPC6_unnormed.corrshift_anal.apm(4,:))
hold on
plot(GPC6_unnormed.corrshift_anal.apm(5,:))

nexttile
plot(GPC6_unnormed.corrshift_anal.eps(1,:))
hold on
plot(GPC6_unnormed.corrshift_anal.eps(2,:))
hold on
plot(GPC6_unnormed.corrshift_anal.eps(3,:))
hold on
plot(GPC6_unnormed.corrshift_anal.eps(4,:))
hold on
plot(GPC6_unnormed.corrshift_anal.eps(5,:))

nexttile
plot(GPC6_unnormed.corrshift_anal.length(1,:))
hold on
plot(GPC6_unnormed.corrshift_anal.length(2,:))
hold on
plot(GPC6_unnormed.corrshift_anal.length(3,:))
hold on
plot(GPC6_unnormed.corrshift_anal.length(4,:))
hold on
plot(GPC6_unnormed.corrshift_anal.length(5,:))

nexttile
plot(GPC6_unnormed.corrshift_anal.amp(1,:))
hold on
plot(GPC6_unnormed.corrshift_anal.amp(2,:))
hold on
plot(GPC6_unnormed.corrshift_anal.amp(3,:))
hold on
plot(GPC6_unnormed.corrshift_anal.amp(4,:))
hold on
plot(GPC6_unnormed.corrshift_anal.amp(5,:))

nexttile
plot(GPC6_unnormed.corrshift_anal.area(1,:))
hold on
plot(GPC6_unnormed.corrshift_anal.area(2,:))
hold on
plot(GPC6_unnormed.corrshift_anal.area(3,:))
hold on
plot(GPC6_unnormed.corrshift_anal.area(4,:))
hold on
plot(GPC6_unnormed.corrshift_anal.area(5,:))

a=1
GPC6_unnormed_anims = [48 49 71 72 73]
for j = 1:5
    curr_anim = GPC6_unnormed_anims(1,j)
    a=1
    clear kur
    b=1
    clear pur
    if initially_norm_by_first_rec
        curr_below_avg = 1
    else
        curr_below_avg = mean(GPC6_unnormed_by_animal(j).apm(1).below_10to5_recs_indiv_mean);
    end
    GPC6_unnormed_by_animal(j).apm(1).all_indiv_below_recs_div_by_all_below_avg = GPC6_unnormed_by_animal(j).apm(1).below_10to5_recs_indiv_mean/curr_below_avg;
    for k = 1:size(GPC6_unnormed_by_animal(j).apm,2)
        GPC6_unnormed_by_animal(j).apm(k).above_10to5_mean = ...
            mean(GPC6_unnormed_by_animal(j).apm(k).above_10to5_recs)/curr_below_avg;
        GPC6_unnormed_by_animal(j).apm(k).below_10to5_mean = ...
            mean(GPC6_unnormed_by_animal(j).apm(k).below_10to5_recs)/curr_below_avg;
        if ~isnan(GPC6_unnormed_by_animal(j).apm(k).above_10to5_mean)
            kur(a,1) = GPC6_unnormed_by_animal(j).apm(k).above_10to5_mean
            GPC6_unnormed_by_animal(j).apm(1).all_indiv_above_recs_div_by_all_below_avg(a,1) = kur(a,1);
            a=a+1
        end
    end
    GPC6_unnormed_by_animal(j).apm(1).mean_above_recs_div_by_all_mean_below = mean(kur);
    GPC6_unnormed.apm_mean_above_recs_div_by_all_mean_below(j,1) = mean(kur)
    [p,h,stats] = ranksum(GPC6_unnormed_by_animal(j).apm(1).below_10to5_recs_indiv_mean,GPC6_unnormed_by_animal(j).apm(1).above_tum_gro_means)
    GPC6_unnormed_by_animal(j).stats.apm_indiv_rec_means_above_vs_below.p = p;
    GPC6_unnormed_by_animal(j).stats.apm_indiv_rec_means_above_vs_below.h = h;
    GPC6_unnormed_by_animal(j).stats.apm_indiv_rec_means_above_vs_below.stats = stats;
    a=1
    clear kur
    b=1
    clear pur
    if initially_norm_by_first_rec
        curr_below_avg = 1
    else
        curr_below_avg = mean(GPC6_unnormed_by_animal(j).eps(1).below_10to5_recs_indiv_mean);
    end
    GPC6_unnormed_by_animal(j).eps(1).all_indiv_below_recs_div_by_all_below_avg = GPC6_unnormed_by_animal(j).eps(1).below_10to5_recs_indiv_mean/curr_below_avg;

    for k = 1:size(GPC6_unnormed_by_animal(j).eps,2)
        GPC6_unnormed_by_animal(j).eps(k).above_10to5_mean = ...
            mean(GPC6_unnormed_by_animal(j).eps(k).above_10to5_recs)/curr_below_avg;
        GPC6_unnormed_by_animal(j).eps(k).below_10to5_mean = ...
            mean(GPC6_unnormed_by_animal(j).eps(k).below_10to5_recs)/curr_below_avg;
        if ~isnan(GPC6_unnormed_by_animal(j).eps(k).above_10to5_mean)
            kur(a,1) = GPC6_unnormed_by_animal(j).eps(k).above_10to5_mean
            GPC6_unnormed_by_animal(j).eps(1).all_indiv_above_recs_div_by_all_below_avg(a,1) = kur(a,1);
            a=a+1
        end
    end
    GPC6_unnormed_by_animal(j).eps(1).mean_above_recs_div_by_all_mean_below = mean(kur);
    GPC6_unnormed.eps_mean_above_recs_div_by_all_mean_below(j,1) = mean(kur)
    [p,h,stats] = ranksum(GPC6_unnormed_by_animal(j).eps(1).below_10to5_recs_indiv_mean,GPC6_unnormed_by_animal(j).eps(1).above_tum_gro_means)
    GPC6_unnormed_by_animal(j).stats.eps_indiv_rec_means_above_vs_below.p = p;
    GPC6_unnormed_by_animal(j).stats.eps_indiv_rec_means_above_vs_below.h = h;
    GPC6_unnormed_by_animal(j).stats.eps_indiv_rec_means_above_vs_below.stats = stats;

    a=1
    clear kur
    b=1
    clear pur
    if initially_norm_by_first_rec
        curr_below_avg = 1
    else
        curr_below_avg = mean(GPC6_unnormed_by_animal(j).length(1).below_10to5_recs_indiv_mean);
    end
    GPC6_unnormed_by_animal(j).length(1).all_indiv_below_recs_div_by_all_below_avg = GPC6_unnormed_by_animal(j).length(1).below_10to5_recs_indiv_mean/curr_below_avg;
    for k = 1:size(GPC6_unnormed_by_animal(j).length,2)
        GPC6_unnormed_by_animal(j).length(k).above_10to5_mean = ...
            mean(GPC6_unnormed_by_animal(j).length(k).above_10to5_recs)/curr_below_avg;
        GPC6_unnormed_by_animal(j).length(k).below_10to5_mean = ...
            mean(GPC6_unnormed_by_animal(j).length(k).below_10to5_recs)/curr_below_avg;
        if ~isnan(GPC6_unnormed_by_animal(j).length(k).above_10to5_mean)
            kur(a,1) = GPC6_unnormed_by_animal(j).length(k).above_10to5_mean
            GPC6_unnormed_by_animal(j).length(1).all_indiv_above_recs_div_by_all_below_avg(a,1) = kur(a,1);
            a=a+1
        end
    end
    GPC6_unnormed_by_animal(j).length(1).mean_above_recs_div_by_all_mean_below = mean(kur);
    GPC6_unnormed.length_mean_above_recs_div_by_all_mean_below(j,1) = mean(kur)
    [p,h,stats] = ranksum(GPC6_unnormed_by_animal(j).length(1).below_10to5_recs_indiv_mean,GPC6_unnormed_by_animal(j).length(1).above_tum_gro_means)
    GPC6_unnormed_by_animal(j).stats.length_indiv_rec_means_above_vs_below.p = p;
    GPC6_unnormed_by_animal(j).stats.length_indiv_rec_means_above_vs_below.h = h;
    GPC6_unnormed_by_animal(j).stats.length_indiv_rec_means_above_vs_below.stats = stats;

    a=1
    clear kur
    b=1
    clear pur
    if initially_norm_by_first_rec
        curr_below_avg = 1
    else
        curr_below_avg = mean(GPC6_unnormed_by_animal(j).amp(1).below_10to5_recs_indiv_mean);
    end
    GPC6_unnormed_by_animal(j).amp(1).all_indiv_below_recs_div_by_all_below_avg = GPC6_unnormed_by_animal(j).amp(1).below_10to5_recs_indiv_mean/curr_below_avg;
    for k = 1:size(GPC6_unnormed_by_animal(j).amp,2)
        GPC6_unnormed_by_animal(j).amp(k).above_10to5_mean = ...
            mean(GPC6_unnormed_by_animal(j).amp(k).above_10to5_recs)/curr_below_avg;
        GPC6_unnormed_by_animal(j).amp(k).below_10to5_mean = ...
            mean(GPC6_unnormed_by_animal(j).amp(k).below_10to5_recs)/curr_below_avg;
        if ~isnan(GPC6_unnormed_by_animal(j).amp(k).above_10to5_mean)
            kur(a,1) = GPC6_unnormed_by_animal(j).amp(k).above_10to5_mean
            GPC6_unnormed_by_animal(j).amp(1).all_indiv_above_recs_div_by_all_below_avg(a,1) = kur(a,1);
            a=a+1
        end
    end
    GPC6_unnormed_by_animal(j).amp(1).mean_above_recs_div_by_all_mean_below = mean(kur);
    GPC6_unnormed.amp_mean_above_recs_div_by_all_mean_below(j,1) = mean(kur)
    [p,h,stats] = ranksum(GPC6_unnormed_by_animal(j).amp(1).below_10to5_recs_indiv_mean,GPC6_unnormed_by_animal(j).amp(1).above_tum_gro_means)
    GPC6_unnormed_by_animal(j).stats.amp_indiv_rec_means_above_vs_below.p = p;
    GPC6_unnormed_by_animal(j).stats.amp_indiv_rec_means_above_vs_below.h = h;
    GPC6_unnormed_by_animal(j).stats.amp_indiv_rec_means_above_vs_below.stats = stats;

    a=1
    clear kur
    b=1
    clear pur
    if initially_norm_by_first_rec
        curr_below_avg = 1
    else
        curr_below_avg = mean(GPC6_unnormed_by_animal(j).area(1).below_10to5_recs_indiv_mean);
    end
    GPC6_unnormed_by_animal(j).area(1).all_indiv_below_recs_div_by_all_below_avg = GPC6_unnormed_by_animal(j).area(1).below_10to5_recs_indiv_mean/curr_below_avg;
    for k = 1:size(GPC6_unnormed_by_animal(j).area,2)
        GPC6_unnormed_by_animal(j).area(k).above_10to5_mean = ...
            mean(GPC6_unnormed_by_animal(j).area(k).above_10to5_recs)/curr_below_avg;
        GPC6_unnormed_by_animal(j).area(k).below_10to5_mean = ...
            mean(GPC6_unnormed_by_animal(j).area(k).below_10to5_recs)/curr_below_avg;
        if ~isnan(GPC6_unnormed_by_animal(j).area(k).above_10to5_mean)
            kur(a,1) = GPC6_unnormed_by_animal(j).area(k).above_10to5_mean
            GPC6_unnormed_by_animal(j).area(1).all_indiv_above_recs_div_by_all_below_avg(a,1) = kur(a,1);
            a=a+1
        end
    end
    GPC6_unnormed_by_animal(j).area(1).mean_above_recs_div_by_all_mean_below = mean(kur);
    GPC6_unnormed.area_mean_above_recs_div_by_all_mean_below(j,1) = mean(kur)
    [p,h,stats] = ranksum(GPC6_unnormed_by_animal(j).area(1).below_10to5_recs_indiv_mean,GPC6_unnormed_by_animal(j).area(1).above_tum_gro_means)
    GPC6_unnormed_by_animal(j).stats.area_indiv_rec_means_above_vs_below.p = p;
    GPC6_unnormed_by_animal(j).stats.area_indiv_rec_means_above_vs_below.h = h;
    GPC6_unnormed_by_animal(j).stats.area_indiv_rec_means_above_vs_below.stats = stats;
end

for j = 1:5
    GPC6_unnormed.apm.mean_below_above_means_normed(j,1) = mean(GPC6_unnormed_by_animal(j).apm(1).all_indiv_below_recs_div_by_all_below_avg)
    GPC6_unnormed.apm.mean_below_above_means_normed(j,2) = mean(GPC6_unnormed_by_animal(j).apm(1).all_indiv_above_recs_div_by_all_below_avg)
    GPC6_unnormed.eps.mean_below_above_means_normed(j,1) = mean(GPC6_unnormed_by_animal(j).eps(1).all_indiv_below_recs_div_by_all_below_avg)
    GPC6_unnormed.eps.mean_below_above_means_normed(j,2) = mean(GPC6_unnormed_by_animal(j).eps(1).all_indiv_above_recs_div_by_all_below_avg)
    GPC6_unnormed.length.mean_below_above_means_normed(j,1) = mean(GPC6_unnormed_by_animal(j).length(1).all_indiv_below_recs_div_by_all_below_avg)
    GPC6_unnormed.length.mean_below_above_means_normed(j,2) = mean(GPC6_unnormed_by_animal(j).length(1).all_indiv_above_recs_div_by_all_below_avg)
    GPC6_unnormed.amp.mean_below_above_means_normed(j,1) = mean(GPC6_unnormed_by_animal(j).amp(1).all_indiv_below_recs_div_by_all_below_avg)
    GPC6_unnormed.amp.mean_below_above_means_normed(j,2) = mean(GPC6_unnormed_by_animal(j).amp(1).all_indiv_above_recs_div_by_all_below_avg)
    GPC6_unnormed.area.mean_below_above_means_normed(j,1) = mean(GPC6_unnormed_by_animal(j).area(1).all_indiv_below_recs_div_by_all_below_avg)
    GPC6_unnormed.area.mean_below_above_means_normed(j,2) = mean(GPC6_unnormed_by_animal(j).area(1).all_indiv_above_recs_div_by_all_below_avg)
end

tumor.stats20231122.apm.Cr86_unnormed_below_above_GPC6_unnormed_below_above(:,1:2) = Cr86_unnormed.apm.mean_below_above_means_normed;
tumor.stats20231122.apm.Cr86_unnormed_below_above_GPC6_unnormed_below_above(:,3:4) = GPC6_unnormed.apm.mean_below_above_means_normed;
tumor.stats20231122.eps.Cr86_unnormed_below_above_GPC6_unnormed_below_above(:,1:2) = Cr86_unnormed.eps.mean_below_above_means_normed;
tumor.stats20231122.eps.Cr86_unnormed_below_above_GPC6_unnormed_below_above(:,3:4) = GPC6_unnormed.eps.mean_below_above_means_normed;
tumor.stats20231122.length.Cr86_unnormed_below_above_GPC6_unnormed_below_above(:,1:2) = Cr86_unnormed.length.mean_below_above_means_normed;
tumor.stats20231122.length.Cr86_unnormed_below_above_GPC6_unnormed_below_above(:,3:4) = GPC6_unnormed.length.mean_below_above_means_normed;
tumor.stats20231122.amp.Cr86_unnormed_below_above_GPC6_unnormed_below_above(:,1:2) = Cr86_unnormed.amp.mean_below_above_means_normed;
tumor.stats20231122.amp.Cr86_unnormed_below_above_GPC6_unnormed_below_above(:,3:4) = GPC6_unnormed.amp.mean_below_above_means_normed;
tumor.stats20231122.area.Cr86_unnormed_below_above_GPC6_unnormed_below_above(:,1:2) = Cr86_unnormed.area.mean_below_above_means_normed;
tumor.stats20231122.area.Cr86_unnormed_below_above_GPC6_unnormed_below_above(:,3:4) = GPC6_unnormed.area.mean_below_above_means_normed;

[p, tbl, stats] = kruskalwallis(tumor.stats20231122.apm.Cr86_unnormed_below_above_GPC6_unnormed_below_above)
saveas(2,['boxplot_apm_Cr86_unnormed_below_above_GPC6_unnormed_by_tum_gro_whole_FOV_means_norm' '.svg'], 'svg');
saveas(2,['boxplot_apm_Cr86_unnormed_below_above_GPC6_unnormed_by_tum_gro_whole_FOV_means_norm' '.emf'], 'emf');
[comparison,means,H,gnames1] = multcompare(stats)
tumor.stats20231122.apm.KW.p = p;
tumor.stats20231122.apm.KW.tbl = tbl;
tumor.stats20231122.apm.KW.stats = stats;
tumor.stats20231122.apm.KW.mult_comparison = comparison;
tumor.stats20231122.apm.KW.mult_means = means;
saveas(H,['multcomp_apm_Cr86_unnormed_below_above_GPC6_unnormed_by_tum_gro_whole_FOV_means_norm' '.png'], 'png')
saveas(H,['multcomp_apm_Cr86_unnormed_below_above_GPC6_unnormed_by_tum_gro_whole_FOV_means_norm' '.fig'], 'fig')

close all
figure(45)
set(gcf,'color','white')
x = tumor.stats20231122.apm.Cr86_unnormed_below_above_GPC6_unnormed_below_above(:,1)
x(find(isnan(x)),:) = [];
xx = tumor.stats20231122.apm.Cr86_unnormed_below_above_GPC6_unnormed_below_above(:,3)
xx(find(isnan(xx)),:) = [];
y = tumor.stats20231122.apm.Cr86_unnormed_below_above_GPC6_unnormed_below_above(:,2)
y(find(isnan(y)),:) = [];
yy = tumor.stats20231122.apm.Cr86_unnormed_below_above_GPC6_unnormed_below_above(:,4)
yy(find(isnan(yy)),:) = [];

h=bar([mean(x) mean(y); mean(xx) mean(yy)]);
hold on
h(1).FaceColor='w';
h(1).LineWidth = 2;
h(1).EdgeColor = 'r';
errorbar(h(1).XEndPoints,[mean(x) mean(xx)],[std(x)/sqrt(length(x)) std(xx)/sqrt(length(xx))],'LineStyle','none','Color','r','LineWidth',2)
hold on
h(2).FaceColor='w';
h(2).LineWidth = 2;
h(2).EdgeColor = 'b';
errorbar(h(2).XEndPoints,[mean(y) mean(yy)],[std(y)/sqrt(length(y)) std(yy)/sqrt(length(yy))],'LineStyle','none','Color','b','LineWidth',2)
set(gca,'FontSize',24)
set(gca,'FontName','Arial')
saveas(45,['barplot_apm_Cr86_unnormed_below_above_GPC6_unnormed_by_tum_gro_whole_FOV_means_norm' '.pdf'], 'pdf')
saveas(45,['barplot_apm_Cr86_unnormed_below_above_GPC6_unnormed_by_tum_gro_whole_FOV_means_norm' '.emf'], 'emf')
saveas(45,['barplot_apm_Cr86_unnormed_below_above_GPC6_unnormed_by_tum_gro_whole_FOV_means_norm' '.svg'], 'svg')
saveas(45,['barplot_apm_Cr86_unnormed_below_above_GPC6_unnormed_by_tum_gro_whole_FOV_means_norm' '.tif'], 'tif')

close all
[p, tbl, stats] = kruskalwallis(tumor.stats20231122.eps.Cr86_unnormed_below_above_GPC6_unnormed_below_above)
saveas(2,['boxplot_eps_Cr86_unnormed_below_above_GPC6_unnormed_by_tum_gro_whole_FOV_means_norm' '.svg'], 'svg');
saveas(2,['boxplot_eps_Cr86_unnormed_below_above_GPC6_unnormed_by_tum_gro_whole_FOV_means_norm' '.emf'], 'emf');
[comparison,means,H,gnames1] = multcompare(stats)
tumor.stats20231122.eps.KW.p = p;
tumor.stats20231122.eps.KW.tbl = tbl;
tumor.stats20231122.eps.KW.stats = stats;
tumor.stats20231122.eps.KW.mult_comparison = comparison;
tumor.stats20231122.eps.KW.mult_means = means;
saveas(H,['multcomp_eps_Cr86_unnormed_below_above_GPC6_unnormed_by_tum_gro_whole_FOV_means_norm' '.png'], 'png')
saveas(H,['multcomp_eps_Cr86_unnormed_below_above_GPC6_unnormed_by_tum_gro_whole_FOV_means_norm' '.fig'], 'fig')

close all
figure(450)
set(gcf,'color','white')
x = tumor.stats20231122.eps.Cr86_unnormed_below_above_GPC6_unnormed_below_above(:,1)
x(find(isnan(x)),:) = [];
xx = tumor.stats20231122.eps.Cr86_unnormed_below_above_GPC6_unnormed_below_above(:,3)
xx(find(isnan(xx)),:) = [];
y = tumor.stats20231122.eps.Cr86_unnormed_below_above_GPC6_unnormed_below_above(:,2)
y(find(isnan(y)),:) = [];
yy = tumor.stats20231122.eps.Cr86_unnormed_below_above_GPC6_unnormed_below_above(:,4)
yy(find(isnan(yy)),:) = [];

h=bar([mean(x) mean(y); mean(xx) mean(yy)]);
hold on
h(1).FaceColor='w';
h(1).LineWidth = 2;
h(1).EdgeColor = 'r';
errorbar(h(1).XEndPoints,[mean(x) mean(xx)],[std(x)/sqrt(length(x)) std(xx)/sqrt(length(xx))],'LineStyle','none','Color','r','LineWidth',2)
hold on
h(2).FaceColor='w';
h(2).LineWidth = 2;
h(2).EdgeColor = 'b';
errorbar(h(2).XEndPoints,[mean(y) mean(yy)],[std(y)/sqrt(length(y)) std(yy)/sqrt(length(yy))],'LineStyle','none','Color','b','LineWidth',2)

set(gca,'FontSize',24)
set(gca,'FontName','Arial')
saveas(450,['barplot_eps_Cr86_unnormed_below_above_GPC6_unnormed_by_tum_gro_whole_FOV_means_norm' '.pdf'], 'pdf')
saveas(450,['barplot_eps_Cr86_unnormed_below_above_GPC6_unnormed_by_tum_gro_whole_FOV_means_norm' '.emf'], 'emf')
saveas(450,['barplot_eps_Cr86_unnormed_below_above_GPC6_unnormed_by_tum_gro_whole_FOV_means_norm' '.svg'], 'svg')
saveas(450,['barplot_eps_Cr86_unnormed_below_above_GPC6_unnormed_by_tum_gro_whole_FOV_means_norm' '.tif'], 'tif')

close all
[p, tbl, stats] = kruskalwallis(tumor.stats20231122.length.Cr86_unnormed_below_above_GPC6_unnormed_below_above)
saveas(2,['boxplot_length_Cr86_unnormed_below_above_GPC6_unnormed_by_tum_gro_whole_FOV_means_norm' '.svg'], 'svg');
saveas(2,['boxplot_length_Cr86_unnormed_below_above_GPC6_unnormed_by_tum_gro_whole_FOV_means_norm' '.emf'], 'emf');
[comparison,means,H,gnames1] = multcompare(stats)
tumor.stats20231122.length.KW.p = p;
tumor.stats20231122.length.KW.tbl = tbl;
tumor.stats20231122.length.KW.stats = stats;
tumor.stats20231122.length.KW.mult_comparison = comparison;
tumor.stats20231122.length.KW.mult_means = means;
saveas(H,['multcomp_length_Cr86_unnormed_below_above_GPC6_unnormed_by_tum_gro_whole_FOV_means_norm' '.png'], 'png')
saveas(H,['multcomp_length_Cr86_unnormed_below_above_GPC6_unnormed_by_tum_gro_whole_FOV_means_norm' '.fig'], 'fig')
close all
figure(455)
set(gcf,'color','white')
x = tumor.stats20231122.length.Cr86_unnormed_below_above_GPC6_unnormed_below_above(:,1)
x(find(isnan(x)),:) = [];
xx = tumor.stats20231122.length.Cr86_unnormed_below_above_GPC6_unnormed_below_above(:,3)
xx(find(isnan(xx)),:) = [];
y = tumor.stats20231122.length.Cr86_unnormed_below_above_GPC6_unnormed_below_above(:,2)
y(find(isnan(y)),:) = [];
yy = tumor.stats20231122.length.Cr86_unnormed_below_above_GPC6_unnormed_below_above(:,4)
yy(find(isnan(yy)),:) = [];

h=bar([mean(x) mean(y); mean(xx) mean(yy)]);
hold on
h(1).FaceColor='w';
h(1).LineWidth = 2;
h(1).EdgeColor = 'r';
errorbar(h(1).XEndPoints,[mean(x) mean(xx)],[std(x)/sqrt(length(x)) std(xx)/sqrt(length(xx))],'LineStyle','none','Color','r','LineWidth',2)
hold on
h(2).FaceColor='w';
h(2).LineWidth = 2;
h(2).EdgeColor = 'b';
errorbar(h(2).XEndPoints,[mean(y) mean(yy)],[std(y)/sqrt(length(y)) std(yy)/sqrt(length(yy))],'LineStyle','none','Color','b','LineWidth',2)

set(gca,'FontSize',24)
set(gca,'FontName','Arial')

saveas(455,['barplot_length_Cr86_unnormed_below_above_GPC6_unnormed_by_tum_gro_whole_FOV_means_norm' '.pdf'], 'pdf')
saveas(455,['barplot_length_Cr86_unnormed_below_above_GPC6_unnormed_by_tum_gro_whole_FOV_means_norm' '.emf'], 'emf')
saveas(455,['barplot_length_Cr86_unnormed_below_above_GPC6_unnormed_by_tum_gro_whole_FOV_means_norm' '.svg'], 'svg')
saveas(455,['barplot_length_Cr86_unnormed_below_above_GPC6_unnormed_by_tum_gro_whole_FOV_means_norm' '.tif'], 'tif')

close all
[p, tbl, stats] = kruskalwallis(tumor.stats20231122.amp.Cr86_unnormed_below_above_GPC6_unnormed_below_above)
saveas(2,['boxplot_amp_Cr86_unnormed_below_above_GPC6_unnormed_by_tum_gro_whole_FOV_means_norm' '.svg'], 'svg');
saveas(2,['boxplot_amp_Cr86_unnormed_below_above_GPC6_unnormed_by_tum_gro_whole_FOV_means_norm' '.emf'], 'emf');
[comparison,means,H,gnames1] = multcompare(stats)
tumor.stats20231122.amp.KW.p = p;
tumor.stats20231122.amp.KW.tbl = tbl;
tumor.stats20231122.amp.KW.stats = stats;
tumor.stats20231122.amp.KW.mult_comparison = comparison;
tumor.stats20231122.amp.KW.mult_means = means;
saveas(H,['multcomp_amp_Cr86_unnormed_below_above_GPC6_unnormed_by_tum_gro_whole_FOV_means_norm' '.png'], 'png')
saveas(H,['multcomp_amp_Cr86_unnormed_below_above_GPC6_unnormed_by_tum_gro_whole_FOV_means_norm' '.fig'], 'fig')

close all
figure(4545)
set(gcf,'color','white')
x = tumor.stats20231122.amp.Cr86_unnormed_below_above_GPC6_unnormed_below_above(:,1)
x(find(isnan(x)),:) = [];
xx = tumor.stats20231122.amp.Cr86_unnormed_below_above_GPC6_unnormed_below_above(:,3)
xx(find(isnan(xx)),:) = [];
y = tumor.stats20231122.amp.Cr86_unnormed_below_above_GPC6_unnormed_below_above(:,2)
y(find(isnan(y)),:) = [];
yy = tumor.stats20231122.amp.Cr86_unnormed_below_above_GPC6_unnormed_below_above(:,4)
yy(find(isnan(yy)),:) = [];
h=bar([mean(x) mean(y); mean(xx) mean(yy)]);
hold on
h(1).FaceColor='w';
h(1).LineWidth = 2;
h(1).EdgeColor = 'r';
errorbar(h(1).XEndPoints,[mean(x) mean(xx)],[std(x)/sqrt(length(x)) std(xx)/sqrt(length(xx))],'LineStyle','none','Color','r','LineWidth',2)
hold on
h(2).FaceColor='w';
h(2).LineWidth = 2;
h(2).EdgeColor = 'b';
errorbar(h(2).XEndPoints,[mean(y) mean(yy)],[std(y)/sqrt(length(y)) std(yy)/sqrt(length(yy))],'LineStyle','none','Color','b','LineWidth',2)

set(gca,'FontSize',24)
set(gca,'FontName','Arial')
saveas(4545,['barplot_amp_Cr86_unnormed_below_above_GPC6_unnormed_by_tum_gro_whole_FOV_means_norm' '.pdf'], 'pdf')
saveas(4545,['barplot_amp_Cr86_unnormed_below_above_GPC6_unnormed_by_tum_gro_whole_FOV_means_norm' '.emf'], 'emf')
saveas(4545,['barplot_amp_Cr86_unnormed_below_above_GPC6_unnormed_by_tum_gro_whole_FOV_means_norm' '.svg'], 'svg')
saveas(4545,['barplot_amp_Cr86_unnormed_below_above_GPC6_unnormed_by_tum_gro_whole_FOV_means_norm' '.tif'], 'tif')

close all
[p, tbl, stats] = kruskalwallis(tumor.stats20231122.area.Cr86_unnormed_below_above_GPC6_unnormed_below_above)
saveas(2,['boxplot_area_Cr86_unnormed_below_above_GPC6_unnormed_by_tum_gro_whole_FOV_means_norm' '.svg'], 'svg');
saveas(2,['boxplot_area_Cr86_unnormed_below_above_GPC6_unnormed_by_tum_gro_whole_FOV_means_norm' '.emf'], 'emf');
[comparison,means,H,gnames1] = multcompare(stats)
tumor.stats20231122.area.KW.p = p;
tumor.stats20231122.area.KW.tbl = tbl;
tumor.stats20231122.area.KW.stats = stats;
tumor.stats20231122.area.KW.mult_comparison = comparison;
tumor.stats20231122.area.KW.mult_means = means;
saveas(H,['multcomp_area_Cr86_unnormed_below_above_GPC6_unnormed_by_tum_gro_whole_FOV_means_norm' '.png'], 'png')
saveas(H,['multcomp_area_Cr86_unnormed_below_above_GPC6_unnormed_by_tum_gro_whole_FOV_means_norm' '.fig'], 'fig')

close all
figure(5545)
set(gcf,'color','white')
x = tumor.stats20231122.area.Cr86_unnormed_below_above_GPC6_unnormed_below_above(:,1)
x(find(isnan(x)),:) = [];
xx = tumor.stats20231122.area.Cr86_unnormed_below_above_GPC6_unnormed_below_above(:,3)
xx(find(isnan(xx)),:) = [];
y = tumor.stats20231122.area.Cr86_unnormed_below_above_GPC6_unnormed_below_above(:,2)
y(find(isnan(y)),:) = [];
yy = tumor.stats20231122.area.Cr86_unnormed_below_above_GPC6_unnormed_below_above(:,4)
yy(find(isnan(yy)),:) = [];

h=bar([mean(x) mean(y); mean(xx) mean(yy)]);
hold on
h(1).FaceColor='w';
h(1).LineWidth = 2;
h(1).EdgeColor = 'r';
errorbar(h(1).XEndPoints,[mean(x) mean(xx)],[std(x)/sqrt(length(x)) std(xx)/sqrt(length(xx))],'LineStyle','none','Color','r','LineWidth',2)
hold on
h(2).FaceColor='w';
h(2).LineWidth = 2;
h(2).EdgeColor = 'b';
errorbar(h(2).XEndPoints,[mean(y) mean(yy)],[std(y)/sqrt(length(y)) std(yy)/sqrt(length(yy))],'LineStyle','none','Color','b','LineWidth',2)

set(gca,'FontSize',24)
set(gca,'FontName','Arial')

saveas(5545,['barplot_area_Cr86_unnormed_below_above_GPC6_unnormed_by_tum_gro_whole_FOV_means_norm' '.pdf'], 'pdf')
saveas(5545,['barplot_area_Cr86_unnormed_below_above_GPC6_unnormed_by_tum_gro_whole_FOV_means_norm' '.emf'], 'emf')
saveas(5545,['barplot_area_Cr86_unnormed_below_above_GPC6_unnormed_by_tum_gro_whole_FOV_means_norm' '.svg'], 'svg')
saveas(5545,['barplot_area_Cr86_unnormed_below_above_GPC6_unnormed_by_tum_gro_whole_FOV_means_norm' '.tif'], 'tif')


%slow

[p, tbl, stats] = ranksum(tumor.stats20231122.apm.Cr86_unnormed_below_above_GPC6_unnormed_below_above(:,1),tumor.stats20231122.apm.Cr86_unnormed_below_above_GPC6_unnormed_below_above(:,3))
tumor.stats20231122.apm.ranksum.slow_Cr86_unnormed_vs_GPC6_unnormed.p = p;
tumor.stats20231122.apm.ranksum.slow_Cr86_unnormed_vs_GPC6_unnormed.tbl = tbl;
tumor.stats20231122.apm.ranksum.slow_Cr86_unnormed_vs_GPC6_unnormed.stats = stats;
close all
figure(45)
set(gcf,'color','white')
x = tumor.stats20231122.apm.Cr86_unnormed_below_above_GPC6_unnormed_below_above(:,1)
x(find(isnan(x)),:) = [];
xx = tumor.stats20231122.apm.Cr86_unnormed_below_above_GPC6_unnormed_below_above(:,3)
xx(find(isnan(xx)),:) = [];
h=bar([mean(x)  mean(xx) ]);
hold on
h(1).FaceColor='w';
h(1).LineWidth = 2;
h(1).EdgeColor = 'b';
errorbar(h(1).XEndPoints,[mean(x) mean(xx)],[std(x)/sqrt(length(x)) std(xx)/sqrt(length(xx))],'LineStyle','none','Color','b','LineWidth',2)
measures = [x xx] ; %GPC6_unnormed.eps.mean_below_above_means_normed % struct2array(load('fisheriris','meas'));
coordLineStyle = 'k.';
%boxplot(measures, 'Symbol', coordLineStyle); hold on;
hold on
scatter([1 1 1 1 1],measures(:,1), 50, [0.4 0.4 0.4],'jitter','on','jitterAmount',0.05)
hold on
scatter([2 2 2 2 2],measures(:,2), 50, [0.4 0.4 0.4],'jitter','on','jitterAmount',0.05)
set(gca,'FontSize',24)
set(gca,'FontName','Arial')
saveas(45,['barplot_apm_Cr86_unnormed_v_GPC6_unnormed_below_by_tum_gro_whole_FOV_means_norm' '.pdf'], 'pdf')
saveas(45,['barplot_apm_Cr86_unnormed_v_GPC6_unnormed_below_by_tum_gro_whole_FOV_means_norm' '.emf'], 'emf')
saveas(45,['barplot_apm_Cr86_unnormed_v_GPC6_unnormed_below_by_tum_gro_whole_FOV_means_norm' '.svg'], 'svg')
saveas(45,['barplot_apm_Cr86_unnormed_v_GPC6_unnormed_below_by_tum_gro_whole_FOV_means_norm' '.tif'], 'tif')

[p, tbl, stats] = ranksum(tumor.stats20231122.eps.Cr86_unnormed_below_above_GPC6_unnormed_below_above(:,1),tumor.stats20231122.eps.Cr86_unnormed_below_above_GPC6_unnormed_below_above(:,3))
tumor.stats20231122.eps.ranksum.slow_Cr86_unnormed_vs_GPC6_unnormed.p = p;
tumor.stats20231122.eps.ranksum.slow_Cr86_unnormed_vs_GPC6_unnormed.tbl = tbl;
tumor.stats20231122.eps.ranksum.slow_Cr86_unnormed_vs_GPC6_unnormed.stats = stats;
close all
figure(45)
set(gcf,'color','white')
x = tumor.stats20231122.eps.Cr86_unnormed_below_above_GPC6_unnormed_below_above(:,1)
x(find(isnan(x)),:) = [];
xx = tumor.stats20231122.eps.Cr86_unnormed_below_above_GPC6_unnormed_below_above(:,3)
xx(find(isnan(xx)),:) = [];
h=bar([mean(x)  mean(xx) ]);
hold on
h(1).FaceColor='w';
h(1).LineWidth = 2;
h(1).EdgeColor = 'b';
errorbar(h(1).XEndPoints,[mean(x) mean(xx)],[std(x)/sqrt(length(x)) std(xx)/sqrt(length(xx))],'LineStyle','none','Color','b','LineWidth',2)
measures = [x xx] ; %GPC6_unnormed.eps.mean_below_above_means_normed % struct2array(load('fisheriris','meas'));
coordLineStyle = 'k.';
%boxplot(measures, 'Symbol', coordLineStyle); hold on;
hold on
scatter([1 1 1 1 1],measures(:,1), 50, [0.4 0.4 0.4],'jitter','on','jitterAmount',0.05)
hold on
scatter([2 2 2 2 2],measures(:,2), 50, [0.4 0.4 0.4],'jitter','on','jitterAmount',0.05)
set(gca,'FontSize',24)
set(gca,'FontName','Arial')
saveas(45,['barplot_eps_Cr86_unnormed_v_GPC6_unnormed_below_by_tum_gro_whole_FOV_means_norm' '.pdf'], 'pdf')
saveas(45,['barplot_eps_Cr86_unnormed_v_GPC6_unnormed_below_by_tum_gro_whole_FOV_means_norm' '.emf'], 'emf')
saveas(45,['barplot_eps_Cr86_unnormed_v_GPC6_unnormed_below_by_tum_gro_whole_FOV_means_norm' '.svg'], 'svg')
saveas(45,['barplot_eps_Cr86_unnormed_v_GPC6_unnormed_below_by_tum_gro_whole_FOV_means_norm' '.tif'], 'tif')


[p, tbl, stats] = ranksum(tumor.stats20231122.length.Cr86_unnormed_below_above_GPC6_unnormed_below_above(:,1),tumor.stats20231122.length.Cr86_unnormed_below_above_GPC6_unnormed_below_above(:,3))
tumor.stats20231122.length.ranksum.slow_Cr86_unnormed_vs_GPC6_unnormed.p = p;
tumor.stats20231122.length.ranksum.slow_Cr86_unnormed_vs_GPC6_unnormed.tbl = tbl;
tumor.stats20231122.length.ranksum.slow_Cr86_unnormed_vs_GPC6_unnormed.stats = stats;
close all
figure(45)
set(gcf,'color','white')
x = tumor.stats20231122.length.Cr86_unnormed_below_above_GPC6_unnormed_below_above(:,1)
x(find(isnan(x)),:) = [];
xx = tumor.stats20231122.length.Cr86_unnormed_below_above_GPC6_unnormed_below_above(:,3)
xx(find(isnan(xx)),:) = [];
h=bar([mean(x)  mean(xx) ]);
hold on
h(1).FaceColor='w';
h(1).LineWidth = 2;
h(1).EdgeColor = 'b';
errorbar(h(1).XEndPoints,[mean(x) mean(xx)],[std(x)/sqrt(length(x)) std(xx)/sqrt(length(xx))],'LineStyle','none','Color','b','LineWidth',2)
measures = [x xx] ; %GPC6_unnormed.eps.mean_below_above_means_normed % struct2array(load('fisheriris','meas'));
coordLineStyle = 'k.';
%boxplot(measures, 'Symbol', coordLineStyle); hold on;
hold on
scatter([1 1 1 1 1],measures(:,1), 50, [0.4 0.4 0.4],'jitter','on','jitterAmount',0.05)
hold on
scatter([2 2 2 2 2],measures(:,2), 50, [0.4 0.4 0.4],'jitter','on','jitterAmount',0.05)
set(gca,'FontSize',24)
set(gca,'FontName','Arial')
saveas(45,['barplot_length_Cr86_unnormed_v_GPC6_unnormed_below_by_tum_gro_whole_FOV_means_norm' '.pdf'], 'pdf')
saveas(45,['barplot_length_Cr86_unnormed_v_GPC6_unnormed_below_by_tum_gro_whole_FOV_means_norm' '.emf'], 'emf')
saveas(45,['barplot_length_Cr86_unnormed_v_GPC6_unnormed_below_by_tum_gro_whole_FOV_means_norm' '.svg'], 'svg')
saveas(45,['barplot_length_Cr86_unnormed_v_GPC6_unnormed_below_by_tum_gro_whole_FOV_means_norm' '.tif'], 'tif')


[p, tbl, stats] = ranksum(tumor.stats20231122.amp.Cr86_unnormed_below_above_GPC6_unnormed_below_above(:,1),tumor.stats20231122.amp.Cr86_unnormed_below_above_GPC6_unnormed_below_above(:,3))
tumor.stats20231122.amp.ranksum.slow_Cr86_unnormed_vs_GPC6_unnormed.p = p;
tumor.stats20231122.amp.ranksum.slow_Cr86_unnormed_vs_GPC6_unnormed.tbl = tbl;
tumor.stats20231122.amp.ranksum.slow_Cr86_unnormed_vs_GPC6_unnormed.stats = stats;
close all
figure(45)
set(gcf,'color','white')
x = tumor.stats20231122.amp.Cr86_unnormed_below_above_GPC6_unnormed_below_above(:,1)
x(find(isnan(x)),:) = [];
xx = tumor.stats20231122.amp.Cr86_unnormed_below_above_GPC6_unnormed_below_above(:,3)
xx(find(isnan(xx)),:) = [];
h=bar([mean(x)  mean(xx) ]);
hold on
h(1).FaceColor='w';
h(1).LineWidth = 2;
h(1).EdgeColor = 'b';
errorbar(h(1).XEndPoints,[mean(x) mean(xx)],[std(x)/sqrt(length(x)) std(xx)/sqrt(length(xx))],'LineStyle','none','Color','b','LineWidth',2)
measures = [x xx] ; %GPC6_unnormed.eps.mean_below_above_means_normed % struct2array(load('fisheriris','meas'));
coordLineStyle = 'k.';
%boxplot(measures, 'Symbol', coordLineStyle); hold on;
hold on
scatter([1 1 1 1 1],measures(:,1), 50, [0.4 0.4 0.4],'jitter','on','jitterAmount',0.05)
hold on
scatter([2 2 2 2 2],measures(:,2), 50, [0.4 0.4 0.4],'jitter','on','jitterAmount',0.05)
set(gca,'FontSize',24)
set(gca,'FontName','Arial')
saveas(45,['barplot_amp_Cr86_unnormed_v_GPC6_unnormed_below_by_tum_gro_whole_FOV_means_norm' '.pdf'], 'pdf')
saveas(45,['barplot_amp_Cr86_unnormed_v_GPC6_unnormed_below_by_tum_gro_whole_FOV_means_norm' '.emf'], 'emf')
saveas(45,['barplot_amp_Cr86_unnormed_v_GPC6_unnormed_below_by_tum_gro_whole_FOV_means_norm' '.svg'], 'svg')
saveas(45,['barplot_amp_Cr86_unnormed_v_GPC6_unnormed_below_by_tum_gro_whole_FOV_means_norm' '.tif'], 'tif')


[p, tbl, stats] = ranksum(tumor.stats20231122.area.Cr86_unnormed_below_above_GPC6_unnormed_below_above(:,1),tumor.stats20231122.area.Cr86_unnormed_below_above_GPC6_unnormed_below_above(:,3))
tumor.stats20231122.area.ranksum.slow_Cr86_unnormed_vs_GPC6_unnormed.p = p;
tumor.stats20231122.area.ranksum.slow_Cr86_unnormed_vs_GPC6_unnormed.tbl = tbl;
tumor.stats20231122.area.ranksum.slow_Cr86_unnormed_vs_GPC6_unnormed.stats = stats;
close all
figure(45)
set(gcf,'color','white')
x = tumor.stats20231122.area.Cr86_unnormed_below_above_GPC6_unnormed_below_above(:,1)
x(find(isnan(x)),:) = [];
xx = tumor.stats20231122.area.Cr86_unnormed_below_above_GPC6_unnormed_below_above(:,3)
xx(find(isnan(xx)),:) = [];
h=bar([mean(x)  mean(xx) ]);
hold on
h(1).FaceColor='w';
h(1).LineWidth = 2;
h(1).EdgeColor = 'b';
errorbar(h(1).XEndPoints,[mean(x) mean(xx)],[std(x)/sqrt(length(x)) std(xx)/sqrt(length(xx))],'LineStyle','none','Color','b','LineWidth',2)
measures = [x xx] ; %GPC6_unnormed.eps.mean_below_above_means_normed % struct2array(load('fisheriris','meas'));
coordLineStyle = 'k.';
%boxplot(measures, 'Symbol', coordLineStyle); hold on;
hold on
scatter([1 1 1 1 1],measures(:,1), 50, [0.4 0.4 0.4],'jitter','on','jitterAmount',0.05)
hold on
scatter([2 2 2 2 2],measures(:,2), 50, [0.4 0.4 0.4],'jitter','on','jitterAmount',0.05)
set(gca,'FontSize',24)
set(gca,'FontName','Arial')
saveas(45,['barplot_area_Cr86_unnormed_v_GPC6_unnormed_below_by_tum_gro_whole_FOV_means_norm' '.pdf'], 'pdf')
saveas(45,['barplot_area_Cr86_unnormed_v_GPC6_unnormed_below_by_tum_gro_whole_FOV_means_norm' '.emf'], 'emf')
saveas(45,['barplot_area_Cr86_unnormed_v_GPC6_unnormed_below_by_tum_gro_whole_FOV_means_norm' '.svg'], 'svg')
saveas(45,['barplot_area_Cr86_unnormed_v_GPC6_unnormed_below_by_tum_gro_whole_FOV_means_norm' '.tif'], 'tif')

%%%%%%%%%%%%% fast

[p, tbl, stats] = ranksum(tumor.stats20231122.apm.Cr86_unnormed_below_above_GPC6_unnormed_below_above(:,2),tumor.stats20231122.apm.Cr86_unnormed_below_above_GPC6_unnormed_below_above(:,4))
tumor.stats20231122.apm.ranksum.fast_Cr86_unnormed_vs_GPC6_unnormed.p = p;
tumor.stats20231122.apm.ranksum.fast_Cr86_unnormed_vs_GPC6_unnormed.tbl = tbl;
tumor.stats20231122.apm.ranksum.fast_Cr86_unnormed_vs_GPC6_unnormed.stats = stats;
close all
figure(45)
set(gcf,'color','white')
x = tumor.stats20231122.apm.Cr86_unnormed_below_above_GPC6_unnormed_below_above(:,2)
x(find(isnan(x)),:) = [];
xx = tumor.stats20231122.apm.Cr86_unnormed_below_above_GPC6_unnormed_below_above(:,4)
xx(find(isnan(xx)),:) = [];
h=bar([mean(x)  mean(xx) ]);
hold on
h(1).FaceColor='w';
h(1).LineWidth = 2;
h(1).EdgeColor = 'r';
errorbar(h(1).XEndPoints,[mean(x) mean(xx)],[std(x)/sqrt(length(x)) std(xx)/sqrt(length(xx))],'LineStyle','none','Color','r','LineWidth',2)
measures = [x xx] ; %GPC6_unnormed.eps.mean_below_above_means_normed % struct2array(load('fisheriris','meas'));
coordLineStyle = 'k.';
%boxplot(measures, 'Symbol', coordLineStyle); hold on;
hold on
scatter([1 1 1 1 1],measures(:,1), 50, [0.4 0.4 0.4],'jitter','on','jitterAmount',0.05)
hold on
scatter([2 2 2 2 2],measures(:,2), 50, [0.4 0.4 0.4],'jitter','on','jitterAmount',0.05)
set(gca,'FontSize',24)
set(gca,'FontName','Arial')
saveas(45,['barplot_apm_Cr86_unnormed_v_GPC6_unnormed_above_by_tum_gro_whole_FOV_means_norm' '.pdf'], 'pdf')
saveas(45,['barplot_apm_Cr86_unnormed_v_GPC6_unnormed_above_by_tum_gro_whole_FOV_means_norm' '.emf'], 'emf')
saveas(45,['barplot_apm_Cr86_unnormed_v_GPC6_unnormed_above_by_tum_gro_whole_FOV_means_norm' '.svg'], 'svg')
saveas(45,['barplot_apm_Cr86_unnormed_v_GPC6_unnormed_above_by_tum_gro_whole_FOV_means_norm' '.tif'], 'tif')

[p, tbl, stats] = ranksum(tumor.stats20231122.eps.Cr86_unnormed_below_above_GPC6_unnormed_below_above(:,2),tumor.stats20231122.eps.Cr86_unnormed_below_above_GPC6_unnormed_below_above(:,4))
tumor.stats20231122.eps.ranksum.fast_Cr86_unnormed_vs_GPC6_unnormed.p = p;
tumor.stats20231122.eps.ranksum.fast_Cr86_unnormed_vs_GPC6_unnormed.tbl = tbl;
tumor.stats20231122.eps.ranksum.fast_Cr86_unnormed_vs_GPC6_unnormed.stats = stats;
close all
figure(45)
set(gcf,'color','white')
x = tumor.stats20231122.eps.Cr86_unnormed_below_above_GPC6_unnormed_below_above(:,2)
x(find(isnan(x)),:) = [];
xx = tumor.stats20231122.eps.Cr86_unnormed_below_above_GPC6_unnormed_below_above(:,4)
xx(find(isnan(xx)),:) = [];
h=bar([mean(x)  mean(xx) ]);
hold on
h(1).FaceColor='w';
h(1).LineWidth = 2;
h(1).EdgeColor = 'r';
errorbar(h(1).XEndPoints,[mean(x) mean(xx)],[std(x)/sqrt(length(x)) std(xx)/sqrt(length(xx))],'LineStyle','none','Color','r','LineWidth',2)
measures = [x xx] ; %GPC6_unnormed.eps.mean_below_above_means_normed % struct2array(load('fisheriris','meas'));
coordLineStyle = 'k.';
%boxplot(measures, 'Symbol', coordLineStyle); hold on;
hold on
scatter([1 1 1 1 1],measures(:,1), 50, [0.4 0.4 0.4],'jitter','on','jitterAmount',0.05)
hold on
scatter([2 2 2 2 2],measures(:,2), 50, [0.4 0.4 0.4],'jitter','on','jitterAmount',0.05)
set(gca,'FontSize',24)
set(gca,'FontName','Arial')
saveas(45,['barplot_eps_Cr86_unnormed_v_GPC6_unnormed_above_by_tum_gro_whole_FOV_means_norm' '.pdf'], 'pdf')
saveas(45,['barplot_eps_Cr86_unnormed_v_GPC6_unnormed_above_by_tum_gro_whole_FOV_means_norm' '.emf'], 'emf')
saveas(45,['barplot_eps_Cr86_unnormed_v_GPC6_unnormed_above_by_tum_gro_whole_FOV_means_norm' '.svg'], 'svg')
saveas(45,['barplot_eps_Cr86_unnormed_v_GPC6_unnormed_above_by_tum_gro_whole_FOV_means_norm' '.tif'], 'tif')

[p, tbl, stats] = ranksum(tumor.stats20231122.length.Cr86_unnormed_below_above_GPC6_unnormed_below_above(:,2),tumor.stats20231122.length.Cr86_unnormed_below_above_GPC6_unnormed_below_above(:,4))
tumor.stats20231122.length.ranksum.fast_Cr86_unnormed_vs_GPC6_unnormed.p = p;
tumor.stats20231122.length.ranksum.fast_Cr86_unnormed_vs_GPC6_unnormed.tbl = tbl;
tumor.stats20231122.length.ranksum.fast_Cr86_unnormed_vs_GPC6_unnormed.stats = stats;
close all
figure(45)
set(gcf,'color','white')
x = tumor.stats20231122.length.Cr86_unnormed_below_above_GPC6_unnormed_below_above(:,2)
x(find(isnan(x)),:) = [];
xx = tumor.stats20231122.length.Cr86_unnormed_below_above_GPC6_unnormed_below_above(:,4)
xx(find(isnan(xx)),:) = [];
h=bar([mean(x)  mean(xx) ]);
hold on
h(1).FaceColor='w';
h(1).LineWidth = 2;
h(1).EdgeColor = 'r';
errorbar(h(1).XEndPoints,[mean(x) mean(xx)],[std(x)/sqrt(length(x)) std(xx)/sqrt(length(xx))],'LineStyle','none','Color','r','LineWidth',2)
measures = [x xx] ; %GPC6_unnormed.eps.mean_below_above_means_normed % struct2array(load('fisheriris','meas'));
coordLineStyle = 'k.';
%boxplot(measures, 'Symbol', coordLineStyle); hold on;
hold on
scatter([1 1 1 1 1],measures(:,1), 50, [0.4 0.4 0.4],'jitter','on','jitterAmount',0.05)
hold on
scatter([2 2 2 2 2],measures(:,2), 50, [0.4 0.4 0.4],'jitter','on','jitterAmount',0.05)
set(gca,'FontSize',24)
set(gca,'FontName','Arial')
saveas(45,['barplot_length_Cr86_unnormed_v_GPC6_unnormed_above_by_tum_gro_whole_FOV_means_norm' '.pdf'], 'pdf')
saveas(45,['barplot_length_Cr86_unnormed_v_GPC6_unnormed_above_by_tum_gro_whole_FOV_means_norm' '.emf'], 'emf')
saveas(45,['barplot_length_Cr86_unnormed_v_GPC6_unnormed_above_by_tum_gro_whole_FOV_means_norm' '.svg'], 'svg')
saveas(45,['barplot_length_Cr86_unnormed_v_GPC6_unnormed_above_by_tum_gro_whole_FOV_means_norm' '.tif'], 'tif')


[p, tbl, stats] = ranksum(tumor.stats20231122.amp.Cr86_unnormed_below_above_GPC6_unnormed_below_above(:,2),tumor.stats20231122.amp.Cr86_unnormed_below_above_GPC6_unnormed_below_above(:,4))
tumor.stats20231122.amp.ranksum.fast_Cr86_unnormed_vs_GPC6_unnormed.p = p;
tumor.stats20231122.amp.ranksum.fast_Cr86_unnormed_vs_GPC6_unnormed.tbl = tbl;
tumor.stats20231122.amp.ranksum.fast_Cr86_unnormed_vs_GPC6_unnormed.stats = stats;
close all
figure(45)
set(gcf,'color','white')
x = tumor.stats20231122.amp.Cr86_unnormed_below_above_GPC6_unnormed_below_above(:,2)
x(find(isnan(x)),:) = [];
xx = tumor.stats20231122.amp.Cr86_unnormed_below_above_GPC6_unnormed_below_above(:,4)
xx(find(isnan(xx)),:) = [];
h=bar([mean(x)  mean(xx) ]);
hold on
h(1).FaceColor='w';
h(1).LineWidth = 2;
h(1).EdgeColor = 'r';
errorbar(h(1).XEndPoints,[mean(x) mean(xx)],[std(x)/sqrt(length(x)) std(xx)/sqrt(length(xx))],'LineStyle','none','Color','r','LineWidth',2)
measures = [x xx] ; %GPC6_unnormed.eps.mean_below_above_means_normed % struct2array(load('fisheriris','meas'));
coordLineStyle = 'k.';
%boxplot(measures, 'Symbol', coordLineStyle); hold on;
hold on
scatter([1 1 1 1 1],measures(:,1), 50, [0.4 0.4 0.4],'jitter','on','jitterAmount',0.05)
hold on
scatter([2 2 2 2 2],measures(:,2), 50, [0.4 0.4 0.4],'jitter','on','jitterAmount',0.05)
set(gca,'FontSize',24)
set(gca,'FontName','Arial')
saveas(45,['barplot_amp_Cr86_unnormed_v_GPC6_unnormed_above_by_tum_gro_whole_FOV_means_norm' '.pdf'], 'pdf')
saveas(45,['barplot_amp_Cr86_unnormed_v_GPC6_unnormed_above_by_tum_gro_whole_FOV_means_norm' '.emf'], 'emf')
saveas(45,['barplot_amp_Cr86_unnormed_v_GPC6_unnormed_above_by_tum_gro_whole_FOV_means_norm' '.svg'], 'svg')
saveas(45,['barplot_amp_Cr86_unnormed_v_GPC6_unnormed_above_by_tum_gro_whole_FOV_means_norm' '.tif'], 'tif')


[p, tbl, stats] = ranksum(tumor.stats20231122.area.Cr86_unnormed_below_above_GPC6_unnormed_below_above(:,2),tumor.stats20231122.area.Cr86_unnormed_below_above_GPC6_unnormed_below_above(:,4))
tumor.stats20231122.area.ranksum.fast_Cr86_unnormed_vs_GPC6_unnormed.p = p;
tumor.stats20231122.area.ranksum.fast_Cr86_unnormed_vs_GPC6_unnormed.tbl = tbl;
tumor.stats20231122.area.ranksum.fast_Cr86_unnormed_vs_GPC6_unnormed.stats = stats;
close all
figure(45)
set(gcf,'color','white')
x = tumor.stats20231122.area.Cr86_unnormed_below_above_GPC6_unnormed_below_above(:,2)
x(find(isnan(x)),:) = [];
xx = tumor.stats20231122.area.Cr86_unnormed_below_above_GPC6_unnormed_below_above(:,4)
xx(find(isnan(xx)),:) = [];
h=bar([mean(x)  mean(xx) ]);
hold on
h(1).FaceColor='w';
h(1).LineWidth = 2;
h(1).EdgeColor = 'r';
errorbar(h(1).XEndPoints,[mean(x) mean(xx)],[std(x)/sqrt(length(x)) std(xx)/sqrt(length(xx))],'LineStyle','none','Color','r','LineWidth',2)
measures = [x xx] ; %GPC6_unnormed.eps.mean_below_above_means_normed % struct2array(load('fisheriris','meas'));
coordLineStyle = 'k.';
%boxplot(measures, 'Symbol', coordLineStyle); hold on;
hold on
scatter([1 1 1 1 1],measures(:,1), 50, [0.4 0.4 0.4],'jitter','on','jitterAmount',0.05)
hold on
scatter([2 2 2 2 2],measures(:,2), 50, [0.4 0.4 0.4],'jitter','on','jitterAmount',0.05)
set(gca,'FontSize',24)
set(gca,'FontName','Arial')
saveas(45,['barplot_area_Cr86_unnormed_v_GPC6_unnormed_above_by_tum_gro_whole_FOV_means_norm' '.pdf'], 'pdf')
saveas(45,['barplot_area_Cr86_unnormed_v_GPC6_unnormed_above_by_tum_gro_whole_FOV_means_norm' '.emf'], 'emf')
saveas(45,['barplot_area_Cr86_unnormed_v_GPC6_unnormed_above_by_tum_gro_whole_FOV_means_norm' '.svg'], 'svg')
saveas(45,['barplot_area_Cr86_unnormed_v_GPC6_unnormed_above_by_tum_gro_whole_FOV_means_norm' '.tif'], 'tif')

tumor_unnormed=tumor;

rev_fig5_data_20231123.tum_gro_based.Cr86_unnormed = Cr86_unnormed;
rev_fig5_data_20231123.tum_gro_based.Cr86_unnormed_by_animal = Cr86_unnormed_by_animal;
rev_fig5_data_20231123.tum_gro_based.GPC6_unnormed = GPC6_unnormed;
rev_fig5_data_20231123.tum_gro_based.GPC6_unnormed_by_animal = GPC6_unnormed_by_animal;

save rev_fig5_data_20231222_unnormed.mat rev_fig5_data_20231123 tumor_unnormed

save rev_fig5_data_20231123.mat rev_fig5_data_20231123 tumor_unnormed



% run this once before rerunning everything for taking into account splined
% tumor growth

a=1
Cr86_unnormed_anims = [15 21 28 38 40]
for j = 1:5
    curr_anim = Cr86_unnormed_anims(1,j)
    tumor_animal(curr_anim).onep.tum_gro_divbypoint5to6_spline_w_apm = rev_fig5_data_20231123.tum_gro_based.Cr86_unnormed_by_animal(j).apm(1).oneperday_x_vs_spline_and_tum_gro;
end

a=1
GPC6_unnormed_anims = [48 49 71 73]
for j = 1:4
    curr_anim = GPC6_unnormed_anims(1,j)
    tumor_animal(curr_anim).onep.tum_gro_divbypoint5to6_spline_w_apm = rev_fig5_data_20231123.tum_gro_based.GPC6_unnormed_by_animal(j).apm(1).oneperday_x_vs_spline_and_tum_gro;
end

