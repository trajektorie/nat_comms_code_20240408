
function [oopsi_no_noise,activity_per_min_oopsi,deltaf_no_noise,activity_per_min_deltaf,noisee] = ...
    deconvolution_Bernhard(initial, oopsi_spike_trace,deltaf_matrix,deconv_sd,deltaf_sd,i2)

%%%%%%%%%%%Yaksi-Friedrich iterative smoothing (here for stimcell only,
%%%%%%%%%%%later generalize for all cells!)

%filter with 4-pole butterworth filter cutoff at 0.2*intial.samplingratehz:

%
% Hd = lowpass_butter(initial);
%
% endframe = size(deltaf_cells,2);
%
% for i = 1:endframe
%
% x = deltaf_cells(:,i);
%
% y(:,i) = filter(Hd,x);
%
% end
%
%
%
% s_f = round(initial.samplingratehz/2);
%
% if mod(s_f,2)
% else
%     s_f = s_f + 1;
% end
%
% clear smooth_deltaf_matrix
%
% for i = 1:endframe
%     smooth_deltaf_matrix(:,i) = smooth(y(:,i),s_f);
% end
%
%
% fps = 1000/initial.msperline;
% traceOpt.trace_computation = 'oopsi';
% traces = smooth_deltaf_matrix;
% oopsi_spike_trace = filterTraces( traces, fps, traceOpt );
%results.oopsi_filtered_deltaf_matrix = oopsi_spike_trace;
% clear oopsi_spike_trace


%%%%%%%define noise level threshold:
endframe = size(oopsi_spike_trace,2);



for i = 1:endframe
    urt = round(0.95*size(oopsi_spike_trace,1));
    if sum(oopsi_spike_trace(12:urt,i))==0
    else
        aroundd = sort(oopsi_spike_trace(:,i));
        stt = length(aroundd);
        bot = prctile(aroundd,1);
        
        tob = prctile(aroundd,99);
        stob = (tob-bot)/100;
        binedges = [bot:stob:tob];
        %[N, edges] = histcounts(oopsi_spike_trace(:,i),binedges);
        
        [N, edges] = histcounts(aroundd(1:round(stt*0.25),1),binedges);
        
        a=find(N == max(N));
        if length(a)>1
            a = a(1,2);
        end
        medi = edges(1,a);
        
        avg_oopsi(i,1) = medi;
        noisee(i).med_oopsi = avg_oopsi(i,1);
        
        noise_below_med = oopsi_spike_trace(find(oopsi_spike_trace(:,i)<avg_oopsi(i,1)),i);
        noisee(i).noiseoopsi = cat(1,noise_below_med, avg_oopsi(i,1)*2-noise_below_med);
        
        noisee(i).std_oopsi = std(noisee(i).noiseoopsi);
        
        noisee(i).thr_oopsi = avg_oopsi(i)+deconv_sd*noisee(i).std_oopsi;
        
        
        
        signal_oopsi = oopsi_spike_trace(find(oopsi_spike_trace(:,i)>2*noisee(i).thr_oopsi),i);
        
        avg_signal_oopsi(i,1) = mean(signal_oopsi);
        
        noisee(i).SNR_oopsi = (avg_signal_oopsi(i,1)-noisee(i).thr_oopsi)/...
            (noisee(i).thr_oopsi - noisee(i).std_oopsi);
        
        noisee(i).avg_signal_oopsi = avg_signal_oopsi(i,1);
    end
end

%noisee.noiseoopsi = noiseoopsi;
% noisee.std_oopsi = std_oopsi;
% noisee.thr_oopsi = thr_oopsi;

%compute activity by subtracting thr_oopsi and summating remaining
%datapoints



for i = 1:endframe
    
    if sum(oopsi_spike_trace(:,i))==0
    else
          if isempty( noisee(i).thr_oopsi)
       noisee(i).thr_oopsi=0;
        end
        oopsi_no_noise(:,i) = oopsi_spike_trace(:,i) - noisee(i).thr_oopsi;
    end
end


%oopsi_no_noise = results.oopsi_filtered_deltaf_matrix

movie_length_min = size(deltaf_matrix,1)/(60*i2.samplingratehz);

endframe = size(oopsi_no_noise,2)

for i = 1:endframe
    for j= 1:size(oopsi_no_noise,1)
        if oopsi_no_noise(j,i)<0
            oopsi_no_noise(j,i) = 0;
        end
    end
    activity_per_min_oopsi(i) = (sum(oopsi_no_noise(:,i))*60000)/(size(oopsi_no_noise,1)*i2.msperline);
end




deltaf_matrix(deltaf_matrix==Inf) = 30;
for i = 1:endframe
    
    if sum(deltaf_matrix(:,i))==0
    else
        
        aroundd = sort(deltaf_matrix(:,i));
        stt = length(aroundd);
        bot = prctile(aroundd,1);
        
        tob = prctile(aroundd,99);
        stob = (tob-bot)/100;
        binedges = [bot:stob:tob];
        %[N, edges] = histcounts(deltaf_matrix(:,i),binedges);
        
        [N, edges] = histcounts(aroundd(1:round(stt*0.25),1),binedges);
        
        
        
        a=find(N == max(N));
        
        if length(a)>1
            a = a(1,2);
        end
        
        medi = edges(1,a);
        
        avg_deltaf(i,1) = medi;
        noisee(i).med_deltaf = avg_deltaf(i,1);
        
        noise_below_med = deltaf_matrix(find(deltaf_matrix(:,i)<avg_deltaf(i,1)),i);
        noisee(i).noisedeltaf = cat(1,noise_below_med, avg_deltaf(i,1)*2-noise_below_med);
        
        noisee(i).std_deltaf = std(noisee(i).noisedeltaf);
        
        noisee(i).thr_deltaf = avg_deltaf(i)+deltaf_sd*noisee(i).std_deltaf;
        
        clear signal_ca
        
        signal_ca = deltaf_matrix(find(deltaf_matrix(:,i)>2*noisee(i).thr_deltaf),i);
        
        avg_signal(i,1) = mean(signal_ca);
        
        noisee(i).SNR = avg_signal(i,1)*(avg_signal(i,1)-noisee(i).thr_deltaf)/...
            (noisee(i).thr_deltaf - noisee(i).std_deltaf)/noisee(i).std_deltaf;
        SNR(i,1) = noisee(i).SNR;
        
        noisee(i).avg_signal = avg_signal(i,1);
    end
end

% noisee.noisedeltaf = noise;
% noisee.std_deltaf = std_deltaf;
% noisee.thr_deltaf = thr_deltaf;
%

%compute activity by subtracting thr_oopsi and summating remaining
%datapoints



for i = 1:endframe
    
    if sum(deltaf_matrix(:,i))==0
    else
        deltaf_no_noise(:,i) = deltaf_matrix(:,i) - noisee(i).thr_deltaf;
    end
end


movie_length_min = size(deltaf_matrix,1)/(60*i2.samplingratehz);


for i = 1:endframe
    for j= 1:size(deltaf_no_noise,1)
        if deltaf_no_noise(j,i)<0
            deltaf_no_noise(j,i) = 0;
        end
    end
    activity_per_min_deltaf(i) = (sum(deltaf_no_noise(:,i))*60000)/(size(deltaf_no_noise,1)*i2.msperline);  % movie_length_min;
end

figure(900009)
plot(SNR)

end



