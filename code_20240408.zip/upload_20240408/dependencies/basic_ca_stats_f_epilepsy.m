function [ca_stats] = basic_ca_stats_f_epilepsy(Folder,i2,matrix,fr,onep,FOV,this_one_serial)


%single cell level:get distribution of event frequency, duration,
%amplitude,

bursts_binary = zeros(size(matrix));
if onep==0
    bursts_binary_neurop = zeros(size(matrix,1),10);
end
a=1;
aaaah=1;



if onep
    w = FOV(1,2);
    h = FOV(1,1);
else
    if isfield(i2,'pixelsperline')
        w = i2.pixelsperline;
        h = i2.linesperframe;
    else
        w = FOV(1,2);
        h = FOV(1,1);
    end
end
area_pix = w*h;
mp = i2.microns_per_pixel/1000;
area_mm2 = mp*mp*area_pix;
ca_stats.area_mm2 = area_mm2;
CNMF_rois_per_mm2 = (size(matrix,2)-10)/area_mm2;
ca_stats.CNMF_rois_per_mm2 = CNMF_rois_per_mm2;

sm = size(matrix,1);
issm = i2.samplingratehz;
msn = i2.msperline;

rois = size(matrix,2);
frames = size(matrix,1);
if onep==0
    bursts_binary_neurop = zeros(size(matrix,1),10);
end

if this_one_serial
    
    for ii = 1:rois
        %clear event_frames IEI_frames
        %%%%%%%%%%%%%%%%%%%
        
        trace = squeeze(matrix(:,ii));
        
        ROI = ii
        mean_DF(ii,1) = mean(trace);
        a = 2; %current frame of trace
        b = 1; %number of current event
        c = 1; %frame within current event
        d = 1; %frame within current IEI
        e = 1; %number of current IEI
        
        
        
        
        event_length = 0;
        event_amplitude = 0;
        IEI_length = 0;
        %event_frames.init = 1;
        %IEI_frames.init = 1;
        IEI_frame_inds = 0;
        event_frame_inds=0;
        while a<length(trace)
            %identifying_events = a;
            if trace(a,1) && trace(a-1,1)==0  %first frame of new event
                d=1;
                e=e+1;
                %curr_event_frame = c;
                
                event_length(b,1) = c;
                %event_frames(b).frame_ind(c,1) = a;
                event_frame_inds(b,c) = a;
                %event_amplitude(b,1) = matrix(event_frames(b).frame_ind(c,1),i);
                %event_amplitude(b,1) = trace(event_frames(b).frame_ind(c,1),1);
                event_amplitude(b,c) = trace(event_frame_inds(b,c),1);
                c=c+1;
                a=a+1;
            else
                if trace(a,1) && trace(a-1,1) %next frame of current event
                    if a==2 %if looking at the first frame of trace
                        %curr_event_frame = 2;
                        event_length(b,1) = 2;
                        %event_frames(b).frame_ind(1,1) = a;
                        event_frame_inds(b,1) = a;
                        %event_amplitude(b,1) = matrix(event_frames(b).frame_ind(1,1),i);
                        %event_amplitude(b,1) = trace(event_frames(b).frame_ind(1,1),1);
                        event_amplitude(b,1) = trace(event_frame_inds(b,1),1);
                        c=c+1;
                        a=a+1;
                        
                    else % if after first frame
                        %curr_event_frame = c;
                        
                        event_length(b,1) = c;
                        %event_frames(b).frame_ind(c,1) = a;
                        event_frame_inds(b,c) = a;
                        %event_amplitude(b,1) = max(matrix(event_frames(b).frame_ind(:,1),i));
                        %event_amplitude(b,1) = max(trace(event_frames(b).frame_ind(:,1),1));
                        [qw, pq] = find(event_frame_inds(b,:));
                        event_amplitude(b,1) = max(trace(event_frame_inds(b,pq),1));
                        c=c+1;
                        a=a+1;
                    end
                else
                    if trace(a-1,1) && trace(a,1)==0 % if first frame of an IEI
                        c=1;
                        
                        %curr_IEI_frame = d;
                        
                        IEI_length(e,1) = d;
                        %IEI_frames(e).frame_ind(d,1) = a;
                        IEI_frame_inds(e,d) = a;
                        d=d+1;
                        a=a+1;
                        b=b+1;
                    else
                        if trace(a-1,1)==0 && trace(a,1)==0 %if next frame of IEI
                            %curr_IEI_frame = d;
                            
                            IEI_length(e,1) = d;
                            %IEI_frames(e).frame_ind(d,1) = a;
                            IEI_frame_inds(e,d) = a;
                            d=d+1;
                            a=a+1;
                        end
                    end
                end
            end
        end
        
        if fr == 0
            tot_secs = sm/issm;%size(matrix,1)/i2.samplingratehz;
        else
            tot_secs = sm;%size(matrix,1)/fr;
        end
        
        events_per_sec(ii,1) = b/tot_secs;
        
        %ROI_events(i).event_frames = event_frames;
        ROI_events(ii).event_frame_inds = event_frame_inds;
        
        if fr ==0
            event_length_ms = event_length*msn;
        else
            event_length_ms = event_length*(1000/fr);
        end
        ROI_events(ii).event_length_ms = event_length_ms;
        mean_event_length_ms(ii,1) = mean(event_length_ms);
        std_event_length_ms(ii,1) = std(event_length_ms,0);
        
        %ROI_events(i).IEI_frames = IEI_frames;
        ROI_events(ii).IEI_frame_inds = IEI_frame_inds;
        
        if fr ==0
            IEI_length_ms = IEI_length*msn;
        else
            IEI_length_ms = IEI_length*(1000/fr);
        end
        ROI_events(ii).IEI_length_ms = IEI_length_ms;
        mean_IEI_length_ms(ii,1) = mean(IEI_length_ms);
        std_IEI_length_ms(ii,1) = std(IEI_length_ms,0);
        
        
        ROI_events(ii).event_amplitude = event_amplitude;
        
        mean_event_amplitude(ii,1) = mean(event_amplitude);
        std_event_amplitude(ii,1) = std(event_amplitude,0);
        
        event_area = event_length_ms.*event_amplitude;
        ROI_events(ii).event_area = event_area;
        
        mean_event_area(ii,1) = mean(event_area);
        std_event_area(ii,1) = std(event_area,0);
        
    end
    
else
    
    parfor ii = 1:rois
        %clear event_frames IEI_frames
        %%%%%%%%%%%%%%%%%%%
        
        trace = squeeze(matrix(:,ii));
        
        trace(isnan(trace))=0;
        
        % ROI = ii
        mean_DF(ii,1) = mean(trace);
        a = 2; %current frame of trace
        b = 1; %number of current event
        c = 1; %frame within current event
        d = 1; %frame within current IEI
        e = 1; %number of current IEI
        
        
        
        
        event_length = 0;
        event_amplitude = 0;
        IEI_length = 0;
        %event_frames.init = 1;
        %IEI_frames.init = 1;
        IEI_frame_inds = 0;
        event_frame_inds=0;
        while a<length(trace)
            %identifying_events = a;
            if trace(a,1) && trace(a-1,1)==0  %first frame of new event
                d=1;
                e=e+1
                %curr_event_frame = c;
                
                event_length(b,1) = c;
                %event_frames(b).frame_ind(c,1) = a;
                event_frame_inds(b,c) = a;
                %event_amplitude(b,1) = matrix(event_frames(b).frame_ind(c,1),i);
                %event_amplitude(b,1) = trace(event_frames(b).frame_ind(c,1),1);
                event_amplitude(b,c) = trace(event_frame_inds(b,c),1);
                c=c+1;
                a=a+1;
            else
                if trace(a,1) && trace(a-1,1) %next frame of current event
                    if a==2 %if looking at the first frame of trace
                        %curr_event_frame = 2;
                        event_length(b,1) = 2;
                        %event_frames(b).frame_ind(1,1) = a;
                        event_frame_inds(b,1) = a;
                        %event_amplitude(b,1) = matrix(event_frames(b).frame_ind(1,1),i);
                        %event_amplitude(b,1) = trace(event_frames(b).frame_ind(1,1),1);
                        event_amplitude(b,1) = trace(event_frame_inds(b,1),1);
                        c=c+1;
                        a=a+1;
                        
                    else % if after first frame
                        %curr_event_frame = c;
                        
                        event_length(b,1) = c;
                        %event_frames(b).frame_ind(c,1) = a;
                        event_frame_inds(b,c) = a;
                        %event_amplitude(b,1) = max(matrix(event_frames(b).frame_ind(:,1),i));
                        %event_amplitude(b,1) = max(trace(event_frames(b).frame_ind(:,1),1));
                        [qw, pq] = find(event_frame_inds(b,:));
                        event_amplitude(b,1) = max(trace(event_frame_inds(b,pq),1));
                        c=c+1;
                        a=a+1;
                    end
                else
                    if trace(a-1,1) && trace(a,1)==0 % if first frame of an IEI
                        c=1;
                        
                        %curr_IEI_frame = d;
                        
                        IEI_length(e,1) = d;
                        %IEI_frames(e).frame_ind(d,1) = a;
                        IEI_frame_inds(e,d) = a;
                        d=d+1;
                        a=a+1;
                        b=b+1;
                    else
                        if trace(a-1,1)==0 && trace(a,1)==0 %if next frame of IEI
                            %curr_IEI_frame = d;
                            
                            IEI_length(e,1) = d;
                            %IEI_frames(e).frame_ind(d,1) = a;
                            IEI_frame_inds(e,d) = a;
                            d=d+1;
                            a=a+1;
                        end
                    end
                end
            end
        end
        
        if fr == 0
            tot_secs = sm/issm;%size(matrix,1)/i2.samplingratehz;
        else
            tot_secs = sm;%size(matrix,1)/fr;
        end
        
        events_per_sec(ii,1) = b/tot_secs;
        
        %ROI_events(i).event_frames = event_frames;
        %ROI_events(ii).event_frame_inds = event_frame_inds;
        
        if fr ==0
            event_length_ms = event_length*msn;
        else
            event_length_ms = event_length*(1000/fr);
        end
        ROI_events(ii).event_length_ms = event_length_ms;
        mean_event_length_ms(ii,1) = mean(event_length_ms);
        std_event_length_ms(ii,1) = std(event_length_ms,0);
        
        %ROI_events(i).IEI_frames = IEI_frames;
        %ROI_events(ii).IEI_frame_inds = IEI_frame_inds;
        
        if fr ==0
            IEI_length_ms = IEI_length*msn;
        else
            IEI_length_ms = IEI_length*(1000/fr);
        end
        ROI_events(ii).IEI_length_ms = IEI_length_ms;
        mean_IEI_length_ms(ii,1) = mean(IEI_length_ms);
        std_IEI_length_ms(ii,1) = std(IEI_length_ms,0);
        
        
        ROI_events(ii).event_amplitude = event_amplitude;
        
        mean_event_amplitude(ii,1) = mean(event_amplitude);
        std_event_amplitude(ii,1) = std(event_amplitude,0);
        
        event_area = event_length_ms.*event_amplitude;
        ROI_events(ii).event_area = event_area;
        
        mean_event_area(ii,1) = mean(event_area);
        std_event_area(ii,1) = std(event_area,0);
        
    end
end
ROI_events(1).mean_DF = mean_DF;
ROI_events(1).events_per_sec = events_per_sec;
ROI_events(1).mean_event_length_ms = mean_event_length_ms;
ROI_events(1).std_event_length_ms = std_event_length_ms;
ROI_events(1).mean_IEI_length_ms = mean_IEI_length_ms;
ROI_events(1).std_IEI_length_ms = std_IEI_length_ms;
ROI_events(1).mean_event_amplitude = mean_event_amplitude;
ROI_events(1).std_event_amplitude = std_event_amplitude;
ROI_events(1).mean_event_area = mean_event_area;
ROI_events(1).std_event_area = std_event_area;
ca_stats.ROI_events = ROI_events;

hus=1
if onep
    bursts_binary = zeros(frames,rois);
else
    bursts_binary = zeros(frames,rois-10);
    bursts_binary_neurop = zeros(frames,10);
end

if this_one_serial
    
    for ii = 1:rois
        trace = squeeze(matrix(:,ii));
        if onep
            for j = 1:frames-10
                if sum(trace(j,1))>0
                    bursts_binary(j,ii) = 1;
                end
            end
            
            hus=hus+1;
        else
            if ii<rois-9
                for j = 1:frames-10
                    if sum(trace(j,1))>0
                        bursts_binary(j,ii) = 1;
                    end
                end
            else
                
                for j = 1:frames-10
                    %jip = zeros(frames,1);
                    if sum(trace(j,1))>0
                        bursts_binary_neurop(j,10-rois+ii) = 1;
                        %jip(j,1) = 1; %10-rois+i) = 1;
                    end
                    
                end
                % bursts_binary_neurop(:,hus) = jip;
                %aaaah=aaaah+1;
                hus=hus+1;
            end
        end
    end
    
else
    for ii = 1:rois
        trace = squeeze(matrix(:,ii));
        roiz=ii
        if onep
            % parfor j = 1:frames-10
            for j = 1:frames-10
                
                if sum(trace(j,1))>0
                    bursts_binary(j,ii) = 1;
                end
            end
            
            hus=hus+1;
        else
            
            
            
            if ii<rois-9
                parfor j = 1:frames-10
                    if sum(trace(j,1))>0
                        bursts_binary(j,ii) = 1;
                    end
                end
            else
                
                for j = 1:frames-10
                    %jip = zeros(frames,1);
                    if sum(trace(j,1))>0
                        bursts_binary_neurop(j,10-rois+ii) = 1;
                        %jip(j,1) = 1; %10-rois+i) = 1;
                    end
                    
                end
                % bursts_binary_neurop(:,hus) = jip;
                %aaaah=aaaah+1;
                hus=hus+1;
            end
        end
    end
end
ca_stats.bursts_binary = bursts_binary;
if onep==0
    ca_stats.bursts_binary_neurop = bursts_binary_neurop;
    %population level: get distribution of activity per cell, synchrony
end

%compute synchrony, interict vs. ictal

clear  burst_synchrony
for ii = 1:size(bursts_binary,1)
    burst_synchrony(ii) = sum(bursts_binary(ii,:));
end
burst_synchrony = burst_synchrony'/size(bursts_binary,2);%max(burst_synchrony);
synchr = burst_synchrony;

ca_stats.synchr_cells = synchr;

if onep==0
    clear  burst_synchrony
    for ii = 1:size(bursts_binary_neurop,1)
        burst_synchrony(ii) = sum(bursts_binary_neurop(ii,:));
    end
    burst_synchrony = burst_synchrony'/size(bursts_binary_neurop,2);%max(burst_synchrony);
    synchr = burst_synchrony;
    
    ca_stats.synchr_neurop = synchr;
end

