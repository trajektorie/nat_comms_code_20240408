

close all

Folder = subfolders(iii).name;
cd(Folder_master)
cd(Folder)

if isfield(recording(iii),'ROI_list')
    if ~isempty(recording(iii).ROI_list)
        if onep
            if use_masked_g_nrh5
                  masked_g = read_file('masked_g_nr.h5',1,200);
                    
                    uyt = masked_g(:,:,1);
            else
            if isfield(recording(iii).initial1,'g')
                uyt = recording(iii).initial1.g(:,:,1);
            else
                if exist('masked_g_bak')
                    uyt = masked_g_bak(:,:,1);
                else
                    masked_g = read_file('masked_g_nr.h5',1,200);
                    
                    uyt = masked_g(:,:,1);
                end
            end
            end 
        else
            if isfield(recording(iii).initial1,'g')
                if size(recording(iii).initial1.g,3)>100 && (strcmp(class(recording(iii).initial1.g),'vvar')==0)
                    uyt = squeeze(mean(recording(iii).initial1.g,3));
                else
                    if recording(iii).initial1.g==0 || strcmp(class(recording(iii).initial1.g),'vvar')
                        if isfield(recording(iii),'template')
                            if isempty(recording(iii).template)
                                uyt =  imread ('avg_ch2.tif');
                            else
                                if size(recording(iii).template,1)==1
                                    uyt =  imread ('avg_ch2.tif'); 
                            else
                                if sum(recording(iii).template(32,32:64)) == 0
                                    uyt =  imread ('avg_ch2.tif');
                                else
                                    uyt = recording(iii).template;
                                end
                            end
                            end
                        else
                            uyt =  imread ('avg_ch2.tif');
                        end
                    else
                        uyt = squeeze(mean(recording(iii).initial1.g,3));
                    end
                end
            else
                uyt =  imread ('avg_ch2.tif');
                
            end
        end
        if flip_uyt
            uyt = rot90(uyt,3);
            uyt = fliplr(uyt);
        end
        
        movie_avg = uyt;
        
        minm = min(min(movie_avg));
        
        movie_avg = movie_avg - minm +1;
        
        recording(iii).movie_avg = movie_avg;
        
        imagej_rois = 0
        if imagej_rois
            xx=2;
        else
            xx=1;
        end
        
        if isfield(recording(iii),'C_dec')
            if ~isempty(recording(iii).C_dec)
                if size(recording(iii).C_dec,1)>size(recording(iii).C_dec,2)
                    matrix = recording(iii).C_dec;
                    
                else
                    matrix = recording(iii).C_dec';
                end
            else
                matrix = recording(iii).FiltMat2_5000;
            end
        else
            matrix = recording(iii).FiltMat2_5000;
        end
        
        numrois = size(matrix,2);
        
        if neuropil_not_present_yet
            
            neuropil_ROIs = [];
            
        else
            
            neuropil_ROIs = [numrois-9:1:numrois];
        end
        
        cell_ROIs = setdiff(xx:1:size(matrix,2),neuropil_ROIs);
        
        %plot ALL neurons' numbers
        close all
        I = movie_avg;
        
        calm = double(max(prctile(I,95)))
        fac = 1.05*calm/32000 %1.05*calm/256
        
        I = round(I/fac);
        
        ROI_list = recording(iii).ROI_list;
        
        results=recording(iii).results;
        
        for i = 1:length(cell_ROIs)
            ii = cell_ROIs(1,i); %1:size(deltaf_matrix,2)
            tx = num2str(ii);
            
            if ii>size(ROI_list,2)
            else
                if imagej_rois
                    Location = [results.ROI_info(i,4) results.ROI_info(i,5)]; % [x y]
                    
                else
                    
                    Location = [ROI_list(ii).centerPos(1,2) ROI_list(ii).centerPos(1,1)]; % [x y]
                    
                end
                
                RGB = insertText(I,Location,tx,'FontSize',8,'TextColor','white','BoxOpacity',0.01);
            end
            RGB = uint16(RGB);
            
            I = rgb2gray(RGB); %RGB;
            %
        end
        
        
        close all
        figure(211)
        maxI = prctile(max(I),90); %max(max(I));
        minI = prctile(min(I),1); % min(min(I));
        clims = [minI maxI]; % [0.05 0.7]
        imagesc(I ,clims)
        colormap gray
        % hold on
        % imshow(I)
        % imagesc(I,clims)
        %
        saveas (211,['ROI_#_overlay'  '.png' ],'png')
        
        
        
        %
        % if length(ROI_list)<size(matrix,2)
        %     if ismember(1,lazy_ROIs)
        %     else
        %         lazy_ROIs(1,length(lazy_ROIs)+1) = 1;
        %     end
        %     nonlazy_ROIs = setdiff(1:1:size(matrix,2),lazy_ROIs);
        %
        %     nonlazy_ROIs = nonlazy_ROIs - 1;
        % else
        %      nonlazy_ROIs = setdiff(1:1:size(matrix,2),lazy_ROIs);
        % end
        %
        % %OR nonlazy
        %
        %
        % I = movie_avg;
        % figure(212)
        % clims = [0 4000]
        % imagesc(I,clims)
        % colormap gray
        % hold on
        %
        % for i = 1:length(nonlazy_ROIs)
        %     ii = nonlazy_ROIs(1,i); %1:size(deltaf_matrix,2)
        %     tx = num2str(i);
        %     htxtins = vision.TextInserter(tx);
        %     htxtins.Color = [0, 0, 0]; % [red, green, blue]
        %     htxtins.FontSize = 10;
        %     htxtins.Opacity = 1;
        %     htxtins.Location = [ROI_list(ii).centerPos(1,2) ROI_list(ii).centerPos(1,1)]; % [x y]
        %     J = step(htxtins, I);
        %     I = J;
        %
        % end
        
        I = movie_avg;
        figure(1234)
        maxI = prctile(I,98);
        minI = round(mean(prctile(I,1)));
        maxI = round(mean(maxI));
        clims = [minI maxI];
        imagesc(I,clims)
        colormap(gray)
        hold on
        
        initial=recording(iii).initial;
        
        a=1
        for i = 1:size(ROI_list,2) %nonlazy_ROIs %
            all_ROI_pixels(a:a+size(ROI_list(i).pixel_list,1)-1,1) = ROI_list(i).pixel_list;
            a=a+size(ROI_list(i).pixel_list,1);
        end
        
        if isfield(recording(iii).initial,'height')
            hh = recording(iii).initial.height;
        else
            hh = recording(iii).initial2.linesperframe;
        end
        if isfield(recording(iii).initial,'width')
            w = recording(iii).initial.width;
        else
            w = recording(iii).initial2.pixelsperline;
        end
        
        if isfield(recording(iii),'Cn')
            if hh == size(recording(iii).Cn,1)
                all_ROI_pixels_bin = zeros(hh,w);
            else
                all_ROI_pixels_bin = zeros(w,hh);
            end
        else
            if hh == size(movie_avg,1)
                all_ROI_pixels_bin = zeros(hh,w);
            else
                all_ROI_pixels_bin = zeros(w,hh);
            end
            
        end
        %a=1
        for i = 1:size(ROI_list,2) %nonlazy_ROIs %
            for j = 1:size(ROI_list(i).pixel_list,1)
                all_ROI_pixels_bin(nonzeros(ROI_list(i).pixel_list(j,1))) = 1;
                %a=a+size(ROI_list(i).pixel_list,1);
            end
        end
        
        si = size(all_ROI_pixels_bin);
        
        red = cat(3,ones(si),zeros(si),zeros(si));
        
        h = imshow(red)
        set(h, 'AlphaData', all_ROI_pixels_bin/3)
        
        saveas (1234,['ROI_footprints_overlay'  '.png' ],'png')
        
        
    end
end

