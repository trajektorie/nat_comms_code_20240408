


a=1;
curr_num=1;
bbu=1;
clear rows_to_delete fc consolidated

for j = 1:size(curr_summary,2)
    if isempty(curr_summary(j).tot_dur_min)
        curr_summary(j).tot_dur_min = 0;
    end
    if curr_summary(j).tot_dur_min == 0
        rows_to_delete(1,bbu) = j;
        bbu=bbu+1;
    end
end

if bbu>1
    curr_summary(rows_to_delete) = [];
end


aa=1;
bb=1;
for j = 1:size(curr_summary,2)
    if j==1
        fc(aa).curr_summ(1).days_of_TeT = curr_summary(j).days_of_TeT;
        fc(aa).curr_summ(1).tot_dur_min = curr_summary(j).tot_dur_min;
        fc(aa).curr_summ(1).mean_synchr = curr_summary(j).mean_synchr;
        fc(aa).curr_summ(1).mean_mean_DF = curr_summary(j).mean_mean_DF;
        fc(aa).curr_summ(1).mean_events_per_sec = curr_summary(j).mean_events_per_sec;
        fc(aa).curr_summ(1).mean_mean_event_length_ms = curr_summary(j).mean_mean_event_length_ms;
        fc(aa).curr_summ(1).mean_mean_event_amplitude = curr_summary(j).mean_mean_event_amplitude;
        fc(aa).curr_summ(1).mean_mean_event_area = curr_summary(j).mean_mean_event_area;
        
        fc(aa).curr_summ(1).overlap_index_pre = curr_summary(j).overlap_index_pre;
        fc(aa).curr_summ(1).num_clusts_norm_by_FOV_squm_pre = curr_summary(j).num_clusts_norm_by_FOV_squm_pre;
        fc(aa).curr_summ(1).avg_nodes_per_module_pre = curr_summary(j).avg_nodes_per_module_pre;
        fc(aa).curr_summ(1).avg_area_per_module_pre = curr_summary(j).avg_area_per_module_pre;
        fc(aa).curr_summ(1).avg_dens_per_module_pre = curr_summary(j).avg_dens_per_module_pre;
        
        
        fc(aa).curr_summ(1).overlap_index_post = curr_summary(j).overlap_index_post;
        fc(aa).curr_summ(1).num_clusts_norm_by_FOV_squm_post = curr_summary(j).num_clusts_norm_by_FOV_squm_post;
        fc(aa).curr_summ(1).avg_nodes_per_module_post = curr_summary(j).avg_nodes_per_module_post;
        fc(aa).curr_summ(1).avg_area_per_module_post = curr_summary(j).avg_area_per_module_post;
        fc(aa).curr_summ(1).avg_dens_per_module_post = curr_summary(j).avg_dens_per_module_post;
        
        
        fc(aa).curr_summ(1).nothing_per_min = curr_summary(j).EEG_segs.nothing_per_min;
        fc(aa).curr_summ(1).artifacts_per_min = curr_summary(j).EEG_segs.artifacts_per_min;
        fc(aa).curr_summ(1).SW_per_min = curr_summary(j).EEG_segs.SW_per_min;
        fc(aa).curr_summ(1).seizures_per_min = curr_summary(j).EEG_segs.seizures_per_min;
        fc(aa).curr_summ(1).int_spikes_per_min = curr_summary(j).EEG_segs.int_spikes_per_min;
        fc(aa).curr_summ(1).others_per_min = curr_summary(j).EEG_segs.others_per_min;
        
        fc(aa).curr_summ(1).ict_high_perc_others = curr_summary(j).ict_high_perc_others;
        fc(aa).curr_summ(1).ict_high_perc_seizures = curr_summary(j).ict_high_perc_seizures;
        fc(aa).curr_summ(1).ict_high_perc_SWs = curr_summary(j).ict_high_perc_SWs;
        fc(aa).curr_summ(1).ict_high_perc_int_spikes = curr_summary(j).ict_high_perc_int_spikes;
        
        fc(aa).curr_summ(1).ict_low_perc_others = curr_summary(j).ict_low_perc_others;
        fc(aa).curr_summ(1).ict_low_perc_seizures = curr_summary(j).ict_low_perc_seizures;
        fc(aa).curr_summ(1).ict_low_perc_SWs = curr_summary(j).ict_low_perc_SWs;
        fc(aa).curr_summ(1).ict_low_perc_int_spikes = curr_summary(j).ict_low_perc_int_spikes;
        
        fc(aa).curr_summ(1).microseiz = curr_summary(j).microseiz;
    else
        if curr_summary(j).days_of_TeT == curr_summary(j-1).days_of_TeT
            bb=bb+1;
            fc(aa).curr_summ(bb).days_of_TeT = curr_summary(j).days_of_TeT;
            fc(aa).curr_summ(bb).tot_dur_min = curr_summary(j).tot_dur_min;
            fc(aa).curr_summ(bb).mean_synchr = curr_summary(j).mean_synchr;
            
            fc(aa).curr_summ(bb).mean_mean_DF = curr_summary(j).mean_mean_DF;
            fc(aa).curr_summ(bb).mean_events_per_sec = curr_summary(j).mean_events_per_sec;
            fc(aa).curr_summ(bb).mean_mean_event_length_ms = curr_summary(j).mean_mean_event_length_ms;
            fc(aa).curr_summ(bb).mean_mean_event_amplitude = curr_summary(j).mean_mean_event_amplitude;
            fc(aa).curr_summ(bb).mean_mean_event_area = curr_summary(j).mean_mean_event_area;
            
            fc(aa).curr_summ(bb).overlap_index_pre = curr_summary(j).overlap_index_pre;
            fc(aa).curr_summ(bb).num_clusts_norm_by_FOV_squm_pre = curr_summary(j).num_clusts_norm_by_FOV_squm_pre;
            fc(aa).curr_summ(bb).avg_nodes_per_module_pre = curr_summary(j).avg_nodes_per_module_pre;
            fc(aa).curr_summ(bb).avg_area_per_module_pre = curr_summary(j).avg_area_per_module_pre;
            fc(aa).curr_summ(bb).avg_dens_per_module_pre = curr_summary(j).avg_dens_per_module_pre;
            
            
            fc(aa).curr_summ(bb).overlap_index_post = curr_summary(j).overlap_index_post;
            fc(aa).curr_summ(bb).num_clusts_norm_by_FOV_squm_post = curr_summary(j).num_clusts_norm_by_FOV_squm_post;
            fc(aa).curr_summ(bb).avg_nodes_per_module_post = curr_summary(j).avg_nodes_per_module_post;
            fc(aa).curr_summ(bb).avg_area_per_module_post = curr_summary(j).avg_area_per_module_post;
            fc(aa).curr_summ(bb).avg_dens_per_module_post = curr_summary(j).avg_dens_per_module_post;
            
            fc(aa).curr_summ(bb).nothing_per_min = curr_summary(j).EEG_segs.nothing_per_min;
            fc(aa).curr_summ(bb).artifacts_per_min = curr_summary(j).EEG_segs.artifacts_per_min;
            fc(aa).curr_summ(bb).SW_per_min = curr_summary(j).EEG_segs.SW_per_min;
            fc(aa).curr_summ(bb).seizures_per_min = curr_summary(j).EEG_segs.seizures_per_min;
            fc(aa).curr_summ(bb).int_spikes_per_min = curr_summary(j).EEG_segs.int_spikes_per_min;
            fc(aa).curr_summ(bb).others_per_min = curr_summary(j).EEG_segs.others_per_min;
            
            fc(aa).curr_summ(bb).ict_high_perc_others = curr_summary(j).ict_high_perc_others;
            fc(aa).curr_summ(bb).ict_high_perc_seizures = curr_summary(j).ict_high_perc_seizures;
            fc(aa).curr_summ(bb).ict_high_perc_SWs = curr_summary(j).ict_high_perc_SWs;
            fc(aa).curr_summ(bb).ict_high_perc_int_spikes = curr_summary(j).ict_high_perc_int_spikes;
            
            fc(aa).curr_summ(bb).ict_low_perc_others = curr_summary(j).ict_low_perc_others;
            fc(aa).curr_summ(bb).ict_low_perc_seizures = curr_summary(j).ict_low_perc_seizures;
            fc(aa).curr_summ(bb).ict_low_perc_SWs = curr_summary(j).ict_low_perc_SWs;
            fc(aa).curr_summ(bb).ict_low_perc_int_spikes = curr_summary(j).ict_low_perc_int_spikes;
            
            fc(aa).curr_summ(bb).microseiz = curr_summary(j).microseiz;
        else
            bb=1;
            aa=aa+1;
            fc(aa).curr_summ(bb).days_of_TeT = curr_summary(j).days_of_TeT;
            fc(aa).curr_summ(bb).tot_dur_min = curr_summary(j).tot_dur_min;
            fc(aa).curr_summ(bb).mean_synchr = curr_summary(j).mean_synchr;
            
            
            fc(aa).curr_summ(bb).mean_mean_DF = curr_summary(j).mean_mean_DF;
            fc(aa).curr_summ(bb).mean_events_per_sec = curr_summary(j).mean_events_per_sec;
            fc(aa).curr_summ(bb).mean_mean_event_length_ms = curr_summary(j).mean_mean_event_length_ms;
            fc(aa).curr_summ(bb).mean_mean_event_amplitude = curr_summary(j).mean_mean_event_amplitude;
            fc(aa).curr_summ(bb).mean_mean_event_area = curr_summary(j).mean_mean_event_area;
            
            
            fc(aa).curr_summ(bb).overlap_index_pre = curr_summary(j).overlap_index_pre;
            fc(aa).curr_summ(bb).num_clusts_norm_by_FOV_squm_pre = curr_summary(j).num_clusts_norm_by_FOV_squm_pre;
            fc(aa).curr_summ(bb).avg_nodes_per_module_pre = curr_summary(j).avg_nodes_per_module_pre;
            fc(aa).curr_summ(bb).avg_area_per_module_pre = curr_summary(j).avg_area_per_module_pre;
            fc(aa).curr_summ(bb).avg_dens_per_module_pre = curr_summary(j).avg_dens_per_module_pre;
            
            
            fc(aa).curr_summ(bb).overlap_index_post = curr_summary(j).overlap_index_post;
            fc(aa).curr_summ(bb).num_clusts_norm_by_FOV_squm_post = curr_summary(j).num_clusts_norm_by_FOV_squm_post;
            fc(aa).curr_summ(bb).avg_nodes_per_module_post = curr_summary(j).avg_nodes_per_module_post;
            fc(aa).curr_summ(bb).avg_area_per_module_post = curr_summary(j).avg_area_per_module_post;
            fc(aa).curr_summ(bb).avg_dens_per_module_post = curr_summary(j).avg_dens_per_module_post;
            fc(aa).curr_summ(bb).nothing_per_min = curr_summary(j).EEG_segs.nothing_per_min;
            fc(aa).curr_summ(bb).artifacts_per_min = curr_summary(j).EEG_segs.artifacts_per_min;
            fc(aa).curr_summ(bb).SW_per_min = curr_summary(j).EEG_segs.SW_per_min;
            fc(aa).curr_summ(bb).seizures_per_min = curr_summary(j).EEG_segs.seizures_per_min;
            fc(aa).curr_summ(bb).int_spikes_per_min = curr_summary(j).EEG_segs.int_spikes_per_min;
            fc(aa).curr_summ(bb).others_per_min = curr_summary(j).EEG_segs.others_per_min;
            
            fc(aa).curr_summ(bb).ict_high_perc_others = curr_summary(j).ict_high_perc_others;
            fc(aa).curr_summ(bb).ict_high_perc_seizures = curr_summary(j).ict_high_perc_seizures;
            fc(aa).curr_summ(bb).ict_high_perc_SWs = curr_summary(j).ict_high_perc_SWs;
            fc(aa).curr_summ(bb).ict_high_perc_int_spikes = curr_summary(j).ict_high_perc_int_spikes;
            
            fc(aa).curr_summ(bb).ict_low_perc_others = curr_summary(j).ict_low_perc_others;
            fc(aa).curr_summ(bb).ict_low_perc_seizures = curr_summary(j).ict_low_perc_seizures;
            fc(aa).curr_summ(bb).ict_low_perc_SWs = curr_summary(j).ict_low_perc_SWs;
            fc(aa).curr_summ(bb).ict_low_perc_int_spikes = curr_summary(j).ict_low_perc_int_spikes;
            
            fc(aa).curr_summ(bb).microseiz = curr_summary(j).microseiz;
        end
    end
end

clear baseline_bef_d_minus_pointone baseline_right_before_tet_inj
baseline_bef_d_minus_pointone=0
for j = 1:size(fc,2)
    totdur = 0;
    mean_synchr = 0;
    mean_mean_DF = 0;
    mean_events_per_sec = 0;
    mean_mean_event_length_ms = 0;
    mean_mean_event_amplitude = 0;
    mean_mean_event_area = 0;
    overlap_index_pre  = 0;
    overlap_index_post  = 0;
    
    num_clusts_norm_by_FOV_squm_pre = 0;
    avg_nodes_per_module_pre = 0;
    avg_area_per_module_pre = 0;
    avg_dens_per_module_pre = 0;
    nothing_per_min = 0;
    artifacts_per_min = 0;
    SW_per_min = 0;
    seizures_per_min = 0;
    int_spikes_per_min = 0;
    others_per_min = 0;
    ict_high_perc_others = 0;
    ict_high_perc_seizures = 0;
    ict_high_perc_SWs = 0;
    ict_high_perc_int_spikes = 0;
    ict_low_perc_others = 0;
    ict_low_perc_seizures = 0;
    ict_low_perc_SWs = 0;
    ict_low_perc_int_spikes = 0;
    
    for k = 1:size(fc(j).curr_summ,2)
        totdur = totdur + fc(j).curr_summ(k).tot_dur_min;
        totdur_synchr = totdur;
        totdur_overlap_pre = totdur;
        totdur_overlap_post = totdur;
        totdur_numclust = totdur;
        totdur_avnod = totdur;
        totdur_avare = totdur;
        totdur_avdens = totdur;
        
        if isnan(fc(j).curr_summ(k).mean_synchr)||isempty(fc(j).curr_summ(k).mean_synchr)
            totdur_synchr = totdur_synchr - fc(j).curr_summ(k).tot_dur_min
        else
            mean_synchr = mean_synchr + fc(j).curr_summ(k).mean_synchr;
        end
        
        mean_mean_DF = mean_mean_DF + fc(j).curr_summ(k).mean_mean_DF;
        mean_events_per_sec = mean_events_per_sec + fc(j).curr_summ(k).mean_events_per_sec;
        mean_mean_event_length_ms = mean_mean_event_length_ms + fc(j).curr_summ(k).mean_mean_event_length_ms;
        mean_mean_event_amplitude = mean_mean_event_amplitude + fc(j).curr_summ(k).mean_mean_event_amplitude;
        mean_mean_event_area = mean_mean_event_area + fc(j).curr_summ(k).mean_mean_event_area;
        
        
        if isempty(fc(j).curr_summ(k).overlap_index_pre)
            totdur_overlap_pre = totdur_overlap_pre - fc(j).curr_summ(k).tot_dur_min
        else
            if isnan(fc(j).curr_summ(k).overlap_index_pre)
                totdur_overlap_pre = totdur_overlap_pre - fc(j).curr_summ(k).tot_dur_min
            else
                overlap_index_pre = overlap_index_pre + fc(j).curr_summ(k).overlap_index_pre;
            end
        end
        
        if isempty(fc(j).curr_summ(k).overlap_index_post)
            totdur_overlap_post = totdur_overlap_post - fc(j).curr_summ(k).tot_dur_min
        else
            if isnan(fc(j).curr_summ(k).overlap_index_post)
                totdur_overlap_post = totdur_overlap_post - fc(j).curr_summ(k).tot_dur_min
            else
                overlap_index_post = overlap_index_post + fc(j).curr_summ(k).overlap_index_post;
            end
        end
        
        if isempty(fc(j).curr_summ(k).num_clusts_norm_by_FOV_squm_pre)
            totdur_numclust = totdur_numclust - fc(j).curr_summ(k).tot_dur_min
        else
            if isnan(fc(j).curr_summ(k).num_clusts_norm_by_FOV_squm_pre)
                totdur_numclust = totdur_numclust - fc(j).curr_summ(k).tot_dur_min
            else
                num_clusts_norm_by_FOV_squm_pre = num_clusts_norm_by_FOV_squm_pre + fc(j).curr_summ(k).num_clusts_norm_by_FOV_squm_pre;
            end
        end
        
        if isempty(fc(j).curr_summ(k).avg_nodes_per_module_pre)
            totdur_avnod = totdur_avnod - fc(j).curr_summ(k).tot_dur_min
        else
            if isnan(fc(j).curr_summ(k).avg_nodes_per_module_pre)
                totdur_avnod = totdur_avnod - fc(j).curr_summ(k).tot_dur_min
            else
                avg_nodes_per_module_pre = avg_nodes_per_module_pre + fc(j).curr_summ(k).avg_nodes_per_module_pre;
            end
        end
        
        if isempty(fc(j).curr_summ(k).avg_area_per_module_pre)
            totdur_avare = totdur_avare - fc(j).curr_summ(k).tot_dur_min
        else
            if isnan(fc(j).curr_summ(k).avg_area_per_module_pre)
                totdur_avare = totdur_avare - fc(j).curr_summ(k).tot_dur_min
            else
                avg_area_per_module_pre = avg_area_per_module_pre + fc(j).curr_summ(k).avg_area_per_module_pre;
            end
        end
        
        if isempty(fc(j).curr_summ(k).avg_dens_per_module_pre)
            totdur_avdens = totdur_avdens - fc(j).curr_summ(k).tot_dur_min
        else
            if isnan(fc(j).curr_summ(k).avg_dens_per_module_pre)
                totdur_avdens = totdur_avdens - fc(j).curr_summ(k).tot_dur_min
            else
                avg_dens_per_module_pre = avg_dens_per_module_pre + fc(j).curr_summ(k).avg_dens_per_module_pre;
            end
        end
        
        
        nothing_per_min = nothing_per_min + fc(j).curr_summ(k).nothing_per_min;
        artifacts_per_min = artifacts_per_min +     fc(j).curr_summ(k).artifacts_per_min;
        SW_per_min = SW_per_min + fc(j).curr_summ(k).SW_per_min;
        seizures_per_min = seizures_per_min +   fc(j).curr_summ(k).seizures_per_min;
        int_spikes_per_min = int_spikes_per_min +    fc(j).curr_summ(k).int_spikes_per_min;
        others_per_min = others_per_min +    fc(j).curr_summ(k).others_per_min;
        
        ict_high_perc_others = ict_high_perc_others +   fc(j).curr_summ(k).ict_high_perc_others;
        ict_high_perc_seizures = ict_high_perc_seizures +   fc(j).curr_summ(k).ict_high_perc_seizures;
        ict_high_perc_SWs = ict_high_perc_SWs +   fc(j).curr_summ(k).ict_high_perc_SWs;
        ict_high_perc_int_spikes = ict_high_perc_int_spikes +    fc(j).curr_summ(k).ict_high_perc_int_spikes;
        
        ict_low_perc_others = ict_low_perc_others +    fc(j).curr_summ(k).ict_low_perc_others;
        ict_low_perc_seizures = ict_low_perc_seizures +    fc(j).curr_summ(k).ict_low_perc_seizures;
        ict_low_perc_SWs = ict_low_perc_SWs +   fc(j).curr_summ(k).ict_low_perc_SWs;
        ict_low_perc_int_spikes = ict_low_perc_int_spikes +   fc(j).curr_summ(k).ict_low_perc_int_spikes;
    end
    
    consolidated(j).days_of_TeT = fc(j).curr_summ(1).days_of_TeT;
    consolidated(j).mean_synchr = mean_synchr/totdur_synchr;
    consolidated(j).mean_mean_DF = mean_mean_DF/totdur;
    consolidated(j).mean_events_per_sec = mean_events_per_sec/totdur;
    consolidated(j).mean_mean_event_length_ms = mean_mean_event_length_ms/totdur;
    consolidated(j).mean_mean_event_amplitude = mean_mean_event_amplitude/totdur;
    consolidated(j).mean_mean_event_area = mean_mean_event_area/totdur;
    consolidated(j).overlap_index_pre = overlap_index_pre/totdur_overlap_pre;
    consolidated(j).overlap_index_post = overlap_index_post/totdur_overlap_post;
    
    consolidated(j).num_clusts_norm_by_FOV_squm_pre = num_clusts_norm_by_FOV_squm_pre/totdur_numclust;
    consolidated(j).avg_nodes_per_module_pre = avg_nodes_per_module_pre/totdur_avnod;
    consolidated(j).avg_area_per_module_pre = avg_area_per_module_pre/totdur_avare;
    consolidated(j).avg_dens_per_module_pre = avg_dens_per_module_pre/totdur_avdens;
    consolidated(j).nothing_per_min = nothing_per_min/totdur;
    consolidated(j).artifacts_per_min = artifacts_per_min/totdur;
    consolidated(j).SW_per_min = SW_per_min/totdur;
    consolidated(j).seizures_per_min = seizures_per_min/totdur;
    consolidated(j).int_spikes_per_min = int_spikes_per_min/totdur;
    consolidated(j).others_per_min = others_per_min/totdur;
    consolidated(j).ict_high_perc_others = ict_high_perc_others/totdur;
    consolidated(j).ict_high_perc_seizures = ict_high_perc_seizures/totdur;
    consolidated(j).ict_high_perc_SWs = ict_high_perc_SWs/totdur;
    consolidated(j).ict_high_perc_int_spikes = ict_high_perc_int_spikes/totdur;
    consolidated(j).ict_low_perc_others = ict_low_perc_others/totdur;
    consolidated(j).ict_low_perc_seizures  = ict_low_perc_seizures/totdur;
    consolidated(j).ict_low_perc_SWs = ict_low_perc_SWs/totdur;
    consolidated(j).ict_low_perc_int_spikes = ict_low_perc_int_spikes/totdur;
    
    
    
    if j>1
        consolidated(j).mean_synchr_norm_by_first_baseline = consolidated(j).mean_synchr/ consolidated(1).mean_synchr
        consolidated(j).mean_mean_DF_norm_by_first_baseline = consolidated(j).mean_mean_DF/ consolidated(1).mean_mean_DF
        consolidated(j).mean_events_per_sec_norm_by_first_baseline = consolidated(j).mean_events_per_sec /consolidated(1).mean_events_per_sec
        consolidated(j).mean_mean_event_length_ms_norm_by_first_baseline = consolidated(j).mean_mean_event_length_ms /consolidated(1).mean_mean_event_length_ms
        consolidated(j).mean_mean_event_amplitude_norm_by_first_baseline = consolidated(j).mean_mean_event_amplitude /consolidated(1).mean_mean_event_amplitude
        consolidated(j).mean_mean_event_area_norm_by_first_baseline = consolidated(j).mean_mean_event_area /consolidated(1).mean_mean_event_area
        consolidated(j).overlap_index_pre_norm_by_first_baseline = consolidated(j).overlap_index_pre /consolidated(1).overlap_index_pre
        consolidated(j).overlap_index_post_norm_by_first_baseline = consolidated(j).overlap_index_pre /consolidated(1).overlap_index_post
        consolidated(j).num_clusts_norm_by_FOV_squm_pre_norm_by_first_baseline = consolidated(j).num_clusts_norm_by_FOV_squm_pre/ consolidated(1).num_clusts_norm_by_FOV_squm_pre
        consolidated(j).avg_nodes_per_module_pre_norm_by_first_baseline = consolidated(j).avg_nodes_per_module_pre/ consolidated(1).avg_nodes_per_module_pre
        consolidated(j).avg_area_per_module_pre_norm_by_first_baseline = consolidated(j).avg_area_per_module_pre /consolidated(1).avg_area_per_module_pre
        consolidated(j).avg_dens_per_module_pre_norm_by_first_baseline = consolidated(j).avg_dens_per_module_pre/ consolidated(1).avg_dens_per_module_pre
        consolidated(j).nothing_per_min_norm_by_first_baseline = consolidated(j).nothing_per_min/ consolidated(1).nothing_per_min
        consolidated(j).artifacts_per_min_norm_by_first_baseline = consolidated(j).artifacts_per_min/ consolidated(1).artifacts_per_min
        consolidated(j).SW_per_min_norm_by_first_baseline = consolidated(j).SW_per_min / consolidated(1).SW_per_min
        consolidated(j).seizures_per_min_norm_by_first_baseline = consolidated(j).seizures_per_min/ consolidated(1).seizures_per_min
        consolidated(j).int_spikes_per_min_norm_by_first_baseline = consolidated(j).int_spikes_per_min/ consolidated(1).int_spikes_per_min
        consolidated(j).others_per_min_norm_by_first_baseline = consolidated(j).others_per_min / consolidated(1).others_per_min
        consolidated(j).ict_high_perc_others_norm_by_first_baseline = consolidated(j).ict_high_perc_others/ consolidated(1).ict_high_perc_others
        consolidated(j).ict_high_perc_seizures_norm_by_first_baseline = consolidated(j).ict_high_perc_seizures /consolidated(1).ict_high_perc_seizures
        consolidated(j).ict_high_perc_SWs_norm_by_first_baseline =  consolidated(j).ict_high_perc_SWs / consolidated(1).ict_high_perc_SWs
        consolidated(j).ict_high_perc_int_spikes_norm_by_first_baseline = consolidated(j).ict_high_perc_int_spikes/ consolidated(1).ict_high_perc_int_spikes
        consolidated(j).ict_low_perc_others_norm_by_first_baseline = consolidated(j).ict_low_perc_others/ consolidated(1).ict_low_perc_others
        consolidated(j).ict_low_perc_seizures_norm_by_first_baseline  = consolidated(j).ict_low_perc_seizures/ consolidated(1).ict_low_perc_seizures
        consolidated(j).ict_low_perc_SWs_norm_by_first_baseline =  consolidated(j).ict_low_perc_SWs / consolidated(1).ict_low_perc_SWs
        consolidated(j).ict_low_perc_int_spikes_norm_by_first_baseline = consolidated(j).ict_low_perc_int_spikes/ consolidated(1).ict_low_perc_int_spikes
    end
    
end








%
%
%
%
% for j = 1:size(curr_summary,2)
%     msph = curr_summary(j).ms_per_hr;
%     mi =size(curr_summary(j).microseiz,2); %  curr_summary(j).num_ms;
%     %                     if mi == 0
%     %                         t=0;
%     %                         %curr_summary(j).tot_dur_s = t;
%     %                         t = curr_summary(j).tot_dur_s;
%     %                     else
%     %                         t = mi*3600/msph;
%     %                         %curr_summary(j).tot_dur_s = t;
%     %                         t = curr_summary(j).tot_dur_s;
%     %                     end
%
%     t = curr_summary(j).tot_dur_min*60;
%
%     if isempty(curr_summary(j).tot_dur_min)
%         curr_summary(j).tot_dur_min = 0;
%     end
%
%     %     if isempty(curr_summary(j).perc_time_in_microsz)
%     %         curr_summary(j).perc_time_in_microsz = 0;
%     %     end
%
%     %curr_summary(j).tot_ms_dur_s = t*curr_summary(j).perc_time_in_microsz/100;
%
%     dt(1,j) = curr_summary(j).days_of_TeT;
%
%     if j>1
%         if dt(1,j) == dt(1,j-1)
%             curr_num=curr_num+1;
%             curr_summary(1).consolidated(a).days_of_TeT = curr_summary(j).days_of_TeT;
%             curr_summary(1).consolidated(a).num_ms = curr_summary(1).consolidated(a).num_ms + mi;
%             curr_summary(1).consolidated(a).tot_dur_s = curr_summary(1).consolidated(a).tot_dur_s + t;
%             curr_summary(1).consolidated(a).tot_ms_dur_s = curr_summary(1).consolidated(a).tot_ms_dur_s + t*curr_summary(j).perc_time_in_microsz/100;
%
%             if j == size(curr_summary,2)
%                 curr_summary(1).consolidated(a).perc_time_in_microsz = 100*curr_summary(1).consolidated(a).tot_ms_dur_s/curr_summary(1).consolidated(a).tot_dur_s;
%
%                 if isempty(curr_summary(1).consolidated(a).perc_time_in_microsz)
%                     curr_summary(1).consolidated(a).ms_per_hr = 0;
%                 else
%                     curr_summary(1).consolidated(a).ms_per_hr = 3600*curr_summary(1).consolidated(a).num_ms/curr_summary(1).consolidated(a).tot_dur_s;
%                 end
%             end
%
%         else
%             a=a+1;
%             curr_summary(1).consolidated(a).days_of_TeT = curr_summary(j).days_of_TeT;
%             curr_summary(1).consolidated(a).num_ms = mi;
%             curr_summary(1).consolidated(a).tot_dur_s = t;
%             curr_summary(1).consolidated(a).tot_ms_dur_s = t*curr_summary(j).perc_time_in_microsz/100;
%             curr_summary(1).consolidated(a-1).perc_time_in_microsz = 100*curr_summary(1).consolidated(a-1).tot_ms_dur_s/curr_summary(1).consolidated(a-1).tot_dur_s;
%
%             if isempty(curr_summary(1).consolidated(a-1).perc_time_in_microsz)
%                 curr_summary(1).consolidated(a-1).ms_per_hr = 0;
%             else
%                 curr_summary(1).consolidated(a-1).ms_per_hr = 3600*curr_summary(1).consolidated(a-1).num_ms/curr_summary(1).consolidated(a-1).tot_dur_s;
%             end
%
%             curr_num=1;
%
%             if j == size(curr_summary,2)
%                 curr_summary(1).consolidated(a).perc_time_in_microsz = curr_summary(j).perc_time_in_microsz;
%                 if isempty(curr_summary(1).consolidated(a).perc_time_in_microsz)
%                     curr_summary(1).consolidated(a).ms_per_hr = 0;
%                 else
%                     curr_summary(1).consolidated(a).ms_per_hr = curr_summary(j).ms_per_hr;
%                 end
%             end
%
%         end
%     else
%         curr_num = 1;
%         curr_summary(1).consolidated(a).days_of_TeT = curr_summary(j).days_of_TeT;
%         curr_summary(1).consolidated(a).tot_dur_s = t;
%         curr_summary(1).consolidated(a).tot_ms_dur_s = t*curr_summary(j).perc_time_in_microsz/100;
%         curr_summary(1).consolidated(a).num_ms = mi; %curr_summary(j).num_ms;
%     end
%
% end
%
%
%
%
% animal(i).lowdose.L23.microseiz_summary = curr_summary;


