
function [onep_results_2] = rerun_ROI_sel_manualey (freq, onep,rec, Folder, Folder_master, initial2, save_normcorred_tiff, save_initial1_g_tiff, initial1,...
    split_first_df_second,use_roigui,EEG_results_nonoise,DF_mouse_EEG_video,downsample_DF_movie_to_orig_Hz,foldername,initial,cmap,start_t,end_t,or2,maxfac,cat_signal_nans_to_zeros)


%re-load the h5 file into RAM
%onep_results_2

%rec=1

%Folder = subfolders(rec).name;
cd(Folder_master)
%cd(Folder)


if onep
else
    foldername = strcat(Folder_master,Folder,'\motion_corrected\ch2'); % 'F:\stargazer\stg-N1131\11-20-18\';
    
    % folder where all the files are located.
    filetype = 'h5'; % type of files to be processed
    % Types currently supported .tif/.tiff, .h5/.hdf5, .raw, .avi, and .mat files
    files = subdir(fullfile(foldername,['*nr.',filetype]));   % list of filenames (will search all subdirectories)
    FOV = size(read_file(files(1).name,1,1));
    numFiles = length(files);
    
    if motion_correct
        registered_files = subdir(fullfile(foldername,['*',append,'.',output_type]));  % list of registered files (modify this to list all the motion corrected files you need to process)
    else
        registered_files = subdir(fullfile(foldername,'*_mc.h5'));
    end
    
    fr = initial2.samplingratehz;                                         % frame rate
    tsub = 1;                                        % degree of downsampling (for 30Hz imaging rate you can try also larger, e.g. 8-10)
    %ds_filename = [foldername,'\ds_data.mat'];
    data_type = class(read_file(registered_files(1).name,1,1));
    %data = matfile(ds_filename,'Writable',true);
    %data.Y  = zeros([FOV,0],data_type);
    %data.Yr = zeros([prod(FOV),0],data_type);
    %data.sizY = [FOV,0];
    F_dark = Inf;                                    % dark fluorescence (min of all data)
    batch_size = 2000;                               % read chunks of that size
    batch_size = round(batch_size/tsub)*tsub;        % make sure batch_size is divisble by tsub
    Ts = zeros(numFiles,1);                          % store length of each file
    cnt = 0;                                         % number of frames processed so far
    tt1 = tic;
    
    for i = 1:numFiles
        name = registered_files(i).name;
        info = h5info(name);
        dims = info.Datasets.Dataspace.Size;
        ndimsY = length(dims);                       % number of dimensions (data array might be already reshaped)
        Ts(i) = dims(end);
        Ysub = zeros(FOV(1),FOV(2),floor(Ts(i)/tsub),data_type);
        %data.Y(FOV(1),FOV(2),sum(floor(Ts/tsub))) = zeros(1,data_type);
        %data.Yr(prod(FOV),sum(floor(Ts/tsub))) = zeros(1,data_type);
        cnt_sub = 0;
        for t = 1:batch_size:Ts(i)
            Y = read_file(name,t,min(batch_size,Ts(i)-t+1));
            F_dark = min(nanmin(Y(:)),F_dark);
            ln = size(Y,ndimsY);
            Y = reshape(Y,[FOV,ln]);
            Y = cast(downsample_data(Y,'time',tsub),data_type);
            ln = size(Y,3);
            Ysub(:,:,cnt_sub+1:cnt_sub+ln) = Y;
            cnt_sub = cnt_sub + ln;
        end
        %data.Y(:,:,cnt+1:cnt+cnt_sub) = Ysub;
        %data.Yr(:,cnt+1:cnt+cnt_sub) = reshape(Ysub,[],cnt_sub);
        toc(tt1);
        cnt = cnt + cnt_sub;
        %data.sizY(1,3) = cnt;
    end
    data.F_dark = F_dark;
    %Ysub = 0;
    %Y = 0;
end
%  save workspace_all_recordings.mat -v7.3


%save as tiff file
%
% t = Tiff(['normcorred' '.tif' ],'w8');
% tagstruct.ImageLength = size(fl,1);
% tagstruct.ImageWidth = size(fl,2);
% tagstruct.Photometric = Tiff.Photometric.MinIsBlack;
% tagstruct.BitsPerSample = 16;
% tagstruct.SamplesPerPixel = 1;
% tagstruct.PlanarConfiguration = Tiff.PlanarConfiguration.Chunky;
% tagstruct.Software = 'MATLAB';
% tagstruct.SampleFormat = Tiff.SampleFormat.Int;
% t.setTag(tagstruct);
% t.write(int16(fl(:,:,1)));
% t.close();
%
% for i = 2:size(fl,3)
%     writing_tiff_g = i
%     %t = Tiff(['motion_corrected_ch2.tif'],'a');
%     t = Tiff(['normcorred' '.tif'],'a');
%     tagstruct.ImageLength = size(fl,1);
%     tagstruct.ImageWidth = size(fl,2);
%     tagstruct.Photometric = Tiff.Photometric.MinIsBlack;
%     tagstruct.BitsPerSample = 16;
%     tagstruct.SamplesPerPixel = 1;
%     tagstruct.PlanarConfiguration = Tiff.PlanarConfiguration.Chunky;
%     tagstruct.Software = 'MATLAB';
%     tagstruct.SampleFormat = Tiff.SampleFormat.Int;
%     t.setTag(tagstruct);
%     t.write(int16(fl(:,:,i)));
%     t.close();
% end

%OR

if save_normcorred_tiff
    
    t = Tiff(['normcorred' '.tif' ],'w8');
    tagstruct.ImageLength = size(Ysub,1);
    tagstruct.ImageWidth = size(Ysub,2);
    tagstruct.Photometric = Tiff.Photometric.MinIsBlack;
    tagstruct.BitsPerSample = 16;
    tagstruct.SamplesPerPixel = 1;
    tagstruct.PlanarConfiguration = Tiff.PlanarConfiguration.Chunky;
    tagstruct.Software = 'MATLAB';
    tagstruct.SampleFormat = Tiff.SampleFormat.Int;
    t.setTag(tagstruct);
    t.write(int16(Ysub(:,:,1)));
    t.close();
    
    for i = 2:size(Ysub,3)
        writing_tiff_g = i
        %t = Tiff(['motion_corrected_ch2.tif'],'a');
        t = Tiff(['normcorred' '.tif'],'a');
        tagstruct.ImageLength = size(Ysub,1);
        tagstruct.ImageWidth = size(Ysub,2);
        tagstruct.Photometric = Tiff.Photometric.MinIsBlack;
        tagstruct.BitsPerSample = 16;
        tagstruct.SamplesPerPixel = 1;
        tagstruct.PlanarConfiguration = Tiff.PlanarConfiguration.Chunky;
        tagstruct.Software = 'MATLAB';
        tagstruct.SampleFormat = Tiff.SampleFormat.Int;
        t.setTag(tagstruct);
        t.write(int16(Ysub(:,:,i)));
        t.close();
    end
    
end
%%%%%%%%%%%%%%%%%OR, if normcorre is not working (which it may not when
%%%%%%%%%%%%%%%%%there is an SD for example
if save_initial1_g_tiff
    
    t = Tiff(['normcorred' '.tif' ],'w8');
    tagstruct.ImageLength = size(initial1.g,1);
    tagstruct.ImageWidth = size(initial1.g,2);
    tagstruct.Photometric = Tiff.Photometric.MinIsBlack;
    tagstruct.BitsPerSample = 16;
    tagstruct.SamplesPerPixel = 1;
    tagstruct.PlanarConfiguration = Tiff.PlanarConfiguration.Chunky;
    tagstruct.Software = 'MATLAB';
    tagstruct.SampleFormat = Tiff.SampleFormat.Int;
    t.setTag(tagstruct);
    t.write(int16(initial1.g(:,:,1)));
    t.close();
    
    for i = 2:size(initial1.g,3)
        writing_tiff_g = i
        %t = Tiff(['motion_corrected_ch2.tif'],'a');
        t = Tiff(['normcorred' '.tif'],'a');
        tagstruct.ImageLength = size(initial1.g,1);
        tagstruct.ImageWidth = size(initial1.g,2);
        tagstruct.Photometric = Tiff.Photometric.MinIsBlack;
        tagstruct.BitsPerSample = 16;
        tagstruct.SamplesPerPixel = 1;
        tagstruct.PlanarConfiguration = Tiff.PlanarConfiguration.Chunky;
        tagstruct.Software = 'MATLAB';
        tagstruct.SampleFormat = Tiff.SampleFormat.Int;
        t.setTag(tagstruct);
        t.write(int16(initial1.g(:,:,i)));
        t.close();
    end
    
end


%%%%%%%%%%%%%%%%split into equal sized ROIs
if split_first_df_second
    iw = initial.width;
    il = initial.height;
    
    %initial.microns_per_pixel = 14;
    
    square_side_um = 500
    
    square_side_px = round(square_side_um/initial2.microns_per_pixel);
    
    hor_sq = (iw - mod(iw,square_side_px))/square_side_px;
    if mod(iw,square_side_px)
        last_column_width = mod(iw,square_side_px);
    else
        last_column_width = 0;
    end
    
    vert_sq = (il - mod(il,square_side_px))/square_side_px;
    if mod(il,square_side_px)
        
        last_row_width = mod(il,square_side_px);
    else
        last_row_width = 0;
    end
    
    if last_column_width
        cols = hor_sq+1;
    else
        cols = hor_sq;
    end
    
    if last_row_width
        rows = vert_sq+1;
    else
        rows = vert_sq;
    end
    
    endframe = cols*rows;
    
    
    if or2.cat_signal == 0
        
        clear cat_signal
        frames = size(fl,3);
        ssp = square_side_px;
        a=1;
        b=1;
        currcol = 1;
        currrow = 1;
        cat_signal = zeros(rows*cols,frames);
        for i = 1:rows
            curr_row = i
            for j = 1:cols
                curr_col = j
                
                if curr_col == cols
                    curr_x = [(j-1)*ssp+1:1:(j-1)*ssp+last_column_width];
                else
                    curr_x = [(j-1)*ssp+1:1:j*ssp];
                end
                
                if curr_row == rows
                    curr_y = [(i-1)*ssp+1:1:(i-1)*ssp+last_row_width];
                else
                    curr_y = [(i-1)*ssp+1:1:i*ssp];
                end
                
                for k = 1:frames
                    
                    cat_signal(a,k) = mean(mean(initial1.g(curr_y,curr_x,k)));
                    
                end
                
                a=a+1;
                
                
            end
        end
        
    else
        cat_signal = or2.cat_signal
    end
    
    a=1;
    currcol = 1;
    currrow = 1;
    
    for i = 1:rows
        %curr_row = i
        for j = 1:cols
            %curr_col = j
            if curr_col == cols
                curr_x = [(j-1)*ssp+1:1:(j-1)*ssp+last_column_width];
            else
                curr_x = [(j-1)*ssp+1:1:j*ssp];
            end
            if curr_row == rows
                curr_y = [(i-1)*ssp+1:1:(i-1)*ssp+last_row_width];
            else
                curr_y = [(i-1)*ssp+1:1:i*ssp];
            end
            
            RL.ROI_info(a,1) = length(curr_x)*length(curr_y);
            RL.ROI_info(a,2) = mean(cat_signal(a,:));
            RL.ROI_info(a,3:4) = [mean(curr_y) mean(curr_x)];
            
            a=a+1
        end
    end
    
    %OR
    if use_roigui
        roigui(Ysub,[],[1,1],99)
    end
    
    %$$$$$$$$$$$$$$$$$$$$
    RL = ROI_list
    %RL.cat_signal = RL.%cat_signal';
    already_unified_cat_signal_present = 0
    baseline_tconst_ms = 40000;
    if strcmp(initial.indicator,'iGluSnfr')
        baseline_tconst_ms = 300000;
    end
    %%%%
    
    [deltaf_matrix,results] = calciumsignalcalculator_matlab(initial,Folder,xml_file,RL,...
        baseline_tconst_ms,already_unified_cat_signal_present,initial2,onep);
    
    
    
    close all
    butterfilt = 0.32;
    maxcount = 5000; %maximum yaksi-friedrich iteration #
    tbin = initial2.msperline/1000;
    tau = 1;
    thrup = 0.5;  %estimated noise level in %DF/F
    apm = zeros(1,size(results.cat_signal,2));
    [DeconvMat5000,FiltMat5000,FiltMat2_5000,deconv_adaptive] = CaDeconvStandAlone(apm,...
        initial,results,tau,thrup,0,2,0,maxcount,tbin,butterfilt,baseline_tconst_ms,initial2);
    
    %%%%%%% denoise DF/F traces
    std_level = 1;
    [deconv_no_noise,activity_per_min_deconv,deltaf_no_noise,activity_per_min_deltaf,noisedata] = ...
        denoise(initial,FiltMat2_5000,FiltMat2_5000,std_level,initial2);
    
    %re-run smoothing
    [DeconvMat5000,FiltMat5000,FiltMat2_5000,deconv_adaptive] = CaDeconvStandAlone(activity_per_min_deltaf,...
        initial,results,tau,thrup,0,0,1,maxcount,tbin,butterfilt,baseline_tconst_ms,initial2);
    
    %re-run denoising
    close all
    deconv_matrix = DeconvMat5000;
    deltaf_sd = 1;
    deconv_sd = 1;
    [deconv_no_noise,activity_per_min_deconv,deltaf_no_noise,activity_per_min_deltaf,noisedata] = ...
        deconvolution_Bernhard(initial,deconv_matrix,FiltMat2_5000,deconv_sd,deltaf_sd,initial2);
    %
    %optional: plotting all traces
    sf = 0
    %close all
    
    sny = [];
    snn = [];
    sig_v_noise = plot_DF_oopsi_Sang(FiltMat2_5000,deltaf_no_noise,DeconvMat5000,...
        deconv_no_noise,noisedata,Folder,sf,initial2,activity_per_min_deltaf,sny,snn,0,0.1,0);
    
    matrix=FiltMat2_5000;
    close all
    [laz_thr,filtmat_red,deconv_red,lazy_ROIs] = det_thr(noisedata, matrix,deltaf_no_noise, deconv_no_noise);
    
    
    
    recording_man_ROIs(iii).C_dec = filtmat_red';
    recording_man_ROIs(iii).S_dec = deconv_red';
    recording_man_ROIs(iii).F_dff = FiltMat2_5000';
    recording_man_ROIs(iii).F0 = FiltMat2_5000';
    recording_man_ROIs(iii).C_full = filtmat_red';
    recording_man_ROIs(iii).R_full = filtmat_red';
    recording_man_ROIs(iii).F_full = filtmat_red';
    recording_man_ROIs(iii).A_keep = [];
    recording_man_ROIs(iii).options = [];
    recording_man_ROIs(iii).Coor = RL;
    recording_man_ROIs(iii).Cn = [];
    recording_man_ROIs(iii).options_mc = [];
    recording_man_ROIs(iii).template = [];
    recording_man_ROIs(iii).results.cat_signal = results.cat_signal;
    
end

%%%%%%%%%%%%%%%%%%%%%% OR, if already made a DF_interp movie, and to align
%%%%%%%%%%%%%%%%%%%%%% squares with teh middle (i.e. cortical midline) of the image

if DF_mouse_EEG_video.DF_interp == 0
else
    
    if downsample_DF_movie_to_orig_Hz
        %if you want to downsample the DF-movie to its original sampling rate
        fr = 1000/DF_mouse_EEG_video.pco_msperline;
        
        DF_mat = uint16(zeros(size(DF_mouse_EEG_video.DF_interp,1),size(DF_mouse_EEG_video.DF_interp,2),round(length(DF_mouse_EEG_video.DF_interp)/(freq/fr))));
        
        for i = 1: size(DF_mat,3)
            extrapolating_DF_mat = i
            DF_mat(:,:,i) = DF_mouse_EEG_video.DF_interp(:,:,round((i-1)*fr/freq)+1)/maxfac(1,i);
            
        end
        
        iw = initial.width;
        il = initial.height;
        
        middle_x = round(iw/2);
        
        %initial2.microns_per_pixel = 14;
        
        square_side_um = 500
        
        square_side_px = round(square_side_um/initial2.microns_per_pixel);
        
        hor_sq = (iw - mod(iw,square_side_px))/square_side_px;
        
        if mod(hor_sq,2)
            hor_sq = hor_sq-1;
        end
        
        x_shift = round(middle_x-square_side_px*(hor_sq/2));
        
        
        
        %
        % if mod(iw,square_side_px)
        % last_column_width = mod(iw,square_side_px);
        % else
        %     last_column_width = 0;
        % end
        
        vert_sq = (il - mod(il,square_side_px))/square_side_px;
        
        
        if mod(il,square_side_px)
            
            last_row_width = mod(il,square_side_px);
        else
            last_row_width = 0;
        end
        
        cols = hor_sq;
        
        % if last_column_width
        %     cols = hor_sq+1;
        % else
        %     cols = hor_sq;
        % end
        
        if last_row_width
            rows = vert_sq+1;
        else
            rows = vert_sq;
        end
        
        endframe = cols*rows;
        
        
        if or2.cat_signal == 0
            
            clear cat_signal
            frames = size(DF_mat,3);
            ssp = square_side_px;
            a=1;
            b=1;
            currcol = 1;
            currrow = 1;
            cat_signal = zeros(rows*cols,frames);
            for i = 1:rows
                curr_row = i
                for j = 1:cols
                    curr_col = j
                    %
                    %         if curr_col == cols
                    %         curr_x = [(j-1)*ssp+1:1:(j-1)*ssp+last_column_width];
                    %         else
                    curr_x = [(j-1)*ssp+1+x_shift:1:j*ssp+x_shift];
                    %         end
                    
                    if curr_row == rows
                        curr_y = [(i-1)*ssp+1:1:(i-1)*ssp+last_row_width];
                    else
                        curr_y = [(i-1)*ssp+1:1:i*ssp];
                    end
                    
                    %here: ignore "zero pixels"...
                    
                    
                    for k = 1:frames
                        rf = squeeze(DF_mat(curr_y,curr_x,k));
                        rf=reshape(rf,[length(curr_x)*length(curr_y)],1);
                        [op, po] = find(rf);
                        rff = rf(po,1)
                        cat_signal(a,k) = mean(rff);
                        
                    end
                    
                    a=a+1;
                    
                    
                end
            end
            
        else
            cat_signal = or2.cat_signal;
        end
        
        
        
        
        %%%%%%%%%%%%%% otherwise run the following code
        
        
        
    else
        
        
        if maxfac==0
            maxfac = 15000/mean(max(max(DF_mouse_EEG_video.DF_interp)));
        end
        
        iw = size(DF_mouse_EEG_video.DF_interp,2); %initial.width;
        il = size(DF_mouse_EEG_video.DF_interp,1); %initial.height;
        
        middle_x = round(iw/2);
        
        %initial2.microns_per_pixel = 14;
        
        square_side_um = 500
        
        square_side_px = round(square_side_um/initial2.microns_per_pixel);
        
        hor_sq = (iw - mod(iw,square_side_px))/square_side_px;
        
        %         if mod(hor_sq,2)
        %             hor_sq = hor_sq-1
        %         end
        
        x_shift = round(middle_x-square_side_px*(hor_sq/2));
        
        
        
        %
        % if mod(iw,square_side_px)
        % last_column_width = mod(iw,square_side_px);
        % else
        %     last_column_width = 0;
        % end
        
        vert_sq = (il - mod(il,square_side_px))/square_side_px;
        
        
        if mod(il,square_side_px)
            
            last_row_width = mod(il,square_side_px);
        else
            last_row_width = 0;
        end
        
        cols = hor_sq;
        
        % if last_column_width
        %     cols = hor_sq+1;
        % else
        %     cols = hor_sq;
        % end
        
        if last_row_width
            rows = vert_sq+1;
        else
            rows = vert_sq;
        end
        
        endframe = cols*rows;
        
        if or2.cat_signal == 0
            clear cat_signal RL
            frames = size(DF_mouse_EEG_video.DF_interp,3);
            ssp = square_side_px;
            a=1;
            b=1;
            aa=1;
            currcol = 1;
            currrow = 1;
            cat_signal = double(zeros(rows*cols,frames));
            for i = 1:rows
                curr_row = i
                for j = 1:cols
                    curr_col = j
                    %
                    %         if curr_col == cols
                    %         curr_x = [(j-1)*ssp+1:1:(j-1)*ssp+last_column_width];
                    %         else
                    curr_x = [(j-1)*ssp+1+x_shift:1:j*ssp+x_shift];
                    %         end
                    
                    if i==1
                        x_grid_ticks(1,j) = (j-1)*ssp+1+x_shift;
                        if j == cols
                            x_grid_ticks(1,j+1) = j*ssp+x_shift;
                        end
                    end
                    
                    if curr_row == rows
                        if last_row_width==0
                            curr_y = [(i-1)*ssp+1:1:i*ssp];
                        else
                            curr_y = [(i-1)*ssp+1:1:(i-1)*ssp+last_row_width];
                        end
                    else
                        curr_y = [(i-1)*ssp+1:1:i*ssp];
                    end
                    
                    
                    if j ==1
                        y_grid_ticks(1,i) = (i-1)*ssp+1;
                        if i == rows
                            if last_row_width==0
                                %y_grid_ticks(1,i+1) = i*ssp;
                            else
                                y_grid_ticks(1,i+1) = (i-1)*ssp+1+last_row_width;
                            end
                        end
                    end
                    
                    
                    % interpolate maxfac!
                    %added 20230227: or extrapolate!
                    
                    msperline = initial2.msperline;
                     num_frames = size(maxfac,2);
                    if msperline>10
                       
                        
                        maxfac_interp  = uint16(zeros(1,ceil(num_frames*msperline/1000*freq)));
                        
                        j2 = 1;
                        i2 = 1;
                        while i2 <= length(maxfac_interp)-10 %&& j<688
                            if (j2*msperline/1000 > i2/freq-1/(2*freq)) && (j2*msperline/1000 <= (i2+1)/freq)...
                                    && sum(sum(maxfac_interp(1,i2))) == 0 %&& deltaf_interp(i-1,k) == 0
                                if j2*msperline/1000-i2/freq <= (i2+1)/freq - j2*msperline/1000
                                    maxfac_interp(1,i2) = maxfac(1,j2);
                                else
                                    maxfac_interp(1,i2+1) = maxfac(1,j2);
                                end
                                j2=j2+1;
                            end
                            i2=i2+1;
                        end
                        
                        i2 = 1;
                        aba = 1;
                        while i2 <= length(maxfac_interp)-1
                            if sum(sum(maxfac_interp(1,i2))) > 0
                                aba = i2;
                            else
                                maxfac_interp(1,i2) = maxfac_interp(1,aba);
                            end
                            i2=i2+1;
                        end
                        
                        
                    else
                        
                        %might need to check again to make sure this is
                        %supposed to remain the original frame rate, not
                        %resampled to 100Hz
                        
                        maxfac_interp = maxfac;
                        
                        
%                         fr = 1000/msperline;
%                         
%                         maxfac_interp  = double(zeros(1,ceil(num_frames*(freq/fr))));
%                         
%                         
%                         for i = 1: size(maxfac_interp,2)
%                             pf=round((i-1)*fr/freq)+1;
%                             extrapolating_DF_mat = pf
%                             maxfac_interp(1,i) = maxfac(1,pf);
%                             
%                         end
                        
                        
                        
                    end
                    
                    for k = 1:frames
                        %cat_framing = k
                        if max(curr_y)<size(DF_mouse_EEG_video.DF_interp,1)+1 && max(curr_x)<size(DF_mouse_EEG_video.DF_interp,2)+1
                            fert = double(DF_mouse_EEG_video.DF_interp(curr_y,curr_x,k));
                            
                            fert=squeeze(fert);
                            fert=reshape(fert,[length(curr_x)*length(curr_y)],1);
                            [op, po] = find(fert);
                            rff = fert(po,1);
                            cat_signal(a,k) = mean(rff/double(maxfac_interp(1,k)));
                            
                            % cat_signal(a,k) = mean(mean(fert/double(maxfac_interp(1,k))));
                            if k == 1
                                if cat_signal(a,k) == 0 || isnan(cat_signal(a,k))
                                    cat_signal(a,k) = 0;
                                end
                            else
                                if k>1
                                    
                                    if cat_signal(a,k) == 0 || isnan(cat_signal(a,k))
                                        if cat_signal_nans_to_zeros
                                            cat_signal(a,k) = 0;
                                        else
                                            cat_signal(a,k) = cat_signal(a,k-1);
                                        end
                                    end
                                end
                            end
                        end
                    end
                    
                    
                    RL.ROI_info(aa,1) = length(curr_x)*length(curr_y);
                    RL.ROI_info(aa,2) = mean(cat_signal(aa,:));
                    RL.ROI_info(aa,3:4) = [mean(curr_y) mean(curr_x)];
                    
                    aa=aa+1
                    
                    
                    %                     %incorporate this above!!
                    %                     for k = 1:frames
                    %                         rf = squeeze(DF_mat(curr_y,curr_x,k));
                    %                         rf=reshape(rf,[length(curr_x)*length(curr_y)],1);
                    %                         [op, po] = find(rf);
                    %                         rff = rf(po,1)
                    %                         cat_signal(a,k) = mean(rff);
                    %
                    %                     end
                    
                    
                    a=a+1;
                    
                end
            end
            
        else
            cat_signal = or2.cat_signal;
        end
        
        numxtics = length(x_grid_ticks);
        numytics = length(y_grid_ticks);
        stepsize = square_side_um/1000;
        
        ped = mean(DF_mouse_EEG_video.DF_interp(:,:,1:1000),3);
        minp = min(min(ped));
        maxp = max(max(ped));
        rmm = maxp/mean(maxfac);
        rim = minp/mean(maxfac);
        tick4 = num2str(round(100*rmm));
        tick1 = num2str(round(100*rim));
        tick2 = round(100*(rim + (rmm - rim)/3));
        tick3 = round(100*(rmm - (rmm - rim)/3));
        pod=rot90(ped,2);
        fig = figure('position',[100 100 700 500],'Color','k');
        imagesc(pod,[minp maxp])
        colormap(cmap)
        ax=gca;
        ax.XTick = x_grid_ticks;
        ax.XTickLabel = [-((numxtics-1)*stepsize/2):stepsize:(numxtics-1)*stepsize/2];
        ax.YTickLabel = fliplr([0:stepsize:numytics*stepsize]);
        ax.YTick = y_grid_ticks;
        ax.FontSize = 13;
        grid on
        ax.GridColor = 'w';
        ax.GridAlpha = 1;
        ax.XColor ='white';
        ax.YColor ='white';
        c = colorbar('Ticks',[0, round(mean(maxfac)/3),round(2*mean(maxfac)/3),round(mean(maxfac))],...
            'TickLabels',{tick1,tick2,tick3,tick4});
        c.Label.String = 'Ca (% DF/F)';
        c.FontSize = 14;
        c.Color = 'w';
        saveas(fig,['reference_frame_w_grid_' num2str(square_side_um) '_um_squares.emf'],'emf')
        
        
        
        
        %
        %         iw = initial.width;
        %         il = initial.height;
        %
        %         initial.microns_per_pixel = 14;
        %
        %         square_side_um = 500
        %
        %         square_side_px = round(square_side_um/initial2.microns_per_pixel);
        %
        %         hor_sq = (iw - mod(iw,square_side_px))/square_side_px;
        %         if mod(iw,square_side_px)
        %             last_column_width = mod(iw,square_side_px);
        %         else
        %             last_column_width = 0;
        %         end
        %
        %         vert_sq = (il - mod(il,square_side_px))/square_side_px;
        %         if mod(il,square_side_px)
        %
        %             last_row_width = mod(il,square_side_px);
        %         else
        %             last_row_width = 0;
        %         end
        %
        %         if last_column_width
        %             cols = hor_sq+1;
        %         else
        %             cols = hor_sq;
        %         end
        %
        %         if last_row_width
        %             rows = vert_sq+1;
        %         else
        %             rows = vert_sq;
        %         end
        %
        %         endframe = cols*rows
        %
        
        %
        %         a=1;
        %         currcol = 1;
        %         currrow = 1;
        %         clear RL
        %         for i = 1:rows
        %             %curr_row = i
        %             for j = 1:cols
        %                 %curr_col = j
        %                 if curr_col == cols
        %                     curr_x = [(j-1)*ssp+1:1:j*ssp];
        %                     %curr_x = [(j-1)*ssp+1:1:(j-1)*ssp+last_column_width];
        %                 else
        %                     curr_x = [(j-1)*ssp+1:1:j*ssp];
        %                 end
        %
        %                 if curr_row == rows
        %                     curr_y = [(i-1)*ssp+1:1:(i-1)*ssp+last_row_width];
        %                 else
        %                     curr_y = [(i-1)*ssp+1:1:i*ssp];
        %                 end
        %
        %                 RL.ROI_info(a,1) = length(curr_x)*length(curr_y);
        %                 RL.ROI_info(a,2) = mean(cat_signal(a,:));
        %                 RL.ROI_info(a,3:4) = [mean(curr_y) mean(curr_x)];
        %
        %                 a=a+1
        %             end
        %         end
        %
        
        
        
        %sort cat_signal into hemisphere and also remove squares that were too dark
        
        
        a=1;
        b=1;
        max_sq_mean = max(RL.ROI_info(:,2));
        thr = 0.05*max_sq_mean;
        clear DF_sq_right DF_sq_left
        for i = 1:size(RL.ROI_info,1)
            sorting_cat_signal = i
            if RL.ROI_info(i,4) < middle_x+x_shift
                
                if RL.ROI_info(i,2) > thr
                    
                    accep_ROI_LH(1,a) = i;
                    
                    DF_sq_right(:,a) = cat_signal(i,:)';
                    
                    a = a+1;
                end
            else
                if RL.ROI_info(i,2) > thr
                    
                    accep_ROI_RH(1,b) = i;
                    
                    DF_sq_left(:,b) = cat_signal(i,:)';
                    
                    b = b+1;
                end
                
            end
        end
        
        onep_results_2.DF_sq_right = DF_sq_right;
        onep_results_2.DF_sq_left = DF_sq_left;
        onep_results_2.accep_ROI_LH = accep_ROI_LH;
        onep_results_2.accep_ROI_RH = accep_ROI_RH;
        
        
        if start_t == 0 && end_t == 0
            start_t = 1;
            end_t = 20;
        end
        t = end_t-start_t;
        if t>10
            if t>100
                if t>1000
                    tick_secs = 200;
                else
                    tick_secs = 100;
                end
            else
                
                tick_secs = 10;
            end
        else
            tick_secs = 2;
        end
        
        num_ticks = (t-mod(t,tick_secs))/tick_secs;
        xticks = [0:tick_secs*freq:num_ticks*tick_secs*freq];
        xtick_labels = [0:tick_secs:num_ticks*tick_secs];
        
        dsl = DF_sq_left(start_t*freq:end_t*freq,:);
        madsl = max(max(dsl));
        midsl = min(min(dsl));
        
        
        clims = [midsl 0.9*madsl]
        close all
        fig = figure('position',[100 100 1550 730],'Color','w');
        
        %subplot(2,2,1)
        subplot('Position',[0.04 0.1 0.43 0.45])
        imagesc(fliplr(dsl)',clims)
        colormap(cmap)
        ax = gca;
        ax.XTick = xticks;
        ax.XTickLabel = xtick_labels;
        ax.Box = 'off'
        ax.FontSize = 16
        ax.YLabel.String = 'ROI #';
        ax.YLabel.FontSize = 16;
        ax.XLabel.String = 'time (sec)';
        ax.XLabel.FontSize = 16;
        
        subplot('Position',[0.51 0.1 0.47 0.45])
        imagesc(fliplr(DF_sq_right(start_t*freq:end_t*freq,:))',clims)
        colormap(cmap)
        ax = gca;
        ax.XTick = xticks;
        ax.XTickLabel = xtick_labels;
        ax.Box = 'off';
        ax.FontSize = 16;
        ax.XLabel.String = 'time (sec)';
        ax.XLabel.FontSize = 16;
        c = colorbar;
        ctl = c.TickLabels;
        sc = size(ctl,1);
        ctt=c.Ticks;
        for i=1:sc
            c.TickLabels{i,1} = ctt(1,i)*100;
        end
        c.FontSize = 14;
        %
        %         poet=max(EEG_results_nonoise.EEG_extrap);
        %         poot=min(EEG_results_nonoise.EEG_extrap);
        %
        mxe1 = prctile(EEG_results_nonoise.EEG_extrap,99); %max(eeg_1);
        mxe2 = prctile(EEG_results_nonoise.EEG_2_extrap,99); %max(eeg_2);
        mi1 = prctile(EEG_results_nonoise.EEG_extrap,1); %min(eeg_1);
        mi2 = prctile(EEG_results_nonoise.EEG_2_extrap,1); %min(eeg_2);
        if mxe1>mxe2
            poet = mxe1*1.5;
        else
            poet = mxe2*1.5;
        end
        if mi1<mi2
            poot = mi1*0.75;
        else
            poot = mi2*0.75;
        end
        
        subplot('Position',[0.04 0.64 0.43 0.3])
        plot(EEG_results_nonoise.EEG_extrap(start_t*freq:end_t*freq,:),'k')
        axis ([0 t*freq poot poet ])
        ax = gca;
        ax.XTick = [];
        ax.YTick = [-1e-6 0 1e-6]
        ax.YTickLabel = [-1 0 1]
        ax.Box = 'off'
        ax.FontSize = 16
        ax.YLabel.String = 'EEG (mV)';
        ax.YLabel.FontSize = 16;
        ax.Title.String = 'Left';
        ax.Title.FontWeight = 'bold';
        
        %         poet=max(EEG_results_nonoise.EEG_2_extrap);
        %         poot=min(EEG_results_nonoise.EEG_2_extrap);
        %
        
        
        subplot('Position',[0.51 0.64 0.43 0.3])
        plot(EEG_results_nonoise.EEG_2_extrap(start_t*freq:end_t*freq,:),'k')
        axis ([0 t*freq poot poet ])
        ax = gca;
        ax.XTick = [];
        ax.YTick = [-1e-6 0 1e-6]
        ax.YTickLabel = [-1 0 1]
        ax.Box = 'off'
        ax.FontSize = 16
        ax.Title.String = 'Right';
        ax.Title.FontWeight = 'bold';
        
        saveas(fig,['bilateral_DF_EEGs_' num2str(start_t) '_to' num2str(end_t) '_sec.emf'],'emf')
        
    end
    
    onep_results_2.cat_signal = cat_signal;
    onep_results_2.RL = RL;
    
end


