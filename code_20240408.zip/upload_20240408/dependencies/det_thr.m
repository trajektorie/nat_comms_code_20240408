
function [laz_thr,fr,dr,lazy_ROIs] = det_thr(noisedata,mm,df,dc)

for i = 1:size(noisedata,2)
snr(i,1) = noisedata(i).SNR;
end

[vall, ind] = sort(snr,'descend');

if min(vall)>25
    lazy_ROIs = [];
    laz_thr = [];
    fr = df;
    dr = dc;
    
else

i=1;
while vall(i,1)>25
    i=i+1;
end
f_ind = i-1;

answer = 0;


while answer ==0 && i<length(ind)+1
    
    figure(ind(i,1))
    plot(mm(1:round(length(mm)/3),ind(i,1)))
    
prompt = {'this one too noisy to analyze ?'};
dlg_title = 'noise thr';
num_lines = 1;
def = {'0'};
answer = inputdlg(prompt,dlg_title,num_lines,def);
answer = str2mat(answer);
answer = str2num(answer);
    
i=i+1;
    
end

laz_thr = vall(i-1,1);

lazy_ROIs = ind(i-1:length(ind),1);

nl_ROIs = [1:1:length(ind)]';
nl_ROIs = setdiff(nl_ROIs,lazy_ROIs);

fr = df(:,nl_ROIs);
dr = dc(:,nl_ROIs);

end





