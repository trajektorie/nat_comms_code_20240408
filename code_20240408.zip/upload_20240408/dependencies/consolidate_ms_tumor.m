
% i = animal_ID;

% tumor_animal(i).barea.L4.microseiz_summary = microseiz_summary;
%
% tumor_animal(i).barea.L23.microseiz_summary = microseiz_summary;
%
% tumor_animal(i).barea.L23.microseiz_summary = microseiz_summary;



%for i = 1:size(tumor_animal,2)

% if isempty(tumor_animal(i).barea)
% else
%     if isfield(tumor_animal(i).barea,'L23')
%         if ~isstruct(tumor_animal(i).barea.L23)
%         else
msbak = ms
msu = ms %tumor_animal(i).barea.L23(L23fovnum).microseiz_summary;
a=1;
curr_num=1;
bbu=1;
clear rows_to_delete
for j = 1:size(msu,2)
    if isempty(msu(j).tot_dur_s)
        msu(j).tot_dur_s = 0;
    end
    if msu(j).tot_dur_s == 0
        rows_to_delete(1,bbu) = j;
        bbu=bbu+1;
    end
end
if bbu>1
    msu(rows_to_delete) = [];
end
for j = 1:size(msu,2)
    msph = msu(j).ms_per_hr;
    mi =size(msu(j).microseiz,2); %  msu(j).num_ms;
    %                     if mi == 0
    %                         t=0;
    %                         %msu(j).tot_dur_s = t;
    %                         t = msu(j).tot_dur_s;
    %                     else
    %                         t = mi*3600/msph;
    %                         %msu(j).tot_dur_s = t;
    %                         t = msu(j).tot_dur_s;
    %                     end
    
    t = msu(j).tot_dur_s;
    if isempty(msu(j).tot_dur_s)
        msu(j).tot_dur_s = 0;
    end
    if isempty(msu(j).perc_time_in_microsz)
        msu(j).perc_time_in_microsz = 0;
    end
    msu(j).tot_ms_dur_s = t*msu(j).perc_time_in_microsz/100;
    
    dt(1,j) = curr_summary(j).days_of_TeT;
    if j>1
        if dt(1,j) == dt(1,j-1)
            curr_num=curr_num+1;
            msu(1).consolidated(a).days_of_TeT = curr_summary(j).days_of_TeT;
            msu(1).consolidated(a).num_ms = msu(1).consolidated(a).num_ms + mi;
            msu(1).consolidated(a).tot_dur_s = msu(1).consolidated(a).tot_dur_s + t;
            msu(1).consolidated(a).tot_ms_dur_s = msu(1).consolidated(a).tot_ms_dur_s + t*msu(j).perc_time_in_microsz/100;
            if j == size(msu,2)
                msu(1).consolidated(a).perc_time_in_microsz = 100*msu(1).consolidated(a).tot_ms_dur_s/msu(1).consolidated(a).tot_dur_s;
                if isempty(msu(1).consolidated(a).perc_time_in_microsz)
                    msu(1).consolidated(a).ms_per_hr = 0;
                else
                    msu(1).consolidated(a).ms_per_hr = 3600*msu(1).consolidated(a).num_ms/msu(1).consolidated(a).tot_dur_s;
                end
            end
        else
            a=a+1;
            msu(1).consolidated(a).days_of_TeT = curr_summary(j).days_of_TeT;
            msu(1).consolidated(a).num_ms = mi;
            msu(1).consolidated(a).tot_dur_s = t;
            msu(1).consolidated(a).tot_ms_dur_s = t*msu(j).perc_time_in_microsz/100;
            msu(1).consolidated(a-1).perc_time_in_microsz = 100*msu(1).consolidated(a-1).tot_ms_dur_s/msu(1).consolidated(a-1).tot_dur_s;
            if isempty(msu(1).consolidated(a-1).perc_time_in_microsz)
                msu(1).consolidated(a-1).ms_per_hr = 0;
            else
                msu(1).consolidated(a-1).ms_per_hr = 3600*msu(1).consolidated(a-1).num_ms/msu(1).consolidated(a-1).tot_dur_s;
            end
            curr_num=1;
            if j == size(msu,2)
                msu(1).consolidated(a).perc_time_in_microsz = msu(j).perc_time_in_microsz;
                if isempty(msu(1).consolidated(a).perc_time_in_microsz)
                    msu(1).consolidated(a).ms_per_hr = 0;
                else
                    msu(1).consolidated(a).ms_per_hr = msu(j).ms_per_hr;
                end
            end
        end
    else
        curr_num = 1;
        msu(1).consolidated(a).days_of_TeT = curr_summary(j).days_of_TeT;
        msu(1).consolidated(a).tot_dur_s = t;
        msu(1).consolidated(a).tot_ms_dur_s = t*msu(j).perc_time_in_microsz/100;
        msu(1).consolidated(a).num_ms = mi; %msu(j).num_ms;
    end
    
end
ms = msu %tumor_animal(i).barea.L23(L23fovnum).microseiz_summary = msu;
%         end
%     end
%
%     if isfield(tumor_animal(i).barea,'L4')
%         if ~isstruct(tumor_animal(i).barea.L4)
%         else
%             msu = tumor_animal(i).barea.L4(L4fovnum).microseiz_summary;
%             a=1;
%             curr_num=1;
%             bbu=1;
%             clear rows_to_delete
%             for j = 1:size(msu,2)
%                 if isempty(msu(j).tot_dur_s)
%                     msu(j).tot_dur_s = 0;
%                 end
%                 if msu(j).tot_dur_s == 0
%                     rows_to_delete(1,bbu) = j;
%                     bbu=bbu+1;
%                 end
%             end
%             if bbu>1
%                 msu(rows_to_delete) = [];
%             end
%             for j = 1:size(msu,2)
%                 msph = msu(j).ms_per_hr;
%                 mi =size(msu(j).microseiz,2); %  msu(j).num_ms;
%                 %                     if mi == 0
%                 %                         t=0;
%                 %                         %msu(j).tot_dur_s = t;
%                 %                         t = msu(j).tot_dur_s;
%                 %                     else
%                 %                         t = mi*3600/msph;
%                 %                         %msu(j).tot_dur_s = t;
%                 %                         t = msu(j).tot_dur_s;
%                 %                     end
%
%                 t = msu(j).tot_dur_s;
%                 if isempty(msu(j).tot_dur_s)
%                     msu(j).tot_dur_s = 0;
%                 end
%                 if isempty(msu(j).perc_time_in_microsz)
%                     msu(j).perc_time_in_microsz = 0;
%                 end
%                 msu(j).tot_ms_dur_s = t*msu(j).perc_time_in_microsz/100;
%
%                 dt(1,j) = curr_summary(j).days_of_TeT;
%                 if j>1
%                     if dt(1,j) == dt(1,j-1)
%                         curr_num=curr_num+1;
%                         msu(1).consolidated(a).days_of_TeT = curr_summary(j).days_of_TeT;
%                         msu(1).consolidated(a).num_ms = msu(1).consolidated(a).num_ms + mi;
%                         msu(1).consolidated(a).tot_dur_s = msu(1).consolidated(a).tot_dur_s + t;
%                         msu(1).consolidated(a).tot_ms_dur_s = msu(1).consolidated(a).tot_ms_dur_s + t*msu(j).perc_time_in_microsz/100;
%                         if j == size(msu,2)
%                             msu(1).consolidated(a).perc_time_in_microsz = 100*msu(1).consolidated(a).tot_ms_dur_s/msu(1).consolidated(a).tot_dur_s;
%                             if isempty(msu(1).consolidated(a).perc_time_in_microsz)
%                                 msu(1).consolidated(a).ms_per_hr = 0;
%                             else
%                                 msu(1).consolidated(a).ms_per_hr = 3600*msu(1).consolidated(a).num_ms/msu(1).consolidated(a).tot_dur_s;
%                             end
%                         end
%                     else
%                         a=a+1;
%                         msu(1).consolidated(a).days_of_TeT = curr_summary(j).days_of_TeT;
%                         msu(1).consolidated(a).num_ms = mi;
%                         msu(1).consolidated(a).tot_dur_s = t;
%                         msu(1).consolidated(a).tot_ms_dur_s = t*msu(j).perc_time_in_microsz/100;
%                         msu(1).consolidated(a-1).perc_time_in_microsz = 100*msu(1).consolidated(a-1).tot_ms_dur_s/msu(1).consolidated(a-1).tot_dur_s;
%                         if isempty(msu(1).consolidated(a-1).perc_time_in_microsz)
%                             msu(1).consolidated(a-1).ms_per_hr = 0;
%                         else
%                             msu(1).consolidated(a-1).ms_per_hr = 3600*msu(1).consolidated(a-1).num_ms/msu(1).consolidated(a-1).tot_dur_s;
%                         end
%                         curr_num=1;
%                         if j == size(msu,2)
%                             msu(1).consolidated(a).perc_time_in_microsz = msu(j).perc_time_in_microsz;
%                             if isempty(msu(1).consolidated(a).perc_time_in_microsz)
%                                 msu(1).consolidated(a).ms_per_hr = 0;
%                             else
%                                 msu(1).consolidated(a).ms_per_hr = msu(j).ms_per_hr;
%                             end
%                         end
%                     end
%                 else
%                     curr_num = 1;
%                     msu(1).consolidated(a).days_of_TeT = curr_summary(j).days_of_TeT;
%                     msu(1).consolidated(a).tot_dur_s = t;
%                     msu(1).consolidated(a).tot_ms_dur_s = t*msu(j).perc_time_in_microsz/100;
%                     msu(1).consolidated(a).num_ms = mi; %msu(j).num_ms;
%                 end
%
%             end
%             %tumor_animal(i).barea.L4(L4fovnum).microseiz_summary = msu;
%         end
%     end
% end

%
% if isempty(tumor_animal(i).barea)
% else
%     if isfield(tumor_animal(i).barea,'L23')
%         if isempty(tumor_animal(i).barea.L23)
%         else
%             msu = tumor_animal(i).barea.L23.microseiz_summary;
%             a=1;
%             curr_num=1;
%             bbu=1;
%             clear rows_to_delete
%             for j = 1:size(msu,2)
%                 if isempty(msu(j).tot_dur_s)
%                     msu(j).tot_dur_s = 0;
%                 end
%                 if msu(j).tot_dur_s == 0
%                     rows_to_delete(1,bbu) = j;
%                     bbu=bbu+1;
%                 end
%             end
%             if bbu>1
%                 msu(rows_to_delete) = [];
%             end
%             for j = 1:size(msu,2)
%                 msph = msu(j).ms_per_hr;
%                 mi =size(msu(j).microseiz,2); %  msu(j).num_ms;
%                 %                     if mi == 0
%                 %                         t=0;
%                 %                         %msu(j).tot_dur_s = t;
%                 %                         t = msu(j).tot_dur_s;
%                 %                     else
%                 %                         t = mi*3600/msph;
%                 %                         %msu(j).tot_dur_s = t;
%                 %                         t = msu(j).tot_dur_s;
%                 %                     end
%
%                 t = msu(j).tot_dur_s;
%                 if isempty(msu(j).tot_dur_s)
%                     msu(j).tot_dur_s = 0;
%                 end
%                 if isempty(msu(j).perc_time_in_microsz)
%                     msu(j).perc_time_in_microsz = 0;
%                 end
%                 msu(j).tot_ms_dur_s = t*msu(j).perc_time_in_microsz/100;
%
%                 dt(1,j) = msu(j).days_of_TeT;
%                 if j>1
%                     if dt(1,j) == dt(1,j-1)
%                         curr_num=curr_num+1;
%                         msu(1).consolidated(a).days_of_TeT = msu(j).days_of_TeT;
%                         msu(1).consolidated(a).num_ms = msu(1).consolidated(a).num_ms + mi;
%                         msu(1).consolidated(a).tot_dur_s = msu(1).consolidated(a).tot_dur_s + t;
%                         msu(1).consolidated(a).tot_ms_dur_s = msu(1).consolidated(a).tot_ms_dur_s + t*msu(j).perc_time_in_microsz/100;
%                         if j == size(msu,2)
%                             msu(1).consolidated(a).perc_time_in_microsz = 100*msu(1).consolidated(a).tot_ms_dur_s/msu(1).consolidated(a).tot_dur_s;
%                             if isempty(msu(1).consolidated(a).perc_time_in_microsz)
%                                 msu(1).consolidated(a).ms_per_hr = 0;
%                             else
%                                 msu(1).consolidated(a).ms_per_hr = 3600*msu(1).consolidated(a).num_ms/msu(1).consolidated(a).tot_dur_s;
%                             end
%                         end
%                     else
%                         a=a+1;
%                         msu(1).consolidated(a).days_of_TeT = msu(j).days_of_TeT;
%                         msu(1).consolidated(a).num_ms = mi;
%                         msu(1).consolidated(a).tot_dur_s = t;
%                         msu(1).consolidated(a).tot_ms_dur_s = t*msu(j).perc_time_in_microsz/100;
%                         msu(1).consolidated(a-1).perc_time_in_microsz = 100*msu(1).consolidated(a-1).tot_ms_dur_s/msu(1).consolidated(a-1).tot_dur_s;
%                         if isempty(msu(1).consolidated(a-1).perc_time_in_microsz)
%                             msu(1).consolidated(a-1).ms_per_hr = 0;
%                         else
%                             msu(1).consolidated(a-1).ms_per_hr = 3600*msu(1).consolidated(a-1).num_ms/msu(1).consolidated(a-1).tot_dur_s;
%                         end
%                         curr_num=1;
%                         if j == size(msu,2)
%                             msu(1).consolidated(a).perc_time_in_microsz = msu(j).perc_time_in_microsz;
%                             if isempty(msu(1).consolidated(a).perc_time_in_microsz)
%                                 msu(1).consolidated(a).ms_per_hr = 0;
%                             else
%                                 msu(1).consolidated(a).ms_per_hr = msu(j).ms_per_hr;
%                             end
%                         end
%                     end
%                 else
%                     curr_num = 1;
%                     msu(1).consolidated(a).days_of_TeT = msu(j).days_of_TeT;
%                     msu(1).consolidated(a).tot_dur_s = t;
%                     msu(1).consolidated(a).tot_ms_dur_s = t*msu(j).perc_time_in_microsz/100;
%                     msu(1).consolidated(a).num_ms = mi; %msu(j).num_ms;
%                 end
%
%             end
%             tumor_animal(i).barea.L23.microseiz_summary = msu;
%         end
%     end
%
%     if isfield(tumor_animal(i).barea,'L4')
%         if isempty(tumor_animal(i).barea.L4)
%         else
%             msu = tumor_animal(i).barea.L4.microseiz_summary;
%             a=1;
%             curr_num=1;
%             bbu=1;
%             clear rows_to_delete
%             for j = 1:size(msu,2)
%                 if isempty(msu(j).tot_dur_s)
%                     msu(j).tot_dur_s = 0;
%                 end
%                 if msu(j).tot_dur_s == 0
%                     rows_to_delete(1,bbu) = j;
%                     bbu=bbu+1;
%                 end
%             end
%             if bbu>1
%                 msu(rows_to_delete) = [];
%             end
%             for j = 1:size(msu,2)
%                 msph = msu(j).ms_per_hr;
%                 mi =size(msu(j).microseiz,2); %  msu(j).num_ms;
%                 %                     if mi == 0
%                 %                         t=0;
%                 %                         %msu(j).tot_dur_s = t;
%                 %                         t = msu(j).tot_dur_s;
%                 %                     else
%                 %                         t = mi*3600/msph;
%                 %                         %msu(j).tot_dur_s = t;
%                 %                         t = msu(j).tot_dur_s;
%                 %                     end
%
%                 t = msu(j).tot_dur_s;
%                 if isempty(msu(j).tot_dur_s)
%                     msu(j).tot_dur_s = 0;
%                 end
%                 if isempty(msu(j).perc_time_in_microsz)
%                     msu(j).perc_time_in_microsz = 0;
%                 end
%                 msu(j).tot_ms_dur_s = t*msu(j).perc_time_in_microsz/100;
%
%                 dt(1,j) = msu(j).days_of_TeT;
%                 if j>1
%                     if dt(1,j) == dt(1,j-1)
%                         curr_num=curr_num+1;
%                         msu(1).consolidated(a).days_of_TeT = msu(j).days_of_TeT;
%                         msu(1).consolidated(a).num_ms = msu(1).consolidated(a).num_ms + mi;
%                         msu(1).consolidated(a).tot_dur_s = msu(1).consolidated(a).tot_dur_s + t;
%                         msu(1).consolidated(a).tot_ms_dur_s = msu(1).consolidated(a).tot_ms_dur_s + t*msu(j).perc_time_in_microsz/100;
%                         if j == size(msu,2)
%                             msu(1).consolidated(a).perc_time_in_microsz = 100*msu(1).consolidated(a).tot_ms_dur_s/msu(1).consolidated(a).tot_dur_s;
%                             if isempty(msu(1).consolidated(a).perc_time_in_microsz)
%                                 msu(1).consolidated(a).ms_per_hr = 0;
%                             else
%                                 msu(1).consolidated(a).ms_per_hr = 3600*msu(1).consolidated(a).num_ms/msu(1).consolidated(a).tot_dur_s;
%                             end
%                         end
%                     else
%                         a=a+1;
%                         msu(1).consolidated(a).days_of_TeT = msu(j).days_of_TeT;
%                         msu(1).consolidated(a).num_ms = mi;
%                         msu(1).consolidated(a).tot_dur_s = t;
%                         msu(1).consolidated(a).tot_ms_dur_s = t*msu(j).perc_time_in_microsz/100;
%                         msu(1).consolidated(a-1).perc_time_in_microsz = 100*msu(1).consolidated(a-1).tot_ms_dur_s/msu(1).consolidated(a-1).tot_dur_s;
%                         if isempty(msu(1).consolidated(a-1).perc_time_in_microsz)
%                             msu(1).consolidated(a-1).ms_per_hr = 0;
%                         else
%                             msu(1).consolidated(a-1).ms_per_hr = 3600*msu(1).consolidated(a-1).num_ms/msu(1).consolidated(a-1).tot_dur_s;
%                         end
%                         curr_num=1;
%                         if j == size(msu,2)
%                             msu(1).consolidated(a).perc_time_in_microsz = msu(j).perc_time_in_microsz;
%                             if isempty(msu(1).consolidated(a).perc_time_in_microsz)
%                                 msu(1).consolidated(a).ms_per_hr = 0;
%                             else
%                                 msu(1).consolidated(a).ms_per_hr = msu(j).ms_per_hr;
%                             end
%                         end
%                     end
%                 else
%                     curr_num = 1;
%                     msu(1).consolidated(a).days_of_TeT = msu(j).days_of_TeT;
%                     msu(1).consolidated(a).tot_dur_s = t;
%                     msu(1).consolidated(a).tot_ms_dur_s = t*msu(j).perc_time_in_microsz/100;
%                     msu(1).consolidated(a).num_ms = mi; %msu(j).num_ms;
%                 end
%
%             end
%             tumor_animal(i).barea.L4.microseiz_summary = msu;
%         end
%     end
% end

%end

