
function [cr2] = correlation_analysis_2(c_ict,c_int,Folder,cmap,ih,il,np,neutr,moes,norm,sf,raw)
%
if ih==0
    ihx=0;
else
    ihx=size(ih,1);
end


if raw
    c_ict_c = c_ict.correlation_coefficient_matrix;
    c_int_c = c_int.correlation_coefficient_matrix;
    
else
    c_ict_c = c_ict.correlation_coefficient_matrix_min_avg_shuf_sig_only;
    c_int_c = c_int.correlation_coefficient_matrix_min_avg_shuf_sig_only;
end
%
% f = size(c_ict_c,1);
% g = ihx;
% h = size(il,1);
% k = size(np,2):
ict_min_interict_corrs = zeros(size(c_ict_c,1),size(c_ict_c,2),size(c_ict_c,3));
a=1;
for i = 1:size(c_ict_c,3)
    if sum(sum(c_ict_c(:,:,i))) == 0
    else
        
        %reshape so that I have first ictal highs, then ictal low, then neutral,
        %then neuropil
        %
        %         for j = 1:f
        %             for jj = 1:f
        %
        %
        %             end
        %         end
        
        ict_min_interict_corrs(:,:,a) = c_int_c(:,:,i)...
            -c_ict_c(:,:,i);
        
        figure (1000+a)
        %clims = [-0.3, 0.6];
        colormap(cmap)
        clims = [-0.5 0.5];
        imagesc (ict_min_interict_corrs (:,:,a),clims);
        colorbar
        % title ([initial.moviename ': tau: ' int2str(bin) ' frames'])
        title ([Folder ': bin ' int2str(a) ])
        %% cd (Folder)
        %saveas (bin,[initial.moviename '_correlation_diagram_tau_' int2str(bin)],'png');
        if sf
            if norm
                saveas (1000+a,[Folder '_correlation_diagram_ict_minus_inter_norm_tau_' int2str(a) ],'png');
            else
                
                saveas (1000+a,[Folder '_correlation_diagram_ict_minus_inter_tau_' int2str(a) ],'png');
            end
        end
    end
    
    
    if isnan(sum(sum(ict_min_interict_corrs(:,:,a))))
    else
        if sum(sum(ict_min_interict_corrs(:,:,a)))
            currcor = squeeze(ict_min_interict_corrs(:,:,a));
            curr_ict = squeeze(c_int_c(:,:,i));
            curr_int = squeeze(c_ict_c(:,:,i));
            b=1;
            b1=1;
            b2=1;
            b3=1;
            b4=1;
            b5=1;
            b6 = 1;
            c=1;
            c1=1;
            c2=1;
            c3=1;
            c4=1;
            c5=1;
            c6=1;
            d=1;
            d1=1;
            d2=1;
            d3=1;
            d4=1;
            d5=1;
            d6=1;
            e=1;
            e1=1;
            e2=1;
            e3=1;
            e4=1;
            e5=1;
            e6=1;
            for ii = 1:size(currcor,1)
                for jj = 1:ii
                    cr2(a).ict_min_interict_corr_vector(1,b) = currcor(ii,jj);
                    cr2(a).ict_corr_vector(1,b) = curr_ict(ii,jj);
                    cr2(a).int_corr_vector(1,b) = curr_int(ii,jj);
                    %ictal high
                    if ii<=ihx
                        if jj<=ihx && jj<ii
                            cr2(a).ict_min_interict_corr_vector_ict_high_only(1,b1) = currcor(ii,jj);
                            cr2(a).ict_corr_vector_ict_high_only(1,b1) = curr_ict(ii,jj);
                            cr2(a).int_corr_vector_ict_high_only(1,b1) = curr_int(ii,jj);
                            b1=b1+1;
                        end
                    else
                        if jj<=ihx
                            cr2(a).ict_min_interict_corr_vector_ict_high_only(1,b1) = currcor(ii,jj);
                            cr2(a).ict_corr_vector_ict_high_only(1,b1) = curr_ict(ii,jj);
                            cr2(a).int_corr_vector_ict_high_only(1,b1) = curr_int(ii,jj);
                            b1=b1+1;
                        end
                    end
                    %ictal low
                    if ii>ihx && ii<=ihx+size(il,1)
                        if jj < ii
                            cr2(a).ict_min_interict_corr_vector_ict_low_only(1,b2) = currcor(ii,jj);
                            cr2(a).ict_corr_vector_ict_low_only(1,b2) = curr_ict(ii,jj);
                            cr2(a).int_corr_vector_ict_low_only(1,b2) = curr_int(ii,jj);
                            b2=b2+1;
                        end
                    end
                    if ii> ihx+size(il,1)
                        if jj > ihx && jj <= ihx+size(il,1)
                            cr2(a).ict_min_interict_corr_vector_ict_low_only(1,b2) = currcor(ii,jj);
                            cr2(a).ict_corr_vector_ict_low_only(1,b2) = curr_ict(ii,jj);
                            cr2(a).int_corr_vector_ict_low_only(1,b2) = curr_int(ii,jj);
                            b2=b2+1;
                        end
                    end
                    %neutral
                    if ii>ihx+size(il,1) && ii<=ihx+size(il,1)+size(neutr,1)
                        if jj<ii
                            cr2(a).ict_min_interict_corr_vector_neutr_only(1,b3) = currcor(ii,jj);
                            cr2(a).ict_corr_vector_neutr_only(1,b3) = curr_ict(ii,jj);
                            cr2(a).int_corr_vector_neutr_only(1,b3) = curr_int(ii,jj);
                            b3=b3+1;
                        end
                    end
                    if ii>ihx+size(il,1)+size(neutr,1)
                        if jj>ihx+size(il,1) && jj<=ihx+size(il,1)+size(neutr,1)
                            cr2(a).ict_min_interict_corr_vector_neutr_only(1,b3) = currcor(ii,jj);
                            cr2(a).ict_corr_vector_neutr_only(1,b3) = curr_ict(ii,jj);
                            cr2(a).int_corr_vector_neutr_only(1,b3) = curr_int(ii,jj);
                            b3=b3+1;
                        end
                    end
                    %neuropil
                    if ii>ihx+size(il,1)+size(neutr,1) && ii<=ihx+size(il,1)+size(neutr,1)+size(np,1)
                        if jj<ii
                            cr2(a).ict_min_interict_corr_vector_neuropil_only(1,b4) = currcor(ii,jj);
                            cr2(a).ict_corr_vector_neuropil_only(1,b4) = curr_ict(ii,jj);
                            cr2(a).int_corr_vector_neuropil_only(1,b4) = curr_int(ii,jj);
                            b4=b4+1;
                        end
                    end
                    if ii>ihx+size(il,1)+size(neutr,1)+size(np,1)
                        if jj>ihx+size(il,1)+size(neutr,1) && jj<=ihx+size(il,1)+size(neutr,1)+size(np,1)
                            cr2(a).ict_min_interict_corr_vector_neuropil_only(1,b4) = currcor(ii,jj);
                            cr2(a).ict_corr_vector_neuropil_only(1,b4) = curr_ict(ii,jj);
                            cr2(a).int_corr_vector_neuropil_only(1,b4) = curr_int(ii,jj);
                            b4=b4+1;
                        end
                    end
                    %motion
                    if ii>ihx+size(il,1)+size(neutr,1)+size(np,1) && ii<=ihx+size(il,1)+size(neutr,1)+size(np,1)+1
                        if jj<ii
                            cr2(a).ict_min_interict_corr_vector_motion_only(1,b5) = currcor(ii,jj);
                            cr2(a).ict_corr_vector_motion_only(1,b5) = curr_ict(ii,jj);
                            cr2(a).int_corr_vector_motion_only(1,b5) = curr_int(ii,jj);
                            b5=b5+1;
                        end
                    end
                    if ii>ihx+size(il,1)+size(neutr,1)+size(np,1)+1
                        if jj>ihx+size(il,1)+size(neutr,1)+size(np,1) && jj<=ihx+size(il,1)+size(neutr,1)+size(np,1)+1
                            cr2(a).ict_min_interict_corr_vector_motion_only(1,b5) = currcor(ii,jj);
                            cr2(a).ict_corr_vector_motion_only(1,b5) = curr_ict(ii,jj);
                            cr2(a).int_corr_vector_motion_only(1,b5) = curr_int(ii,jj);
                            b5=b5+1;
                        end
                    end
                    %EEG
                    if ii == ihx+size(il,1)+size(neutr,1)+size(np,1)+2
                        cr2(a).ict_min_interict_corr_vector_eeg_only(1,b6) = currcor(ii,jj);
                        cr2(a).ict_corr_vector_eeg_only(1,b6) = curr_ict(ii,jj);
                        cr2(a).int_corr_vector_eeg_only(1,b6) = curr_int(ii,jj);
                    end
                    
                    
                    %adjust the next section for matrix selection!
                    if    currcor(ii,jj)>0
                        cr2(a).ict_min_int_corr_vec_pos_corr_only(1,c) = currcor(ii,jj);
                        
                        
                        %ictal high
                        if ii<=ihx
                            if jj<=ihx && jj<ii
                                cr2(a).ict_min_interict_corr_vector_pos_corr_ict_high_only(1,c1) = currcor(ii,jj);
                                c1=c1+1;
                            end
                        else
                            if jj<=ihx
                                cr2(a).ict_min_interict_corr_vector_pos_corr_ict_high_only(1,c1) = currcor(ii,jj);
                                c1=c1+1;
                            end
                        end
                        %ictal low
                        if ii>ihx && ii<=ihx+size(il,1)
                            if jj < ii
                                cr2(a).ict_min_interict_corr_vector_pos_corr_ict_low_only(1,c2) = currcor(ii,jj);
                                c2=c2+1;
                            end
                        end
                        if ii> ihx+size(il,1)
                            if jj > ihx && jj <= ihx+size(il,1)
                                cr2(a).ict_min_interict_corr_vector_pos_corr_ict_low_only(1,c2) = currcor(ii,jj);
                                c2=c2+1;
                            end
                        end
                        %neutral
                        if ii>ihx+size(il,1) && ii<=ihx+size(il,1)+size(neutr,1)
                            if jj<ii
                                cr2(a).ict_min_interict_corr_vector_pos_corr_neutr_only(1,c3) = currcor(ii,jj);
                                c3=c3+1;
                            end
                        end
                        if ii>ihx+size(il,1)+size(neutr,1)
                            if jj>ihx+size(il,1) && jj<=ihx+size(il,1)+size(neutr,1)
                                cr2(a).ict_min_interict_corr_vector_pos_corr_neutr_only(1,c3) = currcor(ii,jj);
                                c3=c3+1;
                            end
                        end
                        %neuropil
                        if ii>ihx+size(il,1)+size(neutr,1) && ii<=ihx+size(il,1)+size(neutr,1)+size(np,1)
                            if jj<ii
                                cr2(a).ict_min_interict_corr_vector_pos_corr_neuropil_only(1,c4) = currcor(ii,jj);
                                c4=c4+1;
                            end
                        end
                        if ii>ihx+size(il,1)+size(neutr,1)+size(np,1)
                            if jj>ihx+size(il,1)+size(neutr,1) && jj<=ihx+size(il,1)+size(neutr,1)+size(np,1)
                                cr2(a).ict_min_interict_corr_vector_pos_corr_neuropil_only(1,c4) = currcor(ii,jj);
                                c4=c4+1;
                            end
                        end
                        %motion
                        if ii>ihx+size(il,1)+size(neutr,1)+size(np,1) && ii<=ihx+size(il,1)+size(neutr,1)+size(np,1)+1
                            if jj<ii
                                cr2(a).ict_min_interict_corr_vector_pos_corr_motion_only(1,c5) = currcor(ii,jj);
                                c5=c5+1;
                            end
                        end
                        if ii>ihx+size(il,1)+size(neutr,1)+size(np,1)+1
                            if jj>ihx+size(il,1)+size(neutr,1)+size(np,1) && jj<=ihx+size(il,1)+size(neutr,1)+size(np,1)+1
                                cr2(a).ict_min_interict_corr_vector_pos_corr_motion_only(1,c5) = currcor(ii,jj);
                                c5=c5+1;
                            end
                        end
                        %EEG
                        if ii == ihx+size(il,1)+size(neutr,1)+size(np,1)+2
                            cr2(a).ict_min_interict_corr_vector_pos_corr_eeg_only(1,c6) = currcor(ii,jj);
                        end
                        
                        c=c+1;
                    end
                    
                    
                    
                    if    currcor(ii,jj)<0
                        cr2(a).ict_min_int_corr_vec_neg_only(1,d) = currcor(ii,jj);
                        
                        %ictal high
                        if ii<=ihx
                            if jj<=ihx && jj<ii
                                cr2(a).ict_min_interict_corr_vector_neg_corr_ict_high_only(1,d1) = currcor(ii,jj);
                                d1=d1+1;
                            end
                        else
                            if jj<=ihx
                                cr2(a).ict_min_interict_corr_vector_neg_corr_ict_high_only(1,d1) = currcor(ii,jj);
                                d1=d1+1;
                            end
                        end
                        %ictal low
                        if ii>ihx && ii<=ihx+size(il,1)
                            if jj < ii
                                cr2(a).ict_min_interict_corr_vector_neg_corr_ict_low_only(1,d2) = currcor(ii,jj);
                                d2=d2+1;
                            end
                        end
                        if ii> ihx+size(il,1)
                            if jj > ihx && jj <= ihx+size(il,1)
                                cr2(a).ict_min_interict_corr_vector_neg_corr_ict_low_only(1,d2) = currcor(ii,jj);
                                d2=d2+1;
                            end
                        end
                        %neutral
                        if ii>ihx+size(il,1) && ii<=ihx+size(il,1)+size(neutr,1)
                            if jj<ii
                                cr2(a).ict_min_interict_corr_vector_neg_corr_neutr_only(1,d3) = currcor(ii,jj);
                                d3=d3+1;
                            end
                        end
                        if ii>ihx+size(il,1)+size(neutr,1)
                            if jj>ihx+size(il,1) && jj<=ihx+size(il,1)+size(neutr,1)
                                cr2(a).ict_min_interict_corr_vector_neg_corr_neutr_only(1,d3) = currcor(ii,jj);
                                d3=d3+1;
                            end
                        end
                        %neuropil
                        if ii>ihx+size(il,1)+size(neutr,1) && ii<=ihx+size(il,1)+size(neutr,1)+size(np,1)
                            if jj<ii
                                cr2(a).ict_min_interict_corr_vector_neg_corr_neuropil_only(1,d4) = currcor(ii,jj);
                                d4=d4+1;
                            end
                        end
                        if ii>ihx+size(il,1)+size(neutr,1)+size(np,1)
                            if jj>ihx+size(il,1)+size(neutr,1) && jj<=ihx+size(il,1)+size(neutr,1)+size(np,1)
                                cr2(a).ict_min_interict_corr_vector_neg_corr_neuropil_only(1,d4) = currcor(ii,jj);
                                d4=d4+1;
                            end
                        end
                        %motion
                        if ii>ihx+size(il,1)+size(neutr,1)+size(np,1) && ii<=ihx+size(il,1)+size(neutr,1)+size(np,1)+1
                            if jj<ii
                                cr2(a).ict_min_interict_corr_vector_neg_corr_motion_only(1,d5) = currcor(ii,jj);
                                d5=d5+1;
                            end
                        end
                        if ii>ihx+size(il,1)+size(neutr,1)+size(np,1)+1
                            if jj>ihx+size(il,1)+size(neutr,1)+size(np,1) && jj<=ihx+size(il,1)+size(neutr,1)+size(np,1)+1
                                cr2(a).ict_min_interict_corr_vector_neg_corr_motion_only(1,d5) = currcor(ii,jj);
                                d5=d5+1;
                            end
                        end
                        %EEG
                        if ii == ihx+size(il,1)+size(neutr,1)+size(np,1)+2
                            cr2(a).ict_min_interict_corr_vector_neg_corr_eeg_only(1,d6) = currcor(ii,jj);
                        end
                        
                        d=d+1;
                    end
                    
                    
                    if    currcor(ii,jj)==0
                        cr2(a).ict_min_int_corr_vec_zeroes = e;
                        e=e+1;
                        
                        %ictal high
                        if ii<=ihx
                            if jj<=ihx && jj<ii
                                cr2(a).ict_min_interict_corr_vector_zeroes_ict_high_only(1,e1) = currcor(ii,jj);
                                e1=e1+1;
                            end
                        else
                            if jj<=ihx
                                cr2(a).ict_min_interict_corr_vector_zeroes_ict_high_only(1,e1) = currcor(ii,jj);
                                e1=e1+1;
                            end
                        end
                        %ictal low
                        if ii>ihx && ii<=ihx+size(il,1)
                            if jj < ii
                                cr2(a).ict_min_interict_corr_vector_zeroes_ict_low_only(1,e2) = currcor(ii,jj);
                                e2=e2+1;
                            end
                        end
                        if ii> ihx+size(il,1)
                            if jj > ihx && jj <= ihx+size(il,1)
                                cr2(a).ict_min_interict_corr_vector_zeroes_ict_low_only(1,e2) = currcor(ii,jj);
                                e2=e2+1;
                            end
                        end
                        %neutral
                        if ii>ihx+size(il,1) && ii<=ihx+size(il,1)+size(neutr,1)
                            if jj<ii
                                cr2(a).ict_min_interict_corr_vector_zeroes_neutr_only(1,e3) = currcor(ii,jj);
                                e3=e3+1;
                            end
                        end
                        if ii>ihx+size(il,1)+size(neutr,1)
                            if jj>ihx+size(il,1) && jj<=ihx+size(il,1)+size(neutr,1)
                                cr2(a).ict_min_interict_corr_vector_zeroes_neutr_only(1,e3) = currcor(ii,jj);
                                e3=e3+1;
                            end
                        end
                        %neuropil
                        if ii>ihx+size(il,1)+size(neutr,1) && ii<=ihx+size(il,1)+size(neutr,1)+size(np,1)
                            if jj<ii
                                cr2(a).ict_min_interict_corr_vector_zeroes_neuropil_only(1,e4) = currcor(ii,jj);
                                e4=e4+1;
                            end
                        end
                        if ii>ihx+size(il,1)+size(neutr,1)+size(np,1)
                            if jj>ihx+size(il,1)+size(neutr,1) && jj<=ihx+size(il,1)+size(neutr,1)+size(np,1)
                                cr2(a).ict_min_interict_corr_vector_zeroes_neuropil_only(1,e4) = currcor(ii,jj);
                                e4=e4+1;
                            end
                        end
                        %motion
                        if ii>ihx+size(il,1)+size(neutr,1)+size(np,1) && ii<=ihx+size(il,1)+size(neutr,1)+size(np,1)+1
                            if jj<ii
                                cr2(a).ict_min_interict_corr_vector_zeroes_motion_only(1,e5) = currcor(ii,jj);
                                e5=e5+1;
                            end
                        end
                        if ii>ihx+size(il,1)+size(neutr,1)+size(np,1)+1
                            if jj>ihx+size(il,1)+size(neutr,1)+size(np,1) && jj<=ihx+size(il,1)+size(neutr,1)+size(np,1)+1
                                cr2(a).ict_min_interict_corr_vector_zeroes_motion_only(1,e5) = currcor(ii,jj);
                                e5=e5+1;
                            end
                        end
                        %EEG
                        if ii == ihx+size(il,1)+size(neutr,1)+size(np,1)+2
                            cr2(a).ict_min_interict_corr_vector_zeroes_eeg_only(1,e6) = currcor(ii,jj);
                        end
                        
                        
                    end
                    b=b+1;
                end
            end
            
            if sf
                if norm
                    figure (10000+a)
                    edges = [-1:0.02:1];
                    histogram(cr2(a).ict_min_interict_corr_vector,'Edges',edges)
                   % % cd (Folder)
                    saveas (10000+a,[Folder 'all_correlation_histogram_ict_minus_inter_norm_tau_' int2str(a) ],'png');
                    if ih
                        figure (20000+a)
                        edges = [-1:0.02:1];
                        histogram(cr2(a).ict_min_interict_corr_vector_ict_high_only,'Edges',edges)
                        % cd (Folder)
                        saveas (20000+a,[Folder 'ict_high_only__correlation_histogram_ict_minus_inter_norm_tau_' int2str(a) ],'png');
                    end
                    figure (30000+a)
                    edges = [-1:0.02:1];
                    histogram(cr2(a).ict_min_interict_corr_vector_ict_low_only,'Edges',edges)
                   % % cd (Folder)
                    saveas (30000+a,[Folder 'ict_low_only__correlation_histogram_ict_minus_inter_norm_tau_' int2str(a) ],'png');
                    
                    figure (40000+a)
                    edges = [-1:0.02:1];
                    histogram(cr2(a).ict_min_interict_corr_vector_neutr_only,'Edges',edges)
                   % % cd (Folder)
                    saveas (40000+a,[Folder 'neutral_only__correlation_histogram_ict_minus_inter_norm_tau_' int2str(a) ],'png');
                    
                    if np
                        figure (50000+a)
                        edges = [-1:0.02:1];
                        histogram(cr2(a).ict_min_interict_corr_vector_neuropil_only,'Edges',edges)
                       % % cd (Folder)
                        saveas (50000+a,[Folder 'neuropil_only__correlation_histogram_ict_minus_inter_norm_tau_' int2str(a) ],'png');
                    end
                    
                    figure (60000+a)
                    edges = [-1:0.02:1];
                    histogram(cr2(a).ict_min_interict_corr_vector_motion_only,'Edges',edges)
                   % % cd (Folder)
                    saveas (60000+a,[Folder 'motion_only__correlation_histogram_ict_minus_inter_norm_tau_' int2str(a) ],'png');
                    
                    
                    if isfield(cr2(a), 'ict_min_interict_corr_vector_eeg_only')
                        figure (70000+a)
                        edges = [-1:0.02:1];
                        histogram(cr2(a).ict_min_interict_corr_vector_eeg_only,'Edges',edges)
                        % cd (Folder)
                        saveas (70000+a,[Folder 'EEG_only__correlation_histogram_ict_minus_inter_norm_tau_' int2str(a) ],'png');
                    end
                else
                    
                    figure (10000+a)
                    edges = [-1:0.02:1];
                    histogram(cr2(a).ict_min_interict_corr_vector,'Edges',edges)
                    % cd (Folder)
                    saveas (10000+a,[Folder 'all_correlation_histogram_ict_minus_inter_tau_' int2str(a) ],'png');
                    
                    if ih
                        figure (20000+a)
                        edges = [-1:0.02:1];
                        histogram(cr2(a).ict_min_interict_corr_vector_ict_high_only,'Edges',edges)
                        % cd (Folder)
                        saveas (20000+a,[Folder 'ict_high_only__correlation_histogram_ict_minus_inter_tau_' int2str(a) ],'png');
                    end
                    
                    figure (30000+a)
                    edges = [-1:0.02:1];
                    histogram(cr2(a).ict_min_interict_corr_vector_ict_low_only,'Edges',edges)
                    % cd (Folder)
                    saveas (30000+a,[Folder 'ict_low_only__correlation_histogram_ict_minus_inter_tau_' int2str(a) ],'png');
                    
                    figure (40000+a)
                    edges = [-1:0.02:1];
                    histogram(cr2(a).ict_min_interict_corr_vector_neutr_only,'Edges',edges)
                    % cd (Folder)
                    saveas (40000+a,[Folder 'neutral_only__correlation_histogram_ict_minus_inter_tau_' int2str(a) ],'png');
                    
                    if np
                        figure (50000+a)
                        edges = [-1:0.02:1];
                        histogram(cr2(a).ict_min_interict_corr_vector_neuropil_only,'Edges',edges)
                        % cd (Folder)
                        saveas(50000+a,[Folder 'neuropil_only__correlation_histogram_ict_minus_inter_tau_' int2str(a) ],'png');
                    end
                    
                    figure (60000+a)
                    edges = [-1:0.02:1];
                    histogram(cr2(a).ict_min_interict_corr_vector_motion_only,'Edges',edges)
                    % cd (Folder)
                    saveas (60000+a,[Folder 'motion_only__correlation_histogram_ict_minus_inter_tau_' int2str(a) ],'png');
                    
                    if isfield(cr2(a), 'ict_min_interict_corr_vector_eeg_only')
                        figure (70000+a)
                        edges = [-1:0.02:1];
                        histogram(cr2(a).ict_min_interict_corr_vector_eeg_only,'Edges',edges)
                        % cd (Folder)
                        %saveas (70000+a,[Folder 'EEG_only__correlation_histogram_ict_minus_inter_tau_' int2str(a) ],'png');
                        export_fig(70000+a,[Folder 'EEG_only__correlation_histogram_ict_minus_inter_tau_' int2str(a) ],'-png');
                    end
                end
            end
        end
    end
    
    
    a=a+1;
    
end


cr2(1).ict_min_interict_corrs = ict_min_interict_corrs;










