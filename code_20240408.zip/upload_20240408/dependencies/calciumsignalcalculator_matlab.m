function [deltaf_matrix,results] = calciumsignalcalculator_matlab(initial,Folder,xml_file,ROI_list,...
    baseline_tconst_ms,apre,i2,onep,apre_ROI_info)

% if initial.linescan ==0
%     Name2 = dir(strcat(Folder,'/T*.txt'));
%     txtFileName = Name2.name
%     cd(Folder)
%     initial.calciumsignal =  importdata(txtFileName, '\t', 1);
% end

if initial.linescan
    framestart_ms(1) = 1;
    for i = 2:initial.max_frame
        framestart_ms(i) = str2num(xml_file.Sequence{1,1}.Frame{1,i}.ATTRIBUTE.relativeTime)*1000;
    end
    
    i2.msperline = framestart_ms(size(framestart_ms,2))/(size(framestart_ms,2)-1)/initial.height;
end

%lp=ROI_list(size(ROI_list,2)).fmean;
if apre
    endd = length(ROI_list.cat_signal);
else
    if length(ROI_list(size(ROI_list,2)).fmean)<length(ROI_list(1).fmean)
        endd = length(ROI_list(size(ROI_list,2)).fmean);
    else
        endd = length(ROI_list(2).fmean);
    end
    
end
% 
% if length(i2.mirror_start_time)<endd
%     endd = length(i2.mirror_start_time);
% end
% 

if apre
    cat_signal = ROI_list.cat_signal;
else
    if initial.linescan ==0 && initial.date<73584
        Name2 = dir(strcat(Folder,'/T*.txt'));
        txtFileName = Name2.name
        
        initial.calciumsignal =  importdata(txtFileName, '\t', 1);
        
        %
        initial.calciumsignal = initial.calciumsignal.data;
        
        endframe = size(initial.calciumsignal,2)-2;
        
        deltaf_matrix = zeros (max(size(initial.calciumsignal)),endframe,initial.numberofmovies);
        
        
        initial.calciumsignal(:,1) = initial.calciumsignal(:,2);
        
        for i=4:size(initial.calciumsignal,2)
            initial.calciumsignal(:,i-2) = initial.calciumsignal(:,i);
        end
        initial.calciumsignal(:, size(initial.calciumsignal,2)-1:size(initial.calciumsignal,2)) = [];
        
        cat_signal = zeros (1,size(initial.calciumsignal,2));
        cat_signal = initial.calciumsignal;
        
        
    else
        if initial.date<73584
            cat_signal = initial.calciumsignal;
        else
            for i = 1:size(ROI_list,2)
                if size(ROI_list(i).fmean,1)>1 %&& size(ROI_list(i).fill_list,1)>4
                cat_signal(:,i) = ROI_list(i).fmean(1:endd,1);
                else
                    cat_signal(:,i) = zeros(initial.max_frame,1);
                end
            end
        end
    end
end
results.cat_signal = cat_signal;
%for frame = 1:initial.numberofframes
%    cat_signal = cat (1,cat_signal,signal (:,:,frame));
%end

period = ceil(baseline_tconst_ms/i2.msperline);
lines = length(cat_signal);

cat_signal_baseline = zeros(lines,size(results.cat_signal,2));
baseline_i = zeros(lines,size(results.cat_signal,2));

cat_signal = results.cat_signal;
for cell_i = 1:size(results.cat_signal,2)
    cell_i
    %around_i = sort(cat_signal((frame_i-period+1):frame_i+period,cell_i));
    %baseline_i = mean(around_i(1:round(length(around_i)*0.7)));
    
    for frame_i = period:(lines-period)
        around_i = sort(cat_signal((frame_i-period+1):frame_i+period,cell_i));
        %around_i = sort(cat_signal((period-period+1):1+period,cell_i));
        baseline_i(frame_i,cell_i) = mean(around_i(1:round(length(around_i)*0.15)));
        cat_signal_baseline(frame_i,cell_i) = baseline_i(frame_i,cell_i);
    end
    
    cat_signal_baseline(1:period,cell_i)=cat_signal_baseline(period,cell_i);
    cat_signal_baseline(lines-period+1:lines,cell_i) = cat_signal_baseline(lines-period,cell_i);
    
end
%
% for cell = 1:size(initial.calciumsignal,2)
%     deltaf_matrix (:,cell) = cat_signal(:,cell);
%     sub_deltaf_matrix (:,cell) = deltaf_matrix(:,cell)-cat_signal_baseline(:,cell);
%     for x=1:lines
%     deltaf_matrix (x,cell) = (sub_deltaf_matrix (x,cell))/(cat_signal_baseline(x,cell));
%     end
% end

deltaf_matrix = zeros(size(results.cat_signal));

for cell = 1:size(results.cat_signal,2)
    deltaf_matrix (:,cell) = results.cat_signal(:,cell);
    deltaf_matrix (:,cell) = deltaf_matrix(:,cell)-cat_signal_baseline(:,cell);
    for i = 1:size(results.cat_signal,1)
        deltaf_matrix (i,cell) = deltaf_matrix(i,cell)/cat_signal_baseline(i,cell);
    end
end


deltaf_matrix_new = zeros(size(results.cat_signal));
for cell = 1:size(results.cat_signal,2)
    deltaf_matrix_new (:,cell) = results.cat_signal(:,cell);
    deltaf_matrix_new (:,cell) = deltaf_matrix_new(:,cell)-cat_signal_baseline(:,cell);
    deltaf_matrix_new (:,cell) = deltaf_matrix_new(:,cell)/mean(cat_signal(:,cell));
end
results.deltaf_matrix_new = deltaf_matrix_new;
results.cat_signal_baseline = cat_signal_baseline;



results.deltaf_matrix = deltaf_matrix;

if apre_ROI_info
    results.ROI_info = ROI_list.ROI_info;
else
    if initial.linescan ==0
        if initial.date<737480
            ROI_info = dir('R*.txt');
            ROI_infotxtFileName = ROI_info.name
            %cd(Folder)
            results.ROI_info =  importdata(ROI_infotxtFileName, '\t', 1);
            
            ROI_info = results.ROI_info.data(:,1:4);
            
            results.ROI_info = ROI_info;
        else
            for i = 1:size(ROI_list,2)
                results.ROI_info(i,1) = size(ROI_list(i).pixel_list,1);
                results.ROI_info(i,2) = mean(ROI_list(i).fmean);
                results.ROI_info(i,3:4) = ROI_list(i).centerPos;
            end
        end
    end
end
%
% if initial.NB208 == 0
% plot(initial.rawData2(:,1))
% else
%     plot(initial.rawData2(:,2))
% end

initial.tiffmovie = 0;
initial.tiffmovie_ch1 = 0;





