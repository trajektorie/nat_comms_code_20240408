

function morlet_wavelet = make_morlet_wavelet_one_channel(low_freq,high_freq,fs,eeg)
% 
% low_freq = 0;
% high_freq = 50;
% fs = 100;  % Sample rate

%eeg = recording(iii).EEG_results_nonoise.EEG_extrap;


clim_zoom = 8;  % Color axis zoom factor


xtime  = linspace(0,length(eeg)/fs,length(eeg));
tmin = xtime(1); tmax = xtime(end);
np = length(xtime);



freq = max([low_freq 1]):high_freq;  % Every Hz, starting from at least 1Hz
% Call qcwt with a Q factor corresponding to the basic Morlet wavelet (nco=5)
% Qmorlet = 5/(2*sqrt(2*log(2)))
morlet_wavelet = qcwt( eeg, fs, freq,  5/(2*sqrt(2*log(2))));

end




