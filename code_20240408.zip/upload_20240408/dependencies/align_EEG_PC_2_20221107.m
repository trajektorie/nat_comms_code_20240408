function [EEG_results] = align_EEG_PC_2_20221107(Folder,initial,matrix,results,deconv_mat,imaged,EEG_mat,...
    NB208_aft16,stimcell_interp_to_Vm,i2,ap,onep,ZH_recording,Folder_master,cat_mat,patched_cell_ROI)%align EEG

cat_signal = real(results.cat_signal);
% [dll_FileName,dll_PathName] = uigetfile('*.dll','Select the dll-file');
%
% addpath(dll_PathName);
% Loc  = strcat(dll_PathName,dll_FileName);
% Folder = findstr(Loc,'\');
% Folder = Loc(1:Folder(end));
%
% Name4 = dir(strcat(Folder,'\nsNEVLibrary.dll'));
% FileName4 = Name4.name;
%
% [ns_RESULT] = ns_SetLibrary(FileName4);
%
% Name3 = dir(strcat(Folder,'\*.ns3'));
% NS_FileName = Name3.name;
%
% addpath(Folder);
%
% [NS_FileName,NS_PathName] = uigetfile('*.ns3','Select the ns3-file');
%
% [ns_RESULT, hFile] = ns_OpenFile(NS_FileName);
%
% [ns_RESULT, nsEntityInfo] = ns_GetEntityInfo(NS_FileName, EntityID);
%
%

%initial.samplingrate_hz = 1000/i2.msperline;

%cd (Folder)


if ap.man
    
    prompt = {'2 channel EEG (1) or not (0) ?'};
    dlg_title = '1 if 2 chan, 0 if 1 chan EEG';
    num_lines = 1;
    def = {'1'};
    answer = inputdlg(prompt,dlg_title,num_lines,def);
    answer = str2mat(answer);
    answer = str2num(answer);
else
    if ap.e2ch
        answer = 1;
        %         answer = str2mat(answer);
        %         answer = str2num(answer);
        
    else
        answer = 0;
        %         answer = str2mat(answer);
        %         answer = str2num(answer);
        %
    end
end

if isfield(i2,'rawData2') || isfield(initial, 'rawData2')
    
    if isfield(i2,'rawData2')
        if length(i2.rawData2)<3
            i2rawData2 = initial.rawData2;
        else
            i2rawData2 = i2.rawData2;
        end
    else
        i2rawData2 = initial.rawData2;
    end
    
    if length(i2rawData2)/i2.sampl_fr<90
        EEG_results.too_short = 1;
        EEG_results.EEG=0;
    else
        
        if size(i2rawData2,2) == 3
            answer=0;
        end
        
        
        if initial.NB208 == 0
            
            if size(EEG_mat,1)>2
                datafile = EEG_mat;
                EEG = EEG_mat(:,size(EEG_mat,2)-2);
                EEG_results.EEG = EEG_mat(:,size(EEG_mat,2)-4);
                if answer
                    EEG_results.EEG_2 = EEG_mat(:,size(EEG_mat,2)-6);
                    EEG_2 = EEG_results.EEG_2;
                end
            else
                Name2 = dir(strcat(Folder,'\d*.txt'));
                EEGFileName = Name2.name
                cd(Folder)
                datafile =  dlmread(EEGFileName, '\t', 1);
                
                if initial.date>735400
                    xd = 8;
                else
                    xd = 2;
                end
                EEG = datafile(:,size(datafile,2)-xd);
                %EEG = initial.EEG(:,4);
                EEG_results.EEG = EEG;
            end
            %answer = 1
            
            if answer
                EEG_2 = datafile(:,size(datafile,2));
                EEG_results.EEG_2 = EEG_2;
            end
            %
            if (datafile(1001,1)>0.495 && datafile(1001,1)<0.505) || datafile(1001,1) == -154
                ax = 2000;
            else
                if datafile(1001,1)>0.195 && datafile(1001,1)<0.205
                    ax = 5000;
                else
                    if datafile(1001,1)>0.095 && datafile(1001,1)<0.105
                        ax = 10000;
                    end
                end
            end
            
            
        else
            if isfield(i2,'rawData2')
                if initial.date >72800 && initial.date < 740000
                    max_ch = size(i2rawData2,2)
                    if NB208_aft16
                        if onep
                            if initial.heka_or_winedr
                                x=7
                            else
                                x = 6
                            end
                        else
                            x = 7
                        end
                        if ZH_recording
                            x=2;
                        end
                    else
                        for i=2:max_ch
                            plot(i2rawData2(1:1000000,i))
                            prompt = {'Is this the EEG (1) or not (0) ?'};
                            dlg_title = '1 if yes, 0 if no';
                            num_lines = 1;
                            def = {'1'};
                            answe = inputdlg(prompt,dlg_title,num_lines,def);
                            answe = str2mat(answe);
                            answe = str2num(answe);
                            if answe
                                x=i;
                            end
                            close all
                        end
                    end
                    
                    EEG_results.EEG = i2rawData2(:,x);
                    if answer
                        EEG_results.EEG_2 = i2rawData2(:,x+1);
                    end
                    if onep
                        EEG_results.EKG = i2rawData2(:,2);
                    end
                else
                    EEG_results.EEG = i2rawData2(:,2);
                    if answer
                        EEG_results.EEG_2 = i2rawData2(:,3);
                    end
                end
                
            else
                EEG_results.EEG=0;
                EEG_results.EEG_2=0;
            end
        end
        
        freq = 100;
        
        if initial.NB208 == 0
            if size(EEG_mat,2)>1
                EEG_TTL = EEG_mat(:,size(EEG_mat,2));
            else
                EEG_TTL = datafile(:,2)+20;
            end
            if initial.date<736000
                ghlub =2% size(initial.rawData2,2);
            else
                ghlub = 1;
            end
            triggersync_TTL = i2rawData2(1:size(i2rawData2,1),ghlub);
            %
            % if initial.heka_or_winedr == 0;
            %     initial.triggersync_hz = initial.sampl_fr;
            % end
            %
            %     if initial.triggersync_hz == 2000
            %     else
            %         factor = initial.triggersync_hz/2000;
            %
            %         triggersync_TTL_corrected  = zeros(round(length(triggersync_TTL)/factor),1);
            %
            %         for i = 1: size(triggersync_TTL_corrected,1)-2
            %             triggersync_TTL_corrected(i) = triggersync_TTL(round((i-1)*factor)+1);
            %         end
            %
            %         triggersync_TTL_bak = triggersync_TTL;
            %         clear triggersync_TTL
            %         triggersync_TTL = triggersync_TTL_corrected;
            %     end
            %
            %
            %     triggersync_TTL = -triggersync_TTL;
            
            %if EEG sampl-freq not 2 kHz:
            
            %
            %     prompt = {'EEG sampl-freq 2000 Hz?'};
            %     dlg_title = '1 yes, 0 if 10 kHz';
            %     num_lines = 1;
            %     def = {'1'};
            %     answer_fr = inputdlg(prompt,dlg_title,num_lines,def);
            %     answer_fr = str2mat(answer_fr);
            %     answer_fr = str2num(answer_fr);
            %
            %     if answer_fr
            %         ax = 2000
            %     else
            %         ax = 10000;
            %     end
            %
            %
            
            
            factor = ax/i2.triggersync_hz;
            EEG_results.ax = ax;
            EEG_TTL_corrected  = zeros(round(length(EEG_TTL)/factor),1);
            
            for i = 1: size(EEG_TTL_corrected,1)-1
                if round((i-1)*factor) < length(EEG_TTL)
                    EEG_TTL_corrected(i) = EEG_TTL(round((i-1)*factor)+1);
                end
            end
            
            EEG_TTL_bak = EEG_TTL;
            clear EEG_TTL
            EEG_TTL = EEG_TTL_corrected;
            
            
            EEG_corrected  = zeros(round(length(EEG)/factor),1);
            
            for i = 1: size(EEG_corrected,1)-1
                if round((i-1)*factor) < length(EEG)
                    EEG_corrected(i) = EEG(round((i-1)*factor)+1);
                end
            end
            
            EEG_bak = EEG;
            clear EEG
            EEG = EEG_corrected;
            
            if answer
                EEG_2_corrected  = zeros(round(length(EEG_2)/factor),1);
                
                for i = 1: size(EEG_2_corrected,1)-1
                    if round((i-1)*factor) < length(EEG_2)
                        EEG_2_corrected(i) = EEG_2(round((i-1)*factor)+1);
                    end
                end
                
                EEG_2_bak = EEG_2;
                clear EEG_2
                EEG_2 = EEG_2_corrected;
            end
            
            
            
            clear EEG_TTL_times EEG_TTL_time_vector
            EEG_TTL_times = 0;
            EEG_TTL_time_vector = 0;
            x = 1;
            i = 15;
            while i < size(EEG_TTL,1)-201
                if EEG_TTL(i+2,1) > EEG_TTL(i,1)+70
                    EEG_TTL_times(1,x) = i;
                    EEG_TTL_time_vector(i) = 100;
                    x = x+1;
                    i = round(i + 0.5*initial.sampl_fr);
                else
                    i = i+1;
                end
            end
            diffEEGTTL= diff(EEG_TTL_times);
            plot(diffEEGTTL)
            clear triggersync_TTL_times triggersync_TTL_time_vector
            triggersync_TTL_times = 0;
            triggersync_TTL_time_vector = 0;
            x = 1;
            i = 1;
            if initial.date<735000
                thrr=0.045;
            else
                thrr=55;
            end
            i=1;
            x=1;
            while i < size(triggersync_TTL,1)-201
                if triggersync_TTL(i+2) > triggersync_TTL(i)+thrr
                    triggersync_TTL_times(x) = i;
                    triggersync_TTL_time_vector(i) = 100;
                    x = x+1;
                    i =round( i + 3.5*i2.sampl_fr);
                else
                    i = i + 1;
                end
            end
            
            difftrigTTL= diff(triggersync_TTL_times);
            plot(difftrigTTL)
            % check alignment of  triggersync and blackrock recordings, assuming
            % blackrock sampl_fr = 2 kHz.
            %initial.triggersync_hz = initial.sampl_fr;
            
            if size(EEG_TTL_times,2) > size(triggersync_TTL_times,2)
                x = size(triggersync_TTL_times,2);
            else
                x = size(EEG_TTL_times,2);
            end
            
            for i = 1:x-1
                blackrock_segments_ms(i) = (EEG_TTL_times(i+1) - EEG_TTL_times(i))/i2.triggersync_hz;
                triggersync_segments(i) = (triggersync_TTL_times(i+1) - triggersync_TTL_times(i))/i2.triggersync_hz;
            end
            
            % results.deltaf_matrix = deltaf_matrix_stargazer;
            
            
            
            
            
            %check if there was shift and how much
            fact = i2.triggersync_hz/1000
            
            if size(triggersync_TTL_times,2) > size(EEG_TTL_times,2)
                max_TTL_number = size(EEG_TTL_times,2);
            else
                max_TTL_number = size(triggersync_TTL_times,2);
            end
            
            shift_ms_1 = (EEG_TTL_times(1,1) - triggersync_TTL_times(1,1))/fact;
            
            shift_ms_2 = (EEG_TTL_times(1,max_TTL_number) - triggersync_TTL_times(1,max_TTL_number))/fact;
            
            if abs(shift_ms_2) - abs(shift_ms_1) > 0
                shift_diff = abs(shift_ms_2) - abs(shift_ms_1);
            else
                shift_diff = abs(shift_ms_1) - abs(shift_ms_2);
            end
            
            if shift_diff < 32
                shift_ms = round((abs(shift_ms_1)+abs(shift_ms_2))/2);
            else
                return
                
            end
            
            if shift_ms_2 > 0
                EEG_bak = EEG;
                EEG_TTL_bak = EEG_TTL;
                EEG(1:ceil(shift_ms*fact)) = [];
                EEG_TTL(1:ceil(shift_ms*fact)) = [];
            else
                EEG_bak = EEG;
                EEG = zeros(size(EEG,1)+ceil(shift_ms*fact),1);
                EEG((ceil(shift_ms*fact))+1:size(EEG,1)) = EEG_bak;
                EEG_TTL_bak = EEG_TTL;
                EEG_TTL = zeros(size(EEG_TTL,1)+ceil(shift_ms*fact),1);
                EEG_TTL(ceil(shift_ms*fact)+1:size(EEG_TTL,1)) = EEG_TTL_bak;
            end
            
            
            if answer
                if shift_ms_2 > 0
                    EEG_2_bak = EEG_2;
                    
                    EEG_2(1:ceil(shift_ms*fact)) = [];
                    
                else
                    EEG_2_bak = EEG_2;
                    EEG_2 = zeros(size(EEG_2,1)+ceil(shift_ms*fact),1);
                    EEG_2(ceil(shift_ms*fact)+1:size(EEG_2,1)) = EEG_2_bak;
                    
                end
                EEG_results.EEG_2 = EEG_2;
                EEG_results.shift_ms_2 = shift_ms_2;
                
            end
            
            
            EEG_results.shift_ms = shift_ms;
            EEG_results.EEG = EEG;
            
            
            max_ch = size(i2rawData2,2)
            if initial.PD_only == 0;
                for i=2:max_ch
                    plot(i2rawData2(1:1000000,i))
                    prompt = {'Is this the voltage trace (1) or not (0) ?'};
                    dlg_title = '1 if yes, 0 if no';
                    num_lines = 1;
                    def = {'1'};
                    answe = inputdlg(prompt,dlg_title,num_lines,def);
                    answe = str2mat(answe);
                    answe = str2num(answe);
                    if answe
                        x=i;
                    end
                    close all
                end
                
                
                voltage_trace = i2rawData2(:,x);
                if imaged
                    voltage_trace(1:i2.frame_times(1,1)-1,:) = [];
                end
                EEG_results.voltage_trace = voltage_trace;
                fr = i2.triggersync_hz;
                Vm_extrap  = zeros(round(length(EEG_results.voltage_trace)/(fr/freq)),1);
                size(Vm_extrap)
                size(EEG_results.voltage_trace)
                for i = 1: size(Vm_extrap,1)
                    Vm_extrap(i) = EEG_results.voltage_trace(round((i-1)*fr/freq)+1);
                end
                
                EEG_results.Vm_extrap = Vm_extrap;
            end
            
        else
            if sum(EEG_results.EEG)==0
            else
                if imaged
                    if i2.frame_times(1,1) > 10
                        
                        EEG_results.EEG(1:i2.frame_times(1,1)-1,:) = [];
                        if answer
                            EEG_results.EEG_2(1:i2.frame_times(1,1)-1,:) = [];
                        end
                    end
                end
                if initial.PD_only == 0
                    
                    if NB208_aft16
                        x = 2;
                    else
                        
                        for i=2:max_ch
                            plot(i2rawData2(1:1000000,i))
                            prompt = {'Is this the voltage trace (1) or not (0) ?'};
                            dlg_title = '1 if yes, 0 if no';
                            num_lines = 1;
                            def = {'1'};
                            answe = inputdlg(prompt,dlg_title,num_lines,def);
                            answe = str2mat(answe);
                            answe = str2num(answe);
                            if answe
                                x=i;
                            end
                            close all
                        end
                    end
                    
                    voltage_trace = i2rawData2(:,x);
                    if imaged
                        voltage_trace(1:i2.frame_times(1,1)-1,:) = [];
                    end
                    EEG_results.voltage_trace = voltage_trace;
                    fr = i2.triggersync_hz;
                    Vm_extrap  = zeros(round(length(EEG_results.voltage_trace)/(fr/freq)),1);
                    size(Vm_extrap)
                    size(EEG_results.voltage_trace)
                    for i = 1: size(Vm_extrap,1)
                        Vm_extrap(i) = EEG_results.voltage_trace(round((i-1)*fr/freq)+1);
                    end
                    
                    EEG_results.Vm_extrap = Vm_extrap;
                    
                    %interpolate patched cell voltage trace to triggersync_hz sampl.
                    %frequency
                    
                    freq = i2.triggersync_hz;
                    if imaged && isempty(cat_signal) ==0
                        stimcell_DF_interp_to_Vm  = zeros(ceil(length(cat_signal)*i2.msperline/1000*freq),1);
                        %
                        %        k=1
                        %             j = 1;
                        %             i = 2;
                        %             while i <= length(stimcell_DF_interp_to_Vm)-10
                        %                 %deltaf_interp (i,1) = i/freq;
                        %                 if (j*i2.msperline/1000 >= i/freq) && (j*i2.msperline/1000 <= i/freq+1/freq)...
                        %                         && stimcell_DF_interp_to_Vm(i,k) == 0 %&& results.cat_signal_interp(1,k) == 0
                        %                     if j*i2.msperline-i/freq <= i+1/freq - j*i2.msperline
                        %                         stimcell_DF_interp_to_Vm(i,k) = matrix(j,k);
                        %                     else
                        %                         stimcell_DF_interp_to_Vm(i+1,k) = matrix(j,k);
                        %                     end
                        %                     j=j+1
                        %                 end
                        %                 i=i+1;
                        %             end
                        %
                        %
                        %         stimcell_DF_interp_to_Vm(stimcell_DF_interp_to_Vm==0)= NaN;
                        %         for i = 1:size(stimcell_DF_interp_to_Vm,2)
                        %             stimcell_DF_interp_to_Vm(1:size(stimcell_DF_interp_to_Vm,1),i)...
                        %                 = inpaint_nans(stimcell_DF_interp_to_Vm(1:size(stimcell_DF_interp_to_Vm,1),i));
                        %         end
                        %
                        %         EEG_results.stimcell_DF_interp_to_Vm = stimcell_DF_interp_to_Vm;
                        %
                        
                        
                        
                        k = patched_cell_ROI
                        a=1;
                        j = 1;
                        i = 2;
                        while i <= length(stimcell_DF_interp_to_Vm)-10
                            %deltaf_interp (i,1) = i/freq;
                            if (j*i2.msperline/1000 >= i/freq) && (j*i2.msperline/1000 <= i/freq+1/freq)...
                                    && stimcell_DF_interp_to_Vm(i,k) == 0 %&& deltaf_interp(i-1,k) == 0
                                if j*i2.msperline-i/freq <= i+1/freq - j*i2.msperline
                                    stimcell_DF_interp_to_Vm(i,k) = matrix(j,k);
                                    if matrix(j,k)==0
                                        zerodf(1,a) = i;
                                        a=a+1;
                                    end
                                else
                                    stimcell_DF_interp_to_Vm(i+1,k) = matrix(j,k);
                                    if matrix(j,k)==0
                                        zerodf(1,a) = i+1;
                                        a=a+1;
                                    end
                                end
                                j=j+1;
                            end
                            i=i+1;
                        end
                        
                        
                        forw = ceil(i2.msperline/(1000/freq));
                        %             %deltaf_stimcell_interp = deltaf_stimcell_interp_bak;
                        deltaf_interp_new = stimcell_DF_interp_to_Vm;
                        %
                        %             %results.deltaf_interp_values(results.deltaf_interp_values==0)= NaN;
                        %             i = 1
                        %             a=1;
                        %             naninds = 0;
                        %             if stimcell_interp_to_Vm
                        %                 for j = 1:length(stimcell_DF_interp_to_Vm)
                        %                     stimc_interp_step = j
                        %                     if j<length(stimcell_DF_interp_to_Vm)-forw
                        %                         if sum(stimcell_DF_interp_to_Vm(j:j+forw,i))>0
                        %                             curr = find(stimcell_DF_interp_to_Vm(j:j+forw,i)==0)+j-1;
                        %                             c = length(curr);
                        %                             naninds(1,a:a+c-1) = curr;
                        %                             a=a+c;
                        %                             %results.deltaf_interp_values(find(results.deltaf_interp_values(j:j+forw,i)==0)',i)= NaN;
                        %                         end
                        %                     else
                        %                         if stimcell_DF_interp_to_Vm(j,i) == 0;
                        %                             naninds(1,a) = j;
                        %                             a=a+1;
                        %                             %results.deltaf_interp_values(j,i) = NaN;
                        %                         end
                        %                     end
                        %                 end
                        %             end
                        
                        
                        
                        a = 1
                        j = 1
                        while a<length(stimcell_DF_interp_to_Vm)
                            stimc_interp_step = a;
                            
                            if stimcell_DF_interp_to_Vm(a,1) == 0
                                naninds(1,j) = a;
                                j = j+1;
                                a=a+1;
                            else
                                a=a+1;
                                
                                
                            end
                        end
                        
                        %remove duplicates from naninds
                        
                        deltaf_interp_new(unique(naninds),1)= NaN;
                        
                        deltaf_interp_new(1:size(stimcell_DF_interp_to_Vm,1),1)...
                            = inpaint_nans(deltaf_interp_new(1:size(stimcell_DF_interp_to_Vm,1),1));
                        
                        % results.deltaf_interp_values = deltaf_interp_values;
                        deltaf_interp_avg = mean(deltaf_interp_new,2);
                        
                        EEG_results.stimcell_DF_interp_to_Vm_avg = deltaf_interp_avg;
                        EEG_results.stimcell_DF_interp_to_Vm = deltaf_interp_new;
                    end
                end
            end
        end
        
    end
else
    EEG_results.EEG = 0;
end
% triggersync_TTL = triggersync_TTL*1000;

%initial.trig_factor = 1000/initial.sampl_fr;

%  %cut the first part of both traces to align timing
%
% EEG(1:EEG_TTL_times(1)-1) = [];
%
% EEG_TTL(1:EEG_TTL_times(1)-1) = [];

freq = 100;

if isfield(i2,'rawData2')
    
    fr = i2.triggersync_hz
    
    
    if EEG_results.EEG==0
    else
        EEG_extrap  = zeros(round(length(EEG_results.EEG)/(fr/freq)),1);
        if onep
            EKG_extrap = zeros(round(length(EEG_results.EEG)/(fr/freq)),1);
        end
        
        for i = 1: size(EEG_extrap,1)
            EEG_extrap(i) = EEG_results.EEG(round((i-1)*fr/freq)+1);
            if onep
                EKG_extrap(i) = EEG_results.EKG(round((i-1)*fr/freq)+1);
            end
        end
        if onep 
            EEG_results.EKG_extrap = EKG_extrap; end
        
        EEG_results.EEG_extrap = EEG_extrap;
        if answer
            EEG_2_extrap  = zeros(round(length(EEG_results.EEG_2)/(fr/freq)),1);
            for i = 1: size(EEG_2_extrap,1)
                EEG_2_extrap(i) = EEG_results.EEG_2(round((i-1)*fr/freq)+1);
            end
            EEG_results.EEG_2_extrap = EEG_2_extrap;
            
        end
        
        if initial.NB208 == 0
            
            EEG_TTL_extrap  = zeros(round(length(EEG_TTL)/(fr/freq)),1);
            
            for i = 1: size(EEG_TTL_extrap,1)
                EEG_TTL_extrap(i) = EEG_TTL(round((i-1)*fr/freq)+1);
            end
            EEG_results.EEG_TTL_extrap = EEG_TTL_extrap;
        end
        % deltaf_matrix = deltaf_matrix_stargazer;
    end
    
end


if ap.man
    
    prompt = {'used microscope?(1) or not (0) ?'};
    dlg_title = '1 if images present, 0 if not';
    num_lines = 1;
    def = {'1'};
    answer_m = inputdlg(prompt,dlg_title,num_lines,def);
    answer_m = str2mat(answer_m);
    answer_m = str2num(answer_m);
    
else
    if ap.um
        answer_m = 1;
        %         answer_m = str2mat(answer_m);
        %         answer_m = str2num(answer_m);
        
    else
        answer_m = 0;
        %         answer_m = str2mat(answer_m);
        %         answer_m = str2num(answer_m);
        
    end
    
    
end

if answer_m && isempty(matrix)==0
    
    if ap.man
        prompt = {'used deltaf_matrix?(1) FoltMat2_3000 (0) ?'};
        dlg_title = '1 if deltaf, 0 if FiltMat2_3000';
        num_lines = 1;
        def = {'1'};
        answer_deltaf = inputdlg(prompt,dlg_title,num_lines,def);
        answer_deltaf = str2mat(answer_deltaf);
        answer_deltaf = str2num(answer_deltaf);
    else
        if ap.DF_o_Fi
            answer_deltaf = 1;
            %             answer_deltaf = str2mat(answer_deltaf);
            %             answer_deltaf = str2num(answer_deltaf);
        else
            answer_deltaf = 0;
            %             answer_deltaf = str2mat(answer_deltaf);
            %             answer_deltaf = str2num(answer_deltaf);
        end
    end
    
    clear smooth_deltaf_matrix
    %Vogelstein deconvolution
    % initial.samplingratehz = i2.msperline;
    
    if answer_deltaf
        s_f = floor(i2.samplingratehz/2);
        
        if mod(s_f,2)
        else
            s_f = s_f - 1;
        end
        
        for i = 1:size(matrix,2)
            smooth_deltaf_matrix(:,i) = smooth(matrix(:,i),s_f);
        end
        
        %smooth_deltaf_matrix = deltaf_matrix;
        
        
        indicator = initial.indicator;
        i2.msperline_bak=i2.msperline;
        i2.msperline = round(i2.msperline,3)
        fps = 1000/i2.msperline;
        traceOpt.trace_computation = 'oopsi';
        traces = smooth_deltaf_matrix;
        oopsi_spike_trace = filterTraces( traces, fps, traceOpt,indicator,initial );
        smooth_oopsi_filtered_deltaf_matrix = oopsi_spike_trace;
        clear oopsi_spike_trace
        EEG_results.oopsi_filtered_smooth_deltaf_matrix_JM_EDITED_ALGORITHM = smooth_oopsi_filtered_deltaf_matrix;
        
    else
        smooth_oopsi_filtered_deltaf_matrix = deconv_mat;
        smooth_deltaf_matrix = matrix;
        EEG_results.oopsi_filtered_smooth_deltaf_matrix_JM_EDITED_ALGORITHM = deconv_mat;
         i2.msperline_bak=i2.msperline;
        i2.msperline = round(i2.msperline,3);
        fps = 1000/i2.msperline;
    end
    
    %EEG_results.P_best = P_best;
    %EEG_results.V = V;
    
    %
    % traces = deltaf_matrix;
    % oopsi_spike_trace = filterTraces( traces, fps, traceOpt );
    % oopsi_filtered_deltaf_matrix = oopsi_spike_trace;
    % clear oopsi_spike_trace
    % results.oopsi_filtered_deltaf_matrix = oopsi_filtered_deltaf_matrix;
    %
    % for i = 1:size(deltaf_matrix,2)
    % diff_smooth_oopsi(:,i) = diff(smooth_oopsi_filtered_deltaf_matrix(:,i));
    % end
    %
    %
    % for i = 1:size(deltaf_matrix,2)
    % diff_smooth_deltaf(:,i) = diff(smooth_deltaf_matrix(:,i));
    % end
    %
    % results.diff_smooth_deltaf = diff_smooth_deltaf;
    
    if i2.msperline > 10
        
        %interpolate deltaf_matrix to freq
        %     s_f = 5;
        %     %deltaf_matrix = smooth(results.deltaf_matrix(:,1),s_f);
        %     for i = 1 : size(results.deltaf_matrix,2)
        %         deltaf_matrix(:,i) = smooth(results.deltaf_matrix(:,i),s_f);
        %     end
        %%%%%%%%%      %%%%%%%%%%%%%%
        if i2.msperline<2
            freq = 500;
        end
        deltaf_interp  = zeros(ceil(freq*length(smooth_deltaf_matrix)*i2.msperline/1000),size(smooth_deltaf_matrix,2));
        
        for k = 1:size(smooth_deltaf_matrix,2)
            a=1;
            j = 1;
            i = 2;
            deltaf_interp_ROI = k
            while i <= length(deltaf_interp)-10
                %deltaf_interp (i,1) = i/freq;
                if (j*i2.msperline/1000 > i/freq-1/(2*freq)) && (j*i2.msperline/1000 <= i/freq+1/freq)...
                        && deltaf_interp(i,k) == 0 %&& deltaf_interp(i-1,k) == 0
                    
                    if j*i2.msperline/1000-i/freq <= (i+1)/freq - j*i2.msperline/1000
                        deltaf_interp(i,k) = smooth_deltaf_matrix(j,k);
                        if smooth_deltaf_matrix(j,k)==0
                            zerodf(1,a) = i;
                            a=a+1;
                        end
                    else
                        deltaf_interp(i+1,k) = smooth_deltaf_matrix(j,k);
                        if smooth_deltaf_matrix(j,k)==0
                            zerodf(1,a) = i+1;
                            a=a+1;
                        end
                    end
                    j=j+1;
                end
                i=i+1;
            end
        end
        
        
        cat_signal_interp  = zeros(ceil(freq*length(cat_signal)*i2.msperline/1000),size(cat_signal,2));
        
        for k = 1:size(cat_signal,2)
            j = 1;
            i = 2;
            cat_signal_interp_ROI = k
            while i <= length(cat_signal_interp)-10
                %deltaf_interp (i,1) = i/freq;
                if (j*i2.msperline/1000 > i/freq-1/(2*freq)) && (j*i2.msperline/1000 <= i/freq+1/freq)...
                        && cat_signal_interp(i,k) == 0 % && results.cat_signal_interp(i-1,k) == 0
                    if j*i2.msperline/1000-i/freq <= (i+1)/freq - j*i2.msperline/1000
                        cat_signal_interp(i,k) = cat_signal(j,k);
                        if cat_signal(j,k)==0
                            %zerocat(1,a) = i;
                            a=a+1;
                        end
                    else
                        cat_signal_interp(i+1,k) = cat_signal(j,k);
                        if cat_signal(j,k)==0
                            %zerocat(1,a) = i+1;
                            a=a+1;
                        end
                    end
                    j=j+1;
                end
                i=i+1;
            end
        end
        
        forw = ceil(i2.msperline/(1000/freq));
        
        cat_signal_interp_values = cat_signal_interp;
        
        %results.cat_signal_interp_values(results.cat_signal_interp_values==0)= NaN;
        
        for i = 1:size(cat_signal_interp_values,2)
            a=1;
            naninds = 0;
            inpaint_nans_cat_signal_ROI = i
            for j = 1:length(cat_signal_interp_values)
                if j<length(cat_signal_interp_values)-forw
                    if sum(cat_signal_interp_values(j:j+forw,i))>0
                        curr = find(cat_signal_interp_values(j:j+forw,i)==0)+j-1;
                        c = length(curr);
                        naninds(1,a:a+c-1) = curr;
                        a=a+c;
                        %results.deltaf_interp_values(find(results.deltaf_interp_values(j:j+forw,i)==0)',i)= NaN;
                    end
                else
                    if cat_signal_interp_values(j,i) == 0;
                        naninds(1,a) = j;
                        a=a+1;
                        %results.deltaf_interp_values(j,i) = NaN;
                    end
                end
            end
            
            %remove duplicates from naninds
            
            cat_signal_interp_values(unique(naninds),i)= NaN;
            
            cat_signal_interp_values(1:size(cat_signal_interp_values,1),i)...
                = inpaint_nans(cat_signal_interp_values(1:size(cat_signal_interp_values,1),i));
        end
        EEG_results.cat_signal_naninds = naninds;
        
        cat_signal_interp = cat_signal_interp_values;
        
        
        %%% extrapolate DF in case msperline<20
        if i2.msperline < 20
            fr = i2.samplingratehz;%500;
            freqq = 100;
            cat_signal_interp_final  = zeros(round(length(cat_signal_interp)/(fr/freqq)),size(smooth_deltaf_matrix,2));
            for kp = 1:size(smooth_deltaf_matrix,2)
                for i = 1: size(cat_signal_interp_final,1)-1
                    cat_signal_interp_final(i,kp) = cat_signal_interp(round((i-1)*fr/freqq)+1,kp);
                end
            end
        else
            cat_signal_interp_final = cat_signal_interp;
        end
        
        
        EEG_results.cat_signal_interp_values = cat_signal_interp_final;
        
        clear deltaf_stimcell_interp_values_rerun
        
        %deltaf_stimcell_interp = deltaf_stimcell_interp_bak;
        deltaf_interp_new = deltaf_interp;
        
        %results.deltaf_interp_values(results.deltaf_interp_values==0)= NaN;
        for i = 1:size(deltaf_interp,2)
            a=1;
            naninds = 0;
            inpaint_nans_deltaf_ROI = i
            for j = 1:length(deltaf_interp)
                if j<length(deltaf_interp)-forw
                    if sum(deltaf_interp(j:j+forw,i))>0
                        curr = find(deltaf_interp(j:j+forw,i)==0)+j-1;
                        c = length(curr);
                        naninds(1,a:a+c-1) = curr;
                        a=a+c;
                        %results.deltaf_interp_values(find(results.deltaf_interp_values(j:j+forw,i)==0)',i)= NaN;
                    end
                else
                    if deltaf_interp(j,i) == 0;
                        naninds(1,a) = j;
                        a=a+1;
                        %results.deltaf_interp_values(j,i) = NaN;
                    end
                end
            end
            
            %remove duplicates from naninds
            
            deltaf_interp_new(unique(naninds),i)= NaN;
            
            deltaf_interp_new(1:size(deltaf_interp,1),i)...
                = inpaint_nans(deltaf_interp_new(1:size(deltaf_interp,1),i));
        end
        % results.deltaf_interp_values = deltaf_interp_values;
        EEG_results.deltaf_naninds = naninds;
        %%% extrapolate DF in case msperline<20
        if i2.msperline < 20
            fr = i2.samplingratehz;%500;
            freqq = 100;
            deltaf_interp_final  = zeros(round(length(deltaf_interp_new)/(fr/freqq)),size(smooth_deltaf_matrix,2));
            for kp = 1:size(smooth_deltaf_matrix,2)
                for i = 1: size(deltaf_interp_final,1)-1
                    deltaf_interp_final(i,kp) = deltaf_interp_new(round((i-1)*fr/freqq)+1,kp);
                end
            end
        else
            deltaf_interp_final = deltaf_interp_new;
        end
        
        
        deltaf_interp_avg = mean(deltaf_interp_final,2);
        
        EEG_results.deltaf_interp_avg = deltaf_interp_avg;
        EEG_results.deltaf_interp_values = deltaf_interp_final;
        
        
        
        
        %%%%%%% oopsi_interp
        oopsi_interp  = zeros(ceil(length(deconv_mat)*i2.msperline/1000*freq),...
            size(deconv_mat,2));
        
        for k = 1:size(deconv_mat,2)
            a=1;
            j = 1;
            i = 2;
            oopsi_interp_ROI = k
            while i <= length(oopsi_interp)-10
                %deltaf_interp (i,1) = i/freq;
                if (j*i2.msperline/1000 > i/freq-1/(2*freq)) && (j*i2.msperline/1000 <= i/freq+1/freq)...
                        && oopsi_interp(i,k) == 0 %&& deltaf_interp(i-1,k) == 0
                    if j*i2.msperline/1000-i/freq <= (i+1)/freq - j*i2.msperline/1000
                        oopsi_interp(i,k) = deconv_mat(j,k);
                        if deconv_mat(j,k)==0
                            zerodf(1,a) = i;
                            a=a+1;
                        end
                    else
                        oopsi_interp(i+1,k) = deconv_mat(j,k);
                        if deconv_mat(j,k)==0
                            zerodf(1,a) = i+1;
                            a=a+1;
                        end
                    end
                    j=j+1;
                end
                i=i+1;
            end
        end
        
        oopsi_interp_new = oopsi_interp;
        %results.deltaf_interp_values(results.deltaf_interp_values==0)= NaN;
        for i = 1:size(oopsi_interp,2)
            a=1;
            naninds = 0;
            inpaint_nans_oopsi_ROI = i
            for j = 1:length(oopsi_interp)
                if j<length(oopsi_interp)-forw
                    if sum(oopsi_interp(j:j+forw,i))>0
                        curr = find(oopsi_interp(j:j+forw,i)==0)+j-1;
                        c = length(curr);
                        naninds(1,a:a+c-1) = curr;
                        a=a+c;
                        %results.deltaf_interp_values(find(results.deltaf_interp_values(j:j+forw,i)==0)',i)= NaN;
                    end
                else
                    if oopsi_interp(j,i) == 0;
                        naninds(1,a) = j;
                        a=a+1;
                        %results.deltaf_interp_values(j,i) = NaN;
                    end
                end
            end
            
            %remove duplicates from naninds
            
            oopsi_interp_new(unique(naninds),i)= NaN;
            
            oopsi_interp_new(1:size(oopsi_interp,1),i)...
                = inpaint_nans(oopsi_interp_new(1:size(oopsi_interp,1),i));
        end
        % results.deltaf_interp_values = deltaf_interp_values;
        EEG_results.oopsi_naninds = naninds;
        
        %%% extrapolate DF in case msperline<20
        if i2.msperline < 2
            fr = 500;
            freqq = 100;
            oopsi_interp_final  = zeros(round(length(oopsi_interp_new)/(fr/freqq)),size(oopsi_interp_new,2));
            for kp = 1:size(smooth_deltaf_matrix,2)
                for i = 1: size(oopsi_interp_final,1)-1
                    oopsi_interp_final(i,kp) = oopsi_interp_new(round((i-1)*fr/freqq)+1,kp);
                end
            end
        else
            oopsi_interp_final = oopsi_interp_new;
        end
        
        oopsi_interp_avg = mean(oopsi_interp_final,2);
        
        EEG_results.oopsi_interp_avg = oopsi_interp_avg;
        oopsi_interp = oopsi_interp_final;
        
        EEG_results.oopsi_interp_values = oopsi_interp;
        
        %%%%%%%%%%
        
        
    else
        if i2.msperline == 10
            EEG_results.cat_signal_interp_values = cat_mat;
            EEG_results.deltaf_interp_values = matrix;
            EEG_results.oopsi_interp_values = deconv_mat;
            oopsi_interp_final= deconv_mat;
        else
            fr = i2.samplingratehz;
            freqq = 100;
            cat_signal_interp_final  = zeros(round(length(cat_signal)/(fr/freqq)),size(smooth_deltaf_matrix,2));
            for kp = 1:size(smooth_deltaf_matrix,2)
                for i = 1: size(cat_signal_interp_final,1)
                    cat_signal_interp_final(i,kp) = cat_signal(round((i-1)*fr/freqq)+1,kp);
                end
            end
            EEG_results.cat_signal_interp_values = cat_signal_interp_final;
            
            
            deltaf_interp_final  = zeros(round(length(smooth_deltaf_matrix)/(fr/freqq)),size(smooth_deltaf_matrix,2));
            for kp = 1:size(smooth_deltaf_matrix,2)
                for i = 1: size(deltaf_interp_final,1)
                    deltaf_interp_final(i,kp) = smooth_deltaf_matrix(round((i-1)*fr/freqq)+1,kp);
                end
            end
            deltaf_interp_avg = mean(deltaf_interp_final,2);
            EEG_results.deltaf_interp_avg = deltaf_interp_avg;
            EEG_results.deltaf_interp_values = deltaf_interp_final;
            
            
            oopsi_interp_final  = zeros(round(length(deconv_mat)/(fr/freqq)),size(smooth_deltaf_matrix,2));
            for kp = 1:size(smooth_deltaf_matrix,2)
                for i = 1: size(oopsi_interp_final,1)
                    oopsi_interp_final(i,kp) = deconv_mat(round((i-1)*fr/freqq)+1,kp);
                end
            end
        end
        
        oopsi_interp_avg = mean(oopsi_interp_final,2);
        EEG_results.oopsi_interp_avg = oopsi_interp_avg;
        oopsi_interp = oopsi_interp_final;
        EEG_results.oopsi_interp_values = oopsi_interp;
        
        %
        %
        %     EEG_2_extrap  = zeros(round(length(EEG_results.EEG_2)/(fr/freq)),1);
        %     for i = 1: size(EEG_2_extrap,1)
        %         EEG_2_extrap(i) = EEG_results.EEG_2(round((i-1)*fr/freq)+1);
        %     end
        %     EEG_results.EEG_2_extrap = EEG_2_extrap;
        %
        
        
        %%%%%%%%%extrapolate deltaf_signal in case of linescan
        
        %
        %
        %         d=fdesign.lowpass('N,Fc',20,1000,initial.samplingratehz);
        %         designmethods(d)
        %         % only valid design method is FIR window method
        %         Hd = design(d);
        %         % Display filter magnitude response
        %         fvtool(Hd);
        %
        %
        %         x = matrix(:,15);
        %
        %
        %         y = filter(Hd,x);
        %
        %     end
        %     %results.deltaf_interp = results.deltaf_interp_values;
        %
        
    end
    
    
    
    clear deltaf_interp
    if EEG_results.EEG==0
    else
        EEG_extrap = EEG_extrap/1000000;
        EEG_results.EEG_extrap = EEG_extrap;
        if answer
            EEG_2_extrap = EEG_2_extrap/1000000;
            EEG_results.EEG_2_extrap = EEG_2_extrap;
        end
        
        freq=100;
        if initial.NB208 == 0
            triggersync_TTL_extrap  = zeros(ceil(length(triggersync_TTL)/(i2.triggersync_hz/freq)),1);
            
            
            for i = 1: size(triggersync_TTL_extrap,1)-1
                triggersync_TTL_extrap(i) = triggersync_TTL(round((i-1)*(i2.triggersync_hz/freq))+1);
            end
            
            
            % triggersync_TTL_extrap = triggersync_TTL_extrap*1000;
            
            triggersync_TTL_extrap(1) = 0;
            
            EEG_results.triggersync_TTL_extrap = triggersync_TTL_extrap;
        end
        % EEG_TTL_extrap = EEG_TTL_extrap/1000+1;
        
        EEG_extrap_inv = EEG_extrap';
        %
        % % BP-filter EEG trace between 1 and 45 Hz
        % x = EEG_extrap_inv;
        % h=fdesign.bandpass('N,F3dB1,F3dB2',10,2,45,freq);
        % d1 = design(h,'butter');
        % y = filtfilt(d1.sosMatrix,d1.ScaleValues,x);
        %
        % if answer
        %
        %     EEG_2_extrap_inv = EEG_2_extrap';
        %
        %
        %     x_2 = EEG_2_extrap_inv;
        %     h=fdesign.bandpass('N,F3dB1,F3dB2',20,1,15,freq);
        %     d1 = design(h,'butter');
        %     y_2 = filtfilt(d1.sosMatrix,d1.ScaleValues,x_2);
        % end
        %
        
        
        cd(Folder_master)
        cd(Folder)
        
        save([Folder 'EEG_extrap_002.txt' ] ,'EEG_extrap','-ASCII', '-tabs');
        
        if answer
            save([Folder 'EEG_2_extrap_002.txt' ] ,'EEG_2_extrap','-ASCII', '-tabs');
        end
        
        %
        % % split deltaf-traces into cellular, astrocytic and neuropile signals
        %
        % if initial.linescan ==0
        %     prompt = {'number of first astrocyte?'};
        %     dlg_title = 'number of first astrocyte';
        %     num_lines = 1;
        %     def = {'76'};
        %     answer = inputdlg(prompt,dlg_title,num_lines,def);
        %     answer = str2mat(answer);
        %     results.first_astro = str2num(answer);
        %
        %
        %     prompt = {'number of first neuropil patch?'};
        %     dlg_title = 'number of first neuropil patch';
        %     num_lines = 1;
        %     def = {'88'};
        %     answer = inputdlg(prompt,dlg_title,num_lines,def);
        %     answer = str2mat(answer);
        %     results.first_neuropil = str2num(answer);
        %
        %
        %     for i = 1:size(results.deltaf_interp_values,1)
        %         results.avg_neuron_deltaf_interp(i) = mean(results.deltaf_interp_values(i,2:results.first_astro-1));
        %         results.avg_astro_deltaf_interp(i) = mean(results.deltaf_interp_values(i,results.first_astro:results.first_neuropil-1));
        %         results.avg_neuropil_deltaf_interp(i) = mean(results.deltaf_interp_values(i,results.first_neuropil:size(results.deltaf_interp_values,2)));
        %     end
        %
        %     y = y/10;
        %
        % end
        %
        
        
        %%%%%next section only valid if EEG_filt is still at 2 kHz!!!!
        
        %
        %
        % EEG_filt_extrap  = zeros(round(length(EEG_filt)*0.5/1000*freq),1);
        %
        % for i = 1: size(EEG_filt_extrap,1)
        %     EEG_filt_extrap(i) = EEG_filt((i-1)*20+1);
        % end
        %
        % if answer
        %
        %     EEG_2_filt_extrap  = zeros(round(length(EEG_2_filt)*0.5/1000*freq),1);
        %
        %     for i = 1: size(EEG_2_filt_extrap,1)
        %         EEG_2_filt_extrap(i) = EEG_2_filt((i-1)*20+1);
        %     end
        % end
        %
        %
    end
    
end



