

%for iii = 1:length(subfolders)


Folder = subfolders(iii).name;
cd(Folder_master)
cd(Folder)
clear gtemp g
recording(iii).initial1.blackpix = 0
%initial = recording(iii).initial;
recording(iii).swap_x_y = 0;
%     if no_raw_tiffs==0 &&  size(recording(iii).initial1.g,1) == 1 && size(recording(iii).initial1.g,2) == 1
%         if redoing_blackpix_corr_but_not_a_ZH_recording
%
%
%             if isempty(recording(iii).initial.Stack_ch1)
%                 namee = recording(iii).initial.Stack_ch2(1,1).name;
%             else
%                 namee = recording(iii).initial.Stack_ch1(1,1).name;
%             end
%             gtemp  = imread (namee); %, 'tif');
%
%             gtemp = int16(gtemp);
%
%             g (:,:,1) = gtemp;
%
%
%         else
%             if (size(recording(iii).initial1.g,1) == 1 && size(recording(iii).initial1.g,2) == 1) || ZH_recording
%
%                 if ZH_recording == 0
%
%                     gtemp  = imread (recording(iii).initial.Stack_ch2(1,1).name, 'tif');
%
%                 else
%
%                     foldername = strcat(Folder_master,Folder); % 'F:\stargazer\stg-N1131\11-20-18\';
%
%
%                     filetype = 'tif'; % type of files to be processed
%                     % Types currently supported .tif/.tiff, .h5/.hdf5, .raw, .avi, and .mat files
%                     files = dir(['*.',filetype]);
%
%                     pa=0
%                     po=1
%                     while pa==0
%                         if length(files(po).name) ==47
%                             pa=1;
%
%                             gtemp  = (imread (files(po).name, 'tif', 1))+(imread (files(po).name, 'tif', 2))...
%                                 +(imread (files(po).name, 'tif', 3))+(imread (files(po).name, 'tif', 4));
%
%
%                         else
%                             po=po+1;
%                         end
%
%
%                     end
%
%
%                 end
%
%                 gtemp = int16(gtemp);
%
%                 g (:,:,1) = gtemp;%(:,:,1);
%
%             else
%
%                 g(:,:,1) = recording(iii).initial1.g(:,:,1);
%
%             end
%         end
%
%     else
%
%         if size(recording(iii).initial1.g,1) > 1
%
%             g(:,:,1) = recording(iii).initial1.g(:,:,1);
%
%         else
%

dirss = dir;
matchy = 0;
for ih = 1:size(dirss,1)
    
    if strcmp(dirss(ih).name,'References')
        matchy = 1;
    end
end
if matchy
    cd('References')
    ch1name = dir('*ch1-ch2*.tif');
    
   
    g  = (imread (ch1name.name, 'tif', 1));
%     
%      t = Tiff('ch1name.name','r');
% imageData = read(t);
    
    if g(1,1) == 32768
        
        g(g==32768) = 0;
    else
        if g(1,1) == 32977
            g(g==32977) = 0;
        end
    end
    if (size(g,1) == recording(iii).options.d1 && size(g,2) == recording(iii).options.d2) || (size(g,2) ==...
            recording(iii).options.d1 && size(g,1) == recording(iii).options.d2)
        
        if size(g,1)==recording(iii).initial.height
        else
            %initial.height = size(g,1);
            %initial.width = size(g,2);
            recording(iii).swap_x_y = 1;
            
            g_temp = g;
            g_temp = rot90(g_temp);
            g_temp = fliplr(g_temp);
            g=g_temp;
            %recording(iii).initial.height = initial.height;
            %recording(iii).initial.width = initial.width;
        end
        
        %     end
        assd = 1;
        recording(iii).initial1.blackpix=0;
        
        if recording(iii).initial.spiral_scan(1,iii)
            for k = 1:1 %size(g,3)
                for i = 1:recording(iii).initial.height
                    for j = 1:recording(iii).initial.width
                        if j<ceil(recording(iii).initial.width/2)  %left half
                            if i < ceil(recording(iii).initial.width/2) %top half
                                if g(i,j,k) <2 % == 0
                                    
                                    %                             g(i,j,k) = g(i+offs,j+offs,k);
                                    %                             r(i,j,k) = r(i+offs,j+offs,k);
                                    if k==1
                                        recording(iii).initial1.blackpix(assd,1) = (j-1)*recording(iii).initial.height+i;
                                        assd=assd+1;
                                    end
                                    
                                    
                                end
                            else   %bottom half
                                if g(i,j,k) <2 % == 0
                                    
                                    %                             g(i,j,k) = g(i-offs,j+offs,k);
                                    %                             r(i,j,k) = r(i-offs,j+offs,k);
                                    if k==1
                                        recording(iii).initial1.blackpix(assd,1) = (j-1)*recording(iii).initial.height+i;
                                        assd=assd+1;
                                    end
                                end
                            end
                        else   %right half
                            if i < ceil(recording(iii).initial.width/2) %top half
                                if g(i,j,k) <2 % == 0
                                    
                                    %                             g(i,j,k) = g(i+offs,j-offs,k);
                                    %                             r(i,j,k) = r(i+offs,j-offs,k);
                                    if k==1
                                        recording(iii).initial1.blackpix(assd,1) = (j-1)*recording(iii).initial.height+i;
                                        assd=assd+1;
                                    end
                                end
                            else   %bottom half
                                if g(i,j,k) <2 % == 0
                                    
                                    %                             g(i,j,k) = g(i-offs,j-offs,k);
                                    %                             r(i,j,k) = r(i-offs,j-offs,k);
                                    if k==1
                                        recording(iii).initial1.blackpix(assd,1) = (j-1)*recording(iii).initial.height+i;
                                        assd=assd+1;
                                    end
                                end
                            end
                        end
                    end
                end
            end
            testbp = zeros(recording(iii).initial.height,recording(iii).initial.width);
            testbp(recording(iii).initial1.blackpix) = 1;
            figure(2754)
            imagesc(testbp)
            saveas (2754,[ ' blackpix'  '.png' ],'png')
            
            %recording(iii).initial1 = initial1;
        else
            
            %make a black square
            
            recording(iii).initial1.blackpix(1:recording(iii).initial.height,1) = 1:recording(iii).initial.height;
            recording(iii).initial1.blackpix(recording(iii).initial.height+1:recording(iii).initial.height+recording(iii).initial.width-1,1) = ...
                recording(iii).initial.height+1:recording(iii).initial.height:recording(iii).initial.height*(recording(iii).initial.width-1)+1;
            recording(iii).initial1.blackpix(recording(iii).initial.height+recording(iii).initial.width:2*recording(iii).initial.height+recording(iii).initial.width-2,1) = ...
                recording(iii).initial.height*(recording(iii).initial.width-1)+2:recording(iii).initial.height*recording(iii).initial.width;
            recording(iii).initial1.blackpix(2*recording(iii).initial.height+recording(iii).initial.width-1:2*recording(iii).initial.height+2*recording(iii).initial.width-4,1) = ...
                2*recording(iii).initial.height:recording(iii).initial.height:recording(iii).initial.height*(recording(iii).initial.width-1);
            
            recording(iii).initial1.blackpix(2*recording(iii).initial.height+2*recording(iii).initial.width-3:3*recording(iii).initial.height+2*recording(iii).initial.width-6,1) = ...
                recording(iii).initial.height+2:2*recording(iii).initial.height-1;
            recording(iii).initial1.blackpix(3*recording(iii).initial.height-5+2*recording(iii).initial.width:3*recording(iii).initial.height+3*recording(iii).initial.width-9,1) = ...
                2*recording(iii).initial.height+2:recording(iii).initial.height:recording(iii).initial.height*(recording(iii).initial.width-2)+2;
            recording(iii).initial1.blackpix(3*recording(iii).initial.height+3*recording(iii).initial.width-8:4*recording(iii).initial.height+3*recording(iii).initial.width-12,1) = ...
                recording(iii).initial.height*(recording(iii).initial.width-2)+3:recording(iii).initial.height*(recording(iii).initial.width-1)-1;
            recording(iii).initial1.blackpix(4*recording(iii).initial.height+3*recording(iii).initial.width-11:4*recording(iii).initial.height+4*recording(iii).initial.width-16,1) = ...
                3*recording(iii).initial.height-1:recording(iii).initial.height:recording(iii).initial.height*(recording(iii).initial.width-2)-1;
            
            
            
            testbp = zeros(recording(iii).initial.height,recording(iii).initial.width);
            testbp(recording(iii).initial1.blackpix) = 1;
            figure(2754)
            imagesc(testbp)
            saveas (2754,[ ' blackpix'  '.png' ],'png')
            
            recording(iii).initial1.spiral_scan = 0;
        end
    else
        disp('reference wrong size!')
        pause on
    end
    
else
    disp('No reference folder!')
    pause on
end

%end


