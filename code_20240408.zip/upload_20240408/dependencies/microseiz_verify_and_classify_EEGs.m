


for iii = 1:size(recording,2)
    clear morlet_wavelet_1 morlet_wavelet_2
    rec=iii
    j = iii;
    
    
    freq = 1000;                                           %downsampling frequency (should be lower than original EEG smapling frequency)
    %some parameters for EEG preprocessing:
    fss = freq;
    steptime = 0.02; %in sec
    windowtime = 0.3; %in sec
    spectra_sf_Hz = 1/steptime;
    spec_fac = 100/spectra_sf_Hz;
    
    %parameters for identifying "low-frequency" seizure events and other
    %segments of interest
    ampthr_LF = 1.3; %in SD
    freqthr_LF = 1.5; %in SD
    initial_HP_filter_cutoff_Hz_LF = 1;
    initial_LP_filter_cutoff_Hz_LF = 200;
    freqband_lower_lim_LF = 0.5;  %in Hz, was 7 (06/26/18)
    freqband_upper_lim_LF = 40;  %in Hz, was 12 (06/26/18)
    min_seiz_length_LF = 0.5;%0.3;  %in sec
    min_seiz_Hz_LF = 0.5; % was 5 (06/25/18)
    min_num_seiz_LF = 0;
    min_seiz_ISI_LF = 0.5; %in sec
    
    %parameters for identifying "high-frequency" artifacts that need to be
    %removed
    ampthr_HF = 1.6; %in SD
    freqthr_HF = 1.5; %in SD
    initial_HP_filter_cutoff_Hz_HF = 20;
    initial_LP_filter_cutoff_Hz_HF = 500;
    freqband_lower_lim_HF = 40;  %in Hz
    freqband_upper_lim_HF = 400;  %in Hz
    min_seiz_length_HF = 0.2;  %in sec
    min_seiz_Hz_HF = 10;
    min_num_seiz_HF = 1;
    min_seiz_ISI_HF = 0.5; %in sec
    
    
    recording(j).initial.freq = freq;
    
    Folder = subfolders(j).name;
    
    analyzing_rec = j
    
    
    if recording(1).initial.datedr(1,j) == 0
        
    else
        
        if All_EEGs_extrap_1000s_already_prepared
        else
            
            if ~isfield(recording(j).initial,'rawData2') || ~isfield(recording(j),'initial2')
                Name2 = dir('*.csv'); % dir(strcat(Folder,'\*.csv'));
                FileName2 = Name2.name;
                recording(j).initial.rawData2 = csvread(FileName2,1,0);
                fs = 10000000/recording(j).initial.rawData2(10001,1);
            else
                fs = recording(j).initial2.sampl_fr;
            end
            
            if size(recording(j).initial.rawData2,2)<2
                wave = recording(j).initial2.rawData2(:,7)'; %recording(j).EEG_results_nonoise.EEG';
                wave2 = recording(j).initial2.rawData2(:,8)'; %recording(j).EEG_results_nonoise.EEG_2';
            else
                if size(recording(j).initial.rawData2,2)<7
                    wave = recording(j).initial.rawData2(:,2)'; %recording(j).EEG_results_nonoise.EEG';
                    wave2 = recording(j).initial.rawData2(:,3)';
                else
                    if isfield(recording(j).EEG_results_nonoise,'EEG')
                        wave = recording(j).EEG_results_nonoise.EEG';
                        wave2 = recording(j).EEG_results_nonoise.EEG_2';
                    else
                        wave = recording(j).initial.rawData2(:,7)'; %recording(j).EEG_results_nonoise.EEG';
                        wave2 = recording(j).initial.rawData2(:,8)'; %recording(j).EEG_results_nonoise.EEG_2';
                    end
                end
            end
            EEG_extrap_1000 = zeros(1,round(length(wave)/(fs/freq)));
            EEG_2_extrap_1000  = zeros(1,round(length(wave2)/(fs/freq)));
            for l = 1: size(EEG_2_extrap_1000,2)
                EEG_2_extrap_1000(1,l) = wave2(1,round((l-1)*fs/freq)+1);
            end
            for l = 1: size(EEG_extrap_1000,2)
                EEG_extrap_1000(1,l) = wave(1,round((l-1)*fs/freq)+1);
            end
            All_EEGs(j).EEG_extrap_1000 = EEG_extrap_1000;
            All_EEGs(j).EEG_2_extrap_1000 = EEG_2_extrap_1000;
        end
        % In teh following loop matlab will re-reference the EEG by subtracting the
        % contralateral channel from teh ipsilateral channel. In my
        % case, ipsilateral is the first EEG trace (channel 7)
        
        prompt = {'reference ispi to contra (1) or contra to ipsi (0) ?'};
        dlg_title = '1 if yes, 0 if no';
        num_lines = 1;
        def = {'1'};
        answe = inputdlg(prompt,dlg_title,num_lines,def);
        answe = str2mat(answe);
        answe = str2num(answe);
        
        if length(All_EEGs(j).EEG_2_extrap_1000) < 10000
            All_EEGs(j).too_short = 1;
        else
            All_EEGs(j).too_short = 0;
        end
        if ~isempty(All_EEGs(j).EEG_2_extrap_1000)
            if answe
                eeg = All_EEGs(j).EEG_extrap_1000;
                eeg2 = All_EEGs(j).EEG_2_extrap_1000;
            else
                eeg = All_EEGs(j).EEG_2_extrap_1000;
                eeg2 = All_EEGs(j).EEG_extrap_1000;
            end
            All_EEGs(j).eegmineeg2 = eeg-eeg2;
            %         figure(j)
            %         plot(All_EEGs(j).eegmineeg2)
        end
        %         cd(Folder_master)
        %
        %         save All_EEGs.mat All_EEGs -v7.3
        %         cd(Folder)
        % Next, we will identify all high-frequency artifacts (40-400 Hz) and
        % remove those from the recording and calculate the power spectra for teh
        % whole recording for each EEG. It also calculates low-frequency (7-12 Hz)
        % to identify potential seizures or interictal spikes.
        
        prompt = {'use re-referenced (0) or contra (1) or ipsi (2) or both contra and ipsi (3) or all three (4) for analysis ?'};
        dlg_title = 'which channel for analysis?';
        num_lines = 1;
        def = {'4'};
        answe = inputdlg(prompt,dlg_title,num_lines,def);
        answe = str2mat(answe);
        answe = str2num(answe);
        
        switch (answe)
            case 0
                reref_con_ips = 0;
            case 1
                reref_con_ips = 1;
            case 2
                reref_con_ips = 2;
            case 3
                reref_con_ips = 3;
            case 4
                reref_con_ips = 4;
        end
        
        if All_EEGs(j).too_short
        else
            if ~isempty(All_EEGs(j).EEG_2_extrap_1000)
                wave_2 = 0;
                wave_3 = 0;
                switch (reref_con_ips)
                    case 0
                        wave = All_EEGs(j).aegminaeg2';
                    case 1
                        wave = All_EEGs(j).EEG_2_extrap_1000';
                    case 2
                        wave = All_EEGs(j).EEG_extrap_1000';
                    case 3
                        wave = All_EEGs(j).EEG_extrap_1000';
                        wave_2 = All_EEGs(j).EEG_2_extrap_1000';
                    case 4
                        wave = All_EEGs(j).EEG_extrap_1000';
                        wave_2 = All_EEGs(j).EEG_2_extrap_1000';
                        wave_3 = All_EEGs(j).eegmineeg2';
                end
                
                mw = mean(wave);
                sw = std(wave,0);
                x=0;
                while sw<1.1
                    wave = wave*10;
                    sw = std(wave,0);
                    x=x+1;
                end
                All_EEGs(j).mw = mean(wave);
                All_EEGs(j).sw = std(wave,0);
                All_EEGs(j).eeg_factor = 10^x;
                close all
                time = 1/fss:1/fss:length(wave)/fss;
                
                [seize_LF,EEG_analysis_LF] = autoseizureread_Atul(Folder,wave, time, windowtime, steptime, fss,ampthr_LF,initial_HP_filter_cutoff_Hz_LF,...
                    initial_LP_filter_cutoff_Hz_LF,min_seiz_length_LF,min_seiz_Hz_LF,min_num_seiz_LF,freqband_lower_lim_LF,freqband_upper_lim_LF,min_seiz_ISI_LF,freqthr_LF);
                
                All_EEGs(j).seize_LF = seize_LF;
                All_EEGs(j).EEG_analysis_LF = EEG_analysis_LF;
                All_EEGs(j).FFT_frqs = EEG_analysis_LF.FFT_frqs;
                fouriersp = All_EEGs(j).EEG_analysis_LF.magvalue_1sided_rel;
                inn.msperline = steptime*1000;
                freqf = 100
                fouriersp = fouriersp';
                skip_inpaint_nans = 1;
                [fouriersp_interp,r] = cat_and_deltaf_interp(fouriersp,0,inn,freqf,skip_inpaint_nans);
                if skip_inpaint_nans
                else
                    fouriersp_interp(fouriersp_interp==0)=NaN;
                    fouriersp_interp = inpaint_nans(fouriersp_interp);
                end
                All_EEGs(j).fouriersp_interp = fouriersp_interp;
                clear fouriersp_interp
                
                [seize_HF,EEG_analysis_HF] = autoseizureread_Atul(Folder,wave, time, windowtime, steptime, fss,ampthr_HF,initial_HP_filter_cutoff_Hz_HF,...
                    initial_LP_filter_cutoff_Hz_HF,min_seiz_length_HF,min_seiz_Hz_HF,min_num_seiz_HF,freqband_lower_lim_HF,freqband_upper_lim_HF,min_seiz_ISI_HF,freqthr_HF);
                All_EEGs(j).seize_HF = seize_HF;
                All_EEGs(j).EEG_analysis_HF = EEG_analysis_HF;
                clear pot_seizures
                b=1;
                if seize_LF(1).stind == 0
                    to_remove=[]
                    All_EEGs(j).pot_seizures = [];
                else
                    
                    for k = 1:size(seize_LF,2)
                        c = seize_LF(k).stind*fss:1:seize_LF(k).enind*fss;
                        f=length(c);
                        pot_seizures(1,b:b+f-1) = c;
                        b=b+f;
                    end
                    All_EEGs(j).pot_seizures = pot_seizures;
                    clear all_HF_artifacts to_remove
                    b=1;
                    all_HF_artifacts=0
                    for k = 1:size(seize_HF,2)
                        if isfield(seize_HF(k),'enind')
                            c = seize_HF(k).stind*fss:1:seize_HF(k).enind*fss;
                            f=length(c);
                            all_HF_artifacts(1,b:b+f-1) = c;
                            b=b+f;
                        end
                    end
                    to_remove = setdiff(all_HF_artifacts,pot_seizures);
                end
                wave_rem = wave;
                if to_remove==0
                else
                    wave_rem(round(to_remove),:) = [];
                end
                All_EEGs(j).removed_samples = to_remove;
                [spectra,freqs,speccomp,contrib,specstd] = ...
                    spectopo(wave_rem', 0, fss, 'freq',freq, 'chanlocs', 1,'limits', [0 60 NaN NaN -10 10], 'freqfac',8,'plot','off');
                close all
                All_EEGs(j).spectra = spectra;
                All_EEGs(j).freqs = freqs;
                All_EEGs(j).speccomp = speccomp;
                All_EEGs(j).contrib = contrib;
                All_EEGs(j).specstd = specstd;
                figure(j)
                scatter(All_EEGs(j).freqs,All_EEGs(j).spectra)
                close all
                
                segments = classify_EEG_segments(All_EEGs,j,1,wave');
                All_EEGs(j).segments = segments;
                
                if wave_2 == 0
                else
                    wave=wave_2;
                    mw = mean(wave);
                    sw = std(wave,0);
                    x=0;
                    while sw<1.1
                        wave = wave*10;
                        sw = std(wave,0);
                        x=x+1;
                    end
                    All_EEGs(j).mw_2 = mean(wave);
                    All_EEGs(j).sw_2 = std(wave,0);
                    All_EEGs(j).eeg_factor_2 = 10^x;
                    close all
                    
                    [seize_LF,EEG_analysis_LF] = autoseizureread_Atul(Folder,wave, time, windowtime, steptime, fss,ampthr_LF,initial_HP_filter_cutoff_Hz_LF,...
                        initial_LP_filter_cutoff_Hz_LF,min_seiz_length_LF,min_seiz_Hz_LF,min_num_seiz_LF,freqband_lower_lim_LF,freqband_upper_lim_LF,min_seiz_ISI_LF,freqthr_LF);
                    All_EEGs(j).seize_LF_2 = seize_LF;
                    All_EEGs(j).EEG_analysis_LF_2 = EEG_analysis_LF;
                    All_EEGs(j).FFT_frqs_2 = EEG_analysis_LF.FFT_frqs;
                    fouriersp = All_EEGs(j).EEG_analysis_LF_2.magvalue_1sided_rel;
                    inn.msperline = steptime*1000;
                    freqf = 100
                    fouriersp = fouriersp';
                    skip_inpaint_nans = 1;
                    [fouriersp_interp,r] = cat_and_deltaf_interp(fouriersp,0,inn,freqf,skip_inpaint_nans);
                    if skip_inpaint_nans
                    else
                        fouriersp_interp(fouriersp_interp==0)=NaN;
                        fouriersp_interp = inpaint_nans(fouriersp_interp);
                    end
                    All_EEGs(j).fouriersp_interp_2 = fouriersp_interp;
                    clear fouriersp_interp
                    
                    [seize_HF,EEG_analysis_HF] = autoseizureread_Atul(Folder,wave, time, windowtime, steptime, fss,ampthr_HF,initial_HP_filter_cutoff_Hz_HF,...
                        initial_LP_filter_cutoff_Hz_HF,min_seiz_length_HF,min_seiz_Hz_HF,min_num_seiz_HF,freqband_lower_lim_HF,freqband_upper_lim_HF,min_seiz_ISI_HF,freqthr_HF);
                    All_EEGs(j).seize_HF_2 = seize_HF;
                    All_EEGs(j).EEG_analysis_HF_2 = EEG_analysis_HF;
                    clear pot_seizures
                    b=1;
                    if seize_LF(1).stind == 0
                        to_remove=[];
                        All_EEGs(j).pot_seizures_2=[];
                    else
                        for k = 1:size(seize_LF,2)
                            c = seize_LF(k).stind*fss:1:seize_LF(k).enind*fss;
                            f=length(c);
                            pot_seizures(1,b:b+f-1) = c;
                            b=b+f;
                        end
                        All_EEGs(j).pot_seizures_2 = pot_seizures;
                        clear all_HF_artifacts to_remove
                        b=1;
                        all_HF_artifacts=0
                        
                        for k = 1:size(seize_HF,2)
                            if isfield(seize_HF(k),'enind')
                                c = seize_HF(k).stind*fss:1:seize_HF(k).enind*fss;
                                f=length(c);
                                all_HF_artifacts(1,b:b+f-1) = c;
                                b=b+f;
                            end
                        end
                        to_remove = setdiff(all_HF_artifacts,pot_seizures);
                    end
                    wave_rem = wave;
                    if to_remove==0
                    else
                        wave_rem(round(to_remove),:) = [];
                    end
                    All_EEGs(j).removed_samples_2 = to_remove;
                    [spectra,freqs,speccomp,contrib,specstd] = ...
                        spectopo(wave_rem', 0, fss, 'freq',freq, 'chanlocs', 1,'limits', [0 60 NaN NaN -10 10], 'freqfac',8,'plot','off');
                    close all
                    All_EEGs(j).spectra_2 = spectra;
                    All_EEGs(j).freqs_2 = freqs;
                    All_EEGs(j).speccomp_2 = speccomp;
                    All_EEGs(j).contrib_2 = contrib;
                    All_EEGs(j).specstd_2 = specstd;
                    figure(j)
                    scatter(All_EEGs(j).freqs_2,All_EEGs(j).spectra_2)
                    close all
                    
                    segments = classify_EEG_segments(All_EEGs,j,2,wave');
                    All_EEGs(j).segments_2 = segments;
                end
                
                if wave_3 == 0
                else
                    wave=wave_3;
                    mw = mean(wave);
                    sw = std(wave,0);
                    x=0;
                    while sw<1.1
                        wave = wave*10;
                        sw = std(wave,0);
                        x=x+1;
                    end
                    All_EEGs(j).mw_3 = mean(wave);
                    All_EEGs(j).sw_3 = std(wave,0);
                    All_EEGs(j).eeg_factor_3 = 10^x;
                    close all
                    
                    [seize_LF,EEG_analysis_LF] = autoseizureread_Atul(Folder,wave, time, windowtime, steptime, fss,ampthr_LF,initial_HP_filter_cutoff_Hz_LF,...
                        initial_LP_filter_cutoff_Hz_LF,min_seiz_length_LF,min_seiz_Hz_LF,min_num_seiz_LF,freqband_lower_lim_LF,freqband_upper_lim_LF,min_seiz_ISI_LF,freqthr_LF);
                    All_EEGs(j).seize_LF_3 = seize_LF;
                    All_EEGs(j).EEG_analysis_LF_3 = EEG_analysis_LF;
                    All_EEGs(j).FFT_frqs_3 = EEG_analysis_LF.FFT_frqs;
                    fouriersp = All_EEGs(j).EEG_analysis_LF_3.magvalue_1sided_rel;
                    inn.msperline = steptime*1000;
                    freqf = 100
                    fouriersp = fouriersp';
                    skip_inpaint_nans = 1;
                    [fouriersp_interp,r] = cat_and_deltaf_interp(fouriersp,0,inn,freqf,skip_inpaint_nans);
                    if skip_inpaint_nans
                    else
                        fouriersp_interp(fouriersp_interp==0)=NaN;
                        fouriersp_interp = inpaint_nans(fouriersp_interp);
                    end
                    All_EEGs(j).fouriersp_interp_3 = fouriersp_interp;
                    clear fouriersp_interp
                    
                    [seize_HF,EEG_analysis_HF] = autoseizureread_Atul(Folder,wave, time, windowtime, steptime, fss,ampthr_HF,initial_HP_filter_cutoff_Hz_HF,...
                        initial_LP_filter_cutoff_Hz_HF,min_seiz_length_HF,min_seiz_Hz_HF,min_num_seiz_HF,freqband_lower_lim_HF,freqband_upper_lim_HF,min_seiz_ISI_HF,freqthr_HF);
                    All_EEGs(j).seize_HF_3 = seize_HF;
                    All_EEGs(j).EEG_analysis_HF_3 = EEG_analysis_HF;
                    clear pot_seizures
                    b=1;
                    if seize_LF(1).stind == 0
                        to_remove=[];
                        All_EEGs(j).pot_seizures_3=[];
                    else
                        for k = 1:size(seize_LF,2)
                            c = seize_LF(k).stind*fss:1:seize_LF(k).enind*fss;
                            f=length(c);
                            pot_seizures(1,b:b+f-1) = c;
                            b=b+f;
                        end
                        All_EEGs(j).pot_seizures_3 = pot_seizures;
                        clear all_HF_artifacts to_remove
                        b=1;
                        all_HF_artifacts=0
                        for k = 1:size(seize_HF,2)
                            if isfield(seize_HF(k),'enind')
                                c = seize_HF(k).stind*fss:1:seize_HF(k).enind*fss;
                                f=length(c);
                                all_HF_artifacts(1,b:b+f-1) = c;
                                b=b+f;
                            end
                        end
                        to_remove = setdiff(all_HF_artifacts,pot_seizures);
                    end
                    wave_rem =wave;
                    if to_remove==0
                    else
                        wave_rem(round(to_remove),:) = [];
                    end
                    All_EEGs(j).removed_samples_3 = to_remove;
                    [spectra,freqs,speccomp,contrib,specstd] = ...
                        spectopo(wave_rem', 0, fss, 'freq',freq, 'chanlocs', 1,'limits', [0 60 NaN NaN -10 10], 'freqfac',8,'plot','off');
                    close all
                    All_EEGs(j).spectra_3 = spectra;
                    All_EEGs(j).freqs_3 = freqs;
                    All_EEGs(j).speccomp_3 = speccomp;
                    All_EEGs(j).contrib_3 = contrib;
                    All_EEGs(j).specstd_3 = specstd;
                    figure(j)
                    scatter(All_EEGs(j).freqs_3,All_EEGs(j).spectra_3)
                    close all
                    
                    segments = classify_EEG_segments(All_EEGs,j,3,wave');
                    All_EEGs(j).segments_3 = segments;
                end
            end
        end
        clear EEG_analysis_HF EEG_analysis_LF fouriersp
        
        
        %%%%%%commented this out 02/18/21
        %
        %     if ~exist('All_EEGs','var')
        %         All_EEGs(rec).fouriersp_interp_2 = 0;
        %     else
        %         if size(All_EEGs,2)<rec
        %           All_EEGs(rec).fouriersp_interp_2 = 0;
        %         else
        %         if ~isfield(All_EEGs(rec),'fouriersp_interp_2')
        %           All_EEGs(rec).fouriersp_interp_2 = 0;
        %         end
        %         end
        %     end
        %     porf=0
        %     perf = size(All_EEGs,1)
        %
        %     if perf>(iii-1)
        %         if size(All_EEGs(rec).fouriersp_interp_2,1) < 2
        %             porf = 1
        %
        %         end
        %     else
        %         porf=1
        %     end
        %     if porf
        %         %if size(All_EEGs(rec).fouriersp_interp_2,1) < 2
        %
        %         %%%%%%%%%%%%%%%compute spectra of EEGs here
        %
        %         %for i = 1:size(recording,2)%5
        %         if isempty(recording(iii).EEG_results_nonoise) || recording(1).initial.datedr(1,iii)==0
        %         else
        %             analyzing_rec = iii
        %             freq = 1000;
        %             fs = recording(iii).initial2.sampl_fr;
        %             waver = recording(iii).EEG_results_nonoise.EEG';
        %             if isfield(recording(iii).EEG_results_nonoise,'EEG_2')
        %             waver2 = recording(iii).EEG_results_nonoise.EEG_2';
        %             else
        %             waver2 = waver;
        %             end
        %             EEG_extrap_1000 = zeros(1,round(length(waver)/(fs/freq)));
        %             EEG_2_extrap_1000  = zeros(1,round(length(waver2)/(fs/freq)));
        %             for ii = 1: size(EEG_2_extrap_1000,2)
        %                 EEG_2_extrap_1000(1,ii) = waver2(1,round((ii-1)*fs/freq)+1);
        %             end
        %             for ii = 1: size(EEG_extrap_1000,2)
        %                 EEG_extrap_1000(1,ii) = waver(1,round((ii-1)*fs/freq)+1);
        %             end
        %             All_EEGs(iii).EEG_extrap_1000 = EEG_extrap_1000;
        %             All_EEGs(iii).EEG_2_extrap_1000 = EEG_2_extrap_1000;
        %
        %             % In teh following loop matlab will re-reference the EEG by subtracting the
        %             % contralateral channel from teh ipsilateral channel.
        %
        %             prompt = {'reference ispi to contra (1) or contra to ipsi (0) ?'};
        %             dlg_title = '1 if yes, 0 if no';
        %             num_lines = 1;
        %             def = {'1'};
        %             answe = inputdlg(prompt,dlg_title,num_lines,def);
        %             answe = str2mat(answe);
        %             answe = str2num(answe);
        %
        %             %for i = 1:size(recording,2)%5
        %
        %             curreeg=iii
        %             if length(All_EEGs(iii).EEG_2_extrap_1000) < 10000
        %                 All_EEGs(iii).too_short = 1;
        %             else
        %                 All_EEGs(iii).too_short = 0;
        %             end
        %
        %             if isempty(All_EEGs(iii).EEG_2_extrap_1000)==0
        %
        %                 if answe
        %                     aeg = All_EEGs(iii).EEG_extrap_1000;
        %                     aeg2 = All_EEGs(iii).EEG_2_extrap_1000;
        %                 else
        %                     aeg = All_EEGs(iii).EEG_2_extrap_1000;
        %                     aeg2 = All_EEGs(iii).EEG_extrap_1000;
        %
        %                 end
        %                 %aegg=(aeg+aeg2);
        %
        %                 %aegg = aegg/2;
        %
        %                 %aeg_sub = aeg - aegg;
        %                 %aeg2_sub = aeg2 - aegg;
        %
        %                 %All_EEGs(i).aeg_sub = aeg_sub;
        %                 %All_EEGs(i).aeg2_sub = aeg2_sub;
        %                 %All_EEGs(i).mean_aeg = aegg;
        %                 All_EEGs(iii).aegminaeg2 = aeg-aeg2;
        %
        %                 figure(iii)
        %                 plot(All_EEGs(iii).aegminaeg2)
        %             end
        %             %end
        %
        %             close all
        %
        %             %If you want you can now reorder the  EEGs inside the All_EEGs structure to put them in chromological order!
        %
        %             % for i = 1:sx
        %             %     All_EEGs(i).too_short = 0;
        %             % end
        %
        %             % Next, it will identify all high-frequency artifacts (40-400 Hz) and
        %             % remove those from the recording and calculate the power spectra for teh
        %             % whole recording for each EEG. It also calculates low-frequency (7-12 Hz)
        %             % to identify potential seizures or interictal spikes.
        %
        %             close all
        %
        %             prompt = {'use re-referenced (0) or contra (1) or ipsi (2) or both contra and ipsi (3) or all three (4) for analysis ?'};
        %             dlg_title = 'which channel for analysis?';
        %             num_lines = 1;
        %             def = {'0'};
        %             answe = inputdlg(prompt,dlg_title,num_lines,def);
        %             answe = str2mat(answe);
        %             answe = str2num(answe);
        %
        %             switch (answe)
        %                 case 0
        %                     reref_con_ips = 0;
        %                 case 1
        %                     reref_con_ips = 1;
        %                 case 2
        %                     reref_con_ips = 2;
        %                 case 3
        %                     reref_con_ips = 3;
        %                 case 4
        %                     reref_con_ips = 4;
        %             end
        %
        %             %save workspace_bef_spectr_anal.mat -v7.3
        %
        %             preprocess_EEGs_one_rec
        %         end
        %     end
        %
        
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        
        
        
        
        %plot everything
        
        %1) DF left
        %2) EEG left -> make sure it's aligned! yes
        %3) EEG spectrum left -> make sure it's aligned! yes
        %4) DF right
        %5) EEG right -> make sure it's aligned! yes
        %6) EEG spectrum right -> make sure it's aligned! yes
        %7) running -> make sure it's aligned!
        %8) whisking
        %9) pupil diam -> aligned with vis stim, still need to crop by offset of
        %first mirror frame
        %10) saccade-> aligned with vis stim, still need to crop by offset of
        %first mirror frame
        %11) eye open/shut-> aligned with vis stim, still need to crop by offset of
        %first mirror frame
        %12) vis stim-> aligned with vis stim, still need to crop by offset of
        %first mirror frame
        
        rec = iii
        
        if isempty(recording(iii).EEG_results_nonoise) || recording(1).initial.datedr(1,iii)==0
            morlet_extrap_1 = 0;
            morlet_extrap_2 = 0;
        else
            eeg1 = All_EEGs(rec).EEG_extrap_1000';
            eeg2 = All_EEGs(rec).EEG_2_extrap_1000';
            low_freq = 0;
            high_freq = 500;
            fs = 1000;
            
            morlet_wavelet_1 = make_morlet_wavelet_one_channel(low_freq,high_freq,fs,eeg1);
            morlet_wavelet_1 = morlet_wavelet_1';
            freq = 100;
            morlet_extrap_1  = zeros(round(length(morlet_wavelet_1)/(fs/freq)),size(morlet_wavelet_1,2));
            for j = 1:size(morlet_extrap_1,2)
                morlet_extrapping = j
                for i = 1: size(morlet_extrap_1,1)
                    morlet_extrap_1(i,j) = morlet_wavelet_1(round((i-1)*fs/freq)+1,j);
                    
                end
            end
            clear morlet_wavelet_1
            All_EEGs(iii).morlet_extrap_1 = morlet_extrap_1;
            
            morlet_wavelet_2 = make_morlet_wavelet_one_channel(low_freq,high_freq,fs,eeg2);
            
            morlet_wavelet_2 = morlet_wavelet_2';
            
            morlet_extrap_2  = zeros(round(length(morlet_wavelet_2)/(fs/freq)),size(morlet_wavelet_2,2));
            
            for j = 1:size(morlet_extrap_2,2)
                morlet_extrapping = j
                for i = 1: size(morlet_extrap_2,1)
                    
                    morlet_extrap_2(i,j) = morlet_wavelet_2(round((i-1)*fs/freq)+1,j);
                end
            end
            clear morlet_wavelet_2
            All_EEGs(iii).morlet_extrap_2 = morlet_extrap_2;
            
        end
        
        if isfield(ms(rec),'num_ms')
            
            if isempty(ms(rec).num_ms)
            else
                if ms(rec).num_ms==0
                else
                    
                    
                    sort_cdec_by_tum_dist = 0;
                    if ~isfield(recording(rec),'eye')
                        no_eye_tracking = 1;
                    else
                        if isempty(recording(rec).eye) == 1
                            no_eye_tracking = 1;
                        else
                            if isstruct(recording(rec).eye)==0
                                no_eye_tracking = 1;
                            else
                                no_eye_tracking = 0;
                            end
                        end
                    end
                    
                    freq = 100;
                    beg_sec = 0;
                    if initial.no_imaging(1,rec)
                    else
                        cdata1 = recording(rec).EEG_results_nonoise.oopsi_interp_values';
                        cdata1 = real(cdata1);
                        
                        clear x p CI_sdec_cells CI_sdec_neuropil
                        CIFcn = @(x,p)prctile(x,abs([0,100]-(100-p)/2));
                        cdata1b = cdata1;
                        clear cdata1
                        cdata1 = cdata1b(1:size(cdata1b,1)-10,:); %(recording(rec).ta2.ROI_inds_sorted_by_tumor_dist',:);
                        mean_sdec_cells = mean(cdata1,1);
                        p=95;
                        for oo =1:length(mean_sdec_cells)
                            CI_sdec_cells(oo,:) = CIFcn(cdata1(:,oo),p);
                        end
                        CI_sdec_cells = CI_sdec_cells';
                        flep = CI_sdec_cells(1,:);
                        CI_sdec_cells(1,:) = CI_sdec_cells(2,:);
                        CI_sdec_cells(2,:) = flep;
                        rois = size(cdata1b,1);
                        cdata1(size(cdata1,1)+1:rois,:) = cdata1b(rois-9:rois,:);
                        mean_sdec_neuropil = mean(cdata1b(rois-9:rois,:),1);
                        for uu = 1:length(mean_sdec_neuropil)
                            CI_sdec_neuropil(uu,:)  = CIFcn(cdata1b(rois-9:rois,uu),p);
                        end
                        CI_sdec_neuropil = CI_sdec_neuropil';
                        flep = CI_sdec_neuropil(1,:);
                        CI_sdec_neuropil(1,:) = CI_sdec_neuropil(2,:);
                        CI_sdec_neuropil(2,:) = flep;
                        
                        if sort_cdec_by_tum_dist
                            cdata1b = cdata1;
                            cdata1 = cdata1b(recording(rec).ta2.ROI_inds_sorted_by_tumor_dist',:);
                        end
                        
                        end_sec = round(length(cdata1)/100);
                        
                        %     eeg1 = recording(rec).EEG_results_nonoise.EEG_extrap;
                        %     eeg2 = recording(rec).EEG_results_nonoise.EEG_2_extrap;
                        %     low_freq = 0;
                        %     high_freq = 50;
                        %     fs = 100;
                        %     %OR
                        %     eeg1 = All_EEGs(rec).EEG_extrap_1000';
                        %     eeg2 = All_EEGs(rec).EEG_2_extrap_1000';
                        %     low_freq = 0;
                        %     high_freq = 500;
                        %     fs = 1000;
                        %     morlet_wavelet_1 = make_morlet_wavelet_one_channel(low_freq,high_freq,fs,eeg1);
                        %     morlet_wavelet_2 = make_morlet_wavelet_one_channel(low_freq,high_freq,fs,eeg2);
                        %     morlet_wavelet_1 = morlet_wavelet_1';
                        %     morlet_wavelet_2 = morlet_wavelet_2';
                        %     freq = 100;
                        %     morlet_extrap_1  = zeros(round(length(morlet_wavelet_1)/(fs/freq)),size(morlet_wavelet_1,2));
                        %     morlet_extrap_2  = zeros(round(length(morlet_wavelet_2)/(fs/freq)),size(morlet_wavelet_2,2));
                        %     for j = 1:size(morlet_extrap_1,2)
                        %         morlet_extrapping = j
                        %         for i = 1: size(morlet_extrap_1,1)
                        %             morlet_extrap_1(i,j) = morlet_wavelet_1(round((i-1)*fs/freq)+1,j);
                        %             morlet_extrap_2(i,j) = morlet_wavelet_2(round((i-1)*fs/freq)+1,j);
                        %         end
                        %     end
                        %     All_EEGs(iii).morlet_extrap_1 = morlet_extrap_1;
                        %     All_EEGs(iii).morlet_extrap_2 = morlet_extrap_2;
                        %
                        fsp_1 = morlet_extrap_1;
                        fsp_2 = morlet_extrap_2;
                        fftlim1 = 400.5;
                        fftlim2 = 500.5;
                        fftclim = 0.01;
                        %OR
                        %     fsp_1 = All_EEGs(rec).fouriersp_interp;
                        %     fsp_2 = All_EEGs(rec).fouriersp_interp_2;
                        %fftlim1 = 200.5;
                        %fftlim2 = 256.5;
                        %fftclim = 0.001;
                        if isempty(recording(iii).EEG_results_nonoise) || recording(1).initial.datedr(1,iii)==0
                            Y1=0
                            Y2=0
                            cdata2 = zeros(1,size(cdata1,2));
                            cdata4 = zeros(1,size(cdata1,2));
                        else
                            if length(recording(rec).EEG_results_nonoise.EEG_extrap) < end_sec*100 || length(fsp_1) < end_sec*100
                                if length(recording(rec).EEG_results_nonoise.EEG_extrap) < length(fsp_1)
                                    end_sec = floor(length(recording(rec).EEG_results_nonoise.EEG_extrap)/100);
                                else
                                    end_sec = floor(length(fsp_1)/100);
                                end
                                cdata1 = cdata1(:,1:end_sec*100);
                            end
                            
                            Y1 = recording(rec).EEG_results_nonoise.EEG_extrap(beg_sec*100+1:end_sec*100,:);
                            if isfield(recording(rec).EEG_results_nonoise,'EEG_2_extrap')
                                Y2 = recording(rec).EEG_results_nonoise.EEG_2_extrap(beg_sec*100+1:end_sec*100,:);
                            else
                                Y2 = 0;
                            end
                            
                            fafi = fliplr(fsp_1(beg_sec*100+1:end_sec*100,:));
                            cdata2 = fafi';
                            
                            fafi = fliplr(fsp_2(beg_sec*100+1:end_sec*100,:));
                            cdata4 = fafi';
                        end
                        
                        cdata3 = recording(rec).EEG_results_nonoise.deltaf_interp_values'; %cat_signal_interp_values';
                        cdata3 = real(cdata3);
                        
                        clear x p CI_cdec_cells CI_cdec_neuropil
                        CIFcn = @(x,p)prctile(x,abs([0,100]-(100-p)/2));
                        %if sort_cdec_by_tum_dist
                        cdata3b = cdata3;
                        clear cdata3
                        cdata3 = cdata3b(1:size(cdata3b,1)-10,:); %(recording(rec).ta2.ROI_inds_sorted_by_tumor_dist',:);
                        mean_cdec_cells = mean(cdata3,1);
                        p=95;
                        for oo =1:length(mean_cdec_cells)
                            CI_cdec_cells(oo,:) = CIFcn(cdata3(:,oo),p);
                        end
                        CI_cdec_cells = CI_cdec_cells';
                        flep = CI_cdec_cells(1,:);
                        CI_cdec_cells(1,:) = CI_cdec_cells(2,:);
                        CI_cdec_cells(2,:) = flep;
                        rois = size(cdata3b,1);
                        cdata3(size(cdata3,1)+1:rois,:) = cdata3b(rois-9:rois,:);
                        mean_cdec_neuropil = mean(cdata3b(rois-9:rois,:),1);
                        for uu = 1:length(mean_cdec_neuropil)
                            CI_cdec_neuropil(uu,:)  = CIFcn(cdata3b(rois-9:rois,uu),p);
                        end
                        CI_cdec_neuropil = CI_cdec_neuropil';
                        flep = CI_cdec_neuropil(1,:);
                        CI_cdec_neuropil(1,:) = CI_cdec_neuropil(2,:);
                        CI_cdec_neuropil(2,:) = flep;
                        
                        if recording(1).initial.datedr(1,rec)==0
                            recording(rec).initial2.mirror_start_time(1,1) = recording(rec).initial2.frame_times(1,1);
                            recording(rec).initial2.sampl_fr = 1;
                        end
                        
                        if isfield(recording(rec).initial2,'mirror_start_time')
                            mi1 = round((recording(rec).initial2.mirror_start_time(1,1)/recording(rec).initial2.sampl_fr)*freq);
                        else
                            mi1 = round((recording(rec).initial2.frame_times(1,1)/recording(rec).initial2.sampl_fr)*freq);
                        end
                        
                        if recording(1).initial.datedr(1,rec)==0 || ~isfield(recording(rec),'wheel_new')
                            wh = zeros(end_sec*100,1);
                        else
                            wh = recording(rec).wheel_new.smooth_speed_extrap;
                        end
                        wh(1:mi1,:) = [];
                        
                        if length(wh) < end_sec*100
                            end_sec = floor(length(wh)/100);
                            cdata1 = cdata1(:,1:end_sec*100);
                            cdata4 = cdata4(:,1:end_sec*100);
                            Y2 = Y2(1:end_sec*100,:);
                            CI_cdec_neuropil = CI_cdec_neuropil(:,1:end_sec*100);
                            mean_cdec_neuropil = mean_cdec_neuropil(:,1:end_sec*100);
                            cdata3 = cdata3(:,1:end_sec*100);
                            CI_cdec_cells = CI_cdec_cells(:,1:end_sec*100);
                            mean_cdec_cells = mean_cdec_cells(:,1:end_sec*100);
                            cdata2 = cdata2(:,1:end_sec*100);
                            Y1 = Y1(1:end_sec*100,:);
                        end
                        
                        Y3 = wh(beg_sec*100+1:end_sec*100,:);
                        if recording(1).initial.datedr(1,rec)==0 || ~isfield(recording(rec),'wheel_new')
                            Y4 = zeros(end_sec*100,1);
                        else
                            if ~isfield(recording(rec),'whisking')
                                Y4 = zeros(end_sec*100,1);
                            else
                                if isempty(recording(rec).whisking)
                                    Y4 = zeros(end_sec*100,1);
                                else
                                    Y4 = recording(rec).whisking.smooth_avg_diffwhisk_extrap_no_noise;
                                end
                            end
                        end
                        if length(Y4)<end_sec*100
                            Y4(length(Y4)+1:end_sec*100,:) = NaN;
                        end
                        Y4 = Y4(beg_sec*100+1:end_sec*100,:);
                        figure(8989)
                        clims_oopsi = [0 1]
                        clims_DF = [0 3];
                        if no_eye_tracking
                            Y5 = Y1;
                            Y6 = Y1;
                            Y7 = Y1;
                            Y8 = Y1;
                        else
                            epw = recording(rec).eye.pupilwidth_adj;
                            epw(1:mi1,:) = [];
                            if (end_sec*100)<length(epw)
                                Y5 = epw(beg_sec*100+1:end_sec*100,:);
                                epp = recording(rec).eye.pupilpositionx;
                                epp(1:mi1,:) = [];
                                Y6 = epp(beg_sec*100+1:end_sec*100,:);
                                eo = recording(rec).eye.eye_open_adj;
                                eo(1:mi1,:) = [];
                                Y7 = eo(beg_sec*100+1:end_sec*100,:);
                                PDR = recording(rec).eye.PD_res_scan_adj;
                                PDR(1:mi1,:) = [];
                                Y8 = PDR(beg_sec*100+1:end_sec*100,:);
                            else
                                Y5 = epw(beg_sec*100+1:length(epw),:);
                                Y5(length(Y5)+1:end_sec*100,:) = 0;
                                epp = recording(rec).eye.pupilpositionx;
                                epp(1:mi1,:) = [];
                                Y6 = epp(beg_sec*100+1:length(epp),:);
                                Y6(length(Y6)+1:end_sec*100,:) = 0;
                                eo = recording(rec).eye.eye_open_adj;
                                eo(1:mi1,:) = [];
                                Y7 = eo(beg_sec*100+1:length(eo),:);
                                Y7(length(Y7)+1:end_sec*100,:) = 0;
                                PDR = recording(rec).eye.PD_res_scan_adj;
                                PDR(1:mi1,:) = [];
                                Y8 = PDR(beg_sec*100+1:length(PDR),:);
                                Y8(length(Y8)+1:end_sec*100,:) = 0;
                            end
                        end
                        %cdata1 = deconv matrix
                        %Y1 = EEG1
                        %cdata2 = fouriersp_1
                        %cdata3 = deltaf matrix
                        %Y2 = EEG2
                        %cdata4 = fouriersp_2
                        %Y3 = wheel
                        %Y4 = whisking
                        %Y5 = pupil width
                        %Y6 = pupil position x
                        %Y7 = eye lid
                        %Y8 = vis stim
                        if plot_cdec_and_sdec
                            createfigure_EEG_rasters_all_05_2020(cdata1, Y1, cdata2, cdata3, Y2, cdata4, Y3, Y4, Y5, Y6, Y7, Y8,clims_DF,clims_oopsi)
                        else
                            if plot_cdec_and_mean_DFs
                                
                                %OR, with cdec only (no deconv) but with mean cell DF/F and mean
                                %neuropil DF/F:
                                createfigure_EEG_rasters_cdec_only_08_2020(Y1, cdata4, cdata2, Y2, cdata3, Y3, Y4, Y5, Y6, Y7, Y8,clims_DF,mean_cdec_cells,...
                                    CI_cdec_cells,mean_cdec_neuropil,CI_cdec_neuropil)
                                
                                %OR, with deconv matrix, both DF/F means, and synchrony (based on deconvolved traces!) instead of eye
                                %lid
                                
                            else
                                Y9 = recording(iii).ca_stats_deconv.synchr_cells;
                                if length(Y9)<end_sec*100
                                    Y9(length(Y9)+1:end_sec*100,:) = NaN;
                                end
                                Y9 = Y9(beg_sec*100+1:end_sec*100,:);
                                createfigure_EEG_rasters_cdec_only_08_2020_microsz(Y1, cdata4, cdata2, Y2, cdata1, Y3, Y4, Y5, Y6, Y7, Y8,Y9,clims_oopsi,mean_sdec_cells,...
                                    CI_sdec_cells,mean_sdec_neuropil,CI_sdec_neuropil,fftlim1,fftlim2,fftclim)
                                pause on
                            end
                        end
                    end
                end
            end
        end
    end
end

