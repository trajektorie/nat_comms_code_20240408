function  [initial, xml_file, Folder] = StackLoad_JM_for_PC_1_11_28_18_batch(iii,initial,xml_files_okay,Folder,onep,...
    rec_xml,no_ch2_requirement)
%STACKLOAD Summary of this function goes here
%   Detailed explanation goes here
%
%keep3 initial



if xml_files_okay
    initial.xml_file_corrupt = 0;
else
    
    prompt = {'xml file okay (0) or corrupt (1) ?'};
    dlg_title = '0 for xml okay, 1 for corrupt';
    num_lines = 1;
    def = {'0'};
    answer = inputdlg(prompt,dlg_title,num_lines,def);
    answer = str2mat(answer);
    initial.xml_file_corrupt = str2num(answer);
    
    if initial.xml_file_corrupt
        initial.xml_file_corrupt = 1;
    else
        initial.xml_file_corrupt = 0;
    end
end

if initial.xml_file_corrupt
    prompt = {'Used BOT (1) or not (0) ?'};
    dlg_title = '1 if BOT, 0 if not';
    num_lines = 1;
    def = {'1'};
    answer = inputdlg(prompt,dlg_title,num_lines,def);
    answer = str2mat(answer);
    BOT = str2num(answer);
end

if rec_xml==0
    xml_FileName = dir(strcat(Folder,'\*_VoltageR*.xml'))
    %xml_file = [];
else
    if onep
        xml_FileName = dir('*_VoltageR*.xml')
        whon=1;
        % xmlfilena = dir('*V*.xml')
        
    else
        %xml_FileName = dir(strcat(Folder,'\*_VoltageR*.xml'))
        %xml_FileName = dir(strcat(Folder,'\*.xml'))
        xml_FileName = dir('*.xml')
        gh = size(xml_FileName,1)
        lk = 0;
        for o = 1:gh
            jh = xml_FileName(o).bytes;
            if jh>lk
                lk=jh;
                whon = o;
            end
        end
        %xml_FileName = xml_FileName(1).name
        % xml_FileName = dir(strcat(Folder,'\*S*.xml'))
    end
end
%
% [xml_FileName,PathName] = uigetfile('*.xml','Select the xml-file');
%
% addpath(PathName);
% Loc  = strcat(PathName,xml_FileName);
% Folder = findstr(Loc,'\');
% Folder = Loc(1:Folder(end));
%
%

if initial.xml_file_corrupt
    if rec_xml
    else
        xml_FileName =  dir('*C*.xml') %dir(strcat(Folder,'\*C*.xml'));
        xml_FileName_aux = dir('x*.xml') %dir(strcat(Folder,'\x*.xml'));
        initial.xml_file_aux = xml2struct(xml_FileName_aux.name);
        xml_file = xml2struct(xml_FileName_aux.name);
    end
    % else
    %     xml_FileName = dir(strcat(Folder,'\*.xml'));
end

if onep
else
    %cd(Folder)
end

if initial.no_imaging(1,iii)==0
    if initial.xml_file_corrupt
        %     if rec_xml==0
        %     else
        initial.xml_file_aux = xml2struct(xml_FileName_aux.name);
        
        if BOT
            xml_file = xml2struct(xml_FileName(1).name);
            initial.max_frame = str2num(xml_file.TSeries{1,1}.PVTSeriesElementSequenceBOT{1,1}.ATTRIBUTE.repetitions);
            initial.numberofframes = initial.max_frame;
            initial.msperline = 1000*str2num(xml_file.TSeries{1,1}.PVTSeriesElementSequenceBOT{1,1}.ATTRIBUTE.repetitionPeriod);
            initial.BOT = 1;
            
        else
            xml_file = xml2struct(xml_FileName(1).name);
            initial.max_frame = str2num(xml_file.TSeries{1,1}.PVTSeriesElementSequenceTimed{1,1}.ATTRIBUTE.repetitions);
            initial.numberofframes = initial.max_frame;
            initial.msperline = 1000*str2num(xml_file.TSeries{1,1}.PVTSeriesElementSequenceTimed{1,1}.ATTRIBUTE.repetitionPeriod);
            initial.BOT = 0;
        end
        %end
    else
        xml_file = xml2struct(xml_FileName(whon).name);
        if isfield(xml_file,'PVScan')
            if isfield(xml_file.PVScan.Sequence,'Frame')
                %         xml_file = xml_parseany(fileread(xml_FileName(1,1).name));
                
                %xml_file = xml_parseany(fileread(xml_FileName));
                
                if initial.no_imaging(1,iii)
                else
                    initial.max_frame = max(size(xml_file.PVScan.Sequence.Frame));
                    initial.numberofframes = initial.max_frame;
                    %initial.msperline = -1000*(str2num(xml_file.PVScan.Sequence.Frame{1,1}.Attributes.relativeTime) -...
                    %   str2num(xml_file.PVScan.Sequence.Frame{1,initial.max_frame}.Attributes.relativeTime))/...
                    %   (initial.max_frame-1);
                end
            end
        end
    end
else
    xml_file = xml2struct(xml_FileName(whon).name);
end

if rec_xml==0 || initial.no_imaging(1,iii)
    %formatin='yyyy-mm-dd,d,HH:MM:SS';
    
    formatin='yyyy-mm-dd';
    
    datestr = xml_file.VRecSessionEntry.DateTime.Text
    l = length(datestr)
    datestr = datestr(1:10)
    date = datenum(datestr,formatin)
    initial.date = date
    csv_file = 1;
else
    if onep
        
        formatin='yyyy-mm-dd';
        datestr = xml_file.VRecSessionEntry.DateTime.Text
        
        l = length(datestr)
        datestr = datestr(1:10)
        date = datenum(datestr,formatin)
    else
        date = datenum(xml_file.PVScan.Attributes.date)
    end
    
    if date>735084 && date<1768250
        csv_file = 1
    else
        csv_file = 0;
    end
    
    initial.date = date;
end

%
% prompt = {'.dat or .edr file present? (1=y, 0=n)'};
% dlg_title = '11 if yes, 0 if no';
% num_lines = 1;
% def = {'1'};
% answer = inputdlg(prompt,dlg_title,num_lines,def);
% answer = str2mat(answer);
% datedr = str2num(answer);

datedr = initial.datedr(1,iii);

if datedr
    if initial.heka_or_winedr(1,iii)
        if csv_file == 0
            Name2 = dir(strcat(Folder,'\*.dat'));
            FileName2 = Name2.name;
            initial.rawData2 = dlmread(FileName2, '\t');
        else
            Name2 = dir('*.csv'); % dir(strcat(Folder,'\*.csv'));
            FileName2 = Name2.name;
            initial.rawData2 = csvread(FileName2,1,0);
            %initial.rawData2 = readmatrix(FileName2);
        end
    else
        Name2 =  dir('*.edr'); %dir(strcat(Folder,'\*.edr')); % dir('*.csv');
        WinEDR_FileName = Name2.name;
        
        fid = fopen(WinEDR_FileName);
        [a,b,c,d] = fopen(fid);
        num_left = 2048;
        
        s = fgetl(fid);
        num_left = num_left-length(s);
        
        [WinEDR_data, h] = import_edr(WinEDR_FileName);
        
        % WinEDR_data = importdata(WinEDR_FileName, '\t');
        %     cat_WinEDR_data = cat(1,cat_WinEDR_data, WinEDR_data);
        %     WinEDR_data = cat_WinEDR_data;
        %     clear cat_WinEDR_data
        
        samples = size(WinEDR_data,1);
        sampl_fr = double(1/(WinEDR_data(samples,1)/samples));
        %sampl_fr = 1/(WinEDR_data(2,1)-WinEDR_data(1,1));
        frame_ms = 1000/sampl_fr;
        initial.sampl_fr = sampl_fr;
        initial.triggersync_hz = sampl_fr;
        initial.samples = samples;
        initial.frame_ms = frame_ms;
        initial.rawData2 = WinEDR_data;
        clear WinEDR_data
    end
    
end
%cd(Folder)
if onep
    
    Stack_ch2 = dir('*00*.tif');
    initial.Stack_ch2 = Stack_ch2;
    
    info = imfinfo(initial.Stack_ch2(1,1).name);
    
    initial.width = info.Width;
    
    initial.height = info.Height;
    
    initial.numberofmovies = 1;
    
    a=0
    for i = 1:length(Stack_ch2)
        info = imfinfo(initial.Stack_ch2(i,1).name);
        frs = length(info);
        a=a+frs;
    end
    
    
    
    
    
    %%%%%%%%%%%%%%%% load tiff files %%%%%%%%%%%%%%%%%%%%%%%
    initial.max_frame = a; %size(Stack_ch2,1);
    max_frame = initial.max_frame;
    initial.numerofframes = initial.max_frame;
    
else
    
    if initial.tif_or_txt && initial.no_imaging(1,iii)==0
        if initial.h5_or_tif(1,iii)
            
            if initial.swap_ch1_ch2
                h5_filenames_ch2 = dir('*ch1*.h5')
                h5_filenames_ch1 = dir('*ch2*.h5')
            else
                h5_filenames_ch2 = dir('*ch2*.h5')
                h5_filenames_ch1 = dir('*ch1*.h5')
            end
            
            if isempty(h5_filenames_ch2)
            else
                
                initial.Stack_ch2 = h5_filenames_ch2;
                if initial.use_red_channel(1,iii)
                    initial.Stack_ch1 = h5_filenames_ch1;
                end
                h5_files = size(h5_filenames_ch2,1);
                tot_frs = 0;
                for i = 1:h5_files
                    info = h5info(h5_filenames_ch2(i).name);
                    
                    if size(info.Groups,1)==1
                        igdds = info.Datasets(1).Dataspace.Size;
                        if size(igdds,2)>2
                            
                            dims = info.Datasets(1).Dataspace.Size;
                            
                        else
                            dims(1,1:2) = info.Datasets(1).Dataspace.Size;
                            siG =  size(info.Groups);
                            dims(1,3) =  siG(1,1);
                        end
                    else
                        if size(info.Groups(2).Datasets,1) ==1
                            igdds = info.Groups(2).Datasets(1).Dataspace.Size;
                            if size(igdds,2)>2
                                
                                dims = info.Groups(2).Datasets(1).Dataspace.Size;
                                
                            else
                                dims(1,1:2) = info.Groups(2).Datasets(1).Dataspace.Size;
                                siG =  size(info.Groups);
                                dims(1,3) =  siG(1,1);
                            end
                        else
                            dims(1,1:2) = info.Groups(2).Datasets(1).Dataspace.Size;
                            dims(1,3) = size(info.Groups(2).Datasets,1);
                        end
                    end
                    frames = dims(1,3);
                    frames_h5(1,i) = frames;
                    tot_frs = tot_frs+frames;
                    if i==1
                        blockframes = frames;
                    end
                    if i == h5_files
                        lastblockframes = frames;
                    end
                end
                initial.height = dims(1,1);
                initial.width = dims(1,2);
                initial.max_frame = tot_frs;
            end
            
        else
            if initial.use_red_channel(1,iii)
                Stack_ch1 = dir('*h1*.tif'); % dir(strcat(Folder,'\*h1*.tif'));
                
                
                info = imfinfo(Stack_ch1(1,1).name);
                
                initial.width = info.Width;
                
                initial.height = info.Height;
                
                initial.numberofmovies = 1;
                initial.Stack_ch1 = Stack_ch1;
            end
            
            
            
            
            Stack_ch2 = dir('*h2*.tif'); % dir(strcat(Folder,'\*h2*.tif'));
            if no_ch2_requirement
                Stack_ch2 = dir('TS*.tif');
            end
            initial.Stack_ch2 = Stack_ch2;
            
            if isempty(Stack_ch2)==0
                
                info = imfinfo(Stack_ch2(1,1).name);
                
                initial.width = info.Width;
                
                initial.height = info.Height;
            end
            initial.numberofmovies = 1;
            
            
            %%%%%%%%%%%%%%%% load tiff files %%%%%%%%%%%%%%%%%%%%%%%
            if initial.h5_already_created(1,iii)
                initial.max_frame = size(Stack_ch2,1);
                max_frame = initial.max_frame;
                initial.numerofframes = initial.max_frame;
                
            end
        end
    end
    
end








