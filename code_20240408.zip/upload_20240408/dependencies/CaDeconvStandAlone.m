function [DeconvMat,FiltMat,FiltMat2,oopsi_results]=CaDeconvStandAlone...
    (apm,initial,results,tau,thrup,thrdc,pfilt,StrongSm,maxcount,tbin,butterfilt,baseline_tconst_ms,i2)


% inmat: input data: time x cells x stimuli
%
% tau: exponential time constant of kernel for deconv in sec
%
% thrup: threshold for filtering, appropximately noise level, in % DF/F,
% normally between 0 and 5. If 0, no iterative filter is applied. This
% is the typical setting.
%
% thrdc: set to 0
%
% pfilt: number of times for post-filtering, ie, filtering of whole trace
% after iterative filtering of segments around peaks. Normally 0.
%
% StrongSm: if 1, a slightly different smoothing algorkithm is used. This
% causes more distortions. Normally, set to 0.
%
% maxcount: maximum number of iterations in filter procedure. Normally 5000.
%
% tbin: frame time of input data in sec.
%
% butterfilt: cutoff frequency for butterworth filter. Usual settings:
% for preservation of fast signals, set to 0.38
% for stronger noise reduction, set to 0.27 (t-resolution reduced a bit)
% for strongest noise reduction, set to 0.16 (t-resolution reduced
% substantially)
%
%OUTPUT:
%
%DeconvMat: filtered and deconvolved; same dimensions as inmat
%
%FiltMat: imat filtered only with Butterworth filter
%
%FiltMat2: imat filtered with Butterworth filter and iterative filter
%
% Example: CaDeconvStandAlone(inmat,3,0,0,0,0,5000,0.128,0.38);




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

inmat = results.cat_signal;
initial.smoothfactor = 2;
ntraces=size(inmat,2);
nodors=1;
FiltMat=inmat;
FiltMat2=inmat;



cellnumber = min(size(inmat));

deltaf = zeros (length(inmat),cellnumber);
movienumber = 1;

%for cell = 1:cellnumber
%smoothcalciumsignal (:,cell) = smooth ((calciumsignal (:,cell)),round (max(size(calciumsignal))/10));
%subcalciumsignal (:,cell) = (calciumsignal (:,cell) - smoothcalciumsignal (:,cell)) + mean (calciumsignal (:,cell)) ;
%smoothestcalciumsignal (:,cell) =  smooth ((subcalciumsignal (:,cell)),initial.smoothfactor);
%deltaf (:,cell) = (smoothestcalciumsignal (:,cell) - mean (subcalciumsignal (:,cell)))/mean (subcalciumsignal (:,cell));
%sortdeltaf (:,cell) = sort (deltaf (:,cell));
%l = (sortdeltaf (:,cell)<0);
%noisedeltaf (cell)= abs (std (sortdeltaf(l,cell)));
%meannoisedeltaf (cell) = abs (mean (sortdeltaf (l,cell)));
%plot (deltaf (:,cell))
%end

%inmat = deltaf;


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 
% prompt = {'start with cat_signal(1) or deltaf_matrix (0) ?'};
% dlg_title = '0 for deltaf, 1 for cat_signal';
% num_lines = 1;
% def = {'0'};
% answer = inputdlg(prompt,dlg_title,num_lines,def);
% answer = str2mat(answer);
% answer = str2num(answer);
answer=1;
if thrdc
    answer=0
    results.deltaf_matrix = results.cat_signal;
end
if answer
    cat_signal = zeros (1,cellnumber);
    cat_signal = inmat;
    movie = 1;
    cat_signal_baseline = zeros(size(cat_signal,1),size(cat_signal,2),movie);
    %for frame = 1:initial.numberofframes
    %    cat_signal = cat (1,cat_signal,signal (:,:,frame));
    %end
    period = ceil(baseline_tconst_ms/i2.msperline);
    lines = length(cat_signal);
    for cell_i = 1:cellnumber
        making_cat_signal_baseline = cell_i
        for frame_i = period:(lines-period)
           % running_frame_i = frame_i
            
           % around_i = sort(cat_signal((frame_i-period+1):frame_i+period,cell_i,movie));
           % baseline_i = mean(around_i(1:round(length(around_i)/6)));
            
            around_i = cat_signal((frame_i-period+1):frame_i+period,cell_i,movie);
            baseline_i = prctile(around_i,5);
            
            
            cat_signal_baseline(frame_i,cell_i,movie) = baseline_i;
            
        end
        cat_signal_baseline(1:period,cell_i,movie)=cat_signal_baseline(period,cell_i,movie);
        cat_signal_baseline(lines-period+1:lines,cell_i,movie) = cat_signal_baseline(lines-period,cell_i,movie);
        
    end
    
    
    
    for cell = 1:cellnumber
        deltaf_matrix (:,cell,movie) = smooth(cat_signal(:,cell,movie),initial.smoothfactor);
        sub_deltaf_matrix (:,cell,movie) = deltaf_matrix(:,cell,movie)-cat_signal_baseline(:,cell,movie);
        
        for x=1:lines
            
            deltaf_matrix (x,cell,movie) = (sub_deltaf_matrix (x,cell,movie))/(cat_signal_baseline(x,cell,movie));
        end
    end
    
    inmat = deltaf_matrix;
    
else
    
    s1 = size(results.cat_signal,1);
    s2= size(results.cat_signal,2);
    for ioi = 1:s2
        for ioo = 1:s1
            inmat(ioo,ioi,1) = results.deltaf_matrix(ioo,ioi);
        end
    end
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
a0 = 1
%for a0=1:nodors,
disp(['Processing odor ',int2str(a0)]);
Dmat=inmat;

% First filtering step: butterworth

if butterfilt>0,
    [B,A]=butter(4,butterfilt);
    for a1=1:ntraces, %deleted par
        filttrace = a1
        ROI_filtering = a1
        if isnan(Dmat(1,a1))
            Dmat(:,a1) = 0;
        else
            if max(max(Dmat))==Inf
              Dmat(:,a1) = 0;
            end
        Dmat(:,a1)=filtfilt(B,A,Dmat(:,a1));
        end
    end
end

FiltMat(:,:,a0)=Dmat;

%Second filtering step: iterative filter

if thrup>0,
    Dmat=IterFilt2(Dmat,thrup,pfilt,maxcount,StrongSm);
end
FiltMat2(:,:,a0)=Dmat;

%deconvolution

if tau>0,
    Dmat=deconvtrace2(tau,tbin,Dmat,0);
end
inmat(:,:,a0)=Dmat;


%end %for a0 loop
DeconvMat=inmat;

%DeconvMat=0;

%Vogelstein
% 
% prompt = {'do teh vogel(1) or not (0) ?'};
% dlg_title = '0 for deltaf, 1 for cat_signal';
% num_lines = 1;
% def = {'0'};
% answer = inputdlg(prompt,dlg_title,num_lines,def);
% answer = str2mat(answer);
% answer = str2num(answer);

answer=0;

freq=100
if answer
indicator = initial.indicator;
freq = 100
fps = 1000/i2.msperline;
traceOpt.trace_computation = 'oopsi';
traces = FiltMat2;
oopsi_spike_trace = filterTraces( traces, fps, traceOpt,indicator,initial,apm );
smooth_oopsi_filtered_deltaf_matrix = oopsi_spike_trace;
clear oopsi_spike_trace
else
    smooth_oopsi_filtered_deltaf_matrix = ones(11111,1);
end
oopsi_results.oopsi_filtered_deltaf_matrix= smooth_oopsi_filtered_deltaf_matrix;


oopsi_interp  = zeros(ceil(length(smooth_oopsi_filtered_deltaf_matrix)*i2.msperline/1000*freq),size(smooth_oopsi_filtered_deltaf_matrix,2));

for k = 1:size(smooth_oopsi_filtered_deltaf_matrix,2)
    j = 1;
    i = 2;
    while i <= length(oopsi_interp)-10
        %deltaf_interp (i,1) = i/freq;
        if (j*i2.msperline/1000 >= i/freq) && (j*i2.msperline/1000 <= i/freq+1/freq)...
                && oopsi_interp(i,k) == 0 %&& oopsi_interp(i-1,k) == 0
            if j*i2.msperline-i/freq <= i+1/freq - j*i2.msperline
                oopsi_interp(i,k) = oopsi_results.oopsi_filtered_deltaf_matrix(j,k);
            else
                oopsi_interp(i+1,k) = oopsi_results.oopsi_filtered_deltaf_matrix(j,k);
            end
            j=j+1
        end
        i=i+1;
    end
end

oopsi_results.oopsi_interp_values = oopsi_interp;

oopsi_results.oopsi_interp_values(oopsi_results.oopsi_interp_values==0)= NaN;
for i = 1:size(oopsi_results.oopsi_interp_values,2)
    oopsi_results.oopsi_interp_values(1:size(oopsi_results.oopsi_interp_values,1),i)...
        = inpaint_nans(oopsi_results.oopsi_interp_values(1:size(oopsi_results.oopsi_interp_values,1),i));
end



end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function DMout=IterFilt2(Dmat,thrup,pfilt,maxcount,StrongSm);

Emat = Dmat;

minpeak=0.1;

disp('smoothing...')
ntraces=size(Dmat,2);
nframes=size(Dmat,1);
for a1=1:ntraces
    changed=1;
    count=1;
    lastpk=0;
    iterfiltering = a1
    while ( (changed==1) && (count<=maxcount) )
        filt_step = count
        [pospeaks,negpeaks]=peakdetect(Dmat(:,a1));
        if ( (length(pospeaks)>0) && (length(negpeaks)>0) )
            if (pospeaks(1)<negpeaks(1))
                peaks1=negpeaks;
                peaks2=pospeaks;
            else
                peaks1=pospeaks;
                peaks2=negpeaks;
            end
        else
            changed=0;
        end
        posindex=ones(size(pospeaks));
        negindex=ones(size(negpeaks));
        negindex=negindex*(-1);
        allindex=[posindex;negindex];
        allpeaks=[pospeaks;negpeaks];
        
        %         stretch=find(allpeaks>=minpeak);
        %         allindex=allindex(stretch);
        %         allpeaks=allpeaks(stretch);
        
        if (length(allpeaks)==0)
            allpeaks=[1;allpeaks];
            if (Dmat(2,a1)<Dmat(1,a1)),
                allindex=[1;allindex];
            else
                allindex=[-1;allindex];
            end
        end
        
        if (allpeaks(1)>1),
            allpeaks=[1;allpeaks];
            if (Dmat(2,a1)<Dmat(1,a1)),
                allindex=[1;allindex];
            else
                allindex=[-1;allindex];
            end
        end
        if (allpeaks(length(allpeaks))<nframes),
            allpeaks=[allpeaks;nframes];
            if (Dmat(nframes,a1)>Dmat(nframes-1,a1)),
                allindex=[allindex;1];
            else
                allindex=[allindex;-1];
            end
        end
        
        [allpeaks,sind]=sort(allpeaks,1); %CHECK: does allindex also have to be sorted??
        allindex=allindex(sind);
        %sort(allindex,1);
        
        %         allamps=zeros(size(allpeaks));
        %         for b1=2:(length(allamps)-1),
        % %             allamps(b1)=( abs(Dmat(allpeaks(b1),a1) - Dmat(allpeaks(b1-1),a1) ) + abs(Dmat(allpeaks(b1),a1) - Dmat(allpeaks(b1+1),a1) ) ) /2;
        % %             allamps(b1)=min( abs(Dmat(allpeaks(b1),a1) - Dmat(allpeaks(b1-1),a1) ), abs(Dmat(allpeaks(b1),a1) - Dmat(allpeaks(b1+1),a1) ) );
        % %             allamps(b1)=max( abs(Dmat(allpeaks(b1),a1) - Dmat(allpeaks(b1-1),a1) ), abs(Dmat(allpeaks(b1),a1) - Dmat(allpeaks(b1+1),a1) ) );
        %             allamps(b1)=abs(Dmat(allpeaks(b1),a1) - Dmat(allpeaks(b1-1),a1) );
        %         end
        %         allamps(1)=abs(Dmat(1,a1)-Dmat(allpeaks(2),a1));
        %         allamps(length(allpeaks))=abs(Dmat(size(Dmat,1))-Dmat(allpeaks(length(allpeaks)-1)));
        
        allamps=zeros(size(allpeaks));
        for b1=2:(length(allamps)),
            %             allamps(b1)=( abs(Dmat(allpeaks(b1),a1) - Dmat(allpeaks(b1-1),a1) ) + abs(Dmat(allpeaks(b1),a1) - Dmat(allpeaks(b1+1),a1) ) ) /2;
            %             allamps(b1)=min( abs(Dmat(allpeaks(b1),a1) - Dmat(allpeaks(b1-1),a1) ), abs(Dmat(allpeaks(b1),a1) - Dmat(allpeaks(b1+1),a1) ) );
            %             allamps(b1)=max( abs(Dmat(allpeaks(b1),a1) - Dmat(allpeaks(b1-1),a1) ), abs(Dmat(allpeaks(b1),a1) - Dmat(allpeaks(b1+1),a1) ) );
            allamps(b1)=abs(Dmat(allpeaks(b1),a1) - Dmat(allpeaks(b1-1),a1) );
        end
        allamps(1)=abs(Dmat(1,a1)-Dmat(allpeaks(2),a1));
        allamps(1)=0;
        %allamps(length(allpeaks))=abs(Dmat(size(Dmat,1))-Dmat(allpeaks(length(allpeaks)-1)));
        
        
        
        %[allpeaks,allamps,Dmat(allpeaks,a1)]
        allamps2=allamps;
        [Y,allamps2ind]=sort(allamps2);
        allamps2=Y;
        
        count2=1;
        help3=0;
        take=0;
        %[allpeaks,allamps]
        
        while ( (count2<length(allamps2)) & (take==0) );
            help4=allamps2ind(count2);
            
            if StrongSm==0,
                %allamps2(count2)-allamps(help4)
                if ( (allamps(help4)<thrup) & (lastpk ~= allpeaks(help4)) & (allamps(help4) ~=0) ),
                    %if ( (allamps(help4)<thrup) & (allamps(help4) ~=0) ),
                    take=1;
                end
            else
                if ( (allamps(help4)<thrup) & (lastpk ~= allpeaks(help4)) & (allindex(help4)==1) ),
                    take=1;
                elseif (allindex(help4)==(-1))
                    take=1;
                end
            end
            count2=count2+1;
        end %2nd while loop
        if (take==1),
            if (help4>1),
                if help4<length(allpeaks),
                    stretch=Dmat(allpeaks(help4-1):allpeaks(help4+1),a1);
                else
                    stretch=Dmat(allpeaks(help4-1):allpeaks(help4),a1);
                end
                %                 disp([allpeaks(help4-1):allpeaks(help4+1)])
                %
                %                  allpeaks(help4)
                %                 allpeaks
            else
                stretch=Dmat(allpeaks(help4):allpeaks(help4+1),a1);
            end
            if length(stretch)>0,
                stretch=itersmooth2(stretch,3);
            end
            if (help4>1),
                if help4<length(allpeaks),
                    Dmat(allpeaks(help4-1):allpeaks(help4+1),a1)=stretch;
                else
                    Dmat(allpeaks(help4-1):allpeaks(help4),a1)=stretch;
                end
            else
                Dmat(allpeaks(help4):allpeaks(help4+1),a1)=stretch;
            end
            
            %              if (help4>1),
            %                 if help4<length(allpeaks),
            %                     Emat(allpeaks(help4-1):allpeaks(help4+1),a1)=stretch;
            %                 else
            %                     Emat(allpeaks(help4-1):allpeaks(help4),a1)=stretch;
            %                 end
            %             else
            %                 Emat(allpeaks(help4):allpeaks(help4+1),a1)=stretch;
            %             end
            
            
            
            lastpk=allpeaks(help4);
            changed=1;
        else
            changed=0;
        end
        count=count+1;
        
        stretch=find(abs(diff(Dmat(:,a1)))<1e-8); %1e-8: arbitrary criterion, found empirically
        if length(stretch)>0;
            Dmat(stretch,a1)=Dmat(stretch,a1)+rand(size(stretch))*10e-6;
        end
        
    end % 1st while loop
    if (pfilt>0),
        Dmat(:,a1)=itersmooth2(Dmat(:,a1),pfilt);
    end
    
    %     if length(stretch)>0;
    %             Emat(stretch,a1)=Emat(stretch,a1)+rand(size(stretch))*10e-6;
    %         end
    %
    %     end % 1st while loop
    %     if (pfilt>0),
    %         Emat(:,a1)=itersmooth2(Emat(:,a1),pfilt);
    %     end
    
end %for a1 loop
% disp ('Done!');
%DMout=Emat;
DMout=Dmat;
clear Dmat;

end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [peaks,valleys]=peakdetect(x);

[row,col]=size(x);
if col>row,
    x=x';
end;

dif=100*diff(x);
dif1=[dif; 0];
dif2=[0; dif];
neg=dif1.*dif2;
%pks=find(neg<=0);
pks=find(neg<0);
warning off;
onedetect=find(pks==1);
warning on;

if 0,
    if length(onedetect),
        pks=pks(find(pks~=1));
    end;
    lang=length(x);
    lastdetect=find(pks==lang);
    if length(lastdetect),
        pks=pks(find(pks~=lang));
    end;
end;

index=zeros(length(pks),1);

for t=1:length(pks),
    if dif2(pks(t))>0,
        index(t)=1;
    elseif dif2(pks(t))<0,
        index(t)=(-1);
    elseif dif2(pks(t))==0,
        if dif1(pks(t))>0,
            index(t)=(-1);
        elseif dif1(pks(t))<0,
            index(t)=1;
        end;
    end;
end;

stretch=find(index==1);
peaks=pks(stretch);
stretch=find(index==(-1));
valleys=pks(stretch);

end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function outvec=itersmooth2(invec,maxiters)

for a2=1:maxiters,
    [ppks,npks]=peakdetect(invec);
    if length(invec)>1,
        if invec(2)<invec(1),
            ppks=[1;ppks];
        else
            npks=[1;npks];
        end
        if invec(length(invec))>invec(length(invec)-1),
            ppks=[ppks;length(invec)];
        else
            npks=[npks;length(invec)];
        end
    end
    for a1=1:length(ppks),
        range=(ppks(a1)-1):(ppks(a1)+1);
        stretch=find( (range>0) & (range<=length(invec)) );
        if length(stretch)>0,
            invec(ppks(a1))=mean(invec(range(stretch)));
        end
    end
    for a1=1:length(npks),
        range=(npks(a1)-1):(npks(a1)+1);
        stretch=find( (range>0) & (range<=length(invec)) );
        if length(stretch)>0,
            invec(npks(a1))=mean(invec(range(stretch)));
        end
    end
end
outvec=invec;
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function outmat=deconvtrace2(tconst,tbin,datamat,plotit)

%datamat=detrend(datamat);

matlength=size(datamat,1);

kernellength=round(2*tconst/tbin);
kernel1=(exp(-[0:kernellength-1]/(tconst/tbin)));
kernel2=abs(1-(exp(-[0:kernellength-1]/(tconst/(tbin*5)))));
kernel=kernel1.*kernel2;
kernel=kernel(2:length(kernel));

alength=kernellength;
%fixed if-statement (had parentheses and semikolon)
if size(datamat,1)<kernellength,
    alength=2*kernellength-size(datamat,1);
end
addmat=ones(alength,1)*ones(1,size(datamat,2));
datamat=[datamat;addmat];

kernel=kernel1;

if plotit,
    figure(10); clf; subplot(222);plot(kernel);%plot((0:kernellength-1)*tbin,kernel)
    subplot(224);plot(kernel2);
    subplot(223);plot(kernel1);
    subplot(221); plot(datamat);
end
ntraces=length(datamat(1,:));
%outmat=zeros(size(datamat));
outmat=zeros(matlength,size(datamat,2));
%took out %'s before lengthdif, and residuals here:
for a1=1:ntraces
    deconving = a1
    [Q,R]=deconv(datamat(:,a1),kernel);
    lengthdif=length(datamat(:,a1))-length(R);
    
    %outmat(1:length(Q),a1)=Q;
    outmat(:,a1)=Q(1:matlength);
    
    residuals(1:length(R),a1)=R;
    
end

subplot(222);
plot(outmat(2:47,:)); hold on;
 subplot(224)
plot(residuals(2:47,:)); hold on;

subplot(221); hold on;
test=conv(outmat(1:47,1),kernel);
plot(test(1:47),'r-')
end