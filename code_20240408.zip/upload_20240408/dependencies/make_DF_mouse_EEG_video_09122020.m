
%%this program will make a video of the DF/F movie (one-p or two-p) in teh
%%top left corner, the mouse on teh weheel in the bottom left corner, EEG1
%%in teh top right corner, and EEg2 in teh bottom right corner.




function [DF_mouse_EEG_video] = make_DF_mouse_EEG_video_09122020(i2,Folder_master,Folder,iii,beg_sec,end_sec,initial,...
    stopped_cam_bef_pv,freq,EEG_results_nonoise,clims,DYall,dfmev,cmap,onep,only_vid_length,memmap,cam15Hz,cam_st_man)

cd(Folder_master)
%1) import the avi-file of the mouse (needs to be in Folder)

if dfmev.cam_interp==0
    cd(Folder)
    avi_FileName = dir('0*.avi');
    
    %
    v = VideoReader(avi_FileName.name)
    
    clear frame la
    la=1;
    if memmap
        DF_mouse_EEG_video = matfile('DF_mouse_EEG_video','Writable',true);
    end
    
    DF_mouse_EEG_video.mouse_avi = uint8(zeros(v.Height,v.Width,ceil(v.Duration*v.FrameRate)));
    
    
    while hasFrame(v)
        frame = readFrame(v);
        DF_mouse_EEG_video.mouse_avi(:,:,la) = frame(:,:,1);
        la=la+1;
    end
    num_frames = size(DF_mouse_EEG_video.mouse_avi,3);
    
    %mouse_avi = uint8(mouse_avi);
    
    %2) align this matrix with the DF matrix
    
    if cam_st_man
        
        totsecs = length(EEG_results_nonoise.oopsi_interp_values)/100;
        
        pv_num_frames = num_frames;
        
        cam_msperline = (totsecs*1000)/num_frames;
        
        for i = 1: num_frames
            
            cam_start_time(1,i) = round((i-1)*cam_msperline/i2.trig_factor)+1;
        end
        
        
        cam_frame_duration = (cam_start_time(size(cam_start_time,2))-cam_start_time(1))/(size(cam_start_time,2)-1);
        %clear  image_frame_time image frame
        for i = 1: length(cam_start_time)
            cam_frame_time(i) = round(cam_start_time(i)+cam_frame_duration/2);
            cam_frame(cam_frame_time(i)) = 100;
        end
        diff_cam_start_time = diff(cam_start_time);
        figure(23093)
        plot(diff_cam_start_time)
        
    else
        
        
        if initial.heka_or_winedr
            cam_pulse = initial.rawData2(:,4);
        else
            cam_pulse = initial.rawData2(:,5);
        end
        
        ogf = 76*i2.sampl_fr;
        ogp = 77*i2.sampl_fr;
        dop = max(cam_pulse(ogf:ogp,1));
        dog = min(cam_pulse(ogf:ogp,1));
        thr = (dop-dog)*0.62
        x=1;
        i=1;
        cam_pulse = cam_pulse - mean(cam_pulse(900000:950000,1));
        forww=0;
        i = round(20*i2.sampl_fr/1000);
        if cam15Hz(1,iii)
            ju = 1.5;
            jui = 1.6;
            ji = 60;
        else
            ju = 0.7;
            jui = 0.79;
            ji = 29;
        end
        if initial.heka_or_winedr(1,iii)
            cam_frame_start(1) = 10;
            cam_start_time(1) = 1;
        else
            i = 5;
            while abs(cam_pulse(i)-cam_pulse(i-2))<thr
                i = i+1;
            end
            x = i;
            cam_frame_start(x) = 10;   %change this according to specific recording
            cam_start_time(1) = x;
            
            if forww
                i = i+round((ju*forww)*i2.sampl_fr);
                videocam_i = i
            else
                i = i+round(ji*i2.sampl_fr/1000);
            end
        end
        
        x=2;
        fps = round(6*i2.sampl_fr/10000);
        while i<length(cam_pulse)-100  %change this according to specific recording
            if (cam_pulse(i,1)<cam_pulse(i+fps,1)-thr) % && (sum(abs(cam_pulse(i-55:i-15,1)))...
                %  <15*thr)
                cam_frame_start(i-1) = 100;
                cam_start_time(x) = i-1;
                x=x+1;
                if forww
                    i = i+round((jui*forww)*i2.sampl_fr)
                else
                    i = i+round(ji*i2.sampl_fr/1000);
                end
            else
                i = i+1;
            end
        end
        
        
        
        diff_cam_start_time = diff(cam_start_time);
        figure(23093)
        plot(diff_cam_start_time)
        cam_frame_duration = (cam_start_time(size(cam_start_time,2))-cam_start_time(1))/(size(cam_start_time,2)-1);
        cam_msperline = cam_frame_duration*i2.trig_factor;
        %clear  image_frame_time image frame
        for i = 1: length(cam_start_time)
            cam_frame_time(i) = round(cam_start_time(i)+cam_frame_duration/2);
            cam_frame(cam_frame_time(i)) = 100;
        end
        
        
        
        
        pv_num_frames = size(cam_start_time,2);
        
        
        
    end
    
    if stopped_cam_bef_pv
        
        
    else
        if num_frames<pv_num_frames
            actual_cam_msperline = cam_msperline*pv_num_frames/num_frames;
            actual_cam_Hz = 1000/actual_cam_msperline;
            DF_mouse_EEG_video.actual_cam_Hz = actual_cam_Hz;
        else
            actual_cam_msperline = cam_msperline;
            actual_cam_Hz = 1000/actual_cam_msperline;
            DF_mouse_EEG_video.actual_cam_Hz = actual_cam_Hz;
            
        end
        
    end
    
    
    %3) interpolate this matrix to freq
    
    tot_msec = 1000*(end_sec-beg_sec);
    pst = i2.frame_times(1,1);
    
    strt = round(pst/(i2.sampl_fr/freq));
    
    if only_vid_length
        cam_interp = uint8(zeros(v.Height,v.Width,ceil(tot_msec/1000*freq)+strt+1));
    else
        cam_interp  = uint8(zeros(v.Height,v.Width,ceil(num_frames*actual_cam_msperline/1000*freq)));
    end
    
    DF_mouse_EEG_video.actual_cam_msperline = actual_cam_msperline;
    
    if only_vid_length
        j = ceil(beg_sec*1000/actual_cam_msperline);
        e_i = floor((beg_sec-1)*1000/(1000/freq));
    else
        j = 1;
        e_i = 0;
    end
    i=1;
    while i <= length(cam_interp)-10
        if (j*actual_cam_msperline/1000> (i+e_i)/freq-1/(2*freq)) && (j*actual_cam_msperline/1000 <= ((i+e_i)+1)/freq)...
                && sum(sum(cam_interp(:,:,i))) == 0 %&& deltaf_interp(i-1,k) == 0
            if j*actual_cam_msperline/1000-(i+e_i)/freq <= ((i+e_i)+1)/freq - j*actual_cam_msperline/1000
                cam_interp(:,:,i) = DF_mouse_EEG_video.mouse_avi(:,:,j);
            else
                cam_interp(:,:,i+1) = DF_mouse_EEG_video.mouse_avi(:,:,j);
            end
            j=j+1;
        end
        i=i+1;
    end
    
    i = 1;
    a = 1;
    while i <= length(cam_interp)-1
        if sum(sum(cam_interp(:,:,i))) > 0
            a = i;
        else
            cam_interp(:,:,i) = cam_interp(:,:,a);
        end
        i=i+1;
    end
    
    pst = i2.frame_times(1,1);
    
    strt = round(pst/(i2.sampl_fr/freq));
    
    if pst > 10
        fd = size(cam_interp,3);
        %cam_interp(:,:,strt+1:strt+fd) = cam_interp;
        cam_interp(:,:,1:strt) = [];
        
    end
    
    
    DF_mouse_EEG_video.cam_interp = cam_interp;
    DF_mouse_EEG_video.orig_length_cam_interp = fd;
    DF_mouse_EEG_video.strt = strt;
    DF_mouse_EEG_video.cam_orig_num_frames = num_frames;
    DF_mouse_EEG_video.cam_frame_time = cam_frame_time;
    DF_mouse_EEG_video.cam_frame = cam_frame;
else
    %cam_interp = dfmev.cam_interp;
    
    DF_mouse_EEG_video = dfmev;
    %DF_mouse_EEG_video.cam_interp =
end

cam_interp = 0;
%initial1.g = 0;


%4) interpolate DF-matrix to 100Hz
msperline = i2.msperline;

if dfmev.DF_interp ==0
    
    if msperline>10
        num_frames = size(DYall,3);
        height = size(DYall,1);
        width = size(DYall,2);
        %         if memmap
        %                     DF_interp = matfile('DF_interp','Writable',true);
        %         else
        
        if only_vid_length
            DF_mouse_EEG_video.DF_interp  = uint16(zeros(height,width,ceil((end_sec+1)*freq)));
        else
            
            DF_mouse_EEG_video.DF_interp  = uint16(zeros(height,width,ceil(num_frames*msperline/1000*freq)));
        end
        % end
        j = 1;
        i = 1;
        while i <= length(DF_mouse_EEG_video.DF_interp)-10 %&& j<688
            if (j*msperline/1000 > i/freq-1/(2*freq)) && (j*msperline/1000 <= (i+1)/freq)...
                    && sum(sum(DF_mouse_EEG_video.DF_interp(:,:,i))) == 0 %&& deltaf_interp(i-1,k) == 0
                if j*msperline/1000-i/freq <= (i+1)/freq - j*msperline/1000
                    DF_mouse_EEG_video.DF_interp(:,:,i) = DYall(:,:,j);
                else
                    DF_mouse_EEG_video.DF_interp(:,:,i+1) = DYall(:,:,j);
                end
                j=j+1;
            end
            i=i+1;
            DF_interp_i = i
        end
        
        i = 1;
        a = 1;
        while i <= length(DF_mouse_EEG_video.DF_interp)-1
            if sum(sum(DF_mouse_EEG_video.DF_interp(:,:,i))) > 0
                a = i;
            else
                DF_mouse_EEG_video.DF_interp(:,:,i) = DF_mouse_EEG_video.DF_interp(:,:,a);
            end
            i=i+1;
            sum_sum_while_i = i
        end
    else
        
        %extrapolate to freq.........
        
        DF_mouse_EEG_video.DF_interp = DYall;
    end
    DF_mouse_EEG_video.pco_msperline = msperline;
    
    % DF_mouse_EEG_video.DF_interp = DF_interp;
    
else
    DF_mouse_EEG_video.DF_interp = dfmev.DF_interp;
end

if isempty(clims)
    
    clim1 = mean(mean(prctile(DF_mouse_EEG_video.DF_interp,5,3)))*0.8
    clim2 = mean(mean(prctile(DF_mouse_EEG_video.DF_interp,99,3)))*3
else
    clim1 = clims(1,1)
    clim2 = clims(1,2)
end

%%%%%%%%%%%%%%%%%
% 5) write the video

clear f
close all

fr = freq;

% trace 1 is DF_interp
% trace 2:
eeg_1 = EEG_results_nonoise.EEG_extrap;
% trace 3 is cam_interp
% trace 4:
eeg_2 = EEG_results_nonoise.EEG_2_extrap;

incremen = 1000/fr;
secplot = 10;
frplot = round(secplot*fr);

%beg_sec = 1000;
%end_sec = 1100;

beg_frame = round(beg_sec*fr);
end_frame = round(end_sec*fr);

adv = round(beg_frame*(1000/fr)/incremen)

camclims = [1 310];

b=1;

xsca = round(1000/i2.microns_per_pixel)

if onep
    middle = round(i2.width/2);
    xsca = round(1000/i2.microns_per_pixel);
    numdivs=floor(i2.width/xsca);
    numtics = numdivs-1;
    
    if mod(numtics,2)
        xtics = [middle-((numtics-1)/2)*xsca:xsca:middle+((numtics-1)/2)*xsca];
        xlabels = [-((numtics-1)/2):1:(numtics-1)/2];
    else
        numtics= numtics+1;
        xtics = [middle-((numtics-1)/2)*xsca:xsca:middle+((numtics-1)/2)*xsca];
        xlabels = [-((numtics-1)/2):1:(numtics-1)/2];
    end
else
    xsca = round(200/i2.microns_per_pixel);
    numtics = floor(i2.width/xsca);
    xtics = [0:xsca:xsca*numtics];
    xlabels = [0:200:200*numtics];
    
end

iw = size(DF_mouse_EEG_video.DF_interp,2);
il = size(DF_mouse_EEG_video.DF_interp,1);
arat = iw/il;

cw = size(DF_mouse_EEG_video.cam_interp,2);
cl = size(DF_mouse_EEG_video.cam_interp,1);
carat = cw/cl;

close all
clear f f_mat
b=1

wf = 1550
hf = 1030

aratf = wf/hf;

fig = figure('position',[100 100 wf hf],'Color','k');

%subplot(2,2,1)
subplot('Position',[0.05 0.05 0.5 0.5])%/(aratf/arat)])
ped = squeeze(DF_mouse_EEG_video.DF_interp(:,:,(round(frplot/2))+adv));
pod=rot90(ped,2);
imshow(pod,'Colormap',cmap,'DisplayRange',[clim1 clim2])
%imagesc(pod,[clim1 clim2]);
%colormap(cmap)
ax = gca;
ax.XColor ='white';
ax.YTick = [];
ax.XTick = xtics;
ax.XTickLabel = xlabels;

mxe1 = prctile(eeg_1,99); %max(eeg_1);
mxe2 = prctile(eeg_2,99); %max(eeg_2);


mi1 = prctile(eeg_1,1); %min(eeg_1);
mi2 = prctile(eeg_2,1); %min(eeg_2);

if mxe1>mxe2
    mxfp = mxe1*5;
else
    mxfp = mxe2*5;
end
if mi1<mi2
    if mi1>0
        mifp = mi1*0.005;
    else
        mifp = mi1*5;
    end
else
    if mi2>0
        mifp = mi2*0.005;
    else
        mifp = mi2*5;
    end
end
%subplot(2,2,2)
subplot('Position',[0.025 0.75 0.25 0.15])
plot(eeg_1(1+adv:frplot+adv,1),'Color','k');
hold on
line([frplot/2 frplot/2], [-3 2], 'Color','r');
axis ([0 frplot mifp mxfp ])
hold off
ax = gca;
title('EEG left', 'Color', 'white')
ax.XTick = [];
ax.YTick = [];

%subplot(2,2,3)
subplot('Position',[0.6 0.35 0.35 0.35*aratf/carat])
if only_vid_length
    imshow(squeeze(DF_mouse_EEG_video.cam_interp(:,:,1)),'Colormap',gray,'DisplayRange',camclims)
    
else
    imshow(squeeze(DF_mouse_EEG_video.cam_interp(:,:,round((frplot/2)+adv))),'Colormap',gray,'DisplayRange',camclims)
end
%imagesc(squeeze(cam_interp(:,:,round((frplot/2)+adv))),camclims);
%colormap(gray)
ax = gca;
ax.XTick = [];
ax.YTick = [];

%subplot(2,2,4)
subplot('Position',[0.325 0.75 0.25 0.15])
plot(eeg_2(1+adv:frplot+adv,1),'Color','k');
hold on
line([frplot/2 frplot/2], [-3 2], 'Color','r');
axis ([0 frplot mifp mxfp ])
hold off
ax = gca;
title('EEG right', 'Color', 'white')
ax.XTick = [];
ax.YTick = [];

f(b) = getframe(fig);
b=b+1;

maxf = end_frame

hold on
b=2
for k = beg_frame+1:maxf %81
    frameee = round((frplot/2)+adv) %k
    adv = round(k*(1000/fr)/incremen);
    if adv+5*freq<length(DF_mouse_EEG_video.DF_interp)
        
        
        %subplot(2,2,1)
        subplot('Position',[0.05 0.05 0.5 0.5])%*aratf/arat])
        ped = squeeze(DF_mouse_EEG_video.DF_interp(:,:,(round(frplot/2))+adv));
        pod=rot90(ped,2);
        imshow(pod,'Colormap',cmap,'DisplayRange',[clim1 clim2])
        %imagesc(pod,[clim1 clim2]);
        %colormap(cmap)
        ax = gca;
        ax.XColor ='white';
        ax.YTick = [];
        ax.XTick = xtics;
        ax.XTickLabel = xlabels;
        
        
        %subplot(2,2,2)
        subplot('Position',[0.025 0.75 0.25 0.15])
        plot(eeg_1(1+adv:frplot+adv,1),'Color','k');
        hold on
        line([frplot/2 frplot/2], [-3 2], 'Color','r');
        axis ([0 frplot mifp mxfp ])
        hold off
        ax = gca;
        title('EEG left', 'Color', 'white')
        ax.XTick = [];
        ax.YTick = [];
        
        %subplot(2,2,3)
        subplot('Position',[0.6 0.35 0.35 0.35*aratf/carat])
        if only_vid_length
            %              k = beg_frame+1:maxf %81
            %     frameee = k
            %     adv = round(k*(1000/fr)/incremen);
            padv = round((k-beg_frame)*(1000/fr)/incremen);
            imshow(squeeze(DF_mouse_EEG_video.cam_interp(:,:,round(1+padv))),'Colormap',gray,'DisplayRange',camclims)
            
        else
            imshow(squeeze(DF_mouse_EEG_video.cam_interp(:,:,round((frplot/2)+adv))),'Colormap',gray,'DisplayRange',camclims)
        end
        %imagesc(squeeze(cam_interp(:,:,round((frplot/2)+adv))),camclims);
        %colormap(gray)
        ax = gca;
        ax.XTick = [];
        ax.YTick = [];
        
        %subplot(2,2,4)
        subplot('Position',[0.325 0.75 0.25 0.15])
        plot(eeg_2(1+adv:frplot+adv,1),'Color','k');
        hold on
        line([frplot/2 frplot/2], [-3 2], 'Color','r');
        axis ([0 frplot mifp mxfp ])
        hold off
        ax = gca;
        title('EEG right', 'Color', 'white')
        ax.XTick = [];
        ax.YTick = [];
        
        f(b) = getframe(fig);
        b=b+1;
        %     frame = getframe;
        %     writeVideo(writerObj,frame);
    end
end


sd = size(f(1).cdata,1);
se = size(f(1).cdata,2);
f_mat = uint8(zeros(sd,se,3,size(f,2)));
for i = 1:size(f,2)
    framert = i
    f_mat(:,:,:,i) = f(i).cdata;
end


vv=VideoWriter(['f_mat_new_' num2str(beg_sec) '_sec_through_' num2str(end_sec) '_sec.avi'],'MOTION JPEG AVI');
vv.FrameRate = 100;
%vv.ColorChannels = 3;
open(vv)
writeVideo(vv,f_mat)
close(vv)



%['bilateral_DF_EEGs_' num2str(start_t) '_to' num2str(end_t) '_sec.emf']


%
%
%
%
%
%
% fr = initial2.triggersync_hz; %initial.samplingratehz;
%
% rff = FiltMat2_3000(:,3);
% rfd = FiltMat2_3000(:,68);
% [rff_interp,rfd_interp] = cat_and_deltaf_interp(rff,rfd,initial,fr);
%
% m_plot12 = rff_interp; %df_interp_new; %df_interp_new is the deltaf-trace (of one ROI), upsampled to the samplingrate of the analog inputs
% m_plot25 = rfd_interp; %results_EEG_patch.voltage_trace; %this is only necessary if you have a patch voltage trace
% %m_plot25 = results_EEG_patch.smooth_firing_rate_Hz;
% eeg_video = EEG_results_nonoise.EEG;
% %
% % writerObj = VideoWriter('EEG_roi15.mp4');%, 'MPEG-4');
% % writerObj.FrameRate = 150;
% % %writerObj.Height = 500;
% % %writerObj.Width = 500;
% %
% % open(writerObj);
% incremen = 1000/fr;
% secplot = 10;
% frplot = secplot*fr;
%
% fig = figure('position',[100 100 650 730]);
%
%
% %beg_sec = 1097;
% %end_sec = 1129;
%
% beg_frame = round(beg_sec*1000/initial.msperline)
% end_frame = round(end_sec*1000/initial.msperline)
%
%
% adv = round(beg_frame*initial.msperline/incremen)
%
% subplot(3,1,1)
% plot(eeg_video(1+adv:frplot+adv,1));
% hold on
% line([frplot/2 frplot/2], [-3 2], 'Color',[0 0 0]);
% axis ([0 frplot -1.5 1 ])
% hold off
% ax = gca;
% ax.XTick = [];
% ax.YTick = [];
% %ax.XTickLabel = {'-10','-5','0','5',};
% %ax.YTickLabel = {'min = -1','-0.5','0','0.5','max = 1'};
%
% subplot(3,1,2)
% plot(m_plot12(1+adv:frplot+adv,1));
% hold on
% line([frplot/2 frplot/2], [min(m_plot12)*0.95 max(m_plot12)*1.05], 'Color',[0 0 0]);
% axis ([0 frplot min(m_plot12)*0.95 max(m_plot12)*1.05 ])
% hold off
% ax = gca;
% ax.XTick = [];
% ax.YTick = [];
%
% subplot(3,1,3)
% plot(m_plot25(1+adv:frplot+adv,1));
% hold on
% line([frplot/2 frplot/2], [min(m_plot25)*0.95 max(m_plot25)*1.05], 'Color',[0 0 0]);
% axis ([0 frplot min(m_plot25)*0.95 max(m_plot25)*1.05])
% hold off
% ax = gca;
% ax.XTick = [];
% ax.YTick = [];
% k=1
% f(k) = getframe(fig);
%
% %
% % frame = getframe;
% % writeVideo(writerObj,frame);
%
% maxf = end_frame %floor(initial.movielengthsec*1000/initial.msperline)-102;       %1990 %ceil(4180.785/5.26216966431);
%
% hold on
% b=2
% for k = beg_frame+1:maxf %81
%     frameee = k
%     adv = round(k*initial.msperline/incremen)%5.26216966431);
%     if adv+2200<length(m_plot12)
%         subplot(3,1,1)
%         plot(eeg_video(1+adv:frplot+adv,1));
%         hold on
%         line([frplot/2 frplot/2], [-3 2], 'Color',[0 0 0]);
%         axis ([0 frplot -1.5 1 ])
%         hold off
%         ax = gca;
%         ax.XTick = [];
%         ax.YTick = [];
%         %ax.XTickLabel = {'-10','-5','0','5',};
%         %ax.YTickLabel = {'min = -1','-0.5','0','0.5','max = 1'};
%
%         subplot(3,1,2)
%         plot(m_plot12(1+adv:frplot+adv,1));
%         hold on
%         line([frplot/2 frplot/2], [min(m_plot12)*0.95 max(m_plot12)*1.05], 'Color',[0 0 0]);
%         axis ([0 frplot min(m_plot12)*0.95 max(m_plot12)*1.05])
%         hold off
%         ax = gca;
%         ax.XTick = [];
%         ax.YTick = [];
%
%         subplot(3,1,3)
%         plot(m_plot25(1+adv:frplot+adv,1));
%         hold on
%         line([frplot/2 frplot/2], [min(m_plot25)*0.95 max(m_plot25)*1.05], 'Color',[0 0 0]);
%         axis ([0 frplot min(m_plot25)*0.95 max(m_plot25)*1.05])
%         hold off
%         ax = gca;
%         ax.XTick = [];
%         ax.YTick = [];
%         f(b) = getframe(fig);
%         b=b+1
%         %     frame = getframe;
%         %     writeVideo(writerObj,frame);
%     end
% end
%
%
% % close all
% % [h, w, p] = size(f(1).cdata);  % use 1st frame to get dimensions
% % hf = figure;
% % % resize figure based on frame's w x h, and place at (150, 150)
% % set(hf, 'position', [150 150 w h]);
% % axis off
% % movie(hf,f);
% %
% clear f_mat
% for i = 1:size(f,2)
%     f_mat(:,:,:,i) = f(i).cdata;
% end
%
% Foldera = Folder % 'J:\TeT-project\N673\03-19-18\TSeries-03192018-1146-001\';
% cd(Foldera)
%
% v=VideoWriter('f_mat_new.avi','MOTION JPEG AVI');
% v.FrameRate = 50;
% open(v)
% writeVideo(v,f_mat)
% close(v)
%
% close all
%
% cam_fr = 20;
% cammsperline = 1000/cam_fr;
% facctor = cam_fr/initial.samplingratehz;
% writerObj = VideoWriter('mouse_resampld.avi', 'MOTION JPEG AVI');
% writerObj.FrameRate = 50;
% open(writerObj);
% clims = [33400 36200]
%
% % writerObj.Height = size(g_avg5,1);
% % writerObj.Width = size(g_avg5,2);
%
% fig = figure('position',[100 100 500 500]);
%
% clear gmatd gmatdd
% for k = beg_frame:end_frame %81
%      frame = k
%     adv = round(k*facctor);%*5.26216966431);
%
%     if round(secplot*0.5*1000/cammsperline)+adv>size(g_avg5,3)   %g_avg5 is the matrix of images imported from an .avi-file that was ...
%         %previously modifed in imagej from teh raw tiffs (using running
%         %average z-stack plugin averaging every 5 frames)
%     else
%
%
%     g_matd(:,:,k+1) = squeeze(g_avg5(:,:,round(secplot*0.5*1000/cammsperline)+adv));
%
%
%     %fig = figure(90)
%     imagesc(g_matd(:,:,k+1))
%     colormap(gray)
%     gmatdd(k+1) = getframe(fig);
% %
% %     colormap(gray)
% %     frame = getframe;
% %     writeVideo(writerObj,frame);
%     end
% end
%
% clear g_mat
% for i = 1:size(gmatdd,2)
%     g_mat(:,:,:,i) = gmatdd(i).cdata;
% end
%
%
% v=VideoWriter('g_mat_new.avi','MOTION JPEG AVI');
% v.FrameRate = 50;
% open(v)
% writeVideo(v,g_mat)
% close(v)
%
%
%
% close(writerObj)
% close all
%
%
% videos.g = initial.g;
% videos.eeg_video = eeg_video;
% videos.deltaf_interp_13 = deltaf_interp_13;
%
% save([Folder 'videos.mat' ] ,'videos', '-v7.3');


