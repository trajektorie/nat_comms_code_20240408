
function [Ca_EEG_results,EEG_segs] = EEG_to_Ca_analysis_all_recs_02_2021(min_isi_ms,min_length_ms,offs_thr,suf,recording,num_rec,...
    one_p_imaging,Folder_master,All_EEGs,no_imaging,...
    subfolders,sec_plot,add_params)




for i = 1:num_rec
    if no_imaging(1,i) || recording(1).initial.datedr(1,i)==0
        Ca_EEG_results(i).no_possibile = 1;
        EEG_segs(i).no_possibile = 1;
    else
    Folder = subfolders(i).name;
    matrix = recording(i).suite2p_deconv.sp_no_noise;
    interp = recording(i).EEG_results_nonoise.oopsi_interp_values;
    a=0;
    b=0;
    c = 0;
    d = 0;
    e = 0;
    f = 0;
    rec = i;
    EEG_results = recording(rec).EEG_results_nonoise;
    for j = 1:size(All_EEGs(i).segments,2)
        
        if All_EEGs(i).segments(j).nothing == 1
            f = f+1;
        else
            
            if All_EEGs(i).segments(j).other == 1
                e = e+1;
            else
                if All_EEGs(i).segments(j).poss_int_spike == 1
                    a = a+1;
                    
                else
                    if All_EEGs(i).segments(j).SW == 1
                        c = c+1;
                    else
                        if All_EEGs(i).segments(j).artifact == 1
                            d = d+1;
                        else
                            if All_EEGs(i).segments(j).seizure == 1
                                b = b+1;
                                
                                
                            end
                        end
                    end
                end
            end
        end
    end
    
    All_EEGs(i).spikes = a;
    All_EEGs(i).seizures = b;
    All_EEGs(i).SW = c;
    All_EEGs(i).artifact = d;
    All_EEGs(i).other = e;
    All_EEGs(i).nothing = f;
    
    All_EEGs(i).duration_min = length(All_EEGs(i).EEG_extrap_1000)/1000/60;
    
    All_EEGs(i).spikes_per_min = a/All_EEGs(i).duration_min;
    All_EEGs(i).seiz_per_min = b/All_EEGs(i).duration_min;
    All_EEGs(i).SW_per_min = c/All_EEGs(i).duration_min;
    All_EEGs(i).artifacts_per_min = d/All_EEGs(i).duration_min;
    All_EEGs(i).other_per_min = e/All_EEGs(i).duration_min;
    All_EEGs(i).nothing_per_min = f/All_EEGs(i).duration_min;
    
    if isfield(add_params,'days_of_TeT')
    if isempty(add_params.days_of_TeT)
        events_v_time(i,1) = add_params.day_P(1,i);
    else
        events_v_time(i,1) = add_params.days_of_TeT(1,i);%files(i).datenum;
    end
    else
        events_v_time(i,1) = add_params.day_P(1,i);
    end
    
    events_v_time(i,2) = All_EEGs(i).spikes_per_min;
    events_v_time(i,3) = All_EEGs(i).seiz_per_min;
    events_v_time(i,4) = All_EEGs(i).SW_per_min;
    events_v_time(i,5) = All_EEGs(i).artifacts_per_min;
    events_v_time(i,6) = All_EEGs(i).other_per_min;
    events_v_time(i,7) = All_EEGs(i).nothing_per_min;
    
    
    figure(90)
    plot(events_v_time(:,1),events_v_time(:,2),events_v_time(:,1),events_v_time(:,3),events_v_time(:,1),events_v_time(:,4),...
        events_v_time(:,1),events_v_time(:,5),events_v_time(:,1),events_v_time(:,6),events_v_time(:,1),events_v_time(:,7))
    
    
    EEG_segs(i).too_short = All_EEGs(i).too_short;
    if isfield(recording(i).initial2,'sampl_fr')
    EEG_segs(i).fs = recording(i).initial2.sampl_fr;
    else
        EEG_segs(i).fs = 1000*round(length(recording(i).EEG_results_nonoise.EEG)/length(All_EEGs(i).EEG_extrap_1000));
    end
    EEG_segs(i).mw = All_EEGs(i).mw;
    EEG_segs(i).sw = All_EEGs(i).sw;
    EEG_segs(i).eeg_factor = All_EEGs(i).eeg_factor;
    EEG_segs(i).seize_LF = All_EEGs(i).seize_LF;
    EEG_segs(i).seize_HF = All_EEGs(i).seize_HF;
    EEG_segs(i).segs = All_EEGs(i).segments;
    
    
    %%%%%%%%%%%%%%%% Ca- EEG correlation analysis
    
    minseiz = 3;
    if no_imaging(1,rec)
    else
        
        initial2 = recording(rec).initial2;
        initial = recording(rec).initial;
        
        event_tds = calcium_EEG_event_correlation (EEG_segs, initial2,rec)
        
        %
        %     tds=0
        %     cam_fr = 20;
        %     wheel_thr = 0.043;
        %    [wheel_new] = wheel_analysis_81516(initial,Folder,cam_fr,tds,wheel_thr,100,0,initial2);
        % %     motx = initial1.offsets(:,1);
        % %     moty = initial1.offsets(:,2);
        % %     diffmotx = diff(motx);
        % %     diffmoty = diff(moty);
        % %     diffmotx = abs(diff(motx));
        % %     diffmoty = abs(diff(moty));
        % %     motion = diffmotx+diffmoty;
        % %     motion(length(motion)+1,1) = 0;
        % %     motion_binary = motion;
        % %     motion_binary(find(motion_binary)) = 1;
        %     wheel_mot_min_binary = wheel_new.wheel_mot_min_binary
        
        initial.no_imaging = 0;
        min_isi_ms = 2000;
        min_length_ms = 200;
        offs_thr = 200;
        
        %interp = recording(rec).EEG_results_nonoise.deltaf_interp_values;
        %suf=0; %save figures (1) or not (0)
        %sec_plot=10;
        close all
        %EEG_results = recording(rec).EEG_results_nonoise;
        %matrix = recording(rec).F_dff';
        %one_p_imaging = onep;
        
        %%%% FIX THIS PART LATER!! %%%%%% 06/06/19
        % initial.offsets = initial1.offsets;
         filtmat = matrix;
         lazy_ROIs = []
        initial2.offsets = zeros(length(matrix),2);
        motion_binary = zeros(length(matrix),1);
        clear slmn somn
        if isempty(event_tds.tds_others) || length(event_tds.tds_others.sonms) == 1
            seiz_dists_others = 0;
        else
            for io = 1:length(event_tds.tds_others.sonms)
                slmn(1,io) = event_tds.tds_others.soffms(1,io) - event_tds.tds_others.sonms(1,io);
                somn(1,io) = event_tds.tds_others.sonms(1,io);
            end
            [tds] = cons_seizures(slmn,somn,initial,Folder,min_isi_ms,min_length_ms,suf,offs_thr,initial2, one_p_imaging);
            if length(tds.sonms)>2
                [seiz_dists_others] = seiz_distances (tds,initial,EEG_results,initial2);
                seiz_dists = seiz_dists_others;
                [dist_plots_filtmat_others] = plot_ca_vs_seiz_dist(Folder,seiz_dists,initial,...
                    matrix,tds,sec_plot,EEG_results,interp,suf,motion_binary,initial2);
                close all
                
                burst_SD = 7;
                alpha = 0.05/30;
                minseiz = 3;
                an_shuf = 0;
                p_ictntrict=0.05;
                iterations = 50000;
                filtmat = matrix;
                deconv=0;
                matrix = filtmat;
                dist_plots = dist_plots_filtmat_others;
                no_mot=0;
                tsb=1;
                lazy_ROIs = []
                [dist_to_next_onset_whole_ict_int_filtmat_new, dist_from_prev_offset_whole_ict_int_filtmat_new, ...
                    ROI_activity_whole_ict_int_filtmat_new,~, p_ranksum_filtmat_others,~,~,...
                    ictal_high_ranksum_filtmat_others, ictal_low_ranksum_filtmat_others,~,~,synchr_whole_ict_int_filtmat_others] =...
                    calc_an_shuf_new_whole_ict_int_ranksum(0,p_ictntrict,tds,sec_plot,an_shuf,Folder,...
                    dist_plots,initial,iterations,alpha,minseiz,matrix,filtmat,...
                    lazy_ROIs,burst_SD,seiz_dists,deconv,no_mot,tsb,initial2);
                Ca_EEG_results(rec).p_ranksum_filtmat_others = p_ranksum_filtmat_others;
                Ca_EEG_results(rec).ictal_high_ranksum_filtmat_others = ictal_high_ranksum_filtmat_others;
                Ca_EEG_results(rec).ictal_low_ranksum_filtmat_others = ictal_low_ranksum_filtmat_others;
            end
        end
        
        clear slmn somn
        
        if isempty(event_tds.tds_poss_int_spikes)  || length(event_tds.tds_poss_int_spikes.sonms) == 1
            seiz_dists_poss_int_spikes = 0;
            Ca_EEG_results(rec).p_ranksum_filtmat_poss_int_spikes = [];
            Ca_EEG_results(rec).ictal_high_ranksum_filtmat_poss_int_spikes = [];
            Ca_EEG_results(rec).ictal_low_ranksum_filtmat_poss_int_spikes = [];
        else
            tds = event_tds.tds_poss_int_spikes;
            for i = 1:length(event_tds.tds_poss_int_spikes.sonms)
                slmn(1,i) = event_tds.tds_poss_int_spikes.soffms(1,i) - event_tds.tds_poss_int_spikes.sonms(1,i);
                somn(1,i) = event_tds.tds_poss_int_spikes.sonms(1,i);
            end
            [tds] = cons_seizures(slmn,somn,initial,Folder,min_isi_ms,min_length_ms,suf,offs_thr,initial2,one_p_imaging);
            if length(tds.sonms)>2
                
                [seiz_dists_poss_int_spikes] = seiz_distances (tds,initial,EEG_results,initial2);
                seiz_dists = seiz_dists_poss_int_spikes;
                [dist_plots_filtmat_poss_int_spikes] = plot_ca_vs_seiz_dist(Folder,seiz_dists,initial,...
                    matrix,tds,sec_plot,EEG_results,interp,suf,motion_binary,initial2);
                close all
                
                burst_SD = 7;
                alpha = 0.05/30;
                % minseiz = 2;
                an_shuf = 0;
                p_ictntrict=0.05;
                iterations = 50000;
                %filtmat = FiltMat2_5000;
                deconv=0;
                % matrix = filtmat_red;
                dist_plots = dist_plots_filtmat_poss_int_spikes;
                no_mot=0;
                tsb=1;
                [dist_to_next_onset_whole_ict_int_filtmat_new, dist_from_prev_offset_whole_ict_int_filtmat_new, ...
                    ROI_activity_whole_ict_int_filtmat_new,~, p_ranksum_filtmat_poss_int_spikes,~,~,...
                    ictal_high_ranksum_filtmat_poss_int_spikes, ictal_low_ranksum_filtmat_poss_int_spikes,~,~,synchr_whole_ict_int_filtmat_poss_int_spikes] =...
                    calc_an_shuf_new_whole_ict_int_ranksum(0,p_ictntrict,tds,sec_plot,an_shuf,Folder,...
                    dist_plots,initial,iterations,alpha,minseiz,matrix,filtmat,...
                    lazy_ROIs,burst_SD,seiz_dists,deconv,no_mot,tsb,initial2);
                Ca_EEG_results(rec).p_ranksum_filtmat_poss_int_spikes = p_ranksum_filtmat_poss_int_spikes;
                Ca_EEG_results(rec).ictal_high_ranksum_filtmat_poss_int_spikes = ictal_high_ranksum_filtmat_poss_int_spikes;
                Ca_EEG_results(rec).ictal_low_ranksum_filtmat_poss_int_spikes = ictal_low_ranksum_filtmat_poss_int_spikes;
            end
        end
        
        clear slmn somn
        
        if isempty(event_tds.tds_seizures)  || length(event_tds.tds_seizures.sonms) == 1
            seiz_dists_seizures = 0;
            Ca_EEG_results(rec).p_ranksum_filtmat_seizures = 0;
            Ca_EEG_results(rec).ictal_high_ranksum_filtmat_seizures = 0;
            Ca_EEG_results(rec).ictal_low_ranksum_filtmat_seizures = 0;
            
        else
            tds = event_tds.tds_seizures;
            for i = 1:length(event_tds.tds_seizures.sonms)
                slmn(1,i) = event_tds.tds_seizures.soffms(1,i) - event_tds.tds_seizures.sonms(1,i);
                somn(1,i) = event_tds.tds_seizures.sonms(1,i);
            end
            [tds] = cons_seizures(slmn,somn,initial,Folder,min_isi_ms,min_length_ms,suf,offs_thr,initial2,one_p_imaging);
            if length(tds.sonms)>2
                
                [seiz_dists_seizures] = seiz_distances (tds,initial,EEG_results,initial2);
                seiz_dists = seiz_dists_seizures;
                [dist_plots_filtmat_seizures] = plot_ca_vs_seiz_dist(Folder,seiz_dists,initial,...
                    matrix,tds,sec_plot,EEG_results,interp,suf,motion_binary,initial2);
                close all
                
                burst_SD = 7;
                alpha = 0.05/30;
                %minseiz = 2;
                an_shuf = 0;
                p_ictntrict=0.05;
                iterations = 50000;
                % filtmat = FiltMat2_3000;
                deconv=0;
                %matrix = filtmat_red;
                dist_plots = dist_plots_filtmat_seizures;
                no_mot=0;
                tsb=1;
                [dist_to_next_onset_whole_ict_int_filtmat_new, dist_from_prev_offset_whole_ict_int_filtmat_new, ...
                    ROI_activity_whole_ict_int_filtmat_new,~, p_ranksum_filtmat_seizures,~,~,...
                    ictal_high_ranksum_filtmat_seizures, ictal_low_ranksum_filtmat_seizures,~,~,synchr_whole_ict_int_filtmat_seizures] =...
                    calc_an_shuf_new_whole_ict_int_ranksum(0,p_ictntrict,tds,sec_plot,an_shuf,Folder,...
                    dist_plots,initial,iterations,alpha,minseiz,matrix,filtmat,...
                    lazy_ROIs,burst_SD,seiz_dists,deconv,no_mot,tsb,initial2);
                Ca_EEG_results(rec).p_ranksum_filtmat_seizures = p_ranksum_filtmat_seizures;
                Ca_EEG_results(rec).ictal_high_ranksum_filtmat_seizures = ictal_high_ranksum_filtmat_seizures;
                Ca_EEG_results(rec).ictal_low_ranksum_filtmat_seizures = ictal_low_ranksum_filtmat_seizures;
            end
        end
        clear slmn somn
        
        if isempty(event_tds.tds_SWs)  || length(event_tds.tds_SWs.sonms) == 1
            seiz_dists_SWs = 0;
            Ca_EEG_results(rec).p_ranksum_filtmat_SWs = 0;
            Ca_EEG_results(rec).ictal_high_ranksum_filtmat_SWs = 0;
            Ca_EEG_results(rec).ictal_low_ranksum_filtmat_SWs = 0;
            
        else
            tds = event_tds.tds_SWs;
            for i = 1:length(event_tds.tds_SWs.sonms)
                slmn(1,i) = event_tds.tds_SWs.soffms(1,i) - event_tds.tds_SWs.sonms(1,i);
                somn(1,i) = event_tds.tds_SWs.sonms(1,i);
            end
            [tds] = cons_seizures(slmn,somn,initial,Folder,min_isi_ms,min_length_ms,suf,offs_thr,initial2,one_p_imaging);
            if length(tds.sonms)>2
                
                [seiz_dists_SWs] = seiz_distances (tds,initial,EEG_results,initial2);
                seiz_dists = seiz_dists_SWs;
                [dist_plots_filtmat_SWs] = plot_ca_vs_seiz_dist(Folder,seiz_dists,initial,...
                    matrix,tds,sec_plot,EEG_results,interp,suf,motion_binary,initial2);
                close all
                
                burst_SD = 7;
                alpha = 0.05/30;
                %minseiz = 2;
                an_shuf = 0;
                p_ictntrict=0.05;
                iterations = 50000;
                %filtmat = FiltMat2_5000;
                deconv=0;
                %matrix = filtmat_red;
                dist_plots = dist_plots_filtmat_SWs;
                no_mot=0;
                tsb=1;
                [dist_to_next_onset_whole_ict_int_filtmat_new, dist_from_prev_offset_whole_ict_int_filtmat_new, ...
                    ROI_activity_whole_ict_int_filtmat_new,~, p_ranksum_filtmat_SWs,~,~,...
                    ictal_high_ranksum_filtmat_SWs, ictal_low_ranksum_filtmat_SWs,~,~,synchr_whole_ict_int_filtmat_SWs] =...
                    calc_an_shuf_new_whole_ict_int_ranksum(0,p_ictntrict,tds,sec_plot,an_shuf,Folder,...
                    dist_plots,initial,iterations,alpha,minseiz,matrix,filtmat,...
                    lazy_ROIs,burst_SD,seiz_dists,deconv,no_mot,tsb,initial2);
                Ca_EEG_results(rec).p_ranksum_filtmat_SWs = p_ranksum_filtmat_SWs;
                Ca_EEG_results(rec).ictal_high_ranksum_filtmat_SWs = ictal_high_ranksum_filtmat_SWs;
                Ca_EEG_results(rec).ictal_low_ranksum_filtmat_SWs = ictal_low_ranksum_filtmat_SWs;
            end
        end
        clear slmn somn
        
        if isempty(event_tds.tds_artifacts) || length(event_tds.tds_artifacts.sonms) == 1
            seiz_dists_artifacts = 0;
            Ca_EEG_results(rec).p_ranksum_filtmat_artifacts = 0;
            Ca_EEG_results(rec).ictal_high_ranksum_filtmat_artifacts = 0;
            Ca_EEG_results(rec).ictal_low_ranksum_filtmat_artifacts = 0;
        else
            tds = event_tds.tds_artifacts;
            for i = 1:length(event_tds.tds_artifacts.sonms)
                slmn(1,i) = event_tds.tds_artifacts.soffms(1,i) - event_tds.tds_artifacts.sonms(1,i);
                somn(1,i) = event_tds.tds_artifacts.sonms(1,i);
            end
            [tds] = cons_seizures(slmn,somn,initial,Folder,min_isi_ms,min_length_ms,suf,offs_thr,initial2,one_p_imaging);
            if length(tds.sonms)>2 && tds.sond(1,1)<initial.max_frame
                
                [seiz_dists_artifacts] = seiz_distances (tds,initial,EEG_results,initial2);
                seiz_dists = seiz_dists_artifacts;
                [dist_plots_filtmat_artifacts] = plot_ca_vs_seiz_dist(Folder,seiz_dists,initial,...
                    matrix,tds,sec_plot,EEG_results,interp,suf,motion_binary,initial2);
                close all
                
                burst_SD = 7;
                alpha = 0.05/30;
                % minseiz = 2;
                an_shuf = 0;
                p_ictntrict=0.05;
                iterations = 50000;
                %filtmat = FiltMat2_5000;
                deconv=0;
                % matrix = filtmat_red;
                dist_plots = dist_plots_filtmat_artifacts;
                no_mot=0;
                tsb=1;
                [dist_to_next_onset_whole_ict_int_filtmat_new, dist_from_prev_offset_whole_ict_int_filtmat_new, ...
                    ROI_activity_whole_ict_int_filtmat_new,~, p_ranksum_filtmat_artifacts,~,~,...
                    ictal_high_ranksum_filtmat_artifacts, ictal_low_ranksum_filtmat_artifacts,~,~,synchr_whole_ict_int_filtmat_artifacts] =...
                    calc_an_shuf_new_whole_ict_int_ranksum(0,p_ictntrict,tds,sec_plot,an_shuf,Folder,...
                    dist_plots,initial,iterations,alpha,minseiz,matrix,filtmat,...
                    lazy_ROIs,burst_SD,seiz_dists,deconv,no_mot,tsb,initial2);
                Ca_EEG_results(rec).p_ranksum_filtmat_artifacts = p_ranksum_filtmat_artifacts;
                Ca_EEG_results(rec).ictal_high_ranksum_filtmat_artifacts = ictal_high_ranksum_filtmat_artifacts;
                Ca_EEG_results(rec).ictal_low_ranksum_filtmat_artifacts = ictal_low_ranksum_filtmat_artifacts;
            end
        end
        clear slmn somn
        
        if isempty(event_tds.tds_nothing)  || length(event_tds.tds_nothing.sonms) == 1
            seiz_dists_nothing = 0;
            Ca_EEG_results(rec).p_ranksum_filtmat_nothing = 0;
            Ca_EEG_results(rec).ictal_high_ranksum_filtmat_nothing = 0;
            Ca_EEG_results(rec).ictal_low_ranksum_filtmat_nothing = 0;
            
        else
            tds = event_tds.tds_nothing;
            for i = 1:length(event_tds.tds_nothing.sonms)
                slmn(1,i) = event_tds.tds_nothing.soffms(1,i) - event_tds.tds_nothing.sonms(1,i);
                somn(1,i) = event_tds.tds_nothing.sonms(1,i);
            end
            [tds] = cons_seizures(slmn,somn,initial,Folder,min_isi_ms,min_length_ms,suf,offs_thr,initial2,one_p_imaging);
            if length(tds.sonms)>2
                
                [seiz_dists_nothing] = seiz_distances (tds,initial,EEG_results,initial2);
                seiz_dists = seiz_dists_nothing;
                [dist_plots_filtmat_nothing] = plot_ca_vs_seiz_dist(Folder,seiz_dists,initial,...
                    matrix,tds,sec_plot,EEG_results,interp,suf,motion_binary,initial2);
                close all
                
                if dist_plots_filtmat_nothing.all_ict_act == 0
                    Ca_EEG_results(rec).p_ranksum_filtmat_nothing = 0;
                    Ca_EEG_results(rec).ictal_high_ranksum_filtmat_nothing = 0;
                    Ca_EEG_results(rec).ictal_low_ranksum_filtmat_nothing = 0;
                else
                    burst_SD = 7;
                    alpha = 0.05/30;
                    %minseiz = 2;
                    an_shuf = 0;
                    p_ictntrict=0.05;
                    iterations = 50000;
                    %filtmat = FiltMat2_5000;
                    deconv=0;
                    %matrix = filtmat_red;
                    dist_plots = dist_plots_filtmat_nothing;
                    no_mot=0;
                    tsb=1;
                    [dist_to_next_onset_whole_ict_int_filtmat_new, dist_from_prev_offset_whole_ict_int_filtmat_new, ...
                        ROI_activity_whole_ict_int_filtmat_new,~, p_ranksum_filtmat_nothing,~,~,...
                        ictal_high_ranksum_filtmat_nothing, ictal_low_ranksum_filtmat_nothing,~,~,synchr_whole_ict_int_filtmat_nothing] =...
                        calc_an_shuf_new_whole_ict_int_ranksum(0,p_ictntrict,tds,sec_plot,an_shuf,Folder,...
                        dist_plots,initial,iterations,alpha,minseiz,matrix,filtmat,...
                        lazy_ROIs,burst_SD,seiz_dists,deconv,no_mot,tsb,initial2);
                    
                    Ca_EEG_results(rec).p_ranksum_filtmat_nothing = p_ranksum_filtmat_nothing;
                    Ca_EEG_results(rec).ictal_high_ranksum_filtmat_nothing = ictal_high_ranksum_filtmat_nothing;
                    Ca_EEG_results(rec).ictal_low_ranksum_filtmat_nothing = ictal_low_ranksum_filtmat_nothing;
                end
            end
        end
        cd(Folder_master)
        save Ca_EEG_results.mat Ca_EEG_results
        %save workspace_all_recordings.mat -v7.3
    end
    end
end

cd(Folder_master)
save EEG_segs.mat EEG_segs



