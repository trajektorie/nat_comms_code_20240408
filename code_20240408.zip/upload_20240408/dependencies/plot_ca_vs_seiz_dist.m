function [dist_plots] = plot_ca_vs_seiz_dist(Folder,seiz_dists,initial,matrix,tds,sec_plot,ER,interp,sf,motion_binary,i2)

deltaf_matrix = matrix;

endframe = size(matrix,2);
frames = size(matrix,1);
ns = size(tds.soffd,2);
clear twosec_prev_out onesec_prev_out threesec_prev_out interict_act ict_act interict_act_no_mot ict_act_no_mot ict_no_mot_frame...
    interict_no_mot_frame interict_mot_frames ict_mot_frames

for i = 1:length(tds.sond)
    seiz_bin_vec(tds.sond(1,i):tds.soffd(1,i),1) = 1;
end
ict_mot_frames = 0;
tensec = round(10000/i2.msperline)
interict_mot_frames = 0;
interict_no_mot_frame = 0;
%identify all interictal activity (but take out seizures with bad motion
%artifacts!
samm = 1;
simm = 1;
interict_act=0;
ict_act=0;
iiain1 = [];
iain1 = [];

interict_act_no_mot = [];
ict_act_no_mot = [];

for i = 1:endframe
    roi_int_ict = i
    sk = 1;
    curseiz = 1;
    z=1;
    zz=1;
    j=tds.soffd(1,1);
    az=1;
    while j<tds.sond(1,ns) && j<length(matrix)+1
        
        if j>tds.sond(1,curseiz+1)-1
            curseiz = curseiz+1;
            az=1;
        end
        
        if seiz_dists.interictal(1,j) && ismember(curseiz,tds.offset_seizures_out) == 0
            
            if j>length(motion_binary)
                interict_act_no_mot(1,zz,i) = matrix(length(matrix),i);
            else
                if motion_binary(j,1) == 0
                    interict_act_no_mot(1,zz,i) = matrix(j,i);
                else
                    if i == 1
                        interict_mot_frames = samm;
                        samm = samm+1;
                    end
                end
            end
            
            interict_act(1,z,i) = matrix(j,i);
            dist_plots.segments(curseiz).interict_act(az,i) = matrix(j,i);
            az=az+1;
            iiain1(1,z) = matrix(j,i);
            if j<length(seiz_dists.next_ons_dists)
                
                
                if j>length(motion_binary)
                    interict_act_no_mot(2,zz,i) = 0;
                else
                    if motion_binary(j,1) == 0
                        interict_act_no_mot(2,zz,i) = seiz_dists.next_ons_dists(1,j);
                    end
                    interict_act(2,z,i) = seiz_dists.next_ons_dists(1,j);
                    iiain2(1,z) = seiz_dists.next_ons_dists(1,j);
                end
            end
            
            if j>length(motion_binary)
                interict_act_no_mot(3,zz,i) = 0;
            else
                if motion_binary(j,1) == 0
                    interict_act_no_mot(3,zz,i) = seiz_dists.prev_offs_dists(1,j);
                    interict_no_mot_frame(zz,1) = j;
                    zz = zz+1;
                end
            end
            interict_act(3,z,i) = seiz_dists.prev_offs_dists(1,j);
            iiain3(1,z) = seiz_dists.prev_offs_dists(1,j);
            z = z+1;
            
        else
            if ismember(curseiz,tds.offset_seizures_out)
                skipped_seiz(1,sk) = curseiz;
                sk=sk+1
            end
        end
        j = j+1;
    end
    
    ict_mot_frames = 0;
    ict_no_mot_frame = 0;
    %identify ictal periods
    zi=1;
    zzi=1;
    ji=tds.sond(1,1);
    a = 1;
    curseizi = 1;
    bz=1;
    while ji<length(matrix)+1 && ji<length(seiz_dists.ictal) % ji<tds.soffd(1,ns)
        if curseizi<ns
            if ji>tds.sond(1,curseizi+1)-1
                curseizi = curseizi+1
                bz=1;
            end
        end
        
        if seiz_dists.ictal(1,ji) && ismember(curseizi,tds.offset_seizures_out) == 0
            
            if j>length(motion_binary)
                ict_act_no_mot(1,zzi,i) = 0;
            else
                if motion_binary(ji,1) == 0
                    ict_act_no_mot(1,zzi,i) = matrix(ji,i);
                else
                    if i == 1
                        ict_mot_frames = simm;
                        simm = simm+1;
                    end
                    
                end
            end
            ict_act(1,zi,i) = matrix(ji,i);
            iain1(1,zi) = matrix(ji,i);
            dist_plots.segments(curseizi).ict_act(bz,i) = matrix(ji,i);
            bz=bz+1;
            if ji > tds.soffd(a)
                a=a+1;
            end
            if ji<length(seiz_dists.prev_offs_dists)
                if j>length(motion_binary)
                    ict_act_no_mot(2,zzi,i) = 0;
                else
                    if motion_binary(ji,1) == 0
                        ict_act_no_mot(2,zzi,i) = ji-tds.sond(1,curseizi);
                    end
                end
                ict_act(2,zi,i) = ji-tds.sond(1,curseizi);
                iain2(1,zi) = ji-tds.sond(1,curseizi);
            end
            if j>length(motion_binary)
                ict_act_no_mot(3,zzi,i) = 0;
            else
                if motion_binary(ji,1) == 0
                    ict_act_no_mot(3,zzi,i) = tds.soffd(1,curseizi)-ji;
                    ict_no_mot_frame(zzi,1) = ji;
                    zzi = zzi+1;
                end
            end
            ict_act(3,zi,i) = tds.soffd(1,curseizi)-ji;
            iain3(1,zi) = tds.soffd(1,curseizi)-ji;
            
            zi = zi+1;
        end
        ji = ji+1;
    end
    
end
dist_plots.ict_no_mot_frame = ict_no_mot_frame;
dist_plots.interict_no_mot_frame = interict_no_mot_frame;
dist_plots.interict_mot_frames = interict_mot_frames;
dist_plots.ict_mot_frames = ict_mot_frames;

dist_plots.all_interict_act = interict_act;
dist_plots.all_ict_act = ict_act;

dist_plots.all_interict_act_no_mot = interict_act_no_mot;
dist_plots.all_ict_act_no_mot = ict_act_no_mot;

dist_plots.iiain1 = iiain1;
dist_plots.iain1 = iain1;

dist_plots.perc_mot_interict_frames = 100*dist_plots.interict_mot_frames/size(dist_plots.all_interict_act,2);
dist_plots.perc_mot_ict_frames = 100*dist_plots.ict_mot_frames/size(dist_plots.all_ict_act,2);

%do the same for EEG_extrap

tds.sofd = round(tds.soffms/10);
tds.sonnd = round(tds.sonms/10);

interict_EEG_extrap = zeros(3,sum(seiz_dists.interictal_extrap));
interict_act_oopsi_extrap = zeros(3,sum(seiz_dists.interictal_extrap),size(ER.oopsi_interp_values,2));

z=1
j=tds.sofd(1,1)
while j<tds.sonnd(1,ns)&&j<length(seiz_dists.interictal_extrap)+1
    j
    if seiz_dists.interictal_extrap(1,j)
        interict_EEG_extrap(1,z) = ER.EEG_extrap(j,1);
        interict_act_oopsi_extrap(1,z,:) = ER.oopsi_interp_values(j,:);
        if j<length(seiz_dists.next_ons_dists_extrap)
            interict_EEG_extrap(2,z) = seiz_dists.next_ons_dists_extrap(1,j);
            interict_act_oopsi_extrap(2,z,:) = seiz_dists.next_ons_dists_extrap(1,j);
        end
        interict_EEG_extrap(3,z) = seiz_dists.prev_offs_dists_extrap(1,j);
        interict_act_oopsi_extrap(3,z,:) = seiz_dists.prev_offs_dists_extrap(1,j);
        z = z+1;
    end
    j = j+1;
end
dist_plots.interict_EEG_extrap= interict_EEG_extrap;
dist_plots.interict_act_oopsi_interp = interict_act_oopsi_extrap;

clear ict_EEG_extrap
ict_EEG_extrap = zeros(3,sum(seiz_dists.ictal_extrap));
ict_act_oopsi_extrap = zeros(3,sum(seiz_dists.ictal_extrap),size(ER.oopsi_interp_values,2));

z=1
j=tds.sonnd(1,1)
a = 1;
while j<tds.sofd(1,ns)&&j<length(seiz_dists.ictal_extrap)+1
    j
    if seiz_dists.ictal_extrap(1,j)
        ict_EEG_extrap(1,z) = ER.EEG_extrap(j,1);
        ict_act_oopsi_extrap(1,z,:) = ER.oopsi_interp_values(j,:);
        if j > tds.sofd(1,a)
            a = a+1;
        end
        if j<length(seiz_dists.prev_offs_dists_extrap)
            ict_EEG_extrap(2,z) = j-tds.sonnd(1,a);
            ict_act_oopsi_extrap(2,z,:) = j-tds.sonnd(1,a);
        end
        ict_EEG_extrap(3,z) = tds.sofd(1,a) - j;
        ict_act_oopsi_extrap(3,z,:) = j-tds.sofd(1,a);
        z = z+1;
    end
    j = j+1;
end

dist_plots.ict_EEG_extrap = ict_EEG_extrap;
dist_plots.ict_act_oopsi_interp = ict_act_oopsi_extrap;

%interictal EEG
ia1s_EEG = squeeze(interict_EEG_extrap(1:2,:))';
ia1s_sorted_EEG = sortrows(ia1s_EEG,2);

clear avg_sd_binned_EEG_interict med_iq_binned_EEG_interict
b = 1;
c=1;
curr = 0;
x=1;
d=1;
avg_sd_binned_EEG_interict = [];
med_iq_binned_EEG_interict = [];


for j = 1:length(ia1s_sorted_EEG)
    if ia1s_sorted_EEG(j,2)<1
        curr(1,c) = ia1s_sorted_EEG(j,1);
        c=c+1;
        
        
    else %if ia1s_sorted_EEG(j,2)>0
        if ia1s_sorted_EEG(j-1,2)<1
            
            avg_sd_binned_EEG_interict(1,x) = mean(curr(1,:));
            avg_sd_binned_EEG_interict(2,x) = std(curr(1,:),1);
            med_iq_binned_EEG_interict(1,x) = median(curr(1,:));
            %med_iq_binned_EEG_interict(2,x) = quantile(curr(1,:),0.16);
            %med_iq_binned_EEG_interict(3,x) = quantile(curr(1,:),0.84);
            c=1;
            curr=0;
            x=x+1
            b = b+1;
            
            curr(1,c) = ia1s_sorted_EEG(j,1);
            c=c+1;
            
            
            
        else
            if ia1s_sorted_EEG(j,2) < b && ia1s_sorted_EEG(j,2) >= (b-1)
                curr(1,c) = ia1s_sorted_EEG(j,1);
                c=c+1;
            else
                
                avg_sd_binned_EEG_interict(1,x) = mean(curr(1,:));
                avg_sd_binned_EEG_interict(2,x) = std(curr(1,:),1);
                med_iq_binned_EEG_interict(1,x) = median(curr(1,:));
                %med_iq_binned_EEG_interict(2,x) = quantile(curr(1,:),0.16);
                %med_iq_binned_EEG_interict(3,x) = quantile(curr(1,:),0.84);
                c=1;
                curr=0;
                x=x+1
                b = b+1;
                
                curr(1,c) = ia1s_sorted_EEG(j,1);
                c=c+1;
            end
        end
    end
end

dist_plots.avg_sd_binned_EEG_interict = avg_sd_binned_EEG_interict;
dist_plots.med_iq_binned_EEG_interict = med_iq_binned_EEG_interict;
dist_plots.ia1s_sorted_EEG_interict = ia1s_sorted_EEG;

%ictal EEG
ia1s_EEG = squeeze(ict_EEG_extrap(1:2,:))';
ia1s_sorted_EEG = sortrows(ia1s_EEG,2);


clear avg_sd_binned_EEG_ict med_iq_binned_EEG_ict
b = 1;
c=1;
curr = 0;
x=1;
d=1;
avg_sd_binned_EEG_ict = [];
med_iq_binned_EEG_ict = [];


for j = 1:length(ia1s_sorted_EEG)
    if ia1s_sorted_EEG(j,2)<1
        curr(1,c) = ia1s_sorted_EEG(j,1);
        c=c+1;
        
        
    else %if ia1s_sorted_EEG(j,2)>0
        if ia1s_sorted_EEG(j-1,2)<1
            
            avg_sd_binned_EEG_ict(1,x) = mean(curr(1,:));
            avg_sd_binned_EEG_ict(2,x) = std(curr(1,:),1);
            med_iq_binned_EEG_ict(1,x) = median(curr(1,:));
            % med_iq_binned_EEG_ict(2,x) = quantile(curr(1,:),0.16);
            % med_iq_binned_EEG_ict(3,x) = quantile(curr(1,:),0.84);
            c=1;
            curr=0;
            x=x+1
            b = b+1;
            
            curr(1,c) = ia1s_sorted_EEG(j,1);
            c=c+1;
            
            
        else
            if ia1s_sorted_EEG(j,2) < b && ia1s_sorted_EEG(j,2) >= (b-1)
                curr(1,c) = ia1s_sorted_EEG(j,1);
                c=c+1;
            else
                
                avg_sd_binned_EEG_ict(1,x) = mean(curr(1,:));
                avg_sd_binned_EEG_ict(2,x) = std(curr(1,:),1);
                med_iq_binned_EEG_ict(1,x) = median(curr(1,:));
                %med_iq_binned_EEG_ict(2,x) = quantile(curr(1,:),0.16);
                % med_iq_binned_EEG_ict(3,x) = quantile(curr(1,:),0.84);
                c=1;
                curr=0;
                x=x+1
                b = b+1;
                
                curr(1,c) = ia1s_sorted_EEG(j,1);
                c=c+1;
            end
        end
    end
end

dist_plots.avg_sd_binned_EEG_ict = avg_sd_binned_EEG_ict;
dist_plots.med_iq_binned_EEG_ict = med_iq_binned_EEG_ict;
dist_plots.ia1s_sorted_EEG_ict = ia1s_sorted_EEG;


%cut off some activity from right after previous offset:
clear interict_act ict_act ia2 ia3 iia2 iia3
%first cut out forbidden interictal and ictal periods:

forb_seiz_inds = union(tds.forb_seiz_inds,tds.offset_seizures_out);
interict_act=0;
ict_act=0;

for i = 1:endframe
    z=1
    j=tds.soffd(1,1)
    curr_seizz = 1;
    while j<tds.sond(1,ns)&& j<length(matrix)+1%(1,ns)
        
        if j>=tds.sond(1,curr_seizz+1)
            curr_seizz = curr_seizz+1;
        end
        
        if seiz_dists.interictal(1,j) && (ismember(curr_seizz,forb_seiz_inds) == 0)
            interict_act(1,z,i) = matrix(j,i);
            ia1(1,z) = matrix(j,i);
            
            if j<length(seiz_dists.next_ons_dists)
                interict_act(2,z,i) = seiz_dists.next_ons_dists(1,j);
                ia2(1,z) = seiz_dists.next_ons_dists(1,j);
            end
            
            interict_act(3,z,i) = seiz_dists.prev_offs_dists(1,j);
            ia3(1,z) = seiz_dists.prev_offs_dists(1,j);
            
            z = z+1;
        end
        j = j+1;
    end
    
    %identify ictal periods
    zi=1
    ji=tds.sond(1,1)
    a = 1;
    curr_seizzz = 1;
    while ji<length(matrix)+1 && ji<length(seiz_dists.ictal) %ji<tds.soffd(1,ns) && 
        
        if curr_seizzz<length(tds.sond)
            if ji>=tds.sond(1,curr_seizzz+1)
                curr_seizzz = curr_seizzz+1;
            end
        end
        
        if seiz_dists.ictal(1,ji) && (ismember(curr_seizzz,forb_seiz_inds) == 0)
            ict_act(1,zi,i) = matrix(ji,i);
            
            if ji > tds.soffd(a)
                a=a+1;
            end
            
            if ji<length(seiz_dists.prev_offs_dists)
                ict_act(2,zi,i) = ji-tds.sond(1,curr_seizzz);
                iia2(1,zi) = ji-tds.sond(1,curr_seizzz);
            end
            ict_act(3,zi,i) = tds.soffd(1,curr_seizzz)-ji;
            iia3(1,zi) = tds.soffd(1,curr_seizzz)-ji;
            
            zi = zi+1;
        end
        ji = ji+1;
    end
    
end

dist_plots.interict_act = interict_act;
dist_plots.ict_act = ict_act;

clear twosec_prev_out onesec_prev_out threesec_prev_out
a=1;
b=1;
c=1;
if interict_act == 0
   dist_plots.interict_act=0;
else
    for i=1:size(interict_act,2)
        if interict_act(3,i,1) > 0
            if interict_act(3,i,1)<2000/i2.msperline
                twosec_prev_out(1,a) = i;
                a = a+1;
            end
            if interict_act(3,i,1)<1000/i2.msperline
                onesec_prev_out(1,b) = i;
                b = b+1;
            end
            if interict_act(3,i,1)<3000/i2.msperline
                threesec_prev_out(1,c) = i;
                c = c+1;
            end
        end
    end
    
    
    interict_act_no_1sec_prev = interict_act;
    interict_act_no_1sec_prev(:,onesec_prev_out,:) = [];
    
    interict_act_no_2sec_prev = interict_act;
    interict_act_no_2sec_prev(:,twosec_prev_out,:) = [];
    
    interict_act_no_3sec_prev = interict_act;
    interict_act_no_3sec_prev(:,threesec_prev_out,:) = [];
    
    dist_plots.interict_act_no_1sec_prev = interict_act_no_1sec_prev;
    dist_plots.interict_act_no_2sec_prev = interict_act_no_2sec_prev;
    dist_plots.interict_act_no_3sec_prev = interict_act_no_3sec_prev;
    
    
    %cut off some activity from right before next onset:
    clear twosec_next_out onesec_next_out threesec_next_out
    twosec_next_out = 0
    onesec_next_out = 0
    threesec_next_out = 0
    a=1;
    b=1;
    c=1;
    for i=1:size(interict_act,2)
        if interict_act(2,i,1) > 0
            if interict_act(2,i,1)<2000/i2.msperline
                twosec_next_out(1,a) = i;
                a = a+1;
            end
            if interict_act(2,i,1)<1000/i2.msperline
                onesec_next_out(1,b) = i;
                b = b+1;
            end
            if interict_act(2,i,1)<3000/i2.msperline
                threesec_next_out(1,c) = i;
                c = c+1;
            end
        end
    end
    
    
    interict_act_no_1sec_next = interict_act;
    if onesec_next_out==0
    else
    interict_act_no_1sec_next(:,onesec_next_out,:) = [];
    end
    
    interict_act_no_2sec_next = interict_act;
       if twosec_next_out==0
    else
    interict_act_no_2sec_next(:,twosec_next_out,:) = [];
       end
       
    interict_act_no_3sec_next = interict_act;
      if threesec_next_out==0
    else
    interict_act_no_3sec_next(:,threesec_next_out,:) = [];
      end
    
    dist_plots.interict_act_no_1sec_next = interict_act_no_1sec_next;
    dist_plots.interict_act_no_2sec_next = interict_act_no_2sec_next;
    dist_plots.interict_act_no_3sec_next = interict_act_no_3sec_next;
    
    
    clear interict_act_binned ict_act_binned avg_sd_binned_ict med_iq_binned_ict...
        avg_sd_binned_ict_bef_offs med_iq_binned_ict_bef_offs avg_sd_binned_interict_aft_offset ...
        med_iq_binned_interict_aft_offset avg_sd_binned_interict_aft_offset_no_1sec_next ...
        med_iq_binned_interict_aft_offset_no_1sec_next avg_sd_binned_interict_aft_offset_no_2sec_next...
        med_iq_binned_interict_aft_offset_no_2sec_next med_iq_binned_interict_aft_offset_no_3sec_next ...
        avg_sd_binned_interict_aft_offset_no_3sec_next avg_sd_binned_1s med_iq_binned_1s ...
        avg_sd_binned_2s med_iq_binned_2s vg_sd_binned_3s med_iq_binned_3s vg_sd_binned_0s med_iq_binned_0s
    
    
    avg_sd_binned_interict_aft_offset = zeros(2,20,endframe);
    avg_sd_binned_0s = zeros(2,20,endframe);
    avg_sd_binned_interict_aft_offset_no_3sec_next = zeros(2,20,endframe);
    avg_sd_binned_3s = zeros(2,20,endframe);
    for i = 1:endframe
        
        %ictal activity after onset
        
        ia1s = squeeze(ict_act(1:2,:,i))';
        ia1s_sorted = sortrows(ia1s,2);
        
        b = min(round(500/i2.msperline),max(ia1s_sorted(:,2))-1); %added "min....,length(ia1s_sorted)-2)" 05/01/21 JM, also below.
        c=1;
        curr = 0;
        x=1;
        d=1;
        for j = 1:length(ia1s_sorted)
            if ia1s_sorted(j,2)>0
                if ia1s_sorted(j,2) <= b && ia1s_sorted(j,2) > round((x-1)*500/i2.msperline)
                    curr(1,c) = ia1s_sorted(j,1);
                    c=c+1;
                else
                    ict_act_binned(x).aft_onset = curr;
                    avg_sd_binned_ict(1,x,i) = mean(curr(1,:));
                    avg_sd_binned_ict(2,x,i) = std(curr(1,:),1);
                    %                 med_iq_binned_ict(1,x,i) = median(curr(1,:));
                    %                 med_iq_binned_ict(2,x,i) = quantile(curr(1,:),0.16);
                    %                 med_iq_binned_ict(3,x,i) = quantile(curr(1,:),0.84);
                    
                    c=1;
                    curr=0;
                    x=x+1
                    b = round(x*500/i2.msperline);
                end
            end
        end
        
        %ictal activity before offset
        
        ia1sa = squeeze(ict_act(1,:,i))';
        ia1sb = squeeze(ict_act(3,:,i))';
        ia1sc = cat(2,ia1sa,ia1sb);
        ia1s_sorted = sortrows(ia1sc,2);
        
        b = min(round(500/i2.msperline),max(ia1s_sorted(:,2))-1);
        c=1;
        curr = 0;
        x=1;
        d=1;
        for j = 1:length(ia1s_sorted)
            if ia1s_sorted(j,2)>0
                if ia1s_sorted(j,2) <= b && ia1s_sorted(j,2) > round((x-1)*500/i2.msperline)
                    curr(1,c) = ia1s_sorted(j,1);
                    c=c+1;
                else
                    ict_act_binned(x).bef_offset = curr;
                    avg_sd_binned_ict_bef_offs(1,x,i) = mean(curr(1,:));
                    avg_sd_binned_ict_bef_offs(2,x,i) = std(curr(1,:),1);
                    %                 med_iq_binned_ict_bef_offs(1,x,i) = median(curr(1,:));
                    %                 med_iq_binned_ict_bef_offs(2,x,i) = quantile(curr(1,:),0.16);
                    %                 med_iq_binned_ict_bef_offs(3,x,i) = quantile(curr(1,:),0.84);
                    
                    c=1;
                    curr=0;
                    x=x+1
                    b = round(x*500/i2.msperline);
                end
            end
        end
        
        %interictal activity after offset
        
        ia1sa = squeeze(interict_act(1,:,i))';
        ia1sb = squeeze(interict_act(3,:,i))';
        ia1sc = cat(2,ia1sa,ia1sb);
        ia1s_sorted = sortrows(ia1sc,2);
        
        b = round(500/i2.msperline);
        c=1;
        curr = 0;
        x=1;
        d=1;
        for j = 1:length(ia1s_sorted)
            if ia1s_sorted(j,2)>0
                if ia1s_sorted(j,2) <= b && ia1s_sorted(j,2) > round((x-1)*500/i2.msperline)
                    curr(1,c) = ia1s_sorted(j,1);
                    c=c+1;
                else
                    interict_act_binned(x).aft_offset = curr;
                    avg_sd_binned_interict_aft_offset(1,x,i) = mean(curr(1,:));
                    avg_sd_binned_interict_aft_offset(2,x,i) = std(curr(1,:),1);
                    %                 med_iq_binned_interict_aft_offset(1,x,i) = median(curr(1,:));
                    %                 med_iq_binned_interict_aft_offset(2,x,i) = quantile(curr(1,:),0.16);
                    %                 med_iq_binned_interict_aft_offset(3,x,i) = quantile(curr(1,:),0.84);
                    
                    c=1;
                    curr=0;
                    x=x+1
                    b = round(x*500/i2.msperline);
                end
            end
        end
        
        %interictal activity after offset without 1 sec before next onset
        
        ia1sa = squeeze(interict_act_no_1sec_next(1,:,i))';
        ia1sb = squeeze(interict_act_no_1sec_next(3,:,i))';
        ia1sc = cat(2,ia1sa,ia1sb);
        ia1s_sorted = sortrows(ia1sc,2);
        
        b = round(500/i2.msperline);
        c=1;
        curr = 0;
        x=1;
        d=1;
        for j = 1:length(ia1s_sorted)
            if ia1s_sorted(j,2)>0
                if ia1s_sorted(j,2) <= b && ia1s_sorted(j,2) > round((x-1)*500/i2.msperline)
                    curr(1,c) = ia1s_sorted(j,1);
                    c=c+1;
                else
                    interict_act_binned(x).aft_offset_no_1sec_next = curr;
                    avg_sd_binned_interict_aft_offset_no_1sec_next(1,x,i) = mean(curr(1,:));
                    avg_sd_binned_interict_aft_offset_no_1sec_next(2,x,i) = std(curr(1,:),1);
                    %                 med_iq_binned_interict_aft_offset_no_1sec_next(1,x,i) = median(curr(1,:));
                    %                 med_iq_binned_interict_aft_offset_no_1sec_next(2,x,i) = quantile(curr(1,:),0.16);
                    %                 med_iq_binned_interict_aft_offset_no_1sec_next(3,x,i) = quantile(curr(1,:),0.84);
                    
                    c=1;
                    curr=0;
                    x=x+1
                    b = round(x*500/i2.msperline);
                end
            end
        end
        
        
        %same without 2 sec before next onset
        
        
        ia1sa = squeeze(interict_act_no_2sec_next(1,:,i))';
        ia1sb = squeeze(interict_act_no_2sec_next(3,:,i))';
        ia1sc = cat(2,ia1sa,ia1sb);
        ia1s_sorted = sortrows(ia1sc,2);
        
        b = round(500/i2.msperline);
        c=1;
        curr = 0;
        x=1;
        d=1;
        for j = 1:length(ia1s_sorted)
            if ia1s_sorted(j,2)>0
                if ia1s_sorted(j,2) <= b && ia1s_sorted(j,2) > round((x-1)*500/i2.msperline)
                    curr(1,c) = ia1s_sorted(j,1);
                    c=c+1;
                else
                    interict_act_binned(x).aft_offset_no_2sec_next = curr;
                    avg_sd_binned_interict_aft_offset_no_2sec_next(1,x,i) = mean(curr(1,:));
                    avg_sd_binned_interict_aft_offset_no_2sec_next(2,x,i) = std(curr(1,:),1);
                    %                 med_iq_binned_interict_aft_offset_no_2sec_next(1,x,i) = median(curr(1,:));
                    %                 med_iq_binned_interict_aft_offset_no_2sec_next(2,x,i) = quantile(curr(1,:),0.16);
                    %                 med_iq_binned_interict_aft_offset_no_2sec_next(3,x,i) = quantile(curr(1,:),0.84);
                    
                    c=1;
                    curr=0;
                    x=x+1
                    b = round(x*500/i2.msperline);
                end
            end
        end
        
        %same without 3 sec before next onset
        
        
        ia1sa = squeeze(interict_act_no_3sec_next(1,:,i))';
        ia1sb = squeeze(interict_act_no_3sec_next(3,:,i))';
        ia1sc = cat(2,ia1sa,ia1sb);
        ia1s_sorted = sortrows(ia1sc,2);
        
        b = round(500/i2.msperline);
        c=1;
        curr = 0;
        x=1;
        d=1;
        for j = 1:length(ia1s_sorted)
            if ia1s_sorted(j,2)>0
                if ia1s_sorted(j,2) <= b && ia1s_sorted(j,2) > round((x-1)*500/i2.msperline)
                    curr(1,c) = ia1s_sorted(j,1);
                    c=c+1;
                else
                    interict_act_binned(x).aft_offset_no_3sec_next = curr;
                    avg_sd_binned_interict_aft_offset_no_3sec_next(1,x,i) = mean(curr(1,:));
                    avg_sd_binned_interict_aft_offset_no_3sec_next(2,x,i) = std(curr(1,:),1);
                    %                 med_iq_binned_interict_aft_offset_no_3sec_next(1,x,i) = median(curr(1,:));
                    %                 med_iq_binned_interict_aft_offset_no_3sec_next(2,x,i) = quantile(curr(1,:),0.16);
                    %                 med_iq_binned_interict_aft_offset_no_3sec_next(3,x,i) = quantile(curr(1,:),0.84);
                    
                    c=1;
                    curr=0;
                    x=x+1
                    b = round(x*500/i2.msperline);
                end
            end
        end
        
        
        %avg and SD for interict without fist 1 sec after previous seizure offset
        
        ia1s = squeeze(interict_act_no_1sec_prev(1:2,:,i))';
        ia1s_sorted = sortrows(ia1s,2);
        
        b = round(500/i2.msperline);
        c=1;
        curr = 0;
        x=1;
        d=1;
        for j = 1:length(ia1s_sorted)
            if ia1s_sorted(j,2)>0
                if ia1s_sorted(j,2) <= b && ia1s_sorted(j,2) > round((x-1)*500/i2.msperline)
                    curr(1,c) = ia1s_sorted(j,1);
                    c=c+1;
                else
                    
                    interict_act_binned(x).bef_onset_no_1sec_prev = curr;
                    avg_sd_binned_1s(1,x,i) = mean(curr(1,:));
                    avg_sd_binned_1s(2,x,i) = std(curr(1,:),1);
                    %                 med_iq_binned_1s(1,x,i) = median(curr(1,:));
                    %                 med_iq_binned_1s(2,x,i) = quantile(curr(1,:),0.16);
                    %                 med_iq_binned_1s(3,x,i) = quantile(curr(1,:),0.84);
                    %
                    c=1;
                    curr=0;
                    x=x+1
                    b = round(x*500/i2.msperline);
                end
            end
        end
        
        %avg and SD for interict without fist 2 sec after previous seizure offset
        ia2s = squeeze(interict_act_no_2sec_prev(1:2,:,i))';
        ia2s_sorted = sortrows(ia2s,2);
        
        b = round(500/i2.msperline);
        c=1;
        curr = 0;
        x=1;
        d=1;
        for j = 1:length(ia2s_sorted)
            if ia2s_sorted(j,2)>0
                if ia2s_sorted(j,2) <= b && ia2s_sorted(j,2) > round((x-1)*500/i2.msperline)
                    curr(1,c) = ia2s_sorted(j,1);
                    c=c+1;
                else
                    interict_act_binned(x).bef_onset_no_2sec_prev = curr;
                    avg_sd_binned_2s(1,x,i) = mean(curr(1,:));
                    avg_sd_binned_2s(2,x,i) = std(curr(1,:),1);
                    %                 med_iq_binned_2s(1,x,i) = median(curr(1,:));
                    %                 med_iq_binned_2s(2,x,i) = quantile(curr(1,:),0.16);
                    %                 med_iq_binned_2s(3,x,i) = quantile(curr(1,:),0.84);
                    c=1;
                    curr=0;
                    x=x+1
                    b = round(x*500/i2.msperline);
                end
            end
        end
        
        %avg and SD for interict without fist 3 sec after previous seizure offset
        ia3s = squeeze(interict_act_no_3sec_prev(1:2,:,i))';
        ia3s_sorted = sortrows(ia3s,2);
        
        b = round(500/i2.msperline);
        c=1;
        curr = 0;
        x=1;
        d=1;
        for j = 1:length(ia3s_sorted)
            if ia3s_sorted(j,2)>0
                if ia3s_sorted(j,2) <= b && ia3s_sorted(j,2) > round((x-1)*500/i2.msperline)
                    curr(1,c) = ia3s_sorted(j,1);
                    c=c+1;
                else
                    interict_act_binned(x).bef_onset_no_3sec_prev = curr;
                    avg_sd_binned_3s(1,x,i) = mean(curr(1,:));
                    avg_sd_binned_3s(2,x,i) = std(curr(1,:),1);
                    %                 med_iq_binned_3s(1,x,i) = median(curr(1,:));
                    %                 med_iq_binned_3s(2,x,i) = quantile(curr(1,:),0.16);
                    %                 med_iq_binned_3s(3,x,i) = quantile(curr(1,:),0.84);
                    c=1;
                    curr=0;
                    x=x+1
                    b = round(x*500/i2.msperline);
                end
            end
        end
        
        
        %avg and SD for interict without fist 0 sec after previous seizure offset
        ia3s = squeeze(interict_act(1:2,:,i))';
        ia3s_sorted = sortrows(ia3s,2);
        
        b = round(500/i2.msperline);
        c=1;
        curr = 0;
        x=1;
        d=1;
        for j = 1:length(ia3s_sorted)
            if ia3s_sorted(j,2)>0
                if ia3s_sorted(j,2) <= b && ia3s_sorted(j,2) > round((x-1)*500/i2.msperline)
                    curr(1,c) = ia3s_sorted(j,1);
                    c=c+1;
                else
                    avg_sd_binned_0s(1,x,i) = mean(curr(1,:));
                    avg_sd_binned_0s(2,x,i) = std(curr(1,:),1);
                    %                 med_iq_binned_0s(1,x,i) = median(curr(1,:));
                    %                 med_iq_binned_0s(2,x,i) = quantile(curr(1,:),0.16);
                    %                 med_iq_binned_0s(3,x,i) = quantile(curr(1,:),0.84);
                    interict_act_binned(x).bef_onset = curr;
                    c=1;
                    curr=0;
                    x=x+1
                    b = round(x*500/i2.msperline);
                end
            end
        end
        dist_plots.ROI(i).ict_act_binned = ict_act_binned;
        dist_plots.ROI(i).interict_act_binned = interict_act_binned;
    end
    
    dist_plots.avg_sd_binned_1s_interict = avg_sd_binned_1s;
    dist_plots.avg_sd_binned_2s_interict = avg_sd_binned_2s;
    dist_plots.avg_sd_binned_3s_interict = avg_sd_binned_3s;
    % dist_plots.med_iq_binned_1s_interict = med_iq_binned_1s;
    % dist_plots.med_iq_binned_2s_interict = med_iq_binned_2s;
    % dist_plots.med_iq_binned_3s_interict = med_iq_binned_3s;
    dist_plots.avg_sd_binned_ict = avg_sd_binned_ict;
    % dist_plots.med_iq_binned_ict = med_iq_binned_ict;
    dist_plots.avg_sd_binned_interict_aft_offset_no_1sec_next = avg_sd_binned_interict_aft_offset_no_1sec_next;
    dist_plots.avg_sd_binned_interict_aft_offset_no_2sec_next = avg_sd_binned_interict_aft_offset_no_2sec_next;
    dist_plots.avg_sd_binned_interict_aft_offset_no_3sec_next = avg_sd_binned_interict_aft_offset_no_3sec_next;
    % dist_plots.med_iq_binned_interict_aft_offset_no_1sec_next = med_iq_binned_interict_aft_offset_no_1sec_next;
    % dist_plots.med_iq_binned_interict_aft_offset_no_2sec_next = med_iq_binned_interict_aft_offset_no_2sec_next;
    % dist_plots.med_iq_binned_interict_aft_offset_no_3sec_next = med_iq_binned_interict_aft_offset_no_3sec_next;
    
    
    xict = size(avg_sd_binned_3s,2);
    
    
    %
    % %now plot all of that for the last 5 or 10 sec of activity before seizure
    % %onset
    % close all
    % fr = sec_plot*2;
    % xaxis = 1:1:fr+xict
    % if endframe<20
    %     z = endframe;
    % else
    %     z = 20;
    % end
    % h = 1;
    % rest = mod(endframe,20);
    % parties = (endframe-rest)/20;
    % for j=1:parties
    %     figure(41500+10*j)
    %     for i=1:5
    %         for k = 1:4
    %             subplot(5,4,k+(i-1)*4)
    %             %errorbar(avg_sd_binned_1s(1,:,(i-1)*4+k+(j-1)*20), avg_sd_binned_1s(2,:,(i-1)*4+k+(j-1)*20), 'Color',[0 0 0]);
    %
    %
    %             mib1 = squeeze(med_iq_binned_1s(1,1:fr,(i-1)*4+k+(j-1)*20));
    %             mibi1 =  squeeze(med_iq_binned_ict(1,1:xict,(i-1)*4+k+(j-1)*20));
    %             mib1 = fliplr(mib1);
    %             mib1cat = cat(2,mib1,mibi1);
    %
    %             mib2 = squeeze(med_iq_binned_1s(2,1:fr,(i-1)*4+k+(j-1)*20));
    %             mibi2 =  squeeze(med_iq_binned_ict(2,1:xict,(i-1)*4+k+(j-1)*20));
    %             mib2 = fliplr(mib2);
    %             mib2cat = cat(2,mib2,mibi2);
    %
    %             mib3 = squeeze(med_iq_binned_1s(3,1:fr,(i-1)*4+k+(j-1)*20));
    %             mibi3 =  squeeze(med_iq_binned_ict(3,1:xict,(i-1)*4+k+(j-1)*20));
    %             mib3 = fliplr(mib3);
    %             mib3cat = cat(2,mib3,mibi3);
    %
    %             plot(xaxis,mib1cat,'Color',[0 0 0])
    %             hold on
    %             plot( xaxis,mib2cat,'Color',[0.5 0.5 0.5])
    %             hold on
    %             plot(xaxis,mib3cat,'Color',[0.5 0.5 0.5])
    %             hold on
    %             line ([fr fr], [-fr fr])
    %
    %             ylabel(num2str((i-1)*4+k+(j-1)*20), 'FontName', 'Arial', 'FontSize', 8, 'FontWeight', 'bold');
    %             set(gca,'FontSize',8,'LineWidth',1,'TickLength',[0.01 0.01])
    %
    %             axis ([0 fr+xict -0.5 1.2 ])  %max(max(deltaf_matrix))
    %             ax = gca;
    %             ax.XTick = [0,10,20,30];
    %             %ax.YTick = [-1,-0.5,0,0.5,1];
    %             ax.XTickLabel = {'-10','-5','0','5',};
    %             %ax.YTickLabel = {'min = -1','-0.5','0','0.5','max = 1'};
    %
    %
    %
    %         end
    %     end
    %     saveas (41500+10*j,[Folder ' med_iq_binned_1s ' num2str(100+10*j) '.png' ],'png')
    % end
    %
    % j=parties+1
    % figure(41700+10*j)
    % for i=1:5
    %     for k = 1:4
    %         if (i-1)*4+k+(j-1)*20 <= endframe
    %             subplot(5,4,k+(i-1)*4)
    %
    %             mib1 = squeeze(med_iq_binned_1s(1,1:fr,(i-1)*4+k+(j-1)*20));
    %             mibi1 =  squeeze(med_iq_binned_ict(1,1:xict,(i-1)*4+k+(j-1)*20));
    %             mib1 = fliplr(mib1);
    %             mib1cat = cat(2,mib1,mibi1);
    %
    %             mib2 = squeeze(med_iq_binned_1s(2,1:fr,(i-1)*4+k+(j-1)*20));
    %             mibi2 =  squeeze(med_iq_binned_ict(2,1:xict,(i-1)*4+k+(j-1)*20));
    %             mib2 = fliplr(mib2);
    %             mib2cat = cat(2,mib2,mibi2);
    %
    %             mib3 = squeeze(med_iq_binned_1s(3,1:fr,(i-1)*4+k+(j-1)*20));
    %             mibi3 =  squeeze(med_iq_binned_ict(3,1:xict,(i-1)*4+k+(j-1)*20));
    %             mib3 = fliplr(mib3);
    %             mib3cat = cat(2,mib3,mibi3);
    %
    %             plot(xaxis,mib1cat,'Color',[0 0 0])
    %             hold on
    %             plot( xaxis,mib2cat,'Color',[0.5 0.5 0.5])
    %             hold on
    %             plot(xaxis,mib3cat,'Color',[0.5 0.5 0.5])
    %             hold on
    %             line ([fr fr], [-fr fr])
    %
    %             ylabel(num2str((i-1)*4+k+(j-1)*20), 'FontName', 'Arial', 'FontSize', 8, 'FontWeight', 'bold');
    %             set(gca,'FontSize',8,'LineWidth',1,'TickLength',[0.01 0.01])
    %
    %             axis ([0 fr+xict -0.5 1.2 ])  %max(max(deltaf_matrix))
    %             ax = gca;
    %             ax.XTick = [0,10,20,30];
    %             %ax.YTick = [-1,-0.5,0,0.5,1];
    %             ax.XTickLabel = {'-10','-5','0','5',};
    %             %ax.YTickLabel = {'min = -1','-0.5','0','0.5','max = 1'};
    %
    %         end
    %     end
    %     saveas (41700+10*j,[Folder ' med_iq_binned_1s ' num2str(100+10*j) '.png' ],'png')
    % end
    %
    %
    %
    % close all
    % if endframe<20
    %     z = endframe;
    % else
    %     z = 20;
    % end
    % h = 1;
    % rest = mod(endframe,20);
    % parties = (endframe-rest)/20;
    % for j=1:parties
    %     figure(41500+10*j)
    %     for i=1:5
    %         for k = 1:4
    %             subplot(5,4,k+(i-1)*4)
    %
    %             mib1 = squeeze(med_iq_binned_2s(1,1:fr,(i-1)*4+k+(j-1)*20));
    %             mibi1 =  squeeze(med_iq_binned_ict(1,1:xict,(i-1)*4+k+(j-1)*20));
    %             mib1 = fliplr(mib1);
    %             mib1cat = cat(2,mib1,mibi1);
    %
    %             mib2 = squeeze(med_iq_binned_2s(2,1:fr,(i-1)*4+k+(j-1)*20));
    %             mibi2 =  squeeze(med_iq_binned_ict(2,1:xict,(i-1)*4+k+(j-1)*20));
    %             mib2 = fliplr(mib2);
    %             mib2cat = cat(2,mib2,mibi2);
    %
    %             mib3 = squeeze(med_iq_binned_2s(3,1:fr,(i-1)*4+k+(j-1)*20));
    %             mibi3 =  squeeze(med_iq_binned_ict(3,1:xict,(i-1)*4+k+(j-1)*20));
    %             mib3 = fliplr(mib3);
    %             mib3cat = cat(2,mib3,mibi3);
    %
    %             plot(xaxis,mib1cat,'Color',[0 0 0])
    %             hold on
    %             plot( xaxis,mib2cat,'Color',[0.5 0.5 0.5])
    %             hold on
    %             plot(xaxis,mib3cat,'Color',[0.5 0.5 0.5])
    %             hold on
    %             line ([fr fr], [-fr fr])
    %
    %             ylabel(num2str((i-1)*4+k+(j-1)*20), 'FontName', 'Arial', 'FontSize', 8, 'FontWeight', 'bold');
    %             set(gca,'FontSize',8,'LineWidth',1,'TickLength',[0.01 0.01])
    %
    %             axis ([0 fr+xict -0.5 1.2 ])  %max(max(deltaf_matrix))
    %             ax = gca;
    %             ax.XTick = [0,10,20,30];
    %             %ax.YTick = [-1,-0.5,0,0.5,1];
    %             ax.XTickLabel = {'-10','-5','0','5',};
    %             %ax.YTickLabel = {'min = -1','-0.5','0','0.5','max = 1'};
    %
    %         end
    %     end
    %     saveas (41500+10*j,[Folder ' med_iq_binned_2s ' num2str(100+10*j) '.png' ],'png')
    % end
    %
    % j=parties+1
    % figure(41700+10*j)
    % for i=1:5
    %     for k = 1:4
    %         if (i-1)*4+k+(j-1)*20 <= endframe
    %             subplot(5,4,k+(i-1)*4)
    %
    %             mib1 = squeeze(med_iq_binned_2s(1,1:fr,(i-1)*4+k+(j-1)*20));
    %             mibi1 =  squeeze(med_iq_binned_ict(1,1:xict,(i-1)*4+k+(j-1)*20));
    %             mib1 = fliplr(mib1);
    %             mib1cat = cat(2,mib1,mibi1);
    %
    %             mib2 = squeeze(med_iq_binned_2s(2,1:fr,(i-1)*4+k+(j-1)*20));
    %             mibi2 =  squeeze(med_iq_binned_ict(2,1:xict,(i-1)*4+k+(j-1)*20));
    %             mib2 = fliplr(mib2);
    %             mib2cat = cat(2,mib2,mibi2);
    %
    %             mib3 = squeeze(med_iq_binned_2s(3,1:fr,(i-1)*4+k+(j-1)*20));
    %             mibi3 =  squeeze(med_iq_binned_ict(3,1:xict,(i-1)*4+k+(j-1)*20));
    %             mib3 = fliplr(mib3);
    %             mib3cat = cat(2,mib3,mibi3);
    %
    %             plot(xaxis,mib1cat,'Color',[0 0 0])
    %             hold on
    %             plot( xaxis,mib2cat,'Color',[0.5 0.5 0.5])
    %             hold on
    %             plot(xaxis,mib3cat,'Color',[0.5 0.5 0.5])
    %             hold on
    %             line ([fr fr], [-fr fr])
    %
    %             ylabel(num2str((i-1)*4+k+(j-1)*20), 'FontName', 'Arial', 'FontSize', 8, 'FontWeight', 'bold');
    %             set(gca,'FontSize',8,'LineWidth',1,'TickLength',[0.01 0.01])
    %
    %             axis ([0 fr+xict -0.5 1.2 ])  %max(max(deltaf_matrix))
    %             ax = gca;
    %             ax.XTick = [0,10,20,30];
    %             %ax.YTick = [-1,-0.5,0,0.5,1];
    %             ax.XTickLabel = {'-10','-5','0','5',};
    %             %ax.YTickLabel = {'min = -1','-0.5','0','0.5','max = 1'};
    %
    %         end
    %     end
    %     saveas (41700+10*j,[Folder ' med_iq_binned_2s ' num2str(100+10*j) '.png' ],'png')
    % end
    
    %
    % close all
    % if endframe<20
    %     z = endframe;
    % else
    %     z = 20;
    % end
    % h = 1;
    % rest = mod(endframe,20);
    % parties = (endframe-rest)/20;
    % for j=1:parties
    %     figure(41500+10*j)
    %     for i=1:5
    %         for k = 1:4
    %             subplot(5,4,k+(i-1)*4)
    %
    %             mib1 = squeeze(med_iq_binned_3s(1,1:fr,(i-1)*4+k+(j-1)*20));
    %             mibi1 =  squeeze(med_iq_binned_ict(1,1:xict,(i-1)*4+k+(j-1)*20));
    %             mib1 = fliplr(mib1);
    %             mib1cat = cat(2,mib1,mibi1);
    %
    %             mib2 = squeeze(med_iq_binned_3s(2,1:fr,(i-1)*4+k+(j-1)*20));
    %             mibi2 =  squeeze(med_iq_binned_ict(2,1:xict,(i-1)*4+k+(j-1)*20));
    %             mib2 = fliplr(mib2);
    %             mib2cat = cat(2,mib2,mibi2);
    %
    %             mib3 = squeeze(med_iq_binned_3s(3,1:fr,(i-1)*4+k+(j-1)*20));
    %             mibi3 =  squeeze(med_iq_binned_ict(3,1:xict,(i-1)*4+k+(j-1)*20));
    %             mib3 = fliplr(mib3);
    %             mib3cat = cat(2,mib3,mibi3);
    %
    %             plot(xaxis,mib1cat,'Color',[0 0 0])
    %             hold on
    %             plot( xaxis,mib2cat,'Color',[0.5 0.5 0.5])
    %             hold on
    %             plot(xaxis,mib3cat,'Color',[0.5 0.5 0.5])
    %             hold on
    %             line ([fr fr], [-fr fr])
    %
    %             ylabel(num2str((i-1)*4+k+(j-1)*20), 'FontName', 'Arial', 'FontSize', 8, 'FontWeight', 'bold');
    %             set(gca,'FontSize',8,'LineWidth',1,'TickLength',[0.01 0.01])
    %
    %             axis ([0 fr+xict -0.5 1.2 ])  %max(max(deltaf_matrix))
    %             ax = gca;
    %             ax.XTick = [0,10,20,30];
    %             %ax.YTick = [-1,-0.5,0,0.5,1];
    %             ax.XTickLabel = {'-10','-5','0','5',};
    %             %ax.YTickLabel = {'min = -1','-0.5','0','0.5','max = 1'};
    %
    %         end
    %     end
    %     saveas (41500+10*j,[Folder ' med_iq_binned_3s ' num2str(100+10*j) '.png' ],'png')
    % end
    %
    % j=parties+1
    % figure(41700+10*j)
    % for i=1:5
    %     for k = 1:4
    %         if (i-1)*4+k+(j-1)*20 <= endframe
    %             subplot(5,4,k+(i-1)*4)
    %
    %             mib1 = squeeze(med_iq_binned_3s(1,1:fr,(i-1)*4+k+(j-1)*20));
    %             mibi1 =  squeeze(med_iq_binned_ict(1,1:xict,(i-1)*4+k+(j-1)*20));
    %             mib1 = fliplr(mib1);
    %             mib1cat = cat(2,mib1,mibi1);
    %
    %             mib2 = squeeze(med_iq_binned_3s(2,1:fr,(i-1)*4+k+(j-1)*20));
    %             mibi2 =  squeeze(med_iq_binned_ict(2,1:xict,(i-1)*4+k+(j-1)*20));
    %             mib2 = fliplr(mib2);
    %             mib2cat = cat(2,mib2,mibi2);
    %
    %             mib3 = squeeze(med_iq_binned_3s(3,1:fr,(i-1)*4+k+(j-1)*20));
    %             mibi3 =  squeeze(med_iq_binned_ict(3,1:xict,(i-1)*4+k+(j-1)*20));
    %             mib3 = fliplr(mib3);
    %             mib3cat = cat(2,mib3,mibi3);
    %
    %             plot(xaxis,mib1cat,'Color',[0 0 0])
    %             hold on
    %             plot( xaxis,mib2cat,'Color',[0.5 0.5 0.5])
    %             hold on
    %             plot(xaxis,mib3cat,'Color',[0.5 0.5 0.5])
    %             hold on
    %             line ([fr fr], [-fr fr])
    %
    %             ylabel(num2str((i-1)*4+k+(j-1)*20), 'FontName', 'Arial', 'FontSize', 8, 'FontWeight', 'bold');
    %             set(gca,'FontSize',8,'LineWidth',1,'TickLength',[0.01 0.01])
    %
    %             axis ([0 fr+xict -0.5 1.2 ])  %max(max(deltaf_matrix))
    %             ax = gca;
    %             ax.XTick = [0,10,20,30];
    %             %ax.YTick = [-1,-0.5,0,0.5,1];
    %             ax.XTickLabel = {'-10','-5','0','5',};
    %             %ax.YTickLabel = {'min = -1','-0.5','0','0.5','max = 1'};
    %
    %         end
    %     end
    %     saveas (41700+10*j,[Folder ' med_iq_binned_3s ' num2str(100+10*j) '.png' ],'png')
    % end
    
    
    
    %EEG...
    %
    % figure(435)
    % subplot(1,2,2)
    % lk = length(med_iq_binned_EEG_ict);
    % xaxis = 1:1:lk;
    % gr = [0.5 0.5 0.5];
    % plot(xaxis,med_iq_binned_EEG_ict(1,:),'Color',[0 0 0])
    % hold on
    % plot(xaxis,med_iq_binned_EEG_ict(2,:),'Color',[0.5 0.5 0.5])
    % hold on
    % plot(xaxis,med_iq_binned_EEG_ict(3,:),'Color',[0.5 0.5 0.5])
    % axis([0 600 -.3 .3])
    % ax = gca;
    % ax.XTick = [0,500,];
    % %ax.YTick = [-1,-0.5,0,0.5,1];
    % ax.XTickLabel = {'0','5'};
    % %ax.YTickLabel = {'min = -1','-0.5','0','0.5','max = 1'};
    %
    % subplot(1,2,1)
    % mib = fliplr(med_iq_binned_EEG_interict);
    % lk = length(mib);
    % xaxis = 1:1:lk;
    % plot(xaxis,mib(1,:),'Color',[0 0 0])
    % hold on
    % plot(xaxis,mib(2,:),'Color',[0.5 0.5 0.5])
    % hold on
    % plot( xaxis,mib(3,:),'Color',[0.5 0.5 0.5])
    % axis([lk-1000 lk -.3 .3])
    % ax = gca;
    % ax.XTick = [lk-1000,lk-500,lk];
    % %ax.YTick = [-1,-0.5,0,0.5,1];
    % ax.XTickLabel = {'-10','-5','0'};
    % %ax.YTickLabel = {'min = -1','-0.5','0','0.5','max = 1'};
    % saveas (435,[Folder ' med_iq_binned_EEG '  '.png' ],'png')
    %
    
    
    % now plot activity around offset
    %
    % %now plot all of that for the last 5 or 10 sec of activity before seizure
    % %onset
    % close all
    % fr = sec_plot*2;
    % xaxis = 1:1:fr+xict
    % if endframe<20
    %     z = endframe;
    % else
    %     z = 20;
    % end
    % h = 1;
    % rest = mod(endframe,20);
    % parties = (endframe-rest)/20;
    % for j=1:parties
    %     figure(41500+10*j)
    %     for i=1:5
    %         for k = 1:4
    %             subplot(5,4,k+(i-1)*4)
    %             %errorbar(avg_sd_binned_1s(1,:,(i-1)*4+k+(j-1)*20), avg_sd_binned_1s(2,:,(i-1)*4+k+(j-1)*20), 'Color',[0 0 0]);
    %
    %
    %             mibi1 = squeeze(med_iq_binned_interict_aft_offset(1,1:fr,(i-1)*4+k+(j-1)*20));
    %             mib1 =  squeeze(med_iq_binned_ict_bef_offs(1,1:xict,(i-1)*4+k+(j-1)*20));
    %             mib1 = fliplr(mib1);
    %             mib1cat = cat(2,mib1,mibi1);
    %
    %             mibi2 = squeeze(med_iq_binned_interict_aft_offset(2,1:fr,(i-1)*4+k+(j-1)*20));
    %             mib2 =  squeeze(med_iq_binned_ict_bef_offs(2,1:xict,(i-1)*4+k+(j-1)*20));
    %             mib2 = fliplr(mib2);
    %             mib2cat = cat(2,mib2,mibi2);
    %
    %             mibi3 = squeeze(med_iq_binned_interict_aft_offset(3,1:fr,(i-1)*4+k+(j-1)*20));
    %             mib3 =  squeeze(med_iq_binned_ict_bef_offs(3,1:xict,(i-1)*4+k+(j-1)*20));
    %             mib3 = fliplr(mib3);
    %             mib3cat = cat(2,mib3,mibi3);
    %
    %             plot(xaxis,mib1cat,'Color',[0 0 0])
    %             hold on
    %             plot( xaxis,mib2cat,'Color',[0.5 0.5 0.5])
    %             hold on
    %             plot(xaxis,mib3cat,'Color',[0.5 0.5 0.5])
    %             hold on
    %             line ([xict xict], [-xict xict])
    %
    %             ylabel(num2str((i-1)*4+k+(j-1)*20), 'FontName', 'Arial', 'FontSize', 8, 'FontWeight', 'bold');
    %             set(gca,'FontSize',8,'LineWidth',1,'TickLength',[0.01 0.01])
    %
    %
    %             axis ([0 fr+xict -0.5 1.2 ])  %max(max(deltaf_matrix))
    %             ax = gca;
    %             ax.XTick = [xict-10,xict,xict+10,xict+20];
    %             %ax.YTick = [-1,-0.5,0,0.5,1];
    %             ax.XTickLabel = {'-5','0','5','10',};
    %             %ax.YTickLabel = {'min = -1','-0.5','0','0.5','max = 1'};
    %
    %
    %         end
    %     end
    %     saveas (41500+10*j,[Folder ' med_iq_binned_around_offset ' num2str(100+10*j) '.png' ],'png')
    % end
    %
    % j=parties+1
    % figure(41700+10*j)
    % for i=1:5
    %     for k = 1:4
    %         if (i-1)*4+k+(j-1)*20 <= endframe
    %             subplot(5,4,k+(i-1)*4)
    %
    %             mibi1 = squeeze(med_iq_binned_interict_aft_offset(1,1:fr,(i-1)*4+k+(j-1)*20));
    %             mib1 =  squeeze(med_iq_binned_ict_bef_offs(1,1:xict,(i-1)*4+k+(j-1)*20));
    %             mib1 = fliplr(mib1);
    %             mib1cat = cat(2,mib1,mibi1);
    %
    %             mibi2 = squeeze(med_iq_binned_interict_aft_offset(2,1:fr,(i-1)*4+k+(j-1)*20));
    %             mib2 =  squeeze(med_iq_binned_ict_bef_offs(2,1:xict,(i-1)*4+k+(j-1)*20));
    %             mib2 = fliplr(mib2);
    %             mib2cat = cat(2,mib2,mibi2);
    %
    %             mibi3 = squeeze(med_iq_binned_interict_aft_offset(3,1:fr,(i-1)*4+k+(j-1)*20));
    %             mib3 =  squeeze(med_iq_binned_ict_bef_offs(3,1:xict,(i-1)*4+k+(j-1)*20));
    %             mib3 = fliplr(mib3);
    %             mib3cat = cat(2,mib3,mibi3);
    %
    %             plot(xaxis,mib1cat,'Color',[0 0 0])
    %             hold on
    %             plot( xaxis,mib2cat,'Color',[0.5 0.5 0.5])
    %             hold on
    %             plot(xaxis,mib3cat,'Color',[0.5 0.5 0.5])
    %             hold on
    %             line ([xict xict], [-xict xict])
    %
    %             ylabel(num2str((i-1)*4+k+(j-1)*20), 'FontName', 'Arial', 'FontSize', 8, 'FontWeight', 'bold');
    %             set(gca,'FontSize',8,'LineWidth',1,'TickLength',[0.01 0.01])
    %
    %             axis ([0 fr+xict -0.5 1.2 ])  %max(max(deltaf_matrix))
    %             ax = gca;
    %             ax.XTick = [xict-10,xict,xict+10,xict+20];
    %             %ax.YTick = [-1,-0.5,0,0.5,1];
    %             ax.XTickLabel = {'-5','0','5','10',};
    %             %ax.YTickLabel = {'min = -1','-0.5','0','0.5','max = 1'};
    %
    %         end
    %     end
    %     saveas (41700+10*j,[Folder ' med_iq_binned_around_offset ' num2str(100+10*j) '.png' ],'png')
    % end
    %
    
    %plot the same, but average and SD
    
    xict = size(avg_sd_binned_ict_bef_offs,2);
    dist_plots.avg_sd_binned_ict_bef_offs = avg_sd_binned_ict_bef_offs;
    
    % close all
    fr = sec_plot*2;
    xaxis = 1:1:fr+xict
    if endframe<20
        z = endframe;
    else
        z = 20;
    end
    h = 1;
    rest = mod(endframe,20);
    parties = (endframe-rest)/20;
    for j=1:parties
        figure(71500+10*j)
        for i=1:5
            for k = 1:4
                
                %if (i-1)*4+k+(j-1)*20 == 5 || (i-1)*4+k+(j-1)*20 == 13
                
                subplot(5,4,k+(i-1)*4)
                %errorbar(avg_sd_binned_1s(1,:,(i-1)*4+k+(j-1)*20), avg_sd_binned_1s(2,:,(i-1)*4+k+(j-1)*20), 'Color',[0 0 0]);
                
                size(avg_sd_binned_interict_aft_offset)
                fr
                (i-1)*4+k+(j-1)*20
                mibi1 = squeeze(avg_sd_binned_interict_aft_offset(1,1:fr,(i-1)*4+k+(j-1)*20));
                mib1 =  squeeze(avg_sd_binned_ict_bef_offs(1,1:xict,(i-1)*4+k+(j-1)*20));
                mib1 = fliplr(mib1);
                mib1cat = cat(2,mib1,mibi1);
                
                mibi2 = squeeze(avg_sd_binned_interict_aft_offset(2,1:fr,(i-1)*4+k+(j-1)*20));
                mib2 =  squeeze(avg_sd_binned_ict_bef_offs(2,1:xict,(i-1)*4+k+(j-1)*20));
                mib2 = fliplr(mib2);
                mib2cat = cat(2,mib2,mibi2);
                mib2cat = mib2cat+mib1cat;
                %             mibi3 = squeeze(avg_sd_binned_interict_aft_offset(3,1:fr,(i-1)*4+k+(j-1)*20));
                %             mib3 =  squeeze(avg_sd_binned_ict_bef_offs(3,1:xict,(i-1)*4+k+(j-1)*20));
                %             mib3 = fliplr(mib3);
                %             mib3cat = cat(2,mib3,mibi3);
                
                plot(xaxis,mib1cat,'Color',[0 0 0])
                hold on
                plot( xaxis,mib2cat,'Color',[0.5 0.5 0.5])
                hold on
                %             plot(xaxis,mib3cat,'Color',[0.5 0.5 0.5])
                %             hold on
                line ([xict xict], [-xict xict])
                
                ylabel(num2str((i-1)*4+k+(j-1)*20), 'FontName', 'Arial', 'FontSize', 8, 'FontWeight', 'bold');
                set(gca,'FontSize',8,'LineWidth',1,'TickLength',[0.01 0.01])
                
                %change y-axis back to -0.5 1.2!
                axis ([0 fr+xict 0 abs(max(mib2cat)*1.2+0.1)])% max(max(deltaf_matrix))])
                ax = gca;
                ax.XTick = [xict-10,xict,xict+10,xict+20];
                %ax.YTick = [-1,-0.5,0,0.5,1];
                ax.XTickLabel = {'-5','0','5','10',};
                %ax.YTickLabel = {'min = -1','-0.5','0','0.5','max = 1'};
                
                %end
                
            end
        end
        if sf
            saveas (71500+10*j,[Folder ' avg_sd_binned_around_offset ' num2str(100+10*j) '.png' ],'png')
        end
    end
    
    %close all
    
    j=parties+1
    figure(71700+10*j)
    for i=1:5
        for k = 1:4
            if (i-1)*4+k+(j-1)*20 <= endframe
                
                
                % if (i-1)*4+k+(j-1)*20 == 5 || (i-1)*4+k+(j-1)*20 == 13
                
                
                subplot(5,4,k+(i-1)*4)
                
                mibi1 = squeeze(avg_sd_binned_interict_aft_offset(1,1:fr,(i-1)*4+k+(j-1)*20));
                mib1 =  squeeze(avg_sd_binned_ict_bef_offs(1,1:xict,(i-1)*4+k+(j-1)*20));
                mib1 = fliplr(mib1);
                mib1cat = cat(2,mib1,mibi1);
                
                mibi2 = squeeze(avg_sd_binned_interict_aft_offset(2,1:fr,(i-1)*4+k+(j-1)*20));
                mib2 =  squeeze(avg_sd_binned_ict_bef_offs(2,1:xict,(i-1)*4+k+(j-1)*20));
                mib2 = fliplr(mib2);
                mib2cat = cat(2,mib2,mibi2);
                mib2cat = mib2cat+mib1cat;
                %             mibi3 = squeeze(avg_sd_binned_interict_aft_offset(3,1:fr,(i-1)*4+k+(j-1)*20));
                %             mib3 =  squeeze(avg_sd_binned_ict_bef_offs(3,1:xict,(i-1)*4+k+(j-1)*20));
                %             mib3 = fliplr(mib3);
                %             mib3cat = cat(2,mib3,mibi3);
                
                plot(xaxis,mib1cat,'Color',[0 0 0])
                hold on
                plot( xaxis,mib2cat,'Color',[0.5 0.5 0.5])
                hold on
                %             plot(xaxis,mib3cat,'Color',[0.5 0.5 0.5])
                %             hold on
                line ([xict xict], [-xict xict])
                
                ylabel(num2str((i-1)*4+k+(j-1)*20), 'FontName', 'Arial', 'FontSize', 8, 'FontWeight', 'bold');
                set(gca,'FontSize',8,'LineWidth',1,'TickLength',[0.01 0.01])
                
                axis ([0 fr+xict 0 max(mib2cat)*1.2+0.1])% max(max(deltaf_matrix)) ])
                ax = gca;
                ax.XTick = [xict-10,xict,xict+10,xict+20];
                %ax.YTick = [-1,-0.5,0,0.5,1];
                ax.XTickLabel = {'-5','0','5','10',};
                %ax.YTickLabel = {'min = -1','-0.5','0','0.5','max = 1'};
                %   end
            end
        end
        if sf
            saveas (71700+10*j,[Folder ' avg_sd_binned_around_offset ' num2str(100+10*j) '.png' ],'png')
        end
    end
    
    %close all
    
    %the same, but around onset
    
    xict = size(avg_sd_binned_ict,2);
    dist_plots.avg_sd_binned_ict = avg_sd_binned_ict;
    % close all
    fr = sec_plot*2;
    xaxis = 1:1:fr+xict
    if endframe<20
        z = endframe;
    else
        z = 20;
    end
    h = 1;
    rest = mod(endframe,20);
    parties = (endframe-rest)/20;
    for j=1:parties
        figure(81500+10*j)
        for i=1:5
            for k = 1:4
                
                %  if (i-1)*4+k+(j-1)*20 == 5 || (i-1)*4+k+(j-1)*20 == 13
                
                
                subplot(5,4,k+(i-1)*4)
                %errorbar(avg_sd_binned_1s(1,:,(i-1)*4+k+(j-1)*20), avg_sd_binned_1s(2,:,(i-1)*4+k+(j-1)*20), 'Color',[0 0 0]);
                
                size(avg_sd_binned_ict)
                
                mibi1 = squeeze(avg_sd_binned_ict(1,1:xict,(i-1)*4+k+(j-1)*20));
                mib1 =  squeeze(avg_sd_binned_0s(1,1:fr,(i-1)*4+k+(j-1)*20));
                mib1 = fliplr(mib1);
                mib1cat = cat(2,mib1,mibi1);
                
                mibi2 = squeeze(avg_sd_binned_ict(2,1:xict,(i-1)*4+k+(j-1)*20));
                mib2 =  squeeze(avg_sd_binned_0s(2,1:fr,(i-1)*4+k+(j-1)*20));
                mib2 = fliplr(mib2);
                mib2cat = cat(2,mib2,mibi2);
                mib2cat = mib2cat+mib1cat;
                %             mibi3 = squeeze(avg_sd_binned_interict_aft_offset(3,1:fr,(i-1)*4+k+(j-1)*20));
                %             mib3 =  squeeze(avg_sd_binned_ict_bef_offs(3,1:xict,(i-1)*4+k+(j-1)*20));
                %             mib3 = fliplr(mib3);
                %             mib3cat = cat(2,mib3,mibi3);
                
                plot(xaxis,mib1cat,'Color',[0 0 0])
                hold on
                plot( xaxis,mib2cat,'Color',[0.5 0.5 0.5])
                hold on
                %             plot(xaxis,mib3cat,'Color',[0.5 0.5 0.5])
                %             hold on
                line ([fr fr], [-fr fr])
                
                ylabel(num2str((i-1)*4+k+(j-1)*20), 'FontName', 'Arial', 'FontSize', 8, 'FontWeight', 'bold');
                set(gca,'FontSize',8,'LineWidth',1,'TickLength',[0.01 0.01])
                
                %change y-axis back to -0.5 1.2!
                axis ([0 fr+xict 0 abs(max(mib2cat)*1.2+0.1)])% max(max(deltaf_matrix)) ])
                ax = gca;
                ax.XTick = [1 11 21 31]%[xict-10,xict,xict+10,xict+20];
                %ax.YTick = [-1,-0.5,0,0.5,1];
                ax.XTickLabel = {'-10','-5','0','5',};
                %ax.YTickLabel = {'min = -1','-0.5','0','0.5','max = 1'};
                %  end
            end
        end
        if sf
            saveas (81500+10*j,[Folder ' avg_sd_binned_around_onset ' num2str(100+10*j) '.png' ],'png')
        end
    end
    
    %close all
    j=parties+1
    figure(81700+10*j)
    for i=1:5
        for k = 1:4
            if (i-1)*4+k+(j-1)*20 <= endframe
                
                % if (i-1)*4+k+(j-1)*20 == 5 || (i-1)*4+k+(j-1)*20 == 13
                
                
                subplot(5,4,k+(i-1)*4)
                
                mibi1 = squeeze(avg_sd_binned_ict(1,1:xict,(i-1)*4+k+(j-1)*20));
                mib1 =  squeeze(avg_sd_binned_0s(1,1:fr,(i-1)*4+k+(j-1)*20));
                mib1 = fliplr(mib1);
                mib1cat = cat(2,mib1,mibi1);
                
                mibi2 = squeeze(avg_sd_binned_ict (2,1:xict,(i-1)*4+k+(j-1)*20));
                mib2 =  squeeze(avg_sd_binned_0s(2,1:fr,(i-1)*4+k+(j-1)*20));
                mib2 = fliplr(mib2);
                mib2cat = cat(2,mib2,mibi2);
                mib2cat = mib2cat+mib1cat;
                %             mibi3 = squeeze(avg_sd_binned_interict_aft_offset(3,1:fr,(i-1)*4+k+(j-1)*20));
                %             mib3 =  squeeze(avg_sd_binned_ict_bef_offs(3,1:xict,(i-1)*4+k+(j-1)*20));
                %             mib3 = fliplr(mib3);
                %             mib3cat = cat(2,mib3,mibi3);
                
                plot(xaxis,mib1cat,'Color',[0 0 0])
                hold on
                plot( xaxis,mib2cat,'Color',[0.5 0.5 0.5])
                hold on
                %             plot(xaxis,mib3cat,'Color',[0.5 0.5 0.5])
                %             hold on
                line ([fr fr], [-fr fr])
                
                ylabel(num2str((i-1)*4+k+(j-1)*20), 'FontName', 'Arial', 'FontSize', 8, 'FontWeight', 'bold');
                set(gca,'FontSize',8,'LineWidth',1,'TickLength',[0.01 0.01])
                
                axis ([0 fr+xict 0 abs(max(mib2cat)*1.2+0.1)]) %max(max(deltaf_matrix)) ])
                ax = gca;
                ax.XTick = [1 11 21 31]%[xict-10,xict,xict+10,xict+20];
                %ax.YTick = [-1,-0.5,0,0.5,1];
                ax.XTickLabel = {'-10','-5','0','5',};
                %ax.YTickLabel = {'min = -1','-0.5','0','0.5','max = 1'};
                %  end
            end
        end
        if sf
            saveas (81700+10*j,[Folder ' avg_sd_binned_around_onset ' num2str(100+10*j) '.png' ],'png')
        end
    end
    
    %close all
    %the same, but without 3 sec before next onset and after previous offset
    
    
    
    dist_plots.avg_sd_binned_3s_interict = avg_sd_binned_3s;
    % dist_plots.med_iq_binned_3s_interict = med_iq_binned_3s;
    dist_plots.avg_sd_binned_ict = avg_sd_binned_ict;
    % dist_plots.med_iq_binned_ict = med_iq_binned_ict;
    dist_plots.avg_sd_binned_interict_aft_offset_no_3sec_next = avg_sd_binned_interict_aft_offset_no_3sec_next;
    % dist_plots.med_iq_binned_interict_aft_offset_no_3sec_next = med_iq_binned_interict_aft_offset_no_3sec_next;
    
    xict = size(avg_sd_binned_ict_bef_offs,2);
    % close all
    fr = sec_plot*2;
    xaxis = 1:1:fr+xict
    if endframe<20
        z = endframe;
    else
        z = 20;
    end
    h = 1;
    rest = mod(endframe,20);
    parties = (endframe-rest)/20;
    for j=1:parties
        figure(171500+10*j)
        for i=1:5
            for k = 1:4
                
                %  if (i-1)*4+k+(j-1)*20 == 5 || (i-1)*4+k+(j-1)*20 == 13
                
                
                subplot(5,4,k+(i-1)*4)
                %errorbar(avg_sd_binned_1s(1,:,(i-1)*4+k+(j-1)*20), avg_sd_binned_1s(2,:,(i-1)*4+k+(j-1)*20), 'Color',[0 0 0]);
                
                
                mibi1 = squeeze(avg_sd_binned_interict_aft_offset_no_3sec_next(1,1:fr,(i-1)*4+k+(j-1)*20));
                mib1 =  squeeze(avg_sd_binned_ict_bef_offs(1,1:xict,(i-1)*4+k+(j-1)*20));
                mib1 = fliplr(mib1);
                mib1cat = cat(2,mib1,mibi1);
                
                mibi2 = squeeze(avg_sd_binned_interict_aft_offset_no_3sec_next(2,1:fr,(i-1)*4+k+(j-1)*20));
                mib2 =  squeeze(avg_sd_binned_ict_bef_offs(2,1:xict,(i-1)*4+k+(j-1)*20));
                mib2 = fliplr(mib2);
                mib2cat = cat(2,mib2,mibi2);
                
                avg_binned_around_offset_no_3sec_next_cat(:,(i-1)*4+k+(j-1)*20) = mib1cat;
                sem_binned_around_offset_no_3sec_next_cat(:,(i-1)*4+k+(j-1)*20) = mib2cat;
                
                %             mibi3 = squeeze(avg_sd_binned_interict_aft_offset(3,1:fr,(i-1)*4+k+(j-1)*20));
                %             mib3 =  squeeze(avg_sd_binned_ict_bef_offs(3,1:xict,(i-1)*4+k+(j-1)*20));
                %             mib3 = fliplr(mib3);
                %             mib3cat = cat(2,mib3,mibi3);
                
                plot(xaxis,mib1cat,'Color',[0 0 0])
                hold on
                plot( xaxis,mib2cat+mib1cat,'Color',[0.5 0.5 0.5])
                hold on
                %             plot(xaxis,mib3cat,'Color',[0.5 0.5 0.5])
                %             hold on
                line ([xict xict], [-xict xict])
                
                ylabel(num2str((i-1)*4+k+(j-1)*20), 'FontName', 'Arial', 'FontSize', 8, 'FontWeight', 'bold');
                set(gca,'FontSize',8,'LineWidth',1,'TickLength',[0.01 0.01])
                
                
                axis ([0 fr+xict 0 abs(max(mib2cat+mib1cat)*1.2+0.1)])% max(max(deltaf_matrix)) ])
                ax = gca;
                ax.XTick = [xict-10,xict,xict+10,xict+20];
                %ax.YTick = [-1,-0.5,0,0.5,1];
                ax.XTickLabel = {'-5','0','5','10',};
                %ax.YTickLabel = {'min = -1','-0.5','0','0.5','max = 1'};
                %  end
                
            end
        end
        if sf
            saveas (171500+10*j,[Folder ' avg_sd_binned_around_offset_no_3sec_next ' num2str(100+10*j) '.png' ],'png')
        end
    end
    %close all
    j=parties+1
    figure(171700+10*j)
    for i=1:5
        for k = 1:4
            if (i-1)*4+k+(j-1)*20 <= endframe
                
                %  if (i-1)*4+k+(j-1)*20 == 5 || (i-1)*4+k+(j-1)*20 == 13
                
                
                subplot(5,4,k+(i-1)*4)
                
                mibi1 = squeeze(avg_sd_binned_interict_aft_offset_no_3sec_next(1,1:fr,(i-1)*4+k+(j-1)*20));
                mib1 =  squeeze(avg_sd_binned_ict_bef_offs(1,1:xict,(i-1)*4+k+(j-1)*20));
                mib1 = fliplr(mib1);
                mib1cat = cat(2,mib1,mibi1);
                
                mibi2 = squeeze(avg_sd_binned_interict_aft_offset_no_3sec_next(2,1:fr,(i-1)*4+k+(j-1)*20));
                mib2 =  squeeze(avg_sd_binned_ict_bef_offs(2,1:xict,(i-1)*4+k+(j-1)*20));
                mib2 = fliplr(mib2);
                mib2cat = cat(2,mib2,mibi2);
                
                avg_binned_around_offset_no_3sec_next_cat(:,(i-1)*4+k+(j-1)*20) = mib1cat;
                sem_binned_around_offset_no_3sec_next_cat(:,(i-1)*4+k+(j-1)*20) = mib2cat;
                
                %             mibi3 = squeeze(avg_sd_binned_interict_aft_offset(3,1:fr,(i-1)*4+k+(j-1)*20));
                %             mib3 =  squeeze(avg_sd_binned_ict_bef_offs(3,1:xict,(i-1)*4+k+(j-1)*20));
                %             mib3 = fliplr(mib3);
                %             mib3cat = cat(2,mib3,mibi3);
                
                plot(xaxis,mib1cat,'Color',[0 0 0])
                hold on
                plot( xaxis,mib2cat+mib1cat,'Color',[0.5 0.5 0.5])
                hold on
                %             plot(xaxis,mib3cat,'Color',[0.5 0.5 0.5])
                %             hold on
                line ([xict xict], [-xict xict])
                
                ylabel(num2str((i-1)*4+k+(j-1)*20), 'FontName', 'Arial', 'FontSize', 8, 'FontWeight', 'bold');
                set(gca,'FontSize',8,'LineWidth',1,'TickLength',[0.01 0.01])
                
                axis ([0 fr+xict 0 abs(max(mib2cat+mib1cat)*1.2+0.1)])% max(max(deltaf_matrix)) ])  %
                ax = gca;
                ax.XTick = [xict-10,xict,xict+10,xict+20];
                %ax.YTick = [-1,-0.5,0,0.5,1];
                ax.XTickLabel = {'-5','0','5','10',};
                %ax.YTickLabel = {'min = -1','-0.5','0','0.5','max = 1'};
                
                %  end
                
            end
        end
        if sf
            saveas (171700+10*j,[Folder ' avg_sd_binned_around_offset_no_3sec_next ' num2str(100+10*j) '.png' ],'png')
        end
    end
    
    %close all
    dist_plots.avg_binned_around_offset_no_3sec_next_cat = avg_binned_around_offset_no_3sec_next_cat;
    dist_plots.sem_binned_around_offset_no_3sec_next_cat = sem_binned_around_offset_no_3sec_next_cat;
    
    %the same, but around onset
    xict = size(avg_sd_binned_ict,2);
    % close all
    fr = sec_plot*2;
    xaxis = 1:1:fr+xict
    if endframe<20
        z = endframe;
    else
        z = 20;
    end
    h = 1;
    rest = mod(endframe,20);
    parties = (endframe-rest)/20;
    for j=1:parties
        figure(181500+10*j)
        for i=1:5
            for k = 1:4
                
                %  if (i-1)*4+k+(j-1)*20 == 5 || (i-1)*4+k+(j-1)*20 == 13
                
                
                subplot(5,4,k+(i-1)*4)
                %errorbar(avg_sd_binned_1s(1,:,(i-1)*4+k+(j-1)*20), avg_sd_binned_1s(2,:,(i-1)*4+k+(j-1)*20), 'Color',[0 0 0]);
                
                size(avg_sd_binned_ict)
                
                mibi1 = squeeze(avg_sd_binned_ict(1,1:xict,(i-1)*4+k+(j-1)*20));
                mib1 =  squeeze(avg_sd_binned_3s(1,1:fr,(i-1)*4+k+(j-1)*20));
                mib1 = fliplr(mib1);
                mib1cat = cat(2,mib1,mibi1);
                
                mibi2 = squeeze(avg_sd_binned_ict(2,1:xict,(i-1)*4+k+(j-1)*20));
                mib2 =  squeeze(avg_sd_binned_3s(2,1:fr,(i-1)*4+k+(j-1)*20));
                mib2 = fliplr(mib2);
                mib2cat = cat(2,mib2,mibi2);
                
                avg_binned_around_onset_no_3sec_prev_cat(:,(i-1)*4+k+(j-1)*20) = mib1cat;
                sem_binned_around_onset_no_3sec_prev_cat(:,(i-1)*4+k+(j-1)*20) = mib2cat;
                
                %             mibi3 = squeeze(avg_sd_binned_interict_aft_offset(3,1:fr,(i-1)*4+k+(j-1)*20));
                %             mib3 =  squeeze(avg_sd_binned_ict_bef_offs(3,1:xict,(i-1)*4+k+(j-1)*20));
                %             mib3 = fliplr(mib3);
                %             mib3cat = cat(2,mib3,mibi3);
                
                plot(xaxis,mib1cat,'Color',[0 0 0])
                hold on
                plot( xaxis,mib2cat+mib1cat,'Color',[0.5 0.5 0.5])
                hold on
                %             plot(xaxis,mib3cat,'Color',[0.5 0.5 0.5])
                %             hold on
                line ([fr fr], [-fr fr])
                
                ylabel(num2str((i-1)*4+k+(j-1)*20), 'FontName', 'Arial', 'FontSize', 8, 'FontWeight', 'bold');
                set(gca,'FontSize',8,'LineWidth',1,'TickLength',[0.01 0.01])
                
                
                axis ([0 fr+xict 0 abs(max(mib2cat+mib1cat)*1.2+0.1)])% max(max(deltaf_matrix)) ])  %
                ax = gca;
                ax.XTick = [1 11 21 31]%[xict-10,xict,xict+10,xict+20];
                %ax.YTick = [-1,-0.5,0,0.5,1];
                ax.XTickLabel = {'-10','-5','0','5',};
                %ax.YTickLabel = {'min = -1','-0.5','0','0.5','max = 1'};
                %   end
            end
        end
        if sf
            saveas (181500+10*j,[Folder ' avg_sd_binned_around_onset_no_3sec_prev ' num2str(100+10*j) '.png' ],'png')
        end
    end
    
    %close all
    j=parties+1
    figure(181700+10*j)
    for i=1:5
        for k = 1:4
            if (i-1)*4+k+(j-1)*20 <= endframe
                
                %  if (i-1)*4+k+(j-1)*20 == 5 || (i-1)*4+k+(j-1)*20 == 13
                
                
                subplot(5,4,k+(i-1)*4)
                
                mibi1 = squeeze(avg_sd_binned_ict(1,1:xict,(i-1)*4+k+(j-1)*20));
                mib1 =  squeeze(avg_sd_binned_3s(1,1:fr,(i-1)*4+k+(j-1)*20));
                mib1 = fliplr(mib1);
                mib1cat = cat(2,mib1,mibi1);
                
                mibi2 = squeeze(avg_sd_binned_ict (2,1:xict,(i-1)*4+k+(j-1)*20));
                mib2 =  squeeze(avg_sd_binned_3s(2,1:fr,(i-1)*4+k+(j-1)*20));
                mib2 = fliplr(mib2);
                mib2cat = cat(2,mib2,mibi2);
                
                avg_binned_around_onset_no_3sec_prev_cat(:,(i-1)*4+k+(j-1)*20) = mib1cat;
                sem_binned_around_onset_no_3sec_prev_cat(:,(i-1)*4+k+(j-1)*20) = mib2cat;
                
                %             mibi3 = squeeze(avg_sd_binned_interict_aft_offset(3,1:fr,(i-1)*4+k+(j-1)*20));
                %             mib3 =  squeeze(avg_sd_binned_ict_bef_offs(3,1:xict,(i-1)*4+k+(j-1)*20));
                %             mib3 = fliplr(mib3);
                %             mib3cat = cat(2,mib3,mibi3);
                
                plot(xaxis,mib1cat,'Color',[0 0 0])
                hold on
                plot( xaxis,mib2cat+mib1cat,'Color',[0.5 0.5 0.5])
                hold on
                %             plot(xaxis,mib3cat,'Color',[0.5 0.5 0.5])
                %             hold on
                line ([fr fr], [-fr fr])
                
                ylabel(num2str((i-1)*4+k+(j-1)*20), 'FontName', 'Arial', 'FontSize', 8, 'FontWeight', 'bold');
                set(gca,'FontSize',8,'LineWidth',1,'TickLength',[0.01 0.01])
                
                axis ([0 fr+xict 0 max(mib2cat+mib1cat)*1.2+0.1])%max(max(deltaf_matrix)) ])  %
                ax = gca;
                ax.XTick = [1 11 21 31]%[xict-10,xict,xict+10,xict+20];
                %ax.YTick = [-1,-0.5,0,0.5,1];
                ax.XTickLabel = {'-10','-5','0','5',};
                %ax.YTickLabel = {'min = -1','-0.5','0','0.5','max = 1'};
                %  end
            end
        end
        if sf
            saveas (181700+10*j,[Folder ' avg_sd_binned_around_onset_no_3sec_prev ' num2str(100+10*j) '.png' ],'png')
        end
    end
    %close all
    dist_plots.avg_binned_around_onset_no_3sec_prev_cat = avg_binned_around_onset_no_3sec_prev_cat;
    dist_plots.sem_binned_around_onset_no_3sec_prev_cat = sem_binned_around_onset_no_3sec_prev_cat;
    
    
    %now plot all raw DF/F traces as overlays around onset
    
    
    %now plot all of that for the last 5 or 10 sec of activity before seizure
    %onset
    
    
    
    
    
    %close all
    fr = sec_plot*2;
    if endframe<20
        z = endframe;
    else
        z = 20;
    end
    h = 1;
    rest = mod(endframe,20);
    parties = (endframe-rest)/20;
    for j=1:parties
        figure(91500+10*j)
        for i=1:5
            for k = 1:4
                
                %  if (i-1)*4+k+(j-1)*20 == 5 || (i-1)*4+k+(j-1)*20 == 13
                
                
                subplot(5,4,k+(i-1)*4)
                
                for l = 1:ns
                    l
                    if length(interp)>round(tds.soffms(1,l)/10)
                        if l ==1
                            curri = interp(1:round(tds.sonms(1,l)/10),...
                                (i-1)*4+k+(j-1)*20)';
                        else
                            
                            curri = interp(round(tds.soffms(1,l-1)/10):round(tds.sonms(1,l)/10),...
                                (i-1)*4+k+(j-1)*20)';
                            
                        end
                        currj = interp(round(tds.sonms(1,l)/10):round(tds.soffms(1,l)/10),...
                            (i-1)*4+k+(j-1)*20)';
                        
                        ef = length(curri);
                        eg = length(currj);
                        currcat = cat(2,curri,currj);
                        xaxis = -ef:1:eg-1;
                        plot(xaxis,currcat);
                        
                        
                        ylabel(num2str((i-1)*4+k+(j-1)*20), 'FontName', 'Arial', 'FontSize', 8, 'FontWeight', 'bold');
                        set(gca,'FontSize',8,'LineWidth',1,'TickLength',[0.01 0.01])
                        hold on
                        
                        
                        axis ([-1000 500 -0.5 max(max(deltaf_matrix))])
                        ax = gca;
                        ax.XTick = [-999,-499,1,499];
                        %ax.YTick = [-1,-0.5,0,0.5,1];
                        ax.XTickLabel = {'-10','-5','0','5',};
                        %ax.YTickLabel = {'min = -1','-0.5','0','0.5','max = 1'};
                        
                    end
                end
                %
                %              hold on
                %             line ([0 0], [-10 10])
                hold on
                line ([0 0], [-10 10])
                % end
            end
        end
        if sf
            saveas (91500+10*j,[Folder ' all_raw_overlays_around_onset ' num2str(100+10*j) '.png' ],'png')
        end
    end
    %close all
    j=parties+1
    figure(91700+10*j)
    for i=1:5
        for k = 1:4
            if (i-1)*4+k+(j-1)*20 <= endframe
                
                %  if (i-1)*4+k+(j-1)*20 == 5 || (i-1)*4+k+(j-1)*20 == 13
                
                
                subplot(5,4,k+(i-1)*4)
                
                for l = 1:ns
                    if length(interp)>round(tds.soffms(1,l)/10)
                        if l ==1
                            curri = interp(1:round(tds.sonms(1,l)/10),...
                                (i-1)*4+k+(j-1)*20)';
                        else
                            
                            curri = interp(round(tds.soffms(1,l-1)/10):round(tds.sonms(1,l)/10),...
                                (i-1)*4+k+(j-1)*20)';
                            
                        end
                        ef = length(curri);
                        currj = interp(round(tds.sonms(1,l)/10):round(tds.soffms(1,l)/10),...
                            (i-1)*4+k+(j-1)*20)';
                        eg = length(currj);
                        currcat = cat(2,curri,currj);
                        xaxis = -ef:1:eg-1;
                        plot(xaxis,currcat);
                        
                        
                        
                        ylabel(num2str((i-1)*4+k+(j-1)*20), 'FontName', 'Arial', 'FontSize', 8, 'FontWeight', 'bold');
                        set(gca,'FontSize',8,'LineWidth',1,'TickLength',[0.01 0.01])
                        
                        
                        axis ([-1000 500 -0.5 max(max(deltaf_matrix))])
                        ax = gca;
                        ax.XTick = [-999,-499,1,499];
                        %ax.YTick = [-1,-0.5,0,0.5,1];
                        ax.XTickLabel = {'-10','-5','0','5',};
                        %ax.YTickLabel = {'min = -1','-0.5','0','0.5','max = 1'};
                        
                        hold on
                        line ([0 0], [-10 10])
                    end
                end
            end
        end
        if sf
            saveas (91700+10*j,[Folder ' all_raw_overlays_around_onset ' num2str(100+10*j) '.png' ],'png')
        end
    end
    
    % close all
    
    %now plot all of that for the last 5 or 10 sec of activity before seizure
    %offset
    % close all
    fr = sec_plot*2;
    if endframe<20
        z = endframe;
    else
        z = 20;
    end
    h = 1;
    rest = mod(endframe,20);
    parties = (endframe-rest)/20;
    for j=1:parties
        figure(82500+10*j)
        for i=1:5
            for k = 1:4
                
                % if (i-1)*4+k+(j-1)*20 == 5 || (i-1)*4+k+(j-1)*20 == 13
                
                
                subplot(5,4,k+(i-1)*4)
                
                for l = 1:ns
                    if l == ns
                        huh = l
                    else
                        huh = l+1;
                    end
                    %if length(interp)>round(tds.sonms(1,huh)/10)
                    if length(interp)>round(tds.soffms(1,huh)/10)
                        curri = interp(round(tds.sonms(1,l)/10):round(tds.soffms(1,l)/10),...
                            (i-1)*4+k+(j-1)*20)';
                        
                        ef = length(curri);
                        
                        if l == ns
                            
                            if length(ER.deltaf_interp_values)>length(interp)
                                lghfns = length(interp);
                            else
                                lghfns = length(ER.deltaf_interp_values);
                            end
                            
                            currj = interp(round(tds.soffms(1,l)/10):lghfns,...
                                (i-1)*4+k+(j-1)*20)';
                        else
                            currj = interp(round(tds.soffms(1,l)/10):round(tds.sonms(1,huh)/10),...
                                (i-1)*4+k+(j-1)*20)';
                            
                        end
                        eg = length(currj);
                        currcat = cat(2,curri,currj);
                        xaxis = -ef:1:eg-1;
                        plot(xaxis,currcat);
                        
                        
                        
                        ylabel(num2str((i-1)*4+k+(j-1)*20), 'FontName', 'Arial', 'FontSize', 8, 'FontWeight', 'bold');
                        set(gca,'FontSize',8,'LineWidth',1,'TickLength',[0.01 0.01])
                        hold on
                        
                        
                        axis ([-500 1000 -0.5 max(max(deltaf_matrix))])
                        ax = gca;
                        ax.XTick = [-499,1,499,999];
                        %ax.YTick = [-1,-0.5,0,0.5,1];
                        ax.XTickLabel = {'-5','0','5','10',};
                        %ax.YTickLabel = {'min = -1','-0.5','0','0.5','max = 1'};
                    end
                end
                
                hold on
                line ([0 0], [-10 10])
                
                %  end
            end
        end
        if sf
            saveas (82500+10*j,[Folder ' all_raw_overlays_around_offset ' num2str(100+10*j) '.png' ],'png')
        end
    end
    %close all
    j=parties+1
    figure(82700+10*j)
    for i=1:5
        for k = 1:4
            if (i-1)*4+k+(j-1)*20 <= endframe
                
                
                %  if (i-1)*4+k+(j-1)*20 == 5 || (i-1)*4+k+(j-1)*20 == 13
                
                subplot(5,4,k+(i-1)*4)
                
                
                for l = 1:ns
                    if l == ns
                        huh = l+1
                    else
                        huh = l;
                    end
                    if length(interp)>round(tds.soffms(1,l)+15000/10)
                        curri = interp(round(tds.sonms(1,l)/10):round(tds.soffms(1,l)/10),...
                            (i-1)*4+k+(j-1)*20)';
                        
                        ef = length(curri);
                        if l == ns
                            currj = interp(round(tds.soffms(1,l)/10):length(ER.deltaf_interp_values),...
                                (i-1)*4+k+(j-1)*20)';
                        else
                            currj = interp(round(tds.soffms(1,l)/10):round(tds.sonms(1,huh)/10),...
                                (i-1)*4+k+(j-1)*20)';
                        end
                        
                        eg = length(currj);
                        currcat = cat(2,curri,currj);
                        xaxis = -ef:1:eg-1;
                        plot(xaxis,currcat);
                        
                        
                        
                        ylabel(num2str((i-1)*4+k+(j-1)*20), 'FontName', 'Arial', 'FontSize', 8, 'FontWeight', 'bold');
                        set(gca,'FontSize',8,'LineWidth',1,'TickLength',[0.01 0.01])
                        hold on
                        
                        
                        axis ([-500 1000 -0.5 max(max(deltaf_matrix))])
                        ax = gca;
                        ax.XTick = [-499,1,499,999];
                        %ax.YTick = [-1,-0.5,0,0.5,1];
                        ax.XTickLabel = {'-5','0','5','10',};
                        %ax.YTickLabel = {'min = -1','-0.5','0','0.5','max = 1'};
                    end
                end
                
                hold on
                line ([0 0], [-10 10])
                
                %  end
            end
        end
    end
    if sf
        saveas (82700+10*j,[Folder ' all_raw_overlays_around_offset ' num2str(100+10*j) '.png' ],'png')
    end
    %close all
end
end
%










