%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%fast motion correction algorithm from Dimitri
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Usage:
%
%inputs:
%initial1.tiffmovie = (height, width,number of movies(usually 1),number of
%frames)
%initial1.tiffmovie_ch1 = same for red channel
%
%outputs:
%g = motion corrected green channel
%r = motion_corrected
%
%also writes all teh motion corrected frames back into the original folder
%(creates folder "motion_corrected"



function [initial1] = fast_motion_correction__PC_100518(iii,initialp,Folder,nocorr,res_int,saveasonetif,a_h,red_bad,rd,...
    Folder_master,save_as_only_one_file,batch_proc,onep,write_to_disk,Sergey_no_repmat)


if initialp.tif_or_txt && initialp.no_imaging(1,iii)==0 && initialp.h5_already_created(1,iii)==0
    if batch_proc
        if red_bad == 0
            Stack_ch1 = initialp.Stack_ch1; % dir(strcat(Folder,'\*h1*.tif'));
        end
        Stack_ch2 = initialp.Stack_ch2; % dir(strcat(Folder,'\*h2*.tif'));
    else
        if onep
            
            Stack_ch2 = initialp.Stack_ch2;
        else
            if red_bad==0
                Stack_ch1 = initialp.Stack_ch1; %dir(strcat(Folder,'\*h1*.tif'));
            end
            Stack_ch2 = initialp.Stack_ch2; %dir(strcat(Folder,'\*h2*.tif'));
        end
    end
    
    if initialp.h5_or_tif(1,iii)
        info = h5info(Stack_ch2(1).name);
        initial1.width = info.Groups(2).Datasets.Dataspace.Size(1,2);
        initial1.height =  info.Groups(2).Datasets.Dataspace.Size(1,1);
        if initialp.date>736000 && initialp.date < 737800
            initial1.height = info.Groups(2).Datasets.Dataspace.Size(1,2);
            initial1.width =  info.Groups(2).Datasets.Dataspace.Size(1,1);
        end
        initial1.numberofmovies = 1;
    else
        info = imfinfo(Stack_ch2(1,1).name);
        initial1.width = info.Width;
        initial1.height = info.Height;
        initial1.numberofmovies = 1;
    end
    %%%%%%%%%%%%%%%% load tiff files %%%%%%%%%%%%%%%%%%%%%%%
    max_frame = initialp.max_frame;
    initial1.numerofframes = initialp.max_frame;
    
    if initialp.Sergey_scan_sc_p_fr(1,iii)
        initial1.raw_frame_num = max_frame;
        max_frame = max_frame*initialp.Sergey_scan_sc_p_fr(1,iii);
        initial1.numerofframes = max_frame;
    end
    
    if onep
        
        if rd
            initial1.g = vvar(initial1.height,initial1.width,max_frame, 'uint16');
        else
            initial1.g = uint16(zeros(initial1.height,initial1.width,max_frame));
        end
        
        cd(Folder_master)
        cd(Folder)
        
        files = initialp.Stack_ch2;
        
        a=0;
        for i = 1:size(files,1)
            
            FileTif=files(i).name;      %'ImageStack.tif';
            InfoImage=imfinfo(FileTif);
            mImage=InfoImage(1).Width;
            nImage=InfoImage(1).Height;
            NumberImages=length(InfoImage);
            % FinalImage=zeros(nImage,mImage,NumberImages,'uint16');
            
            TifLink = Tiff(FileTif, 'r');
            for iii=1:NumberImages
                TifLink.setDirectory(iii);
                initial1.g(:,:,a+iii)=TifLink.read();
                imageread = a+iii
            end
            TifLink.close();
            
            a = a+NumberImages;
        end
        
    else
        
        write_red=0
        if write_to_disk
            if red_bad
                write_red = 0;
            else
                write_red = 1;
            end
        end
        
        
        if Sergey_no_repmat
            hei = initial1.height/initialp.Sergey_scan_sc_p_fr(1,iii);
            wid =  initial1.width;; %initial1.width/initialp.Sergey_scan_sc_p_fr(1,iii);
        else
            hei    = initial1.height;
            wid    = initial1.width;
        end
        
        if rd
            if write_red
                initial1.r = vvar(hei,wid,max_frame, 'uint16');
            end
            initial1.g = vvar(hei,wid,max_frame, 'uint16');
        else
            initial1.g = uint16(zeros(hei,wid,max_frame));
            %g = uint16(g);
        end
        
        %F=strcat(Folder,'raw_tiffs\ch2');
        mkdir('raw_tiffs')
        Loc  =  'raw_tiffs'; %strcat(Folder,'\raw_tiffs'); %
        cd(Loc);
        mkdir ('ch1')
        mkdir('ch2')
        Loc1 = strcat(Loc,'\ch1');
        Loc2 = strcat(Loc,'\ch2');
        
        if res_int
            hdinterlacer = vision.Deinterlacer;
        end
        
        
        cd(Folder_master)
        cd(Folder)
        
        if initialp.h5_or_tif(1,iii)
            if initialp.swap_ch1_ch2
                h5_filenames_ch2 = dir('*ch1*.h5')
                initial1.h5_filenames_ch2 = h5_filenames_ch2;
                h5_filenames_ch1 = dir('*ch2*.h5')
                initial1.h5_filenames_ch1 = h5_filenames_ch1;
            else
                h5_filenames_ch2 = dir('*ch2*.h5')
                initial1.h5_filenames_ch2 = h5_filenames_ch2;
                h5_filenames_ch1 = dir('*ch1*.h5')
                initial1.h5_filenames_ch1 = h5_filenames_ch1;
            end
            
            h5_files = size(h5_filenames_ch2,1);
            tot_frs = 0;
            for i = 1:h5_files
                info = h5info(h5_filenames_ch2(i).name);
                if size(info.Groups,1)==1
                    igdds = info.Datasets(1).Dataspace.Size;
                    if size(igdds,2)>2
                        
                        dims = info.Datasets(1).Dataspace.Size;
                        
                    else
                        dims(1,1:2) = info.Datasets(1).Dataspace.Size;
                        siG =  size(info.Groups);
                        dims(1,3) =  siG(1,1);
                    end
                else
                    if size(info.Groups(2).Datasets,1) ==1
                        %dims = info.Groups(2).Datasets(1).Dataspace.Size;
                        igdds = info.Groups(2).Datasets(1).Dataspace.Size;
                        if size(igdds,2)>2
                            
                            dims = info.Groups(2).Datasets(1).Dataspace.Size;
                            
                        else
                            dims(1,1:2) = info.Groups(2).Datasets(1).Dataspace.Size;
                            siG =  size(info.Groups);
                            dims(1,3) =  siG(1,1);
                        end
                    else
                        dims(1,1:2) = info.Groups(2).Datasets(1).Dataspace.Size;
                        dims(1,3) = size(info.Groups(2).Datasets,1);
                    end
                end
                %dims = info.Groups(2).Datasets.Dataspace.Size;
                frames = dims(1,3);
                frames_h5(1,i) = frames;
                tot_frs = tot_frs+frames;
                if i<h5_files || i==1
                    blockframes = frames;
                end
                if i == h5_files
                    lastblockframes = frames;
                end
            end
            %initial1.height = dims(1,1);
            %initial1.width = dims(1,2);
            if initialp.Sergey_scan_sc_p_fr(1,iii)==0
                initial1.max_frame = tot_frs;
            else
                initial1.max_frame = initial1.numerofframes;
            end
            xf = h5_files;
            initial1.frames_h5 = frames_h5;
        else
            rest = mod(max_frame,10);
            blockframes = (max_frame-rest)/10;
            firstbf = blockframes;
            lastblockframes = blockframes+rest;
            mkdir raw_tiffs
            xf = 10;
        end
        
        for block = 1:xf
            cd(Folder_master)
            cd(Folder)
            
            if block == xf && block >1
                if initialp.Sergey_scan_sc_p_fr(1,iii)
                    lastblockframes = lastblockframes*initialp.Sergey_scan_sc_p_fr(1,iii);
                end
                blockfr = lastblockframes;
                %blockframes = blockfr;
                if initialp.h5_or_tif(1,iii)==0
                    currest = rest;
                else
                    currest = 0;
                end
                %rd=0;
                
                if rd
                    g = vvar(hei,wid,lastblockframes, 'uint16');
                else
                    g = uint16(zeros(hei,wid,lastblockframes));
                end
            else
                if initialp.Sergey_scan_sc_p_fr(1,iii)
                    blockfr = blockframes*initialp.Sergey_scan_sc_p_fr(1,iii);
                    blockframes = blockfr;
                end
                blockfr = blockframes;
                %if initialp.h5_or_tif(1,iii)==0
                
                currest = 0;
                %end
                %rd=0;
                if rd
                    g = vvar(hei,wid,blockfr, 'uint16');
                else
                    g = uint16(zeros(hei,wid,blockfr));
                end
            end
            if initialp.h5_or_tif(1,iii)
                name = h5_filenames_ch2(block,1).name;
                frames =frames_h5(1,block);
                if initialp.Sergey_scan_sc_p_fr(1,iii)
                    gup = h5read(name,'/t0/channel0');
                    
                    if initialp.date<737800 && initialp.date>736000
                        gu = zeros(size(gup));
                        for pu = 1: size(gup,3)
                            jh=squeeze(gup(:,:,pu));
                            I2 = rot90(fliplr(jh),1);
                            gu(:,:,pu) = I2;
                        end
                        gup=gu;
                    end
                    a=1;
                    reps = initialp.height/initialp.Sergey_scan_sc_p_fr(1,iii);
                    for pos = 1:frames
                        running_sergey_frame_decomp = pos
                        for pis = 1:initialp.Sergey_scan_sc_p_fr(1,iii)
                            
                            if Sergey_no_repmat
                                plup = gup((pis-1)*reps+1:pis*reps,:,pos);
                                g(:,:,a)    = plup;
                            else
                                for pes = 1:reps
                                    plup = gup((pis-1)*reps+pes,:,pos);
                                    plump = repmat(plup,initialp.Sergey_scan_sc_p_fr(1,iii),1,1);
                                    g((pes-1)*initialp.Sergey_scan_sc_p_fr(1,iii)+1:(pes)*initialp.Sergey_scan_sc_p_fr(1,iii),:,a) = ...
                                        plump;
                                end
                            end
                            a=a+1;
                        end
                    end
                else
                    g = h5read(name,'/t0/channel0');
                    if initialp.date<737800 && initialp.date>736000
                        clear gu
                        for pu = 1: size(g,3)
                            jh=squeeze(g(:,:,pu));
                            I2 = rot90(fliplr(jh),1);
                            gu(:,:,pu) = I2;
                        end
                        g=gu;
                    end
                end
            else
                frcount = 0;
                for frame = (block-1)*firstbf+1:block*firstbf+currest %+blockfr %max_frame
                    %frame = (block-1)*blockframes+1:block*blockframes+currest %+blockfr %max_frame
                    frcount=frcount+1;
                    cd(Folder_master)
                    cd(Folder)
                    read_frame = frame
                    if a_h == 1 || a_h == 0
                        fram = frame;
                    else
                        if a_h == 2
                            fram = initialp.numerofframes+frame;
                        end
                    end
                    if size(imread (Stack_ch2(fram,1).name, 'tif'),1) == initial1.height
                        clear gtemp
                        gtemp  = imread (Stack_ch2(fram,1).name, 'tif');
                        gtemp = int16(gtemp);
                        if res_int
                            gtemp_di = gtemp;
                            gtemp = hdinterlacer(gtemp_di);
                        end
                        g (:,:,frcount) = gtemp;
                        %inff = imfinfo(Stack_ch2(fram,1).name);
                    end
                end
            end
            if red_bad == 0
                if block ==xf && block>1
                    blockfr = lastblockframes;
                    if initialp.h5_or_tif(1,iii)==0
                        currest = rest;
                    else
                        currest=0;
                    end
                    rd=0;
                    if rd
                        r = vvar(initial1.height,initial1.width,lastblockframes, 'uint16');
                    else
                        r = uint16(zeros(initial1.height,initial1.width,lastblockframes));
                    end
                else
                    blockfr = blockframes;
                    %if initialp.h5_or_tif(1,iii)==0
                    currest = 0;
                    %end
                    rd=0;
                    if rd
                        r = vvar(initial1.height,initial1.width,blockframes, 'uint16');
                    else
                        r = uint16(zeros(initial1.height,initial1.width,blockframes));
                    end
                end
                %F=strcat(Folder,'raw_tiffs\ch1')
                if initialp.h5_or_tif(1,iii)
                    name = h5_filenames_ch1(block,1).name;
                    frames =frames_h5(1,block);
                    if initialp.Sergey_scan_sc_p_fr(1,iii)
                        gup = h5read(name,'/t0/channel0');
                        
                        if initialp.date<737800 && initialp.date>736000
                            clear gu
                            for pu = 1: size(gup,3)
                                jh=squeeze(gup(:,:,pu));
                                I2 = rot90(fliplr(jh),1);
                                gu(:,:,pu) = I2;
                            end
                            gup=gu;
                        end
                        a=1;
                        reps = initialp.height/initialp.Sergey_scan_sc_p_fr(1,iii);
                        for pos = 1:frames
                            running_sergey_frame_decomp = pos
                            for pis = 1:initialp.Sergey_scan_sc_p_fr(1,iii)
                                for pes = 1:reps
                                    
                                    plup = gup((pis-1)*reps+pes,:,pos);
                                    plump = repmat(plup,initialp.Sergey_scan_sc_p_fr(1,iii),1,1);
                                    r((pes-1)*initialp.Sergey_scan_sc_p_fr(1,iii)+1:(pes)*initialp.Sergey_scan_sc_p_fr(1,iii),:,a) = ...
                                        plump;
                                end
                                a=a+1;
                            end
                        end
                    else
                        r = h5read(name,'/t0/channel0');
                        if initialp.date<737800 && initialp.date>736000
                            for pu = 1: size(r,3)
                                jh=squeeze(r(:,:,pu));
                                I2 = rot90(fliplr(jh),1);
                                ru(:,:,pu) = I2;
                            end
                            r=ru;
                        end
                    end
                else
                    frcount = 0;
                    for frame = (block-1)*firstbf+1:block*firstbf+currest%+blockfr %max_frame
                        frcount=frcount+1;
                        cd(Folder_master)
                        cd(Folder)
                        if size(imread (Stack_ch1(frame,1).name, 'tif'),1) == initial1.height
                            readframe_r = frame
                            r (:,:,frcount) = imread (Stack_ch1(frame,1).name, 'tif');
                            %inff = imfinfo(Stack_ch1(frame,1).name);
                        end
                    end
                end
            end
            if nocorr(1,iii) == 0
                offs = round(0.25*(initial1.width+initial1.height)/2);
                assd = 1;
                if red_bad == 0
                    if initialp.spiral_scan(1,iii)
                        for k = 1:size(g,3)
                            for i = 1:initial1.height
                                for j = 1:initial1.width
                                    if j<ceil(initial1.width/2)  %left half
                                        if i < ceil(initial1.width/2) %top half
                                            if g(i,j,k) == 0
                                                
                                                g(i,j,k) = g(i+offs,j+offs,k);
                                                r(i,j,k) = r(i+offs,j+offs,k);
                                                if k==1
                                                    initial1.blackpix(assd,1) = (j-1)*initial1.height+i;
                                                    assd=assd+1;
                                                end
                                            end
                                        else   %bottom half
                                            if g(i,j,k) == 0
                                                
                                                g(i,j,k) = g(i-offs,j+offs,k);
                                                r(i,j,k) = r(i-offs,j+offs,k);
                                                if k==1
                                                    initial1.blackpix(assd,1) = (j-1)*initial1.height+i;
                                                    assd=assd+1;
                                                end
                                            end
                                        end
                                    else   %right half
                                        if i < ceil(initial1.width/2) %top half
                                            if g(i,j,k) == 0
                                                
                                                g(i,j,k) = g(i+offs,j-offs,k);
                                                r(i,j,k) = r(i+offs,j-offs,k);
                                                if k==1
                                                    initial1.blackpix(assd,1) = (j-1)*initial1.height+i;
                                                    assd=assd+1;
                                                end
                                            end
                                        else   %bottom half
                                            if g(i,j,k) == 0
                                                
                                                g(i,j,k) = g(i-offs,j-offs,k);
                                                r(i,j,k) = r(i-offs,j-offs,k);
                                                if k==1
                                                    initial1.blackpix(assd,1) = (j-1)*initial1.height+i;
                                                    assd=assd+1;
                                                end
                                            end
                                        end
                                    end
                                end
                            end
                        end
                    end
                else
                    if initialp.spiral_scan(1,iii)
                        for k = 1:size(g,3)
                            for i = 1:initial1.height
                                for j = 1:initial1.width
                                    if j<ceil(initial1.width/2)  %left half
                                        if i < ceil(initial1.width/2) %top half
                                            if g(i,j,k) == 0
                                                
                                                g(i,j,k) = g(i+offs,j+offs,k);
                                                % r(i,j,k) = r(i+offs,j+offs,k);
                                                if k==1
                                                    initial1.blackpix(assd,1) = (j-1)*initial1.height+i;
                                                    assd=assd+1;
                                                end
                                            end
                                        else   %bottom half
                                            if g(i,j,k) == 0
                                                
                                                g(i,j,k) = g(i-offs,j+offs,k);
                                                %r(i,j,k) = r(i-offs,j+offs,k);
                                                if k==1
                                                    initial1.blackpix(assd,1) = (j-1)*initial1.height+i;
                                                    assd=assd+1;
                                                end
                                            end
                                        end
                                    else   %right half
                                        if i < ceil(initial1.width/2) %top half
                                            if g(i,j,k) == 0
                                                
                                                g(i,j,k) = g(i+offs,j-offs,k);
                                                % r(i,j,k) = r(i+offs,j-offs,k);
                                                if k==1
                                                    initial1.blackpix(assd,1) = (j-1)*initial1.height+i;
                                                    assd=assd+1;
                                                end
                                            end
                                        else   %bottom half
                                            if g(i,j,k) == 0
                                                
                                                g(i,j,k) = g(i-offs,j-offs,k);
                                                % r(i,j,k) = r(i-offs,j-offs,k);
                                                if k==1
                                                    initial1.blackpix(assd,1) = (j-1)*initial1.height+i;
                                                    assd=assd+1;
                                                end
                                            end
                                        end
                                    end
                                end
                            end
                        end
                    end
                end
                
                if initialp.spiral_scan(1,iii)
                    testbp = zeros(initial1.height,initial1.width);
                    testbp(initial1.blackpix) = 1;
                    figure(2754)
                    imagesc(testbp)
                    saveas (2754,[ ' blackpix'  '.png' ],'png')
                end
                % fetch basic information
                key.nframes = size(g,3);
                key.frame_width = size(g,1);
                key.frame_height = size(g,2);
                %                 if red_bad == 0
                %                     % key.raw_red   = single(squeeze(mean(r,3)));
                %                 end
                % motion correction
                if mod(key.nframes,4)
                    switch mod(key.nframes,4)
                        case 1
                            n1 = (key.nframes-1)/4;
                            n2 = n1*2;
                            n3 = n1*3;
                            n4 = key.nframes;
                        case 2
                            n1 = (key.nframes-2)/4;
                            n2 = n1*2;
                            n3 = n1*3;
                            n4 = key.nframes;
                        case 3
                            n1 = (key.nframes-3)/4;
                            n2 = n1*2;
                            n3 = n1*3;
                            n4 = key.nframes;
                    end
                else
                    n1 = key.nframes/4;
                    n2 = n1*2;
                    n3 = n1*3;
                    n4 = n1*4;
                end
                szs=size(g,3);
                clear g1 g2 g3 g4 r1 r2 r3 r4
                if red_bad
                    'fitting_part1'
                    [offsets_1, ~, g1,template] = MotionCorrection1.fit(g(:,:,1:n1));
                    g = g(:,:,n1+1:szs);
                else
                    'fitting_part1'
                    [offsets_1, ~, r1,template] = MotionCorrection1.fit(r(:,:,1:n1));
                    g1 = MotionCorrectiont.apply(g(:,:,1:n1), offsets_1);
                    g(:,:,1:n1) = [];
                    r(:,:,1:n1) = [];
                end
                szs = size(g,3);
                if red_bad
                    'fitting_part2'
                    [offsets_2, ~, g2] = MotionCorrectionx.fit(g(:,:,1:n2-n1),template);
                    g = g(:,:,n2-n1+1:szs);
                else
                    'fitting_part2'
                    [offsets_2, ~, r2] = MotionCorrectionx.fit(r(:,:,1:n2-n1),template);
                    g2 = MotionCorrectiont.apply(g(:,:,1:n3-n2), offsets_2);
                    g(:,:,1:n2-n1) = [];
                    r(:,:,1:n2-n1) = [];
                end
                g1 = cat(3,g1,g2);
                clear g2
                szs=size(g,3);
                if red_bad
                    'fitting_part3'
                    [offsets_3, ~, g3] = MotionCorrectionx.fit(g(:,:,1:n3-n2),template);
                    g = g(:,:,n3-n2+1:szs);
                else
                    'fitting_part3'
                    [offsets_3, ~, r3] = MotionCorrectionx.fit(r(:,:,1:n3-n2),template);
                    g3 = MotionCorrectiont.apply(g(:,:,1:n3-n2), offsets_3);
                    g(:,:,1:n3-n2) = [];
                    r(:,:,1:n3-n2) = [];
                end
                g1 = cat(3,g1,g3);
                clear g3
                szs=size(g,3);
                if red_bad
                    'fitting_part4'
                    [offsets_4, ~, g4] = MotionCorrectionx.fit(g,template);
                else
                    'fitting_part4'
                    [offsets_4, ~, r4] = MotionCorrectionx.fit(r(:,:,1:n4-n3),template);
                    g4 = MotionCorrectiont.apply(g(:,:,1:n4-n3), offsets_4);
                    g = [];
                    r = [];
                end
                g1 = cat(3,g1,g4);
                clear g4
                g=g1;
                clear g1
                offsets_curr = cat(1,offsets_1,offsets_2,offsets_3,offsets_4);
                offsets((block-1)*blockfr+1:(block-1)*blockfr+size(g,3),:) = offsets_curr; %currest,:) = offsets_curr;
                clear offsets_1 offsets_2 offsets_3 offsets_4
                % fill out correction information
                key.motion_correction = int8(offsets_curr);
                key.green_img = single(squeeze(mean(g,3)));
                if red_bad == 0
                    r1 = cat(3,r1,r2);
                    clear r2
                    r3 = cat(3,r3,r4);
                    clear r4
                    r1 = cat(3,r1,r3);
                    clear r3
                    r=r1;
                    clear r1
                    key.red_img   = single(squeeze(mean(r,3)));
                end
            end
            
            cd(Folder_master)
            cd (Folder);
            if initialp.swap_ch1_ch2
                mkdir('motion_corrected_swap_ch1_ch2')
                Loc  = 'motion_corrected_swap_ch1_ch2'; % strcat(Folder,'motion_corrected');
                cd(Loc);
            else
                mkdir('motion_corrected')
                Loc  = 'motion_corrected'; % strcat(Folder,'motion_corrected');
                cd(Loc);
            end
            
            mkdir ('ch1')
            mkdir('ch2')
            %if batch_proc
            Loc1 = 'ch1'; %strcat(Loc,'\ch1');
            Loc2 = 'ch2';  %strcat(Loc,'\ch2');
            if write_to_disk
                g = int16(g);
                %                 cd(Folder_master)
                %                 cd (Folder);
                %                 mkdir('motion_corrected')
                %                 Loc  = 'motion_corrected'; % strcat(Folder,'motion_corrected');
                %                 cd(Loc);
                %                 mkdir ('ch1')
                %                 mkdir('ch2')
                %                 %if batch_proc
                %                 Loc1 = 'ch1'; %strcat(Loc,'\ch1');
                %                 Loc2 = 'ch2';  %strcat(Loc,'\ch2');
                cd(Loc2);
                if save_as_only_one_file==0
                    if saveasonetif
                        t = Tiff(['motion_corrected_ch2_' int2str(block) '.tif' ],'w8');
                        tagstruct.ImageLength = size(g,1);
                        tagstruct.ImageWidth = size(g,2);
                        tagstruct.Photometric = Tiff.Photometric.MinIsBlack;
                        tagstruct.BitsPerSample = 16;
                        tagstruct.SamplesPerPixel = 1;
                        tagstruct.PlanarConfiguration = Tiff.PlanarConfiguration.Chunky;
                        tagstruct.Software = 'MATLAB';
                        tagstruct.SampleFormat = Tiff.SampleFormat.Int;
                        t.setTag(tagstruct);
                        t.write(g(:,:,1));
                        t.close();
                        for i = 2:size(g,3)
                            writing_tiff_g = i
                            %t = Tiff(['motion_corrected_ch2.tif'],'a');
                            t = Tiff(['motion_corrected_ch2_' int2str(block) '.tif'],'a');
                            tagstruct.ImageLength = size(g,1);
                            tagstruct.ImageWidth = size(g,2);
                            tagstruct.Photometric = Tiff.Photometric.MinIsBlack;
                            tagstruct.BitsPerSample = 16;
                            tagstruct.SamplesPerPixel = 1;
                            tagstruct.PlanarConfiguration = Tiff.PlanarConfiguration.Chunky;
                            tagstruct.Software = 'MATLAB';
                            tagstruct.SampleFormat = Tiff.SampleFormat.Int;
                            t.setTag(tagstruct);
                            t.write(g(:,:,i));
                            t.close();
                        end
                    else
                        for i = 1:size(g,3)
                            clear tagstruct
                            if i<10
                                t = Tiff(['motion_corrected_00000' int2str(i) '.tif'],'w');
                                tagstruct.ImageLength = size(g,1);
                                tagstruct.ImageWidth = size(g,2);
                                tagstruct.Photometric = Tiff.Photometric.MinIsBlack;
                                tagstruct.BitsPerSample = 16;
                                tagstruct.SamplesPerPixel = 1;
                                tagstruct.PlanarConfiguration = Tiff.PlanarConfiguration.Chunky;
                                tagstruct.Software = 'MATLAB';
                                tagstruct.SampleFormat = Tiff.SampleFormat.Int;
                                t.setTag(tagstruct);
                                t.write(g(:,:,i));
                                t.close();
                            elseif i<100
                                t = Tiff(['motion_corrected_0000' int2str(i) '.tif'],'w');
                                tagstruct.ImageLength = size(g,1);
                                tagstruct.ImageWidth = size(g,2);
                                tagstruct.Photometric = Tiff.Photometric.MinIsBlack;
                                tagstruct.BitsPerSample = 16;
                                tagstruct.SamplesPerPixel = 1;
                                tagstruct.PlanarConfiguration = Tiff.PlanarConfiguration.Chunky;
                                tagstruct.Software = 'MATLAB';
                                tagstruct.SampleFormat = Tiff.SampleFormat.Int;
                                t.setTag(tagstruct);
                                t.write(g(:,:,i));
                                t.close();
                            elseif i<1000
                                t = Tiff(['motion_corrected_000' int2str(i) '.tif'],'w');
                                tagstruct.ImageLength = size(g,1);
                                tagstruct.ImageWidth = size(g,2);
                                tagstruct.Photometric = Tiff.Photometric.MinIsBlack;
                                tagstruct.BitsPerSample = 16;
                                tagstruct.SamplesPerPixel = 1;
                                tagstruct.PlanarConfiguration = Tiff.PlanarConfiguration.Chunky;
                                tagstruct.Software = 'MATLAB';
                                tagstruct.SampleFormat = Tiff.SampleFormat.Int;
                                t.setTag(tagstruct);
                                t.write(g(:,:,i));
                                t.close();
                            elseif i<10000
                                t = Tiff(['motion_corrected_00' int2str(i) '.tif'],'w');
                                tagstruct.ImageLength = size(g,1);
                                tagstruct.ImageWidth = size(g,2);
                                tagstruct.Photometric = Tiff.Photometric.MinIsBlack;
                                tagstruct.BitsPerSample = 16;
                                tagstruct.SamplesPerPixel = 1;
                                tagstruct.PlanarConfiguration = Tiff.PlanarConfiguration.Chunky;
                                tagstruct.Software = 'MATLAB';
                                tagstruct.SampleFormat = Tiff.SampleFormat.Int;
                                t.setTag(tagstruct);
                                t.write(g(:,:,i));
                                t.close();
                            elseif i<100000
                                t = Tiff(['motion_corrected_0' int2str(i) '.tif'],'w');
                                tagstruct.ImageLength = size(g,1);
                                tagstruct.ImageWidth = size(g,2);
                                tagstruct.Photometric = Tiff.Photometric.MinIsBlack;
                                tagstruct.BitsPerSample = 16;
                                tagstruct.SamplesPerPixel = 1;
                                tagstruct.PlanarConfiguration = Tiff.PlanarConfiguration.Chunky;
                                tagstruct.Software = 'MATLAB';
                                tagstruct.SampleFormat = Tiff.SampleFormat.Int;
                                t.setTag(tagstruct);
                                t.write(g(:,:,i));
                                t.close();
                            else
                                t = Tiff(['motion_corrected_' int2str(i) '.tif'],'w');
                                tagstruct.ImageLength = size(g,1);
                                tagstruct.ImageWidth = size(g,2);
                                tagstruct.Photometric = Tiff.Photometric.MinIsBlack;
                                tagstruct.BitsPerSample = 16;
                                tagstruct.SamplesPerPixel = 1;
                                tagstruct.PlanarConfiguration = Tiff.PlanarConfiguration.Chunky;
                                tagstruct.Software = 'MATLAB';
                                tagstruct.SampleFormat = Tiff.SampleFormat.Int;
                                t.setTag(tagstruct);
                                t.write(g(:,:,i));
                                t.close();
                            end
                        end
                    end
                    if write_red
                        cd(Loc1);
                        if saveasonetif
                            %t = Tiff(['motion_corrected_ch1.tif'],'w8');
                            t = Tiff(['motion_corrected_ch1_' int2str(block) '.tif'],'w8');
                            tagstruct.ImageLength = size(r,1);
                            tagstruct.ImageWidth = size(r,2);
                            tagstruct.Photometric = Tiff.Photometric.MinIsBlack;
                            tagstruct.BitsPerSample = 16;
                            tagstruct.SamplesPerPixel = 1;
                            tagstruct.PlanarConfiguration = Tiff.PlanarConfiguration.Chunky;
                            tagstruct.Software = 'MATLAB';
                            tagstruct.SampleFormat = Tiff.SampleFormat.Int;
                            t.setTag(tagstruct);
                            t.write(int16(r(:,:,1)));
                            t.close();
                            for i = 2:size(r,3)
                                writing_tiff_r = i
                                %t = Tiff(['motion_corrected_ch1.tif'],'a');
                                t = Tiff(['motion_corrected_ch1_'  int2str(block) '.tif'],'a');
                                tagstruct.ImageLength = size(r,1);
                                tagstruct.ImageWidth = size(r,2);
                                tagstruct.Photometric = Tiff.Photometric.MinIsBlack;
                                tagstruct.BitsPerSample = 16;
                                tagstruct.SamplesPerPixel = 1;
                                tagstruct.PlanarConfiguration = Tiff.PlanarConfiguration.Chunky;
                                tagstruct.Software = 'MATLAB';
                                tagstruct.SampleFormat = Tiff.SampleFormat.Int;
                                t.setTag(tagstruct);
                                t.write(int16(r(:,:,i)));
                                t.close();
                            end
                        else
                            r = int16(r);
                            if i<10
                                t = Tiff(['motion_corrected_ch1_00000' int2str(i) '.tif'],'w');
                                tagstruct.ImageLength = size(r,1);
                                tagstruct.ImageWidth = size(r,2);
                                tagstruct.Photometric = Tiff.Photometric.MinIsBlack;
                                tagstruct.BitsPerSample = 16;
                                tagstruct.SamplesPerPixel = 1;
                                tagstruct.PlanarConfiguration = Tiff.PlanarConfiguration.Chunky;
                                tagstruct.Software = 'MATLAB';
                                tagstruct.SampleFormat = Tiff.SampleFormat.Int;
                                t.setTag(tagstruct);
                                t.write(r(:,:,i));
                                t.close();
                            elseif i<100
                                t = Tiff(['motion_corrected_ch1_0000' int2str(i) '.tif'],'w');
                                tagstruct.ImageLength = size(r,1);
                                tagstruct.ImageWidth = size(r,2);
                                tagstruct.Photometric = Tiff.Photometric.MinIsBlack;
                                tagstruct.BitsPerSample = 16;
                                tagstruct.SamplesPerPixel = 1;
                                tagstruct.PlanarConfiguration = Tiff.PlanarConfiguration.Chunky;
                                tagstruct.Software = 'MATLAB';
                                tagstruct.SampleFormat = Tiff.SampleFormat.Int;
                                t.setTag(tagstruct);
                                t.write(r(:,:,i));
                                t.close();
                            elseif i<1000
                                t = Tiff(['motion_corrected_ch1_000' int2str(i) '.tif'],'w');
                                tagstruct.ImageLength = size(r,1);
                                tagstruct.ImageWidth = size(r,2);
                                tagstruct.Photometric = Tiff.Photometric.MinIsBlack;
                                tagstruct.BitsPerSample = 16;
                                tagstruct.SamplesPerPixel = 1;
                                tagstruct.PlanarConfiguration = Tiff.PlanarConfiguration.Chunky;
                                tagstruct.Software = 'MATLAB';
                                tagstruct.SampleFormat = Tiff.SampleFormat.Int;
                                t.setTag(tagstruct);
                                t.write(r(:,:,i));
                                t.close();
                            elseif i<10000
                                t = Tiff(['motion_corrected_ch1_00' int2str(i) '.tif'],'w');
                                tagstruct.ImageLength = size(r,1);
                                tagstruct.ImageWidth = size(r,2);
                                tagstruct.Photometric = Tiff.Photometric.MinIsBlack;
                                tagstruct.BitsPerSample = 16;
                                tagstruct.SamplesPerPixel = 1;
                                tagstruct.PlanarConfiguration = Tiff.PlanarConfiguration.Chunky;
                                tagstruct.Software = 'MATLAB';
                                tagstruct.SampleFormat = Tiff.SampleFormat.Int;
                                t.setTag(tagstruct);
                                t.write(r(:,:,i));
                                t.close();
                            elseif i<100000
                                t = Tiff(['motion_corrected_ch1_0' int2str(i) '.tif'],'w');
                                tagstruct.ImageLength = size(r,1);
                                tagstruct.ImageWidth = size(r,2);
                                tagstruct.Photometric = Tiff.Photometric.MinIsBlack;
                                tagstruct.BitsPerSample = 16;
                                tagstruct.SamplesPerPixel = 1;
                                tagstruct.PlanarConfiguration = Tiff.PlanarConfiguration.Chunky;
                                tagstruct.Software = 'MATLAB';
                                tagstruct.SampleFormat = Tiff.SampleFormat.Int;
                                t.setTag(tagstruct);
                                t.write(r(:,:,i));
                                t.close();
                            else
                                t = Tiff(['motion_corrected_ch1_' int2str(i) '.tif'],'w');
                                tagstruct.ImageLength = size(r,1);
                                tagstruct.ImageWidth = size(r,2);
                                tagstruct.Photometric = Tiff.Photometric.MinIsBlack;
                                tagstruct.BitsPerSample = 16;
                                tagstruct.SamplesPerPixel = 1;
                                tagstruct.PlanarConfiguration = Tiff.PlanarConfiguration.Chunky;
                                tagstruct.Software = 'MATLAB';
                                tagstruct.SampleFormat = Tiff.SampleFormat.Int;
                                t.setTag(tagstruct);
                                t.write(r(:,:,i));
                                t.close();
                            end
                        end
                    end
                end
            end
            
            initial1.g(:,:,(block-1)*blockframes+1:(block-1)*blockframes+size(g,3)) = int16(g);
            
            if write_to_disk
                if write_red
                    initial1.r(:,:,(block-1)*blockframes+1:(block-1)*blockframes+size(r,3)) = int16(r);
                end
            end
            clear g r
        end
        if write_to_disk
            if save_as_only_one_file
                t = Tiff(['motion_corrected_ch2_'  '.tif' ],'w8');
                tagstruct.ImageLength = size(initial1.g,1);
                tagstruct.ImageWidth = size(initial1.g,2);
                tagstruct.Photometric = Tiff.Photometric.MinIsBlack;
                tagstruct.BitsPerSample = 16;
                tagstruct.SamplesPerPixel = 1;
                tagstruct.PlanarConfiguration = Tiff.PlanarConfiguration.Chunky;
                tagstruct.Software = 'MATLAB';
                tagstruct.SampleFormat = Tiff.SampleFormat.Int;
                t.setTag(tagstruct);
                t.write(int16(initial1.g(:,:,1)));
                t.close();
                for i = 2:size(initial1.g,3)
                    writing_tiff_g = i
                    %t = Tiff(['motion_corrected_ch2.tif'],'a');
                    t = Tiff(['motion_corrected_ch2_' '.tif'],'a');
                    tagstruct.ImageLength = size(initial1.g,1);
                    tagstruct.ImageWidth = size(initial1.g,2);
                    tagstruct.Photometric = Tiff.Photometric.MinIsBlack;
                    tagstruct.BitsPerSample = 16;
                    tagstruct.SamplesPerPixel = 1;
                    tagstruct.PlanarConfiguration = Tiff.PlanarConfiguration.Chunky;
                    tagstruct.Software = 'MATLAB';
                    tagstruct.SampleFormat = Tiff.SampleFormat.Int;
                    t.setTag(tagstruct);
                    t.write(int16(initial1.g(:,:,i)));
                    t.close();
                end
                if write_red
                    cd(Folder_master)
                    cd (Folder);
                    cd(Loc);
                    cd (Loc1);
                    t = Tiff(['motion_corrected_ch1_'  '.tif' ],'w8');
                    tagstruct.ImageLength = size(initial1.r,1);
                    tagstruct.ImageWidth = size(initial1.r,2);
                    tagstruct.Photometric = Tiff.Photometric.MinIsBlack;
                    tagstruct.BitsPerSample = 16;
                    tagstruct.SamplesPerPixel = 1;
                    tagstruct.PlanarConfiguration = Tiff.PlanarConfiguration.Chunky;
                    tagstruct.Software = 'MATLAB';
                    tagstruct.SampleFormat = Tiff.SampleFormat.Int;
                    t.setTag(tagstruct);
                    t.write(int16(initial1.r(:,:,1)));
                    t.close();
                    for i = 2:size(initial1.r,3)
                        writing_tiff_r = i
                        %t = Tiff(['motion_corrected_ch2.tif'],'a');
                        t = Tiff(['motion_corrected_ch1_' '.tif'],'a');
                        tagstruct.ImageLength = size(initial1.r,1);
                        tagstruct.ImageWidth = size(initial1.r,2);
                        tagstruct.Photometric = Tiff.Photometric.MinIsBlack;
                        tagstruct.BitsPerSample = 16;
                        tagstruct.SamplesPerPixel = 1;
                        tagstruct.PlanarConfiguration = Tiff.PlanarConfiguration.Chunky;
                        tagstruct.Software = 'MATLAB';
                        tagstruct.SampleFormat = Tiff.SampleFormat.Int;
                        t.setTag(tagstruct);
                        t.write(int16(initial1.r(:,:,i)));
                        t.close();
                    end
                    
                end
            end
        end
        if nocorr(1,iii) == 0
            initial1.offsets = offsets;
        end
        r = 0;
        initial1.tiffmovie = 0;
        initial1.tiffmovie_ch1 = 0;
        initial1.red_bad = red_bad;
    end
else
    
    if initialp.h5_already_created(1,iii)==1
        
        max_frame = initialp.max_frame;
        initial1.numerofframes = initialp.max_frame;
        
        if onep
            
            h5file = dir('masked*.h5')
            info = h5info(h5file.name)
            sz=info.Datasets.Dataspace.Size;
            initial1.height = sz(1,1)
            initial1.width = sz(1,2)
            initial1.numberofmovies = 1;
        else
            cd('motion_corrected\ch2')
            
            h5file = dir('motion*.h5')
            info = h5info(h5file.name)
            sz=info.Datasets.Dataspace.Size;
            initial1.height = sz(1,1)
            initial1.width = sz(1,2)
            initial1.numberofmovies = 1;
        end
    else
        initial1.no_tiffs = 1;
        if batch_proc
            if red_bad == 0
                Stack_ch1 = initialp.Stack_ch1; % dir(strcat(Folder,'\*h1*.tif'));
            end
            Stack_ch2 = initialp.Stack_ch2; % dir(strcat(Folder,'\*h2*.tif'));
        else
            if onep
                
                Stack_ch2 = initialp.Stack_ch2;
            else
                if red_bad==0
                    Stack_ch1 = initialp.Stack_ch1; %dir(strcat(Folder,'\*h1*.tif'));
                end
                Stack_ch2 = initialp.Stack_ch2; %dir(strcat(Folder,'\*h2*.tif'));
            end
        end
        if initialp.h5_or_tif(1,iii)
            info = h5info(Stack_ch2(1).name);
            initial1.width = info.Groups(2).Datasets.Dataspace.Size(1,2);
            initial1.height =  info.Groups(2).Datasets.Dataspace.Size(1,1);
            if initialp.date>736000 && initialp.date < 737800
                initial1.height = info.Groups(2).Datasets.Dataspace.Size(1,2);
                initial1.width =  info.Groups(2).Datasets.Dataspace.Size(1,1);
            end
            initial1.numberofmovies = 1;
        else
            info = imfinfo(Stack_ch2(1,1).name);
            initial1.width = info.Width;
            initial1.height = info.Height;
            initial1.numberofmovies = 1;
        end
        %%%%%%%%%%%%%%%% load tiff files %%%%%%%%%%%%%%%%%%%%%%%
        max_frame = initialp.max_frame;
        initial1.numerofframes = initialp.max_frame;
    end
end







