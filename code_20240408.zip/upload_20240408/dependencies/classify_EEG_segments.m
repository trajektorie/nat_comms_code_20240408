
% 
% All_EEGs,j,1,wave'
% rec = j
% d = 1
% wave = wave';


function [segments] = classify_EEG_segments(All_EEGs,rec,d,wave)

segments=[];

prompt = {'y-axes fixed (0), or individual (1)?'};
dlg_title = 'y-axes fixed?';
num_lines = 1;
def = {'0'};
answe = inputdlg(prompt,dlg_title,num_lines,def);
answe = str2mat(answe);
answey = str2num(answe);

c = 1;

switch (d)
    case 1
        
        r = All_EEGs(rec).pot_seizures;
    case 2
        
        r = All_EEGs(rec).pot_seizures_2;
    case 3
        
        r = All_EEGs(rec).pot_seizures_3;
        
end
a=1;

diffr = diff(r);
drmo = diffr-1;

drmon = nonzeros(drmo);

segs = length(drmon)+1;

for j = 1:segs
    curr_seg = j
    tot_segs = segs
    curr_file = i
    
    b=0;
    if a+1>length(r)
    else
        dps = r(1,a+1) - r(1,a);
        while dps < 2 && a<length(r)-2
            b=b+1;
            a=a+1;
            dps = r(1,a+1) - r(1,a);
        end
        if b<2
            b=2;
        end
        begseg = r(1,a-b);
        endseg = r(1,a-1);
        a=a+1;%dps;
        segments(j).begseg = begseg;
        segments(j).endseg = endseg;
        
        if begseg>1000%All_EEGs(i).fs
            pfs = 1000;%All_EEGs(i).fs;
        else
            pfs = 0;
        end
        
        if endseg + 1000 > length(wave) || pfs==0
            prk = 0;
        else
            prk = 1000;%All_EEGs(i).fs;
        end
        
        toplot = wave(1,begseg-pfs:endseg+prk);
        
        if answey
            if min(toplot)<0
                %                 ymin = min(wave)*1.8;
                %                 ymax = max(wave)*1.8;
                ymin = prctile(wave,1)*5;
                ymax = prctile(wave,99)*5;
            else
                ymin =prctile(wave,1)*0.05;
                ymax = prctile(wave,99)*5;
            end
        else
            ymin = -1;
            ymax = 1;
        end
        
        
        
        figure(90)
        plot(toplot)
        hold on
        if length(prk:1:prk+endseg-begseg)<length(wave(begseg:endseg))
            aop=1
        else
            aop=0;
        end
        plot(prk:1:prk+endseg-begseg,wave(begseg:endseg-aop),'Color',[1 0 0])
        axis([0 2000+endseg-begseg ymin ymax])
        
        list = {'seizure','spike','SWD',...
            'artifact','other','nothing'};
        [indx,tf] = listdlg('ListString',list);
        
%         
%         prompt = {'Is this a seizure (0), spike (1), SW (2), artifact (3), other event (4) or nothing (5)?'};
%         dlg_title = 'what type of event?';
%         num_lines = 1;
%         def = {'2'};
%         answe = inputdlg(prompt,dlg_title,num_lines,def);
%         answe = str2mat(answe);
%         answe = str2num(answe);
%         
%         
        switch (indx)
            
            case 1
                segments(j).seizure = 1;
                segments(j).poss_int_spike = 0;
                segments(j).SW = 0;
                segments(j).artifact = 0;
                segments(j).other = 0;
                segments(j).nothing = 0;
            case 2
                segments(j).poss_int_spike = 1;
                segments(j).seizure = 0;
                segments(j).SW = 0;
                segments(j).artifact = 0;
                segments(j).other = 0;
                segments(j).nothing = 0;
            case 3
                segments(j).SW = 1;
                segments(j).poss_int_spike = 0;
                segments(j).seizure = 0;
                segments(j).artifact = 0;
                segments(j).other = 0;
                segments(j).nothing = 0;
            case 4
                segments(j).artifact = 1;
                segments(j).poss_int_spike = 0;
                segments(j).seizure = 0;
                segments(j).SW = 0;
                segments(j).other = 0;
                segments(j).nothing = 0;
            case 5
                segments(j).other = 1;
                segments(j).poss_int_spike = 0;
                segments(j).seizure = 0;
                segments(j).SW = 0;
                segments(j).artifact = 0;
                segments(j).nothing = 0;
            case 6
                
                segments(j).other = 0;
                segments(j).poss_int_spike = 0;
                segments(j).seizure = 0;
                segments(j).SW = 0;
                segments(j).artifact = 0;
                segments(j).nothing = 1;
        end
        close 90
    end
end

