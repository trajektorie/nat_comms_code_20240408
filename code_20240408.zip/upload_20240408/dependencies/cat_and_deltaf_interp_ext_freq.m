function [deltaf_interp,cat_signal_interp] = cat_and_deltaf_interp_ext_freq(deltaf_matrix,cat_signal,initial,freq)

%freq = 100;

results.cat_signal = cat_signal;
smooth_deltaf_matrix = deltaf_matrix;
%
%     %
%     %     indicator = initial.indicator;
%     %
%     %     fps = 1000/initial.msperline;
%     %     traceOpt.trace_computation = 'oopsi';
%     %     traces = deltaf_matrix;
%     %     oopsi_spike_trace = filterTraces_old( traces, fps, traceOpt,indicator );
%     %     smooth_oopsi_filtered_deltaf_matrix = oopsi_spike_trace;
%     %     clear oopsi_spike_trace
%     EEG_results.oopsi_filtered_smooth_deltaf_matrix_JM_EDITED_ALGORITHM = oopsi_results.oopsi_filtered_deltaf_matrix;
%     smooth_oopsi_filtered_deltaf_matrix = oopsi_results.oopsi_filtered_deltaf_matrix;
%     %EEG_results.P_best = P_best;
%     %EEG_results.V = V;
%
%     %
%     % traces = deltaf_matrix;
%     % oopsi_spike_trace = filterTraces( traces, fps, traceOpt );
%     % oopsi_filtered_deltaf_matrix = oopsi_spike_trace;
%     % clear oopsi_spike_trace
%     % results.oopsi_filtered_deltaf_matrix = oopsi_filtered_deltaf_matrix;
%     %
%     % for i = 1:size(deltaf_matrix,2)
%     % diff_smooth_oopsi(:,i) = diff(smooth_oopsi_filtered_deltaf_matrix(:,i));
%     % end
%     %
%     %
%     % for i = 1:size(deltaf_matrix,2)
%     % diff_smooth_deltaf(:,i) = diff(smooth_deltaf_matrix(:,i));
%     % end
%     %
%     % results.diff_smooth_deltaf = diff_smooth_deltaf;
%
if initial.msperline > 10
    
    %interpolate deltaf_matrix to freq
    %     s_f = 5;
    %     %deltaf_matrix = smooth(results.deltaf_matrix(:,1),s_f);
    %     for i = 1 : size(results.deltaf_matrix,2)
    %         deltaf_matrix(:,i) = smooth(results.deltaf_matrix(:,i),s_f);
    %     end
    
    deltaf_interp  = zeros(ceil(length(smooth_deltaf_matrix)*initial.msperline/1000*freq),size(smooth_deltaf_matrix,2));
    
    for k = 1:size(smooth_deltaf_matrix,2)
        a=1;
        j = 1;
        i = 2;
        deltaf_interp_ROI = k
        while i <= length(deltaf_interp)-10
            %deltaf_interp (i,1) = i/freq;
            if (j*initial.msperline/1000 >= i/freq) && (j*initial.msperline/1000 <= i/freq+1/freq)...
                    && deltaf_interp(i,k) == 0 %&& deltaf_interp(i-1,k) == 0
                if j*initial.msperline-i/freq <= i+1/freq - j*initial.msperline
                    deltaf_interp(i,k) = smooth_deltaf_matrix(j,k);
                    if smooth_deltaf_matrix(j,k)==0
                        zerodf(1,a) = i;
                        a=a+1;
                    end
                else
                    deltaf_interp(i+1,k) = smooth_deltaf_matrix(j,k);
                    if smooth_deltaf_matrix(j,k)==0
                        zerodf(1,a) = i+1;
                        a=a+1;
                    end
                end
                j=j+1;
            end
            i=i+1;
        end
    end
    
    
    results.cat_signal_interp  = zeros(ceil(length(results.cat_signal)*initial.msperline/1000*freq),size(results.cat_signal,2));
    
    for k = 1:size(results.cat_signal,2)
        j = 1;
        i = 2;
        cat_signal_interp_ROI = k
        while i <= length(results.cat_signal_interp)-10
            %deltaf_interp (i,1) = i/freq;
            if (j*initial.msperline/1000 >= i/freq) && (j*initial.msperline/1000 <= i/freq+1/freq)...
                    && results.cat_signal_interp(i,k) == 0 % && results.cat_signal_interp(i-1,k) == 0
                if j*initial.msperline-i/freq <= i+1/freq - j*initial.msperline
                    results.cat_signal_interp(i,k) = results.cat_signal(j,k);
                    if results.cat_signal(j,k)==0
                        zerocat(1,a) = i;
                        a=a+1;
                    end
                else
                    results.cat_signal_interp(i+1,k) = results.cat_signal(j,k);
                    if results.cat_signal(j,k)==0
                        zerocat(1,a) = i+1;
                        a=a+1;
                    end
                end
                j=j+1;
            end
            i=i+1;
        end
    end
    
    forw = ceil(initial.msperline/(1000/freq));
    
    results.cat_signal_interp_values = results.cat_signal_interp;
    
    %results.cat_signal_interp_values(results.cat_signal_interp_values==0)= NaN;
    
    for i = 1:size(results.cat_signal_interp_values,2)
        a=1;
        inpaint_nans_cat_siangl_ROI = i
        naninds = 0;
        for j = 1:length(results.cat_signal_interp_values)
            if j<length(results.cat_signal_interp_values)-forw
                if sum(results.cat_signal_interp_values(j:j+forw,i))>0
                    curr = find(results.cat_signal_interp_values(j:j+forw,i)==0)+j-1;
                    c = length(curr);
                    naninds(1,a:a+c-1) = curr;
                    a=a+c;
                    %results.deltaf_interp_values(find(results.deltaf_interp_values(j:j+forw,i)==0)',i)= NaN;
                end
            else
                if results.cat_signal_interp_values(j,i) == 0;
                    naninds(1,a) = j;
                    a=a+1;
                    %results.deltaf_interp_values(j,i) = NaN;
                end
            end
        end
        
        %remove duplicates from naninds
        
        results.cat_signal_interp_values(unique(naninds),i)= NaN;
        
        results.cat_signal_interp_values(1:size(results.cat_signal_interp_values,1),i)...
            = inpaint_nans(results.cat_signal_interp_values(1:size(results.cat_signal_interp_values,1),i));
    end
    
    cat_signal_interp = results.cat_signal_interp_values;
    
    clear deltaf_stimcell_interp_values_rerun
    
    %deltaf_stimcell_interp = deltaf_stimcell_interp_bak;
    deltaf_interp_new = deltaf_interp;
    
    %results.deltaf_interp_values(results.deltaf_interp_values==0)= NaN;
    for i = 1:size(deltaf_interp,2)
        a=1;
        inpaint_nans_deltaf_ROI = i
        naninds = 0;
        for j = 1:length(deltaf_interp)
            if j<length(deltaf_interp)-forw
                if sum(deltaf_interp(j:j+forw,i))>0
                    curr = find(deltaf_interp(j:j+forw,i)==0)+j-1;
                    c = length(curr);
                    naninds(1,a:a+c-1) = curr;
                    a=a+c;
                    %results.deltaf_interp_values(find(results.deltaf_interp_values(j:j+forw,i)==0)',i)= NaN;
                end
            else
                if deltaf_interp(j,i) == 0;
                    naninds(1,a) = j;
                    a=a+1;
                    %results.deltaf_interp_values(j,i) = NaN;
                end
            end
        end
        
        %remove duplicates from naninds
        
        deltaf_interp_new(unique(naninds),i)= NaN;
        
        deltaf_interp_new(1:size(deltaf_interp,1),i)...
            = inpaint_nans(deltaf_interp_new(1:size(deltaf_interp,1),i));
    end
    % results.deltaf_interp_values = deltaf_interp_values;
    deltaf_interp_avg = mean(deltaf_interp_new,2);
    
    EEG_results.deltaf_interp_avg = deltaf_interp_avg;
    deltaf_interp = deltaf_interp_new;
end



