function ca_EEG = calcium_EEG_event_correlation (EEG_segs, initial,rec)

ki = length(EEG_segs(rec).segs)

others = 0;
poss_int_spikes = 0;
seizures = 0;
SWs = 0;
artifacts = 0;
nothing = 0;
a=1
b=1
c=1
d=1
e=1
f=1

for i=1:ki
    if EEG_segs(rec).segs(i).other == 1
        others = others+1;
        other_seg(a).begseg = EEG_segs(rec).segs(i).begseg;
        other_seg(a).endseg = EEG_segs(rec).segs(i).endseg;
        a=a+1;
    end
     if EEG_segs(rec).segs(i).poss_int_spike == 1
        poss_int_spikes = poss_int_spikes+1;
        poss_int_spikes_seg(b).begseg = EEG_segs(rec).segs(i).begseg;
        poss_int_spikes_seg(b).endseg = EEG_segs(rec).segs(i).endseg;
        b=b+1;
     end
     if EEG_segs(rec).segs(i).seizure == 1
        seizures = seizures+1;
        seizure_seg(c).begseg = EEG_segs(rec).segs(i).begseg;
        seizure_seg(c).endseg = EEG_segs(rec).segs(i).endseg;
        c=c+1;
     end
     if EEG_segs(rec).segs(i).SW == 1
        SWs = SWs+1;
        SW_seg(d).begseg = EEG_segs(rec).segs(i).begseg;
        SW_seg(d).endseg = EEG_segs(rec).segs(i).endseg;
        d=d+1;
     end
     if EEG_segs(rec).segs(i).artifact == 1
        artifacts = artifacts+1;
        artifact_seg(e).begseg = EEG_segs(rec).segs(i).begseg;
        artifact_seg(e).endseg = EEG_segs(rec).segs(i).endseg;
        e=e+1;
     end
     if EEG_segs(rec).segs(i).nothing == 1
        nothing = nothing+1;
        nothing_seg(f).begseg = EEG_segs(rec).segs(i).begseg;
        nothing_seg(f).endseg = EEG_segs(rec).segs(i).endseg;
        f=f+1;
    end
end


if others
    for i = 1:length(other_seg)
        tds.sonms(1,i) = other_seg(i).begseg;
        tds.soffms(1,i) = other_seg(i).endseg;
        tds.sond(1,i) = round(other_seg(i).begseg/(1000/initial.samplingratehz));
        tds.soffd(1,i) = round(other_seg(i).endseg/(1000/initial.samplingratehz));
    end
    ca_EEG.tds_others = tds;
else
    ca_EEG.tds_others = [];
end

clear tds
if poss_int_spikes
    for i = 1:length(poss_int_spikes_seg)
        tds.sonms(1,i) = poss_int_spikes_seg(i).begseg;
        tds.soffms(1,i) = poss_int_spikes_seg(i).endseg;
        tds.sond(1,i) = round(poss_int_spikes_seg(i).begseg/(1000/initial.samplingratehz));
        tds.soffd(1,i) = round(poss_int_spikes_seg(i).endseg/(1000/initial.samplingratehz));
    end
    ca_EEG.tds_poss_int_spikes = tds;
else
    ca_EEG.tds_poss_int_spikes = [];
end


clear tds
if seizures
    for i = 1:length(seizure_seg)
        tds.sonms(1,i) = seizure_seg(i).begseg;
        tds.soffms(1,i) = seizure_seg(i).endseg;
        tds.sond(1,i) = round(seizure_seg(i).begseg/(1000/initial.samplingratehz));
        tds.soffd(1,i) = round(seizure_seg(i).endseg/(1000/initial.samplingratehz));
    end
    ca_EEG.tds_seizures = tds;
else
    ca_EEG.tds_seizures = [];
end

clear tds
if SWs
    for i = 1:length(SW_seg)
        tds.sonms(1,i) = SW_seg(i).begseg;
        tds.soffms(1,i) = SW_seg(i).endseg;
        tds.sond(1,i) = round(SW_seg(i).begseg/(1000/initial.samplingratehz));
        tds.soffd(1,i) = round(SW_seg(i).endseg/(1000/initial.samplingratehz));
    end
    ca_EEG.tds_SWs = tds;
else
    ca_EEG.tds_SWs = [];
end

clear tds
if artifacts
    for i = 1:length(artifact_seg)
        tds.sonms(1,i) = artifact_seg(i).begseg;
        tds.soffms(1,i) = artifact_seg(i).endseg;
        tds.sond(1,i) = round(artifact_seg(i).begseg/(1000/initial.samplingratehz));
        tds.soffd(1,i) = round(artifact_seg(i).endseg/(1000/initial.samplingratehz));
    end
    ca_EEG.tds_artifacts = tds;
else
    ca_EEG.tds_artifacts = [];
end


clear tds
if nothing
    for i = 1:length(nothing_seg)
        tds.sonms(1,i) = nothing_seg(i).begseg;
        tds.soffms(1,i) = nothing_seg(i).endseg;
        tds.sond(1,i) = round(nothing_seg(i).begseg/(1000/initial.samplingratehz));
        tds.soffd(1,i) = round(nothing_seg(i).endseg/(1000/initial.samplingratehz));
    end
    ca_EEG.tds_nothing = tds;
else
    ca_EEG.tds_nothing = [];
end



end
    