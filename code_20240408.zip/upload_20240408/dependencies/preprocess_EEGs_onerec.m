

if onep


    if All_EEGs(iii).too_short
    else
        if isempty(All_EEGs(iii).EEG_2_extrap_1000)==0

            wave_2 = 0;
            wave_3=0;
            switch (reref_con_ips)
                case 0
                    wave = All_EEGs(iii).aegminaeg2';   %EEG_extrap_1000';
                case 1
                    wave = All_EEGs(iii).EEG_2_extrap_1000';
                case 2
                    wave = All_EEGs(iii).EEG_extrap_1000';
                case 3
                    wave = All_EEGs(iii).EEG_extrap_1000';
                    wave_2 = All_EEGs(iii).EEG_2_extrap_1000';
                case 4
                    wave = All_EEGs(iii).EEG_extrap_1000';
                    wave_2 = All_EEGs(iii).EEG_2_extrap_1000';
                    wave_3 = All_EEGs(iii).aegminaeg2';
            end


            mw = mean(wave);
            sw = std(wave,0);

            x=0;
            while sw<1.1
                wave = wave*10;
                sw = std(wave,0);
                x=x+1;
            end

            All_EEGs(iii).mw = mean(wave);
            All_EEGs(iii).sw = std(wave,0);
            All_EEGs(iii).eeg_factor = 10^x;
            %All_EEGs(i).EEG_extrap_1000 = wave;

            close all
            fss = 1000; %initial.sampl_fr; %in Hz
            time = 1/fss:1/fss:length(wave)/fss;
            steptime = 0.02; %in sec
            windowtime = 0.5; %in sec
            spectra_sf_Hz = 1/steptime
            spec_fac = 100/spectra_sf_Hz;
            ampthr = 1.3; %in SD
            freqthr = 1.5; %in SD
            initial_LP_filter_cutoff_Hz = 1;
            initial_HP_filter_cutoff_Hz = 200;
            freqband_lower_lim = 0.5;  %in Hz, was 7 (06/26/18)
            freqband_upper_lim = 30;  %in Hz, was 12 (06/26/18)
            min_seiz_length = 1;%0.3;  %in sec
            min_seiz_Hz = 0.5; % was 5 (06/25/18)
            min_num_seiz = 0;
            min_seiz_ISI = 0; %in sec
            %
            %fs=fss

            [seize_LF,EEG_analysis_LF] = autoseizureread_Atul(Folder,wave, time, windowtime, steptime, fss,ampthr,initial_LP_filter_cutoff_Hz,...
                initial_HP_filter_cutoff_Hz,min_seiz_length,min_seiz_Hz,min_num_seiz,freqband_lower_lim,freqband_upper_lim,min_seiz_ISI,freqthr);

            All_EEGs(iii).seize_LF = seize_LF;
            All_EEGs(iii).EEG_analysis_LF = EEG_analysis_LF;
            All_EEGs(iii).FFT_frqs = EEG_analysis_LF.FFT_frqs;
            fouriersp = All_EEGs(iii).EEG_analysis_LF.magvalue_1sided_rel;

            %fouriersp = fouriersp(1:size(fouriersp,1)/2,:);
            %sp_hz = 1/steptime;
            inn.msperline = steptime*1000;
            freq = 100
            fouriersp = fouriersp';
            skip_inpaint_nans = 1;
            [fouriersp_interp,rew] = cat_and_deltaf_interp(fouriersp,0,inn,freq,skip_inpaint_nans);
            if skip_inpaint_nans
            else
                fouriersp_interp(fouriersp_interp==0)=NaN;
                fouriersp_interp = inpaint_nans(fouriersp_interp);
            end
            All_EEGs(iii).fouriersp_interp = fouriersp_interp;

            clear fouriersp_interp

            %fouriersp = flipud(fouriersp);
            %imagesc(fouriersp_interp')

            close all
            fss = 1000; %initial.sampl_fr; %in Hz
            time = 1/fss:1/fss:length(wave)/fss;
            steptime = 0.02; %in sec

            windowtime = 0.5; %in sec
            ampthr = 1.6; %in SD
            freqthr = 1.5; %in SD
            initial_LP_filter_cutoff_Hz = 20;
            initial_HP_filter_cutoff_Hz = 500;
            freqband_lower_lim = 40;  %in Hz
            freqband_upper_lim = 400;  %in Hz
            min_seiz_length = 0;  %in sec
            min_seiz_Hz = 3;
            min_num_seiz = 1;
            min_seiz_ISI = 0; %in sec
            %
            [seize_HF,EEG_analysis_HF] = autoseizureread_Atul(Folder,wave, time, windowtime, steptime, fss,ampthr,initial_LP_filter_cutoff_Hz,...
                initial_HP_filter_cutoff_Hz,min_seiz_length,min_seiz_Hz,min_num_seiz,freqband_lower_lim,freqband_upper_lim,min_seiz_ISI,freqthr);

            All_EEGs(iii).seize_HF = seize_HF;
            All_EEGs(iii).EEG_analysis_HF = EEG_analysis_HF;

            % %
            %        high_freq_band = mean(EEG_analysis.magvalue(EEG_analysis.theta,:),1);
            %
            %         HF_band = interp(high_freq_band,double(fss)/double(1/steptime));
            %
            %         x = -1/2:1/(fss/2-1):1/2;
            %
            %         fil = exp( -(x.^2)/(2*0.2^2) );
            %
            %         HF_band_c = conv(HF_band,fil);
            %
            %         %mw = mean(HF_band_c);
            %         mw = median(HF_band_c);
            %         sw = std(HF_band_c,0);
            %
            %         HF_thr = mw+sw*0.7;
            %
            %         clear to_remove
            %         a=1;
            %         for j = 1:length(HF_band_c)
            %             if HF_band_c(1,j)>HF_thr
            %                 to_remove(1,a) = j;
            %                 a=a+1;
            %             end
            %
            %
            %         end

            clear pot_seizs
            abb=1;
            for k = 1:size(seize_LF,2)
                currr = seize_LF(k).stind*fss:1:seize_LF(k).enind*fss;
                fc=length(currr);
                pot_seizs(1,abb:abb+fc-1) = currr;
                abb=abb+fc;
            end


            All_EEGs(iii).pot_seizs = pot_seizs;

            clear all_HF_stuff to_remove
            abb=1;
            all_HF_stuff=0
            for k = 1:size(seize_HF,2)
                if isfield(seize_HF(k),'enind')
                    currr = seize_HF(k).stind*fss:1:seize_HF(k).enind*fss;
                    fc=length(currr);
                    all_HF_stuff(1,abb:abb+fc-1) = currr;
                    abb=abb+fc;
                end
            end

            to_remove = setdiff(all_HF_stuff,pot_seizs);

            wave_bak = wave;
            if to_remove==0
            else
                wave(round(to_remove),:) = [];
            end

            All_EEGs(iii).removed_samples = to_remove;

            [spectra,freqs,speccomp,contrib,specstd] = ...
                spectopo(wave', 0, fss, 'freq',freq, 'chanlocs', 1,'limits', [0 60 NaN NaN -10 10], 'freqfac',8,'plot','off');

            close all

            All_EEGs(iii).spectra = spectra;
            All_EEGs(iii).freqs = freqs;
            All_EEGs(iii).speccomp = speccomp;
            All_EEGs(iii).contrib = contrib;
            All_EEGs(iii).specstd = specstd;
            %All_EEGs(i).HF_band_c = HF_band_c;

            figure(iii)
            scatter(All_EEGs(iii).freqs,All_EEGs(iii).spectra)


            if wave_2 == 0
            else
                wave=wave_2;
                mw = mean(wave);
                sw = std(wave,0);

                x=0;
                while sw<1.1
                    wave = wave*10;
                    sw = std(wave,0);
                    x=x+1;
                end

                All_EEGs(iii).mw_2 = mean(wave);
                All_EEGs(iii).sw_2 = std(wave,0);
                All_EEGs(iii).eeg_factor_2 = 10^x;
                %All_EEGs(i).EEG_extrap_1000 = wave;

                close all
                fss = 1000; %initial.sampl_fr; %in Hz
                time = 1/fss:1/fss:length(wave)/fss;
                steptime = 0.02; %in sec
                windowtime = 0.5; %in sec
                ampthr = 1.3; %in SD
                freqthr = 1.5; %in SD
                initial_LP_filter_cutoff_Hz = 1;
                initial_HP_filter_cutoff_Hz = 200;
                freqband_lower_lim = 0.5;  %in Hz, was 7 (06/26/18)
                freqband_upper_lim = 30;  %in Hz, was 12 (06/26/18)
                min_seiz_length = 1;%0.3;  %in sec
                min_seiz_Hz = 0.5; % was 5 (06/25/18)
                min_num_seiz = 0;
                min_seiz_ISI = 0; %in sec
                %
                %fs=fss
                %         ilpc=initial_LP_filter_cutoff_Hz
                %         ihpc=initial_HP_filter_cutoff_Hz
                %         fbll=freqband_lower_lim
                %         fbul=freqband_upper_lim
                %         frsx=freqthr
                %
                [seize_LF,EEG_analysis_LF] = autoseizureread_Atul(Folder,wave, time, windowtime, steptime, fss,ampthr,initial_LP_filter_cutoff_Hz,...
                    initial_HP_filter_cutoff_Hz,min_seiz_length,min_seiz_Hz,min_num_seiz,freqband_lower_lim,freqband_upper_lim,min_seiz_ISI,freqthr);

                All_EEGs(iii).seize_LF_2 = seize_LF;
                All_EEGs(iii).EEG_analysis_LF_2 = EEG_analysis_LF;


                fouriersp = All_EEGs(iii).EEG_analysis_LF_2.magvalue_1sided_rel;

                %fouriersp = fouriersp(1:size(fouriersp,1)/2,:);
                %sp_hz = 1/steptime;
                inn.msperline = steptime*1000;
                freq = 100
                fouriersp = fouriersp';
                skip_inpaint_nans = 1;
                [fouriersp_interp,rew] = cat_and_deltaf_interp(fouriersp,0,inn,freq,skip_inpaint_nans);
                if skip_inpaint_nans
                else
                    fouriersp_interp(fouriersp_interp==0)=NaN;
                    fouriersp_interp = inpaint_nans(fouriersp_interp);
                end
                All_EEGs(iii).fouriersp_interp_2 = fouriersp_interp;

                clear fouriersp_interp

                close all
                fss = 1000; %initial.sampl_fr; %in Hz
                time = 1/fss:1/fss:length(wave)/fss;
                steptime = 0.02; %in sec
                windowtime = 0.5; %in sec
                ampthr = 1.6; %in SD
                freqthr = 1.5; %in SD
                initial_LP_filter_cutoff_Hz = 20;
                initial_HP_filter_cutoff_Hz = 500;
                freqband_lower_lim = 40;  %in Hz
                freqband_upper_lim = 400;  %in Hz
                min_seiz_length = 0;  %in sec
                min_seiz_Hz = 3;
                min_num_seiz = 1;
                min_seiz_ISI = 0; %in sec
                %
                [seize_HF,EEG_analysis_HF] = autoseizureread_Atul(Folder,wave, time, windowtime, steptime, fss,ampthr,initial_LP_filter_cutoff_Hz,...
                    initial_HP_filter_cutoff_Hz,min_seiz_length,min_seiz_Hz,min_num_seiz,freqband_lower_lim,freqband_upper_lim,min_seiz_ISI,freqthr);

                All_EEGs(iii).seize_HF_2 = seize_HF;
                All_EEGs(iii).EEG_analysis_HF_2 = EEG_analysis_HF;

                % %
                %        high_freq_band = mean(EEG_analysis.magvalue(EEG_analysis.theta,:),1);
                %
                %         HF_band = interp(high_freq_band,double(fss)/double(1/steptime));
                %
                %         x = -1/2:1/(fss/2-1):1/2;
                %
                %         fil = exp( -(x.^2)/(2*0.2^2) );
                %
                %         HF_band_c = conv(HF_band,fil);
                %
                %         %mw = mean(HF_band_c);
                %         mw = median(HF_band_c);
                %         sw = std(HF_band_c,0);
                %
                %         HF_thr = mw+sw*0.7;
                %
                %         clear to_remove
                %         a=1;
                %         for j = 1:length(HF_band_c)
                %             if HF_band_c(1,j)>HF_thr
                %                 to_remove(1,a) = j;
                %                 a=a+1;
                %             end
                %
                %
                %         end

                clear pot_seizs
                abb=1;
                for k = 1:size(seize_LF,2)
                    currr = seize_LF(k).stind*fss:1:seize_LF(k).enind*fss;
                    fc=length(currr);
                    pot_seizs(1,abb:abb+fc-1) = currr;
                    abb=abb+fc;
                end


                All_EEGs(iii).pot_seizs_2 = pot_seizs;

                clear all_HF_stuff to_remove
                abb=1;
                all_HF_stuff=0
                for k = 1:size(seize_HF,2)
                    if isfield(seize_HF(k),'enind')
                        currr = seize_HF(k).stind*fss:1:seize_HF(k).enind*fss;
                        fc=length(currr);
                        all_HF_stuff(1,abb:abb+fc-1) = currr;
                        abb=abb+fc;
                    end
                end

                to_remove = setdiff(all_HF_stuff,pot_seizs);

                wave_bak = wave;
                if to_remove==0
                else
                    wave(round(to_remove),:) = [];
                end

                All_EEGs(iii).removed_samples_2 = to_remove;

                [spectra,freqs,speccomp,contrib,specstd] = ...
                    spectopo(wave', 0, fss, 'freq',freq, 'chanlocs', 1,'limits', [0 60 NaN NaN -10 10], 'freqfac',8,'plot','off');

                close all

                All_EEGs(iii).spectra_2 = spectra;
                All_EEGs(iii).freqs_2 = freqs;
                All_EEGs(iii).speccomp_2 = speccomp;
                All_EEGs(iii).contrib_2 = contrib;
                All_EEGs(iii).specstd_2 = specstd;
                %All_EEGs(i).HF_band_c = HF_band_c;


            end


            if wave_3 == 0
            else
                wave=wave_3;
                mw = mean(wave);
                sw = std(wave,0);

                x=0;
                while sw<1.1
                    wave = wave*10;
                    sw = std(wave,0);
                    x=x+1;
                end

                All_EEGs(iii).mw_3 = mean(wave);
                All_EEGs(iii).sw_3 = std(wave,0);
                All_EEGs(iii).eeg_factor_3 = 10^x;
                %All_EEGs(i).EEG_extrap_1000 = wave;

                close all
                fss = 1000; %initial.sampl_fr; %in Hz
                time = 1/fss:1/fss:length(wave)/fss;
                steptime = 0.02; %in sec
                windowtime = 0.5; %in sec
                ampthr = 1.3; %in SD
                freqthr = 1.5; %in SD
                initial_LP_filter_cutoff_Hz = 1;
                initial_HP_filter_cutoff_Hz = 200;
                freqband_lower_lim = 0.5;  %in Hz, was 7 (06/26/18)
                freqband_upper_lim = 30;  %in Hz, was 12 (06/26/18)
                min_seiz_length = 1;%0.3;  %in sec
                min_seiz_Hz = 0.5; % was 5 (06/25/18)
                min_num_seiz = 0;
                min_seiz_ISI = 0; %in sec
                %
                %fs=fss
                %         ilpc=initial_LP_filter_cutoff_Hz
                %         ihpc=initial_HP_filter_cutoff_Hz
                %         fbll=freqband_lower_lim
                %         fbul=freqband_upper_lim
                %         frsx=freqthr
                %
                [seize_LF,EEG_analysis_LF] = autoseizureread_Atul(Folder,wave, time, windowtime, steptime, fss,ampthr,initial_LP_filter_cutoff_Hz,...
                    initial_HP_filter_cutoff_Hz,min_seiz_length,min_seiz_Hz,min_num_seiz,freqband_lower_lim,freqband_upper_lim,min_seiz_ISI,freqthr);

                All_EEGs(iii).seize_LF_3 = seize_LF;
                All_EEGs(iii).EEG_analysis_LF_3 = EEG_analysis_LF;


                fouriersp = All_EEGs(iii).EEG_analysis_LF_3.magvalue_1sided_rel;

                %fouriersp = fouriersp(1:size(fouriersp,1)/2,:);
                %sp_hz = 1/steptime;
                inn.msperline = steptime*1000;
                freq = 100
                fouriersp = fouriersp';
                skip_inpaint_nans = 1;
                [fouriersp_interp,rew] = cat_and_deltaf_interp(fouriersp,0,inn,freq,skip_inpaint_nans);
                if skip_inpaint_nans
                else
                    fouriersp_interp(fouriersp_interp==0)=NaN;
                    fouriersp_interp = inpaint_nans(fouriersp_interp);
                end
                All_EEGs(iii).fouriersp_interp_3 = fouriersp_interp;

                clear fouriersp_interp

                close all
                fss = 1000; %initial.sampl_fr; %in Hz
                time = 1/fss:1/fss:length(wave)/fss;
                steptime = 0.02; %in sec
                windowtime = 0.5; %in sec
                ampthr = 1.6; %in SD
                freqthr = 1.5; %in SD
                initial_LP_filter_cutoff_Hz = 20;
                initial_HP_filter_cutoff_Hz = 500;
                freqband_lower_lim = 40;  %in Hz
                freqband_upper_lim = 400;  %in Hz
                min_seiz_length = 0;  %in sec
                min_seiz_Hz = 3;
                min_num_seiz = 1;
                min_seiz_ISI = 0; %in sec
                %
                [seize_HF,EEG_analysis_HF] = autoseizureread_Atul(Folder,wave, time, windowtime, steptime, fss,ampthr,initial_LP_filter_cutoff_Hz,...
                    initial_HP_filter_cutoff_Hz,min_seiz_length,min_seiz_Hz,min_num_seiz,freqband_lower_lim,freqband_upper_lim,min_seiz_ISI,freqthr);

                All_EEGs(iii).seize_HF_3 = seize_HF;
                All_EEGs(iii).EEG_analysis_HF_3 = EEG_analysis_HF;

                % %
                %        high_freq_band = mean(EEG_analysis.magvalue(EEG_analysis.theta,:),1);
                %
                %         HF_band = interp(high_freq_band,double(fss)/double(1/steptime));
                %
                %         x = -1/2:1/(fss/2-1):1/2;
                %
                %         fil = exp( -(x.^2)/(2*0.2^2) );
                %
                %         HF_band_c = conv(HF_band,fil);
                %
                %         %mw = mean(HF_band_c);
                %         mw = median(HF_band_c);
                %         sw = std(HF_band_c,0);
                %
                %         HF_thr = mw+sw*0.7;
                %
                %         clear to_remove
                %         a=1;
                %         for j = 1:length(HF_band_c)
                %             if HF_band_c(1,j)>HF_thr
                %                 to_remove(1,a) = j;
                %                 a=a+1;
                %             end
                %
                %
                %         end

                clear pot_seizs
                abb=1;
                for k = 1:size(seize_LF,2)
                    currr = seize_LF(k).stind*fss:1:seize_LF(k).enind*fss;
                    fc=length(currr);
                    pot_seizs(1,abb:abb+fc-1) = currr;
                    abb=abb+fc;
                end


                All_EEGs(iii).pot_seizs_3 = pot_seizs;

                clear all_HF_stuff to_remove
                abb=1;
                all_HF_stuff=0
                for k = 1:size(seize_HF,2)
                    if isfield(seize_HF(k),'enind')
                        currr = seize_HF(k).stind*fss:1:seize_HF(k).enind*fss;
                        fc=length(currr);
                        all_HF_stuff(1,abb:abb+fc-1) = currr;
                        abb=abb+fc;
                    end
                end

                to_remove = setdiff(all_HF_stuff,pot_seizs);

                wave_bak = wave;
                if to_remove==0
                else
                    wave(round(to_remove),:) = [];
                end

                All_EEGs(iii).removed_samples_3 = to_remove;

                [spectra,freqs,speccomp,contrib,specstd] = ...
                    spectopo(wave', 0, fss, 'freq',freq, 'chanlocs', 1,'limits', [0 60 NaN NaN -10 10], 'freqfac',8,'plot','off');

                close all

                All_EEGs(iii).spectra_3 = spectra;
                All_EEGs(iii).freqs_3 = freqs;
                All_EEGs(iii).speccomp_3 = speccomp;
                All_EEGs(iii).contrib_3 = contrib;
                All_EEGs(iii).specstd_3 = specstd;
                %All_EEGs(i).HF_band_c = HF_band_c;


            end


        end
    end

else
    % for iii = 1:size(recording,2)
    if All_EEGs(iii).too_short
    else
        if isempty(All_EEGs(iii).EEG_2_extrap_1000)==0
            Folder = subfolders(iii).name;
            cd(Folder_master)
            cd(Folder)

            wave_2 = 0;
            wave_3=0;
            switch (reref_con_ips)
                case 0
                    wave = All_EEGs(iii).aegminaeg2';   %EEG_extrap_1000';
                case 1
                    wave = All_EEGs(iii).EEG_2_extrap_1000';
                case 2
                    wave = All_EEGs(iii).EEG_extrap_1000';
                case 3
                    wave = All_EEGs(iii).EEG_extrap_1000';
                    wave_2 = All_EEGs(iii).EEG_2_extrap_1000';
                case 4
                    wave = All_EEGs(iii).EEG_extrap_1000';
                    wave_2 = All_EEGs(iii).EEG_2_extrap_1000';
                    wave_3 = All_EEGs(iii).aegminaeg2';
            end


            mw = mean(wave);
            sw = std(wave,0);

            x=0;
            while sw<1.1
                wave = wave*10;
                sw = std(wave,0);
                x=x+1;
            end

            All_EEGs(iii).mw = mean(wave);
            All_EEGs(iii).sw = std(wave,0);
            All_EEGs(iii).eeg_factor = 10^x;
            %All_EEGs(i).EEG_extrap_1000 = wave;

            close all
            fss = 1000; %initial.sampl_fr; %in Hz
            time = 1/fss:1/fss:length(wave)/fss;
            steptime = 0.02; %in sec
            windowtime = 0.5; %in sec
            spectra_sf_Hz = 1/steptime
            spec_fac = 100/spectra_sf_Hz;
            ampthr = 1.3; %in SD
            freqthr = 1.5; %in SD
            initial_LP_filter_cutoff_Hz = 1;
            initial_HP_filter_cutoff_Hz = 200;
            freqband_lower_lim = 0.5;  %in Hz, was 7 (06/26/18)
            freqband_upper_lim = 30;  %in Hz, was 12 (06/26/18)
            min_seiz_length = 1;%0.3;  %in sec
            min_seiz_Hz = 0.5; % was 5 (06/25/18)
            min_num_seiz = 0;
            min_seiz_ISI = 0; %in sec
            %
            %fs=fss

            [seize_LF,EEG_analysis_LF] = autoseizureread_Atul(Folder,wave, time, windowtime, steptime, fss,ampthr,initial_LP_filter_cutoff_Hz,...
                initial_HP_filter_cutoff_Hz,min_seiz_length,min_seiz_Hz,min_num_seiz,freqband_lower_lim,freqband_upper_lim,min_seiz_ISI,freqthr);

            All_EEGs(iii).seize_LF = seize_LF;
            All_EEGs(iii).EEG_analysis_LF = EEG_analysis_LF;
            All_EEGs(iii).FFT_frqs = EEG_analysis_LF.FFT_frqs;
            fouriersp = All_EEGs(iii).EEG_analysis_LF.magvalue_1sided_rel;

            %fouriersp = fouriersp(1:size(fouriersp,1)/2,:);
            %sp_hz = 1/steptime;
            inn.msperline = steptime*1000;
            freq = 100
            fouriersp = fouriersp';
            skip_inpaint_nans = 1;
            [fouriersp_interp,rew] = cat_and_deltaf_interp(fouriersp,0,inn,freq,skip_inpaint_nans);
            if skip_inpaint_nans
            else
                fouriersp_interp(fouriersp_interp==0)=NaN;
                fouriersp_interp = inpaint_nans(fouriersp_interp);
            end
            All_EEGs(iii).fouriersp_interp = fouriersp_interp;

            clear fouriersp_interp

            %fouriersp = flipud(fouriersp);
            %imagesc(fouriersp_interp')

            close all
            fss = 1000; %initial.sampl_fr; %in Hz
            time = 1/fss:1/fss:length(wave)/fss;
            steptime = 0.02; %in sec

            windowtime = 0.5; %in sec
            ampthr = 1.6; %in SD
            freqthr = 1.5; %in SD
            initial_LP_filter_cutoff_Hz = 20;
            initial_HP_filter_cutoff_Hz = 500;
            freqband_lower_lim = 40;  %in Hz
            freqband_upper_lim = 400;  %in Hz
            min_seiz_length = 0;  %in sec
            min_seiz_Hz = 3;
            min_num_seiz = 1;
            min_seiz_ISI = 0; %in sec
            %
            [seize_HF,EEG_analysis_HF] = autoseizureread_Atul(Folder,wave, time, windowtime, steptime, fss,ampthr,initial_LP_filter_cutoff_Hz,...
                initial_HP_filter_cutoff_Hz,min_seiz_length,min_seiz_Hz,min_num_seiz,freqband_lower_lim,freqband_upper_lim,min_seiz_ISI,freqthr);

            All_EEGs(iii).seize_HF = seize_HF;
            All_EEGs(iii).EEG_analysis_HF = EEG_analysis_HF;

            % %
            %        high_freq_band = mean(EEG_analysis.magvalue(EEG_analysis.theta,:),1);
            %
            %         HF_band = interp(high_freq_band,double(fss)/double(1/steptime));
            %
            %         x = -1/2:1/(fss/2-1):1/2;
            %
            %         fil = exp( -(x.^2)/(2*0.2^2) );
            %
            %         HF_band_c = conv(HF_band,fil);
            %
            %         %mw = mean(HF_band_c);
            %         mw = median(HF_band_c);
            %         sw = std(HF_band_c,0);
            %
            %         HF_thr = mw+sw*0.7;
            %
            %         clear to_remove
            %         a=1;
            %         for j = 1:length(HF_band_c)
            %             if HF_band_c(1,j)>HF_thr
            %                 to_remove(1,a) = j;
            %                 a=a+1;
            %             end
            %
            %
            %         end

            clear pot_seizs
            abb=1;
            for k = 1:size(seize_LF,2)
                currr = seize_LF(k).stind*fss:1:seize_LF(k).enind*fss;
                fc=length(currr);
                pot_seizs(1,abb:abb+fc-1) = currr;
                abb=abb+fc;
            end


            All_EEGs(iii).pot_seizs = pot_seizs;

            clear all_HF_stuff to_remove
            abb=1;
            all_HF_stuff=0
            for k = 1:size(seize_HF,2)
                if isfield(seize_HF(k),'enind')
                    currr = seize_HF(k).stind*fss:1:seize_HF(k).enind*fss;
                    fc=length(currr);
                    all_HF_stuff(1,abb:abb+fc-1) = currr;
                    abb=abb+fc;
                end
            end

            to_remove = setdiff(all_HF_stuff,pot_seizs);

            wave_bak = wave;
            if to_remove==0
            else
                wave(round(to_remove),:) = [];
            end

            All_EEGs(iii).removed_samples = to_remove;

            [spectra,freqs,speccomp,contrib,specstd] = ...
                spectopo(wave', 0, fss, 'freq',freq, 'chanlocs', 1,'limits', [0 60 NaN NaN -10 10], 'freqfac',8,'plot','off');

            close all

            All_EEGs(iii).spectra = spectra;
            All_EEGs(iii).freqs = freqs;
            All_EEGs(iii).speccomp = speccomp;
            All_EEGs(iii).contrib = contrib;
            All_EEGs(iii).specstd = specstd;
            %All_EEGs(i).HF_band_c = HF_band_c;

            figure(iii)
            scatter(All_EEGs(iii).freqs,All_EEGs(iii).spectra)


            if wave_2 == 0
            else
                wave=wave_2;
                mw = mean(wave);
                sw = std(wave,0);

                x=0;
                while sw<1.1
                    wave = wave*10;
                    sw = std(wave,0);
                    x=x+1;
                end

                All_EEGs(iii).mw_2 = mean(wave);
                All_EEGs(iii).sw_2 = std(wave,0);
                All_EEGs(iii).eeg_factor_2 = 10^x;
                %All_EEGs(i).EEG_extrap_1000 = wave;

                close all
                fss = 1000; %initial.sampl_fr; %in Hz
                time = 1/fss:1/fss:length(wave)/fss;
                steptime = 0.02; %in sec
                windowtime = 0.5; %in sec
                ampthr = 1.3; %in SD
                freqthr = 1.5; %in SD
                initial_LP_filter_cutoff_Hz = 1;
                initial_HP_filter_cutoff_Hz = 200;
                freqband_lower_lim = 0.5;  %in Hz, was 7 (06/26/18)
                freqband_upper_lim = 30;  %in Hz, was 12 (06/26/18)
                min_seiz_length = 1;%0.3;  %in sec
                min_seiz_Hz = 0.5; % was 5 (06/25/18)
                min_num_seiz = 0;
                min_seiz_ISI = 0; %in sec
                %
                %fs=fss
                %         ilpc=initial_LP_filter_cutoff_Hz
                %         ihpc=initial_HP_filter_cutoff_Hz
                %         fbll=freqband_lower_lim
                %         fbul=freqband_upper_lim
                %         frsx=freqthr
                %
                [seize_LF,EEG_analysis_LF] = autoseizureread_Atul(Folder,wave, time, windowtime, steptime, fss,ampthr,initial_LP_filter_cutoff_Hz,...
                    initial_HP_filter_cutoff_Hz,min_seiz_length,min_seiz_Hz,min_num_seiz,freqband_lower_lim,freqband_upper_lim,min_seiz_ISI,freqthr);

                All_EEGs(iii).seize_LF_2 = seize_LF;
                All_EEGs(iii).EEG_analysis_LF_2 = EEG_analysis_LF;


                fouriersp = All_EEGs(iii).EEG_analysis_LF_2.magvalue_1sided_rel;

                %fouriersp = fouriersp(1:size(fouriersp,1)/2,:);
                %sp_hz = 1/steptime;
                inn.msperline = steptime*1000;
                freq = 100
                fouriersp = fouriersp';
                skip_inpaint_nans = 1;
                [fouriersp_interp,rew] = cat_and_deltaf_interp(fouriersp,0,inn,freq,skip_inpaint_nans);
                if skip_inpaint_nans
                else
                    fouriersp_interp(fouriersp_interp==0)=NaN;
                    fouriersp_interp = inpaint_nans(fouriersp_interp);
                end
                All_EEGs(iii).fouriersp_interp_2 = fouriersp_interp;

                clear fouriersp_interp

                close all
                fss = 1000; %initial.sampl_fr; %in Hz
                time = 1/fss:1/fss:length(wave)/fss;
                steptime = 0.02; %in sec
                windowtime = 0.5; %in sec
                ampthr = 1.6; %in SD
                freqthr = 1.5; %in SD
                initial_LP_filter_cutoff_Hz = 20;
                initial_HP_filter_cutoff_Hz = 500;
                freqband_lower_lim = 40;  %in Hz
                freqband_upper_lim = 400;  %in Hz
                min_seiz_length = 0;  %in sec
                min_seiz_Hz = 3;
                min_num_seiz = 1;
                min_seiz_ISI = 0; %in sec
                %
                [seize_HF,EEG_analysis_HF] = autoseizureread_Atul(Folder,wave, time, windowtime, steptime, fss,ampthr,initial_LP_filter_cutoff_Hz,...
                    initial_HP_filter_cutoff_Hz,min_seiz_length,min_seiz_Hz,min_num_seiz,freqband_lower_lim,freqband_upper_lim,min_seiz_ISI,freqthr);

                All_EEGs(iii).seize_HF_2 = seize_HF;
                All_EEGs(iii).EEG_analysis_HF_2 = EEG_analysis_HF;

                % %
                %        high_freq_band = mean(EEG_analysis.magvalue(EEG_analysis.theta,:),1);
                %
                %         HF_band = interp(high_freq_band,double(fss)/double(1/steptime));
                %
                %         x = -1/2:1/(fss/2-1):1/2;
                %
                %         fil = exp( -(x.^2)/(2*0.2^2) );
                %
                %         HF_band_c = conv(HF_band,fil);
                %
                %         %mw = mean(HF_band_c);
                %         mw = median(HF_band_c);
                %         sw = std(HF_band_c,0);
                %
                %         HF_thr = mw+sw*0.7;
                %
                %         clear to_remove
                %         a=1;
                %         for j = 1:length(HF_band_c)
                %             if HF_band_c(1,j)>HF_thr
                %                 to_remove(1,a) = j;
                %                 a=a+1;
                %             end
                %
                %
                %         end

                clear pot_seizs
                abb=1;
                for k = 1:size(seize_LF,2)
                    currr = seize_LF(k).stind*fss:1:seize_LF(k).enind*fss;
                    fc=length(currr);
                    pot_seizs(1,abb:abb+fc-1) = currr;
                    abb=abb+fc;
                end


                All_EEGs(iii).pot_seizs_2 = pot_seizs;

                clear all_HF_stuff to_remove
                abb=1;
                all_HF_stuff=0
                for k = 1:size(seize_HF,2)
                    if isfield(seize_HF(k),'enind')
                        currr = seize_HF(k).stind*fss:1:seize_HF(k).enind*fss;
                        fc=length(currr);
                        all_HF_stuff(1,abb:abb+fc-1) = currr;
                        abb=abb+fc;
                    end
                end

                to_remove = setdiff(all_HF_stuff,pot_seizs);

                wave_bak = wave;
                if to_remove==0
                else
                    wave(round(to_remove),:) = [];
                end

                All_EEGs(iii).removed_samples_2 = to_remove;

                [spectra,freqs,speccomp,contrib,specstd] = ...
                    spectopo(wave', 0, fss, 'freq',freq, 'chanlocs', 1,'limits', [0 60 NaN NaN -10 10], 'freqfac',8,'plot','off');

                close all

                All_EEGs(iii).spectra_2 = spectra;
                All_EEGs(iii).freqs_2 = freqs;
                All_EEGs(iii).speccomp_2 = speccomp;
                All_EEGs(iii).contrib_2 = contrib;
                All_EEGs(iii).specstd_2 = specstd;
                %All_EEGs(i).HF_band_c = HF_band_c;


            end


            if wave_3 == 0
            else
                wave=wave_3;
                mw = mean(wave);
                sw = std(wave,0);

                x=0;
                while sw<1.1
                    wave = wave*10;
                    sw = std(wave,0);
                    x=x+1;
                end

                All_EEGs(iii).mw_3 = mean(wave);
                All_EEGs(iii).sw_3 = std(wave,0);
                All_EEGs(iii).eeg_factor_3 = 10^x;
                %All_EEGs(i).EEG_extrap_1000 = wave;

                close all
                fss = 1000; %initial.sampl_fr; %in Hz
                time = 1/fss:1/fss:length(wave)/fss;
                steptime = 0.02; %in sec
                windowtime = 0.5; %in sec
                ampthr = 1.3; %in SD
                freqthr = 1.5; %in SD
                initial_LP_filter_cutoff_Hz = 1;
                initial_HP_filter_cutoff_Hz = 200;
                freqband_lower_lim = 0.5;  %in Hz, was 7 (06/26/18)
                freqband_upper_lim = 30;  %in Hz, was 12 (06/26/18)
                min_seiz_length = 1;%0.3;  %in sec
                min_seiz_Hz = 0.5; % was 5 (06/25/18)
                min_num_seiz = 0;
                min_seiz_ISI = 0; %in sec
                %
                %fs=fss
                %         ilpc=initial_LP_filter_cutoff_Hz
                %         ihpc=initial_HP_filter_cutoff_Hz
                %         fbll=freqband_lower_lim
                %         fbul=freqband_upper_lim
                %         frsx=freqthr
                %
                [seize_LF,EEG_analysis_LF] = autoseizureread_Atul(Folder,wave, time, windowtime, steptime, fss,ampthr,initial_LP_filter_cutoff_Hz,...
                    initial_HP_filter_cutoff_Hz,min_seiz_length,min_seiz_Hz,min_num_seiz,freqband_lower_lim,freqband_upper_lim,min_seiz_ISI,freqthr);

                All_EEGs(iii).seize_LF_3 = seize_LF;
                All_EEGs(iii).EEG_analysis_LF_3 = EEG_analysis_LF;


                fouriersp = All_EEGs(iii).EEG_analysis_LF_3.magvalue_1sided_rel;

                %fouriersp = fouriersp(1:size(fouriersp,1)/2,:);
                %sp_hz = 1/steptime;
                inn.msperline = steptime*1000;
                freq = 100
                fouriersp = fouriersp';
                skip_inpaint_nans = 1;
                [fouriersp_interp,rew] = cat_and_deltaf_interp(fouriersp,0,inn,freq,skip_inpaint_nans);
                if skip_inpaint_nans
                else
                    fouriersp_interp(fouriersp_interp==0)=NaN;
                    fouriersp_interp = inpaint_nans(fouriersp_interp);
                end
                All_EEGs(iii).fouriersp_interp_3 = fouriersp_interp;

                clear fouriersp_interp

                close all
                fss = 1000; %initial.sampl_fr; %in Hz
                time = 1/fss:1/fss:length(wave)/fss;
                steptime = 0.02; %in sec
                windowtime = 0.5; %in sec
                ampthr = 1.6; %in SD
                freqthr = 1.5; %in SD
                initial_LP_filter_cutoff_Hz = 20;
                initial_HP_filter_cutoff_Hz = 500;
                freqband_lower_lim = 40;  %in Hz
                freqband_upper_lim = 400;  %in Hz
                min_seiz_length = 0;  %in sec
                min_seiz_Hz = 3;
                min_num_seiz = 1;
                min_seiz_ISI = 0; %in sec
                %
                [seize_HF,EEG_analysis_HF] = autoseizureread_Atul(Folder,wave, time, windowtime, steptime, fss,ampthr,initial_LP_filter_cutoff_Hz,...
                    initial_HP_filter_cutoff_Hz,min_seiz_length,min_seiz_Hz,min_num_seiz,freqband_lower_lim,freqband_upper_lim,min_seiz_ISI,freqthr);

                All_EEGs(iii).seize_HF_3 = seize_HF;
                All_EEGs(iii).EEG_analysis_HF_3 = EEG_analysis_HF;

                % %
                %        high_freq_band = mean(EEG_analysis.magvalue(EEG_analysis.theta,:),1);
                %
                %         HF_band = interp(high_freq_band,double(fss)/double(1/steptime));
                %
                %         x = -1/2:1/(fss/2-1):1/2;
                %
                %         fil = exp( -(x.^2)/(2*0.2^2) );
                %
                %         HF_band_c = conv(HF_band,fil);
                %
                %         %mw = mean(HF_band_c);
                %         mw = median(HF_band_c);
                %         sw = std(HF_band_c,0);
                %
                %         HF_thr = mw+sw*0.7;
                %
                %         clear to_remove
                %         a=1;
                %         for j = 1:length(HF_band_c)
                %             if HF_band_c(1,j)>HF_thr
                %                 to_remove(1,a) = j;
                %                 a=a+1;
                %             end
                %
                %
                %         end

                clear pot_seizs
                abb=1;
                for k = 1:size(seize_LF,2)
                    currr = seize_LF(k).stind*fss:1:seize_LF(k).enind*fss;
                    fc=length(currr);
                    pot_seizs(1,abb:abb+fc-1) = currr;
                    abb=abb+fc;
                end


                All_EEGs(iii).pot_seizs_3 = pot_seizs;

                clear all_HF_stuff to_remove
                abb=1;
                all_HF_stuff=0
                for k = 1:size(seize_HF,2)
                    if isfield(seize_HF(k),'enind')
                        currr = seize_HF(k).stind*fss:1:seize_HF(k).enind*fss;
                        fc=length(currr);
                        all_HF_stuff(1,abb:abb+fc-1) = currr;
                        abb=abb+fc;
                    end
                end

                to_remove = setdiff(all_HF_stuff,pot_seizs);

                wave_bak = wave;
                if to_remove==0
                else
                    wave(round(to_remove),:) = [];
                end

                All_EEGs(iii).removed_samples_3 = to_remove;

                [spectra,freqs,speccomp,contrib,specstd] = ...
                    spectopo(wave', 0, fss, 'freq',freq, 'chanlocs', 1,'limits', [0 60 NaN NaN -10 10], 'freqfac',8,'plot','off');

                close all

                All_EEGs(iii).spectra_3 = spectra;
                All_EEGs(iii).freqs_3 = freqs;
                All_EEGs(iii).speccomp_3 = speccomp;
                All_EEGs(iii).contrib_3 = contrib;
                All_EEGs(iii).specstd_3 = specstd;
                %All_EEGs(i).HF_band_c = HF_band_c;


            end


        end
    end
    %  end
end




%for iii = 1:size(recording,2)
if All_EEGs(iii).too_short
else

    rec = iii

    if isempty(recording(iii).EEG_results_nonoise) || recording(1).initial.datedr(1,iii)==0
        morlet_extrap_1 = 0;
        morlet_extrap_2 = 0;
    else
        eeg1 = All_EEGs(rec).EEG_extrap_1000';
        eeg2 = All_EEGs(rec).EEG_2_extrap_1000';
        low_freq = 0;
        high_freq = 500;
        fs = 1000;

        morlet_wavelet_1 = make_morlet_wavelet_one_channel(low_freq,high_freq,fs,eeg1);
        morlet_wavelet_1 = morlet_wavelet_1';
        freq = 100;
        morlet_extrap_1  = zeros(round(length(morlet_wavelet_1)/(fs/freq)),size(morlet_wavelet_1,2));
        for j = 1:size(morlet_extrap_1,2)
            morlet_extrapping = j
            for i = 1: size(morlet_extrap_1,1)
                morlet_extrap_1(i,j) = morlet_wavelet_1(round((i-1)*fs/freq)+1,j);

            end
        end
        clear morlet_wavelet_1
        All_EEGs(iii).morlet_extrap_1 = morlet_extrap_1;

        morlet_wavelet_2 = make_morlet_wavelet_one_channel(low_freq,high_freq,fs,eeg2);

        morlet_wavelet_2 = morlet_wavelet_2';

        morlet_extrap_2  = zeros(round(length(morlet_wavelet_2)/(fs/freq)),size(morlet_wavelet_2,2));

        for j = 1:size(morlet_extrap_2,2)
            morlet_extrapping = j
            for i = 1: size(morlet_extrap_2,1)

                morlet_extrap_2(i,j) = morlet_wavelet_2(round((i-1)*fs/freq)+1,j);
            end
        end
        clear morlet_wavelet_2
        All_EEGs(iii).morlet_extrap_2 = morlet_extrap_2;

    end

end
%end


%for iii = 1:size(recording,2)

%which channel is better?

eeg1 = All_EEGs(iii).EEG_extrap_1000;

eeg2 = All_EEGs(iii).EEG_2_extrap_1000;

figure(789)
subplot(2,1,1)
plot(eeg1(1,1:20000))
subplot(2,1,2)
plot(eeg2(1,1:20000))

options.WindowStyle = 'normal';
prompt = {'EEG1 or EEG2 better?'};
dlg_title = 'better EEG?';
num_lines = 1;
def = {'1'};
answer = inputdlg(prompt,dlg_title,num_lines,def,options);
rd = str2mat(answer);
lambda = str2num(rd);

if lambda==1
    mor = All_EEGs(iii).morlet_extrap_1;
else
    mor = All_EEGs(iii).morlet_extrap_2;
end

mor_LF_avg = mean(mor(:,[6:9 13:16]),2);

figure(463)
plot(mor_LF_avg(1:14000,1))


options.WindowStyle = 'normal';
prompt = {'threshold?'};
dlg_title = '?seizure threshold';
num_lines = 1;
def = {'0.01'};
answer = inputdlg(prompt,dlg_title,num_lines,def,options);
rd = str2mat(answer);
lambda = str2num(rd);
thr = lambda
%threshold mor_LF_avg

mor_LF_avg_thr = mor_LF_avg - thr;
mor_LF_avg_thr(mor_LF_avg_thr<0) = 0;
szs_binary = zeros(size(mor_LF_avg_thr));
szs_binary = mor_LF_avg_thr;
szs_binary(szs_binary>0) = 1;

[s_inds szs] = find(szs_binary>0);


All_EEGs(iii).mor_LF_avg = mor_LF_avg;
All_EEGs(iii).mor_LF_avg_thr = mor_LF_avg_thr;
All_EEGs(iii).szs_binary = szs_binary;
All_EEGs(iii).s_inds = s_inds;
tot_dur_sec = size(mor_LF_avg_thr,1)/100;
All_EEGs(iii).tot_dur_in_szs_s = sum(szs_binary)/100;

a = 1;
b = 1;
half_sec=3
if All_EEGs(iii).tot_dur_in_szs_s>0 % && sum(microseiz_summary(i).ca_stats_deconv.microszs_binary(1:10)==0)

    micro_dt = diff(szs_binary);


    [ep,op] = find(micro_dt == 1);
    [pip,pup] = find(micro_dt == -1);
    jut=1;
    if length(pip)>length(ep)
        flort= length(ep)
        firstep=1
    else
        firstep=0
        flort = length(pip);
    end
    for ju = 1:flort
        if ep(ju,1)>half_sec*100
            if ep(ju,1) > add_params.first_frame(1,iii) && (ep(ju,1) < add_params.last_frame(1,iii) || add_params.last_frame(1,iii) == 0)
                if ju==1 && firstep==1
                    All_EEGs(iii).seiz(jut).start = 1;
                else
                    All_EEGs(iii).seiz(jut).start = ep(ju,1);
                end
                All_EEGs(iii).seiz(jut).end = pip(ju,1);
                All_EEGs(iii).seiz(jut).length_s = (pip(ju,1) - ep(ju,1))/100;
                [All_EEGs(iii).seiz(jut).max_amp, mpl] = max(mor_LF_avg_thr(ep(ju,1):pip(ju,1)));
                All_EEGs(iii).seiz(jut).max_loc = ep(ju,1) + mpl;
                % start_to_max = mpl;
                % tensec_around_max = [microseiz_summary(i).ca_stats_deconv.microseiz(jut).max_loc - ...
                %     half_sec*100 : microseiz_summary(i).ca_stats_deconv.microseiz(jut).max_loc +  half_sec*100];
                %

                % ernoiv_no_ms = ernoiv;
                %
                % ernoiv_no_ms(ms_inds,:) = [];
                %
                % mean_ernoiv_no_ms = median(ernoiv_no_ms,1);% %changed from mean to median 05-02-2021 JM
                % std_ernoiv_no_ms = std(ernoiv_no_ms,0);
                %
                % d_all = diff(ernoiv_no_ms);
                %
                %
                %
                % mean_d_all = median(d_all,1); %changed from mean to median 05-02-2021 JM
                % std_d_all = std(d_all,0);

                %     if tensec_around_max(1,end)<length(ernoiv)
                %
                % oopsi_tensec = ernoiv(tensec_around_max,:);
                %
                % %set everything 0.5 sec before ms start and
                % %1 sec after ms end to zero
                %
                % oopsi_tensec(1:half_sec*100-start_to_max-50,:) = 0;
                % oopsi_tensec(half_sec*100+pip(ju,1)-ep(ju,1)+mpl+100:size(oopsi_tensec,1),:) = 0;
                %
                % d_o = diff(oopsi_tensec);
                % o_t_a = oopsi_tensec - mean_ernoiv_no_ms - 5*std_ernoiv_no_ms %changed from 7*std 04-24-2021 %changed from 6 SD 05-02-2021
                %
                % o_t_a(o_t_a<0) = 0;
                % d_o_a = d_o - mean_d_all - 5*std_d_all;
                % d_o_a(d_o_a<0) = 0;
                % d_o_ab = d_o_a;
                % d_o_ab(d_o_ab>0) = 1;
                %
                % microseiz_summary(i).ca_stats_deconv.microseiz(jut).ROI_oopsi_above_indiv_thr = o_t_a;
                % microseiz_summary(i).ca_stats_deconv.microseiz(jut).mean_oopsi_interictal = mean_ernoiv_no_ms;
                %
                % microseiz_summary(i).ca_stats_deconv.microseiz(jut).ROI_active_sec = sum(d_o_ab)/100;
                % microseiz_summary(i).ca_stats_deconv.microseiz(jut).oopsi_around_max_loc = oopsi_tensec;
                % microseiz_summary(i).ca_stats_deconv.microseiz(jut).oopsi_diff = d_o;
                % microseiz_summary(i).ca_stats_deconv.microseiz(jut).oopsi_binary = d_o_ab;
                %
                % microseiz_summary(i).ca_stats_deconv.microseiz(jut).ROI_mean_ms_oopsi = mean(ernoiv(ep(ju,1):pip(ju,1),:),1);
                %
                % %recording(i).ca_stats_deconv.microseiz(jut-1).max_amp = [];
                % %recording(i).ca_stats_deconv.microseiz(jut-1).max_loc = [];
                % %recording(i).ca_stats_deconv.microseiz(jut-1).ROI_active_sec = [];
                % %recording(i).ca_stats_deconv.microseiz(jut-1).oopsi_around_max_loc = [];
                % %recording(i).ca_stats_deconv.microseiz(jut-1).oopsi_diff = [];
                % %recording(i).ca_stats_deconv.microseiz(jut-1).oopsi_binary = [];
                % microseiz_summary(i).ca_stats_deconv.microseiz(jut).ROI_recruit_fr = [];
                % microseiz_summary(i).ca_stats_deconv.microseiz(jut).ROI_recruit_min_max_fr = [];
                % microseiz_summary(i).ca_stats_deconv.microseiz(jut).sorted_lag = [];
                %
                %
                % d_o_abdiff = diff(d_o_ab);
                % %imagesc(d_o_abdiff')
                %
                % piaa = 1;
                % clear particip_inds
                % particip_inds = 0
                % for ja = 1:size(oopsi_tensec,2)
                %
                %
                %     [pe,pep] = find(squeeze(d_o_abdiff(:,ja)) == 1);
                %     if isempty(pe)
                %         microseiz_summary(i).ca_stats_deconv.microseiz(jut).ROI_recruit_fr(1,ja) = NaN;
                %         microseiz_summary(i).ca_stats_deconv.microseiz(jut).ROI_recruit_min_max_fr(1,ja) = NaN;
                %         microseiz_summary(i).ca_stats_deconv.microseiz(jut).ROI_recruit_min_start_fr(1,ja) = NaN;
                %
                %         microseiz_summary(i).ca_stats_deconv.microseiz(jut).ROI_recruit_mean_ms_oopsi(1,ja) = 0;
                %         microseiz_summary(i).ca_stats_deconv.microseiz(jut).ROI_recruit_mean_oopsi_interictal(1,ja) = 0;
                %     else
                %         microseiz_summary(i).ca_stats_deconv.microseiz(jut).ROI_recruit_fr(1,ja) = pe(1,1)...
                %             +microseiz_summary(i).ca_stats_deconv.microseiz(jut).max_loc -  half_sec*100;
                %         microseiz_summary(i).ca_stats_deconv.microseiz(jut).ROI_recruit_min_max_fr(1,ja) =  ...
                %             pe(1,1) - half_sec*100 ;
                %         microseiz_summary(i).ca_stats_deconv.microseiz(jut).ROI_recruit_min_start_fr(1,ja) = ...
                %             pe(1,1) - half_sec*100 - start_to_max;
                %
                %         %participator mean DF during
                %         %seizure
                %         microseiz_summary(i).ca_stats_deconv.microseiz(jut).ROI_recruit_mean_ms_oopsi(1,ja) = ...
                %             microseiz_summary(i).ca_stats_deconv.microseiz(jut).ROI_mean_ms_oopsi(1,ja);
                %
                %         %participator mean DF during
                %         %interictal
                %         microseiz_summary(i).ca_stats_deconv.microseiz(jut).ROI_recruit_mean_oopsi_interictal(1,ja) = ...
                %             microseiz_summary(i).ca_stats_deconv.microseiz(jut).mean_oopsi_interictal(1,ja);
                %         particip_inds(1,piaa) = ja;
                %         piaa=piaa+1;
                %     end
                % end
                %
                % if sum(particip_inds)==0
                %     microseiz_summary(i).ca_stats_deconv.microseiz(jut).participators_unclear = 1;
                % else
                %
                %     microseiz_summary(i).ca_stats_deconv.microseiz(jut).participator_mean_ms_oopsi_avg = ...
                %         mean(microseiz_summary(i).ca_stats_deconv.microseiz(jut).ROI_recruit_mean_ms_oopsi(particip_inds),1);
                %
                %     microseiz_summary(i).ca_stats_deconv.microseiz(jut).participator_mean_interict_oopsi_avg = ...
                %         mean(microseiz_summary(i).ca_stats_deconv.microseiz(jut).ROI_recruit_mean_oopsi_interictal(particip_inds),1);
                %
                %     [re,ru] = sort(microseiz_summary(i).ca_stats_deconv.microseiz(jut).ROI_recruit_min_max_fr,'ascend');
                %
                %     microseiz_summary(i).ca_stats_deconv.microseiz(jut).sorted_lag = ru;
                %
                %
                % end
                %
                jut=jut+1;

                %if two consecutive microseizures are too close to each
                %other in time, just go ahead and merge the hack
                %oudofdem...
                % if jut>2 && (All_EEGs(iii).seiz(jut-1).max_loc - ...
                %         All_EEGs(iii).seiz(jut-2).max_loc) < 200
                %     All_EEGs(iii).seiz(jut-2).end = ...
                %         All_EEGs(iii).seiz(jut-1).end;
                %     All_EEGs(iii).seiz(jut-1).end = [];
                %     All_EEGs(iii).seiz(jut-1).start = [];
                %
                %     All_EEGs(iii).seiz(jut-2).length_s = ...
                %         All_EEGs(iii).seiz(jut-2).length_s + ...
                %         All_EEGs(iii).seiz(jut-1).length_s;


                if jut>2 && (All_EEGs(iii).seiz(jut-1).start - ...
                        All_EEGs(iii).seiz(jut-2).end) < 65     %edited 20230816 JM



                    All_EEGs(iii).seiz(jut-2).end = ...
                        All_EEGs(iii).seiz(jut-1).end;
                    All_EEGs(iii).seiz(jut-1).end = [];
                    All_EEGs(iii).seiz(jut-1).start = [];

                    All_EEGs(iii).seiz(jut-2).length_s = (All_EEGs(iii).seiz(jut-2).end - ...
                        All_EEGs(iii).seiz(jut-2).start)/100;



                    All_EEGs(iii).seiz(jut-1).length_s = [];
                    %
                    % if microseiz_summary(i).ca_stats_deconv.microseiz(jut-2).max_amp > ...
                    %         microseiz_summary(i).ca_stats_deconv.microseiz(jut-1).max_amp
                    %
                    %     microseiz_summary(i).ca_stats_deconv.microseiz(jut-1).max_amp = [];
                    %     microseiz_summary(i).ca_stats_deconv.microseiz(jut-1).max_loc = [];
                    %     microseiz_summary(i).ca_stats_deconv.microseiz(jut-1).ROI_active_sec = [];
                    %     microseiz_summary(i).ca_stats_deconv.microseiz(jut-1).oopsi_around_max_loc = [];
                    %     microseiz_summary(i).ca_stats_deconv.microseiz(jut-1).oopsi_diff = [];
                    %     microseiz_summary(i).ca_stats_deconv.microseiz(jut-1).oopsi_binary = [];
                    %     microseiz_summary(i).ca_stats_deconv.microseiz(jut-1).ROI_recruit_fr = [];
                    %     microseiz_summary(i).ca_stats_deconv.microseiz(jut-1).ROI_recruit_min_max_fr = [];
                    %     microseiz_summary(i).ca_stats_deconv.microseiz(jut-1).sorted_lag = [];
                    % else
                    %     microseiz_summary(i).ca_stats_deconv.microseiz(jut-2).max_amp = ...
                    %         microseiz_summary(i).ca_stats_deconv.microseiz(jut-1).max_amp;
                    %     microseiz_summary(i).ca_stats_deconv.microseiz(jut-1).max_amp = [];
                    %
                    %     microseiz_summary(i).ca_stats_deconv.microseiz(jut-2).max_loc = ...
                    %         microseiz_summary(i).ca_stats_deconv.microseiz(jut-1).max_loc;
                    %     microseiz_summary(i).ca_stats_deconv.microseiz(jut-1).max_loc = [];
                    %
                    %     microseiz_summary(i).ca_stats_deconv.microseiz(jut-2).ROI_active_sec = ...
                    %         microseiz_summary(i).ca_stats_deconv.microseiz(jut-1).ROI_active_sec;
                    %     microseiz_summary(i).ca_stats_deconv.microseiz(jut-1).ROI_active_sec = [];
                    %
                    %     microseiz_summary(i).ca_stats_deconv.microseiz(jut-2).oopsi_around_max_loc = ...
                    %         microseiz_summary(i).ca_stats_deconv.microseiz(jut-1).oopsi_around_max_loc;
                    %     microseiz_summary(i).ca_stats_deconv.microseiz(jut-1).oopsi_around_max_loc = [];
                    %
                    %     microseiz_summary(i).ca_stats_deconv.microseiz(jut-2).oopsi_diff = ...
                    %         microseiz_summary(i).ca_stats_deconv.microseiz(jut-1).oopsi_diff;
                    %     microseiz_summary(i).ca_stats_deconv.microseiz(jut-1).oopsi_diff = [];
                    %
                    %     microseiz_summary(i).ca_stats_deconv.microseiz(jut-2).oopsi_binary = ...
                    %         microseiz_summary(i).ca_stats_deconv.microseiz(jut-1).oopsi_binary;
                    %     microseiz_summary(i).ca_stats_deconv.microseiz(jut-1).oopsi_binary = [];
                    %
                    %     microseiz_summary(i).ca_stats_deconv.microseiz(jut-2).ROI_recruit_fr = ...
                    %         microseiz_summary(i).ca_stats_deconv.microseiz(jut-1).ROI_recruit_fr;
                    %     microseiz_summary(i).ca_stats_deconv.microseiz(jut-1).ROI_recruit_fr = [];
                    %
                    %     microseiz_summary(i).ca_stats_deconv.microseiz(jut-2).ROI_recruit_min_max_fr = ...
                    %         microseiz_summary(i).ca_stats_deconv.microseiz(jut-1).ROI_recruit_min_max_fr;
                    %     microseiz_summary(i).ca_stats_deconv.microseiz(jut-1).ROI_recruit_min_max_fr = [];
                    %
                    %     microseiz_summary(i).ca_stats_deconv.microseiz(jut-2).sorted_lag = ...
                    %         microseiz_summary(i).ca_stats_deconv.microseiz(jut-1).sorted_lag;
                    %     microseiz_summary(i).ca_stats_deconv.microseiz(jut-1).sorted_lag = [];
                    % end

                    jut=jut-1;
                end

                %   end
            end
        end
    end
    All_EEGs(iii).seiz(1).num_ms = jut-1;
    All_EEGs(iii).seiz(1).ms_per_hr = ((jut-1) / tot_dur_sec)*3600;
    % All_EEGs(iii).seiz(1).perc_time_in_microsz = microseiz_summary(i).ca_stats_deconv.perc_time_in_microsz;
    All_EEGs(iii).seiz(1).seiz = All_EEGs(iii).seiz;
    All_EEGs(iii).seiz(1).tot_dur_s = tot_dur_sec;
    tmprej = 0;
    for j = 1:size(All_EEGs(iii).seiz,2)
        if ~isempty(All_EEGs(iii).seiz(j).start)
            tmprej(j,1) = All_EEGs(iii).seiz(j).start;
            tmprej(j,2) = All_EEGs(iii).seiz(j).end;
        end

    end
    save TMPREJ.mat tmprej
end

%convert into tmprej



%end









