%Input EEG reading, time vector, window time for Fourier Transform,
%step time of Fourier Transform, and sampling frequency respectively

%extract median data of time frames revolving around seizures
%function [seize, preic1r, preic2r, ica, postica, preic1a, preic2a, icr, posticr] = autoseizureread(wave, time, windowtime, steptime, fs)

%only extract seizure times in a structure data type
function [seize,EEG_stats] = autoseizureread_Atul(Folder,wave, time, windowtime, steptime, fs,ampthr,...
    ihpc,ilpc,min_seiz_length,min_seiz_Hz,min_num_seiz,fbll,fbul,min_seiz_ISI,frsx,as)
%

[b,a]=butter(6,ilpc/fs,'low');        %Filters waves above 35*ilpc Hz
waver = filtfilt(b, a, wave);
wave_bak = wave;
wave_1 = waver;


[b,a]=butter(4,2*ihpc/fs,'high');        %Filters waves below ihpc Hz
waver = filtfilt(b, a, wave_1);
%wave_bak = wave;
wave_2 = waver;


wave = wave_2;
%Frequency - Theta frequency (and above) power greater than average (because seizures can skew the
%average significantly, meaning 50% above the average would miss many%hotspots)
startindex = 1;
endindex = 0;
magvalue = [];
frq = [];

%tukey = tukeywin(round(windowtime*fs+1));
endindex = startindex + round(windowtime*fs);
L = endindex-startindex+1;
NFFT = 2^nextpow2(L);

%modified version
tukey = tukeywin(NFFT);
magvalue = zeros(NFFT, ceil((length(wave)-fs*windowtime)/(steptime*fs)));
%%%%%%%%%%%%%%%%%%%%%%%%%%%%
magvalue_1sided_rel = zeros(NFFT/2, ceil((length(wave)-fs*windowtime)/(steptime*fs)));

%tukey = tukeywin(round(windowtime*fs+1));
%magvalue = zeros(round(windowtime*fs+1), ceil((length(wave)-fs*windowtime)/(steptime*fs)));
%%%%%%%%%%%%%%%%%%%


i = 1;
% 
% while (endindex < length(wave))
%     endindex = startindex + round(windowtime*fs);
%     if (endindex < length(wave))
%         cuv = tukey.*wave(startindex:endindex);
%         fourier = fft(cuv);
%         x1 = real(fourier);
%         y1 = imag(fourier);
%         magnitude = sqrt(x1.^2 + y1.^2);
%         magvalue(:,i) = magnitude;
%         i = i + 1;
%     end
%     startindex = startindex + round(steptime*fs);
% end

%modified version
 while (endindex < length(wave))
%
     endindex = startindex + NFFT;
%
     if (endindex < length(wave))
         fourier = fft(tukey.*wave(startindex:endindex-1),NFFT);
         x1 = real(fourier);
         y1 = imag(fourier);
         magnitude = sqrt(x1.^2 + y1.^2);
         mag2 = abs(fourier/length(wave));
         mag1 = mag2(1:round(L/2)+1);
         mag1(2:end-1) = 2*mag1(2:end-1);
         magvalue_1sided_rel(1:size(mag1,1),i) = mag1;
         magvalue(:,i) = magnitude;
         i = i + 1;
     end
         startindex = startindex + round(steptime*fs);
 end
 
 
EEG_stats.magvalue = magvalue;
EEG_stats.magvalue_1sided_rel = magvalue_1sided_rel;
startindex = 1;
endindex = 0;
%
%
f = fs-2*linspace(0,1,NFFT/2+1);
plot(f,2*abs(fourier(1:NFFT/2+1)))
%

display('EEG Powers Calculated');

frq = [0:round(fs/2)/(length(mag1)-1):round(fs/2)];
theta = [];
for(x=1:length(frq))
    if (frq(x) >= fbll && frq(x) <= fbul) %initially: between 4 and 59 Hz
        theta = [theta, x];
    end
end
sum1 = mean(magvalue(theta(1):theta(end),:),1);
EEG_stats.theta = theta;
EEG_stats.sum1 = sum1;
EEG_stats.FFT_frqs = frq;
EEG_stats.filtered_EEG = wave;


%
% if mod(sum1,2)
%     aaas = length(sum1)-1;
% else
%     aaas = length(sum1);
% end
%
% for i = 1: aaas/2
%     sum1_ds(i) = mean(sum1(1,(i-1)*2+1:(i-1)*2+2));
% end

sumavg = mean(sum1);
counter = 1;
clear sum1 magnitude fourier a b startindex endindex x1 y1;
firstsort = zeros(1, round(length(wave)*.75));
firstsort_vec = 0;
for(x=round(fs/100):length(magvalue)) %initially 10*fs
    compare = mean(magvalue(theta(1):theta(end), x));
    compare = smooth(compare,round(fs/5));
    if(compare > frsx*sumavg) %initially 1*sumavg; orig 1.6
        firstsort(counter) = x;
        counter = counter + 1;
        if x*steptime*fs-windowtime*fs/2>0
        firstsort_vec(1,round(x*steptime*fs-windowtime*fs/2):round(x*steptime*fs+windowtime*fs/2)) = 1;
        end
    end
end

subplot(2,1,1)
plot(EEG_stats.filtered_EEG)
axis([10000 30000 min(EEG_stats.filtered_EEG) max(EEG_stats.filtered_EEG)])
subplot(2,1,2)
if firstsort_vec == 0
else
plot(firstsort_vec)
end
axis([10000 30000 0 1.1])


firstsort = firstsort*steptime+windowtime/2;
firstsort = firstsort(1:counter-1);
display('First Sort Complete');

firstsort_dup = round(firstsort*fs);
EEG_stats.firstsort_raw = zeros(1,length(wave));
EEG_stats.firstsort_raw(1,firstsort_dup) = 1;

EEG_stats.firstsort = firstsort;
%Amplitude - Instantaneous amplitude > 2.5x baseline amplitude (baseline defined as the
%median of amplitudes from the EEG)
eegmean = mean(wave);
C = hilbert(wave-eegmean);
x1 = real(C);
y1 = imag(C);
amp = sqrt(x1.^2 + y1.^2);
baseline = median(amp);
secondsort = [];
secondsort_raw = [];
hilbert_thr_vec = 0;
for(i=round(fs/2):length(wave)) %initially 10*fs
    if(abs(wave(i)) > baseline*ampthr)   %initially: *2.5
        secondsort = [secondsort, i*1/fs];
        secondsort_raw = [secondsort_raw, i];
        hilbert_thr_vec(1,i) = 1;
    end
end

EEG_stats.secondssort_raw = zeros(1,length(wave));
EEG_stats.secondsort_raw(1,secondsort_raw) = 1;
EEG_stats.Hilbert_trans = C;
EEG_stats.Hilbert_amp = amp;
EEG_stats.Hilbert_thr_vec = hilbert_thr_vec;

%Morphology - finds all spikes
 %[trashx, mx] = findpeaks(wave);
% [trashy, mn] = findpeaks(-wave);
% 
[trashx, mx] = findpeaks(wave,fs,'MinPeakDistance',0.12);
[trashy, mn] = findpeaks(-wave,fs,'MinPeakDistance',0.12);

for i = 1:length(mx)
mx(i,1) = round(mx(i,1)*fs);
end

for i = 1:length(mn)
mn(i,1) = round(mn(i,1)*fs);
end

EEG_stats.pos_peak_vec = zeros(size(wave));
EEG_stats.pos_peak_vec(mx,1) = 1;
EEG_stats.neg_peak_vec = zeros(size(wave));
EEG_stats.neg_peak_vec(mn,1) = 1;



clear trashx trashy;
locs = [transpose(mx), transpose(mn)];
locs = sort(locs);
locs = locs*1/fs;

EEG_stats.peak_locs = locs;
EEG_stats.pos_peaks = zeros(1,length(wave));
EEG_stats.pos_peaks(1,mx) = 1;
EEG_stats.neg_peaks(1,mn) = 1;
all_peaks = union(mx,mn);
EEG_stats.all_peaks = zeros(1,length(wave));
EEG_stats.all_peaks(1,all_peaks) = 1;


clear mx mn


% round vectors to nearest 0.05 sec:

firstsort_round = firstsort*20;
firstsort_round = round(firstsort_round);
firstsort_round = firstsort_round/20;

secondsort_round = secondsort*20;
secondsort_round = round(secondsort_round);
secondsort_round = secondsort_round/20;

locs_round = locs*20;
locs_round = round(locs_round);
locs_round = locs_round/20;

EEG_stats.locs_round = locs_round;
EEG_stats.secondsort_round = secondsort_round;
EEG_stats.firstsort_round = firstsort_round;

%Overlapping times
freqcond = intersect(firstsort_round, locs_round);
ampcond = intersect(secondsort_round, locs_round);
thorough = intersect(freqcond, ampcond);
EEG_stats.freqcond = freqcond;
EEG_stats.ampcond = ampcond;
EEG_stats.thorough = thorough;

%Length - spikes must occur at least 5 times in a second for greater than
%1 second
i = 1;
j = 1;
seizuretimes = [];
seizurerange = 'Seizure times are approximately: ';
figure(1000)
subplot(1,2,1)
plot(time, wave);
hold on;
seize(1).stind=0;
while(i < length(thorough))
    while (thorough(i+1) - thorough(i) < 1/min_seiz_Hz && i ~= length(thorough)-1 ) %initially 2
        if (i < length(thorough))
            seizuretimes = [seizuretimes, thorough(i)];
            i = i + 1;
        end
    end
    if (isempty(seizuretimes) ~= 1)
        seizuretimes = [seizuretimes, thorough(i)];
    end
    i = i + 1;
    if(isempty(seizuretimes) ~= 1)
        if j>1
            if (seizuretimes(end)-seizuretimes(1) > min_seiz_length && length(seizuretimes) > 1  && seizuretimes(1) > seize(j-1).enind + min_seiz_ISI) %initially 2, 10
                seizurerange = [seizurerange, num2str(seizuretimes(1)), ' to ', num2str(seizuretimes(end)), ', '];
                beginind = seizuretimes(1);
                endind = seizuretimes(end);
                interval = [beginind:1/fs:endind];
                plot(interval, wave(round(beginind*fs):round(beginind*fs)+length(interval)-1), '-r');
                hold on;
                text(seizuretimes(1) + 1, 0, num2str(j));
                seize(j).stind = seizuretimes(1);
                seize(j).enind = seizuretimes(end);
                j = j + 1;
            end
        else
            (seizuretimes(end)-seizuretimes(1) > 1 && length(seizuretimes) > 10  ) %initially 2, 10
            seizurerange = [seizurerange, num2str(seizuretimes(1)), ' to ', num2str(seizuretimes(end)), ', '];
            beginind = seizuretimes(1);
            endind = seizuretimes(end);
            interval = [beginind:1/fs:endind];
            plot(interval, wave(round(beginind*fs):round(beginind*fs)+length(interval)-1), '-r');
            hold on;
            text(seizuretimes(1) + 1, 0, num2str(j));
            seize(j).stind = seizuretimes(1);
            seize(j).enind = seizuretimes(end);
            j = j + 1;
            
            
          
        end
    end
    seizuretimes = [];
end

xlabel('Time (s)');
ylabel('Amplitude of EEG Reading');
title('EEG of Stargazer Mice with Seizures Using Amp+Freq Conditions');

%Prints Approximate Seizure Times
seizurerange = [seizurerange, ' seconds.'];
display(seizurerange);
%saveas (1000,[Folder ' autoseizureread_output '  '.png' ],'png')