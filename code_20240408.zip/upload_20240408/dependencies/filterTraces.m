% function traces = filterTraces( traces, fps, traceOpt )
% filters a set of traces according to speficiations in traceOpt
% Inputs
%   traces is a columnwise matrix.
%   traceOpt is a structure with fields specified by @TraceOpts
%
% Dimitri Yatsenko, 2010-09-07





function [traces, P_best, V] = filterTraces( traces, fps, traceOpt,indicator,initial, apm)

traces = double(traces);

%fps = 1000/initial.msperline;

%traceOpt.trace_computation = oopsi;

switch traceOpt.trace_computation

    case 'raw'
        % high-pass filtration
        if isfield(traceOpt,'fstop1') && ~isnan(traceOpt.fstop1)
            if traceOpt.fstop1>0
                k = hamming(round(fps/traceOpt.fstop1)*2+1);
                k = k/sum(k);
                if length(k)<size(traces,1)
                    traces = traces./convmirr(traces,k)-1;  %  dF/F where F is low pass
                end
            else
                traces = bsxfun(@rdivide,traces,mean(traces))-1;  % dF/F where F is mean
            end
        end
        % low-pass filtration
        if isfield(traceOpt,'fstop2') && ~isnan(traceOpt.fstop2)
            k = hamming(round(fps/traceOpt.fstop2)*2+1);
            k = k/sum(k);
            traces = convmirr(traces,k);
        end

    case 'exp model'
        traces = getCaEvents( traces, fps, traceOpt.tau, traceOpt.fstop1 );

    case 'exp matching pursuit'
        traces = getMPEvents( traces, fps, traceOpt.tau, traceOpt.fstop1 );

    case 'rectify'
        traces = max(0,[zeros(1,size(traces,2)); diff(traces)]);

    case 'spike recovery'
        % Eva's algorithm
        for iTrace=1:size(traces,2)
            [spikes,threshSpikes,calciumTransient,xx2] = getspikes_nolearning(double(traces(:,iTrace)),[],[]);
            traces(:,iTrace)=spikes(1:size(traces,1));
            fprintf('[%d/%d]\n',iTrace,size(traces,2));
        end

    case 'oopsi'
        if isfield(traceOpt,'fstop1') && traceOpt.fstop1>0
            k = hamming(round(fps/traceOpt.fstop1)*2+1);
            k = k/sum(k);
            traces = bsxfun( @plus, traces-convmirr(traces,k), mean(traces) ); 
        end
        
          
        
        %est_sig:    1 to estimate sig
   
   V.est_b = 0;     % 1 to estimate b
   V.est_a = 0;      %1 to estimate a
%
% P.        structure of neuron model Parameters
%
%   a:      spatial filter
%   b:      background fluorescence
%   sig:    standard deviation of observation noise
%   gam:    decayish, ie, tau=dt/(1-gam)
%   lam:    firing rate-ish, ie, expected # of spikes per frame
        
        V.fast_plot = 0;
        V.fast_iter_max = 15;
        V.dt = 1/fps;
        switch indicator
            case 'OGB'
                V.tau_input = 1.5;
            case 'GCamp6F'
                V.tau_input = 1.2;
            case 'GCamp6M'
                V.tau_input = 1.5;
            case 'GCamp6S'
                V.tau_input = 3.8;
        end
        
             V.est_gam = 1-(initial.msperline/(V.tau_input*1000));    %1 to estimate gam
       
        
        for iTrace = 1:size(traces,2)
            if apm == 0
                V.est_lam =  30/V.tau_input/500;
            else
            V.est_lam =  apm(1,iTrace)^8/V.tau_input/500; %before: ^4
            end
            
            [n_best, P_best,V ] = fast_oopsi_edited_JM( traces(:,iTrace)', V );
            traces(:,iTrace) = n_best;
        end
        
        
        %original from dimitri:
%         for iTrace = 1:size(traces,2)
%             [n_best P_best] = fast_oopsi( traces(:,iTrace)', struct('dt',1/fps) );
%             traces(:,iTrace) = n_best;
%         end
        
    otherwise
        error('Don''t know how to do process traces as "%s"', traceOpt.trace_computation)
end

%assert( ~any(isnan(traces(:))), 'Found nans in traces' );
end