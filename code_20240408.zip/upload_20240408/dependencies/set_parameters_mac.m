function [initial] = set_parameters_mac(avg_2_fr,spiral_scan,vis_or_spont, heka_or_winedr, no_patch_or_patch, tif_or_txt,...
    tdtomato_or_not, voltage_clamp,el_stim,...
    voltage_only,old_file,interneuron_modulation,sham_stim,contrast_or_sp_freq,cell_ROIs_only,sim_sham_stim,linescan,...
    stim_and_sham_combined,sim_stim,indicator,stimcfov,NB208,imaging_or_not,use_red_channel,PC_or_linux,...
    num_rec,datedr,h5_or_tif,sscdf)

initial.Sergey_scan_sc_p_fr = sscdf;

initial.h5_or_tif = h5_or_tif;
initial.datedr = datedr;
initial.avg_2_fr = avg_2_fr;
initial.spiral_scan = spiral_scan; %[1,1,1,1,1,1,1,1,0,1];
initial.use_red_channel = use_red_channel; %[1,1,1,1,1,1,1,1,1,0];
initial.heka_or_winedr = heka_or_winedr; %[1,1,1,1,1,1,1,1,0,1];
initial.no_imaging = imaging_or_not;

initial.num_rec = num_rec;
% 
% if use_red_channel
%     initial.use_red_channel = 1;
% else
%     initial.use_red_channel = 0;
% end

if PC_or_linux
    initial.PC_or_linux = 1;
else
    initial.PC_or_linux = 0;
end

% 
% if imaging_or_not
%     initial.no_imaging = 0;
% else
%     initial.no_imaging = 1;
% end

if strcmp(indicator,'GCamp6M')
    initial.indicator = 'GCamp6M';
else
    if strcmp(indicator,'OGB')
        initial.indicator = 'OGB';
    else
        if strcmp(indicator,'GCamp6S')
            initial.indicator = 'GCamp6S';
        else
            if strcmp(indicator,'GCamp6F')
                initial.indicator = 'GCamp6F';
            else
                if strcmp(indicator,'GCaMP7f')
                    initial.indicator = 'GCaMP7f';
                else
                    if strcmp(indicator,'iGluSnfr')
                        initial.indicator = 'iGluSnfr';
                    end
                end
            end
        end
    end
end

if stimcfov
    initial.stimcfov = 1;
else
    initial.stimcfov = 0;
end

if NB208
    initial.NB208 = 1; 
else
    initial.NB208 = 0;
end
% 
% if spiral_scan
%     initial.spiral_scan = 1;
% else
%     initial.spiral_scan = 0;
% end

if voltage_only
    initial.voltage_only = 1;
else
    initial.voltage_only = 0;
end

if sham_stim
    initial.sham_stim = 1;
else
    initial.sham_stim = 0;
end

if el_stim
    initial.el_stim = 1;
else
    initial.el_stim = 0;
end

if voltage_clamp
    initial.voltage_clamp = 1;
else
    initial.voltage_clamp = 0;
end

if tdtomato_or_not
    tdtomato_or_not = 1;
    initial.tdtomato_or_not = 1;
else
    tdtomato_or_not = 0;
    initial.tdtomato_or_not = 0;
end

if old_file
    old_file = 1;
    initial.old_file = 1;
else
    old_file = 0;
    initial.old_file = 0;
end

if no_patch_or_patch
    PD_only = 1; 
    initial.PD_only = 1;
else
    PD_only = 0;
    initial.PD_only = 0;
    
    if initial.voltage_clamp ==0
prompt = {'wholecell (1) or cell-attached (0) ?'};
dlg_title = '0 for wholecell, 1 for cell-attached';
num_lines = 1;
def = {'1'};
answer = inputdlg(prompt,dlg_title,num_lines,def);
answer = str2mat(answer);
whole_or_attached = str2num(answer);
initial.whole_or_attached = whole_or_attached;
    end
end

if tif_or_txt
    tif_or_txt = 1; 
    initial.tif_or_txt= 1;
else
    tif_or_txt = 0;
    initial.tif_or_txt = 0;
end

if vis_or_spont
    initial.vis_or_spont = 1;
else
    initial.vis_or_spont = 0;
end
% 
% if heka_or_winedr 
%     initial.heka_or_winedr = 1;
% else
%     initial.heka_or_winedr = 0;
% end

if interneuron_modulation
    initial.interneuron_modulation = 1;
else
    initial.interneuron_modulation = 0;
end


if contrast_or_sp_freq
    initial.contrast_or_sp_freq = 1;
else
    initial.contrast_or_sp_freq = 0;
end


if cell_ROIs_only
    initial.cell_ROIs_only = 1;
else
    initial.cell_ROIs_only = 0;
end


if sim_sham_stim
    initial.sim_sham_stim = 1;
else
    initial.sim_sham_stim = 0;
end

if linescan
    initial.linescan = 1;
else
    initial.linescan = 0;
end

if stim_and_sham_combined
    initial.stim_and_sham_combined = 1;
else
    initial.stim_and_sham_combined = 0;
end

if sim_stim
    initial.sim_stim = 1;
else
    initial.sim_stim = 0;
end


