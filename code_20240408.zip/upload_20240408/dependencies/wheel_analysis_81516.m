
function [wheel] = wheel_analysis_81516(initial,Folder,cam_fr,tds,wheel_thr,freq,analyze_offsets_etc,i2,wheel_added_to_winedr,iii,onep,mst)


if wheel_added_to_winedr
    wheel_1 = initial.rawData2(:,8);
    wheel_2 = initial.rawData2(:,9);
else
    
    if size(i2.rawData2,2) == 7
        wheel_1 = i2.rawData2(:,4);
        wheel_2 = i2.rawData2(:,7);
    else
        if size(i2.rawData2,2) == 6
            wheel_1 = i2.rawData2(:,5);
            wheel_2 = i2.rawData2(:,6);
        else
            if size(i2.rawData2,2) == 5
                wheel_1 = i2.rawData2(:,4);
                wheel_2 = i2.rawData2(:,5);
            else
                wheel_1 = i2.rawData2(:,6);
                wheel_2 = i2.rawData2(:,9);
            end
        end
    end
end






if max(wheel_1)>10
    facc = max(wheel_1)/6;
    wheel_1 = wheel_1/facc;
end


if max(wheel_2)>10
    facc = max(wheel_2)/6;
    wheel_2 = wheel_2/facc;
end



if onep
    sec_offs = mst/i2.sampl_fr;
    fr_offs = round(sec_offs*i2.sampl_fr)%-fr*(cam_fr_times(1,1)/initial.sampl_fr); %HERE: ADD cam_fr_times(1,1) (in fr time)
    wheel.fr_offs = fr_offs;
    
    wheel_1(1:fr_offs,:) = [];
    wheel_2(1:fr_offs,:) = [];
    %         avg_diffwhisk(1:fr_offs,:) = [];
    %         smooth_avg_diffwhisk(1:fr_offs,:) = [];
    %
end


wheel.wheel_1 = wheel_1;
wheel.wheel_2 = wheel_2;

samples = length(wheel_1);
clear wheel_1_pulse wheel_2_pulse wheel_1_or_2_pulse either_wheel_pulse wheel_1_direction_change_no direction_change...
    wheel_2_direction_change_no abs_speed wheel_1_pulse_stamp wheel_2_pulse_stamp wheel_1_or_2_pulse_stamp direction_change_stamp
a=1;
b=1;
c=1;
wheel_1_pulse(1,1) = 1;
wheel_2_pulse(1,1) = 1;
wheel_2_pulse_stamp = zeros(samples-2,1);
wheel_1_pulse_stamp = zeros(samples-2,1);
wheel_1_or_2_pulse = 0;
either_wheel_pulse = 0;
wheel_1_pulse_left_out = 0;
wheel_2_pulse_left_out = 0;
for i = 1: samples-2
    if a==1
        bb=2;
    else
        bb = a;
    end
    if wheel_1_pulse(bb-1,1) == i-1
        wheel_1_pulse_left_out = wheel_1_pulse_left_out+1;
    else
        if wheel_1(i,1) > wheel_1(i+1,1)+0.2... %&& wheel_1(i+2,1) < wheel_1(i+1,1) - 0.01 ) ...
                || wheel_1(i,1) < wheel_1(i+1,1) - 0.2 %&& wheel_1(i+2,1) < wheel_1(i+1,1) -0.01)
            wheel_1_pulse(a,1) = i;
            wheel_1_pulse_stamp(i,1) = 6;
            a=a+1;
            wheel_1_or_2_pulse(c,1) = 1;
            wheel_1_or_2_pulse_time(c,1) = i;
            
            wheel_1_or_2_pulse_stamp(i,1) = 6;
            either_wheel_pulse(c,1) = i;
            c = c+1;
        end
    end
    if b==1
        cc=2;
    else
        cc = b;
    end
    if wheel_2_pulse(cc-1,1) == i-1
        wheel_2_pulse_left_out = wheel_2_pulse_left_out+1;
        
    else
        if wheel_2(i,1) > wheel_2(i+1,1)+0.2 ...%&& wheel_2(i+2,1) < wheel_2(i+1,1) - 0.01 ) || ...
                ||  wheel_2(i,1) < wheel_2(i+1,1) - 0.2 %&& wheel_2(i+2,1) < wheel_2(i+1,1) -0.01)
            wheel_2_pulse(b,1) = i;
            wheel_2_pulse_stamp(i,1) = 6;
            b=b+1;
            wheel_1_or_2_pulse(c,1) = -1;
            wheel_1_or_2_pulse_time(c,1) = i;
            wheel_1_or_2_pulse_stamp(i,1) = -6;
            either_wheel_pulse(c,1) = i;
            c = c+1;
        end
    end
end
wheel.wheel_1_pulse = wheel_1_pulse;
wheel.wheel_1_pulse_stamp = wheel_1_pulse_stamp;
wheel.wheel_1_or_2_pulse = wheel_1_or_2_pulse;
wheel.either_wheel_pulse = either_wheel_pulse;
wheel.wheel_2_pulse = wheel_2_pulse;
wheel.wheel_2_pulse_stamp = wheel_2_pulse_stamp;

clear direction_change direction_change_stamp wheel_1_direction_change_no wheel_2_direction_change_no...
    direction_change_w1_stamp direction_change_w2_stamp

wheel_1_direction_change_no = zeros(size(wheel_1));
wheel_2_direction_change_no = zeros(size(wheel_1));
direction_change = zeros(size(wheel_1));
direction_change_stamp = zeros(size(wheel_1));
direction_change_w1_stamp = zeros(size(wheel_1));
direction_change_w2_stamp = zeros(size(wheel_1));

a=1;
b = 0;
c = 0;
d = 1;
porl = length(wheel_1_or_2_pulse);
prev_i_1 = 0;
prev_i_2 = 0;
prev_sum_1 = 0;
prev_sum_2 = 0;
for i = 1:1:porl-1
    
    frac_done = i/porl
    
    currsum = wheel_1_or_2_pulse(i,1)+wheel_1_or_2_pulse(i+1,1);
    if abs(currsum)
        if wheel_1_or_2_pulse(i,1) == 1
            sum1 = prev_sum_1 + sum(wheel_1_pulse_stamp(prev_i_1+1:wheel_1_or_2_pulse_time(i,1),1));
            w1pn = sum1/6;
            b = b+1;
            wheel_1_direction_change_no(b,1) = d;
            direction_change(a,1) = wheel_1_pulse(w1pn,1);
            direction_change_stamp(wheel_1_pulse(w1pn,1),1) = 6;
            direction_change_w1_stamp(wheel_1_pulse(w1pn,1),1) = 6;
            a=a+1;
            d = d+1;
            prev_i_1 = wheel_1_or_2_pulse_time(i,1);
            prev_sum_1 = sum1;
        else
            sum2 =prev_sum_2 + sum(wheel_2_pulse_stamp(prev_i_2+1:wheel_1_or_2_pulse_time(i,1),1));
            w2pn = sum2/6;
            c = c+1;
            wheel_2_direction_change_no(c,1) = d;
            direction_change(a,1) = wheel_2_pulse(w2pn,1);
            direction_change_stamp(wheel_2_pulse(w2pn,1),1) = 6;
            direction_change_w2_stamp(wheel_2_pulse(w2pn,1),1) = 6;
            a=a+1;
            d = d+1;
            prev_i_2 = wheel_1_or_2_pulse_time(i,1);
            prev_sum_2 = sum2;
        end
        
        %          if wheel_1_or_2_pulse(i,1) == 1
        %             sum1 = sum(wheel_1_pulse_stamp(1:wheel_1_or_2_pulse_time(i,1),1));
        %             w1pn = sum1/6;
        %             b = b+1;
        %             wheel_1_direction_change_no(b,1) = d;
        %             direction_change(a,1) = wheel_1_pulse(w1pn,1);
        %             direction_change_stamp(wheel_1_pulse(w1pn,1),1) = 6;
        %             direction_change_w1_stamp(wheel_1_pulse(w1pn,1),1) = 6;
        %             a=a+1;
        %             d = d+1;
        %         else
        %             sum2 = sum(wheel_2_pulse_stamp(1:wheel_1_or_2_pulse_time(i,1),1));
        %             w2pn = sum2/6;
        %             c = c+1;
        %             wheel_2_direction_change_no(c,1) = d;
        %             direction_change(a,1) = wheel_2_pulse(w2pn,1);
        %             direction_change_stamp(wheel_2_pulse(w2pn,1),1) = 6;
        %             direction_change_w2_stamp(wheel_2_pulse(w2pn,1),1) = 6;
        %             a=a+1;
        %             d = d+1;
        %         end
    end
end
wheel.wheel_1_direction_change_no= wheel_1_direction_change_no;
wheel.direction_change = direction_change;
wheel.direction_change_stamp = direction_change_stamp;
wheel.wheel_2_direction_change_no = wheel_2_direction_change_no;

all_pulse_times = cat(1,wheel_1_pulse,wheel_2_pulse);
all_pulse_times = sort(all_pulse_times);
all_pulse_diff = diff(all_pulse_times);
all_pulse_speeds = (ones(length(all_pulse_diff),1))./all_pulse_diff;

wheel.all_pulse_times = all_pulse_times;
wheel.all_pulse_diff = all_pulse_diff;
wheel.all_pulse_speeds = all_pulse_speeds;


%now put it together into the direction segments
a=1+all_pulse_times(1,1);
for i = 1:length(all_pulse_speeds)
    abs_speed(a:all_pulse_times(i,1)) = all_pulse_speeds(i,1);
    a = all_pulse_times(i,1)+1;
end

wheel.abs_speed = abs_speed;

%make direction (-1/+1) vector, then multiply with abs_speed, then smooth,
%then downsample (or upsample motion offsets)

clear direction_vec
a=0;
b=3;
o =length(direction_change);
for i = 1:o
    if mod(b,2)
        direction_vec(a+1:direction_change(i,1),1) = 1;
    else
        direction_vec(a+1:direction_change(i,1),1) = -1;
    end
    a=direction_change(i,1);
    b=b+1;
end

wheel.direction_vec = direction_vec;
wheel.direction_change = direction_change;


x=length(abs_speed);
if direction_change(o,1) == -1
    y = 1;
else
    y = -1;
end
direction_vec(max(direction_change)+1:x,1) = y;

speed = abs_speed'.*direction_vec;

s = mean(speed);
if s < 0
    speed = -speed;
end

wheel.speed = speed;

xx = round(i2.triggersync_hz/freq);
smooth_speed = smooth(speed,xx);
smooth_abs_speed = smooth(abs_speed,xx);

wheel.smooth_speed = smooth_speed;
wheel.smooth_abs_speed = smooth_abs_speed;

fr = i2.triggersync_hz
%freq = 100;
smooth_speed_extrap  = zeros(round(length(smooth_speed)/(fr/freq)),1);
for i = 1: size(smooth_speed_extrap,1)
    smooth_speed_extrap(i) = smooth_speed(round((i-1)*fr/freq)+1);
end

smooth_abs_speed_extrap  = zeros(round(length(smooth_abs_speed)/(fr/freq)),1);
for i = 1: size(smooth_speed_extrap,1)
    smooth_abs_speed_extrap(i) = smooth_abs_speed(round((i-1)*fr/freq)+1);
end

if initial.no_imaging(1,iii)
else
    freq = 1000/i2.msperline;
    smooth_speed_exxtrap  = zeros(round(length(smooth_speed)/(fr/freq)),1);
    for i = 1: size(smooth_speed_exxtrap,1)
        smooth_speed_exxtrap(i) = smooth_speed(round((i-1)*fr/freq)+1);
    end
    
    smooth_abs_speed_exxtrap  = zeros(round(length(smooth_abs_speed)/(fr/freq)),1);
    for i = 1: size(smooth_speed_exxtrap,1)
        smooth_abs_speed_exxtrap(i) = smooth_abs_speed(round((i-1)*fr/freq)+1);
    end
    
    wheel.smooth_speed_extrap = smooth_speed_extrap;
    wheel.smooth_abs_speed_extrap = smooth_abs_speed_extrap;
    wheel.smooth_abs_speed_exxtrap = smooth_abs_speed_exxtrap;
    wheel.smooth_speed_exxtrap = smooth_speed_exxtrap;
    
    
    if analyze_offsets_etc
        
        motx = i2.offsets(:,1);
        moty = i2.offsets(:,2);
        diffmotx = diff(motx);
        diffmoty = diff(moty);
        diffmotx(diffmotx<0) = 0;
        diffmoty(diffmoty<0) = 0;
        motion = (abs(motx)+abs(moty))';
        diff_motion = (diffmotx+diffmoty)';
        freq = i2.sampl_fr;
        fr = i2.samplingratehz;
        if length(diff_motion) < length(motion)
            motion(:,length(diff_motion)+1:length(motion)) = [];
        end
        % motion_interp  = zeros(ceil(length(motion)*initial.msperline/1000*freq),size(motion,2));
        % diff_motion_interp = zeros(ceil(length(diff_motion)*initial.msperline/1000*freq),size(diff_motion,2));
        
        
        mot = motion';%(1:1000,1)';
        diff_mot = diff_motion';%(1:1000,1)';
        freq=100
        
        [motion_interp,diff_motion_interp] = cat_and_deltaf_interp_ext_freq(mot,diff_mot,initial,freq);
        
        wheel.motion_interp = motion_interp;
        wheel.diff_motion_interp = diff_motion_interp;
        
        %
        clear angle_deg
        for i = 1: size(i2.offsets,1)
            y = i2.offsets(i,2);
            x = i2.offsets(i,1);
            angle = atan(y/x);
            angle = rad2deg(angle);
            angle_raw = angle;
            if x == 0
                if y>0
                    angle = 90;
                    angle_raw = 90;
                else
                    if y<0
                        angle = 90;
                        angle_raw = 270;
                    else
                        angle = 0;
                        angle_raw = 0;
                    end
                end
            end
            
            
            if y == 0
                if x>0
                    angle = 0;
                    angle_raw = 0;
                else
                    if x<0
                        angle = 180;
                        angle_raw = 180;
                    else
                        angle = 0;
                        angle_raw = 0;
                    end
                end
                
            end
            
            if x<0 && y>0
                angle = 180+angle;
                angle_raw = 180+angle;
            end
            if x<0 && y<0
                angle = 180-angle;
                angle_raw = 180+angle;
            end
            if x>0 && y<0
                angle = -angle;
                angle_raw = 360+angle;
            end
            angle_deg(i,1) = angle;
            angle_deg_raw(i,1) = angle_raw;
        end
        freq = 100;
        
        %freq = cam_fr;
        forw = ceil(i2.msperline/(1000/freq));                                              
        %%%%%%% angle_deg_interp
        angle_deg_interp  = zeros(ceil(length(angle_deg)*i2.msperline/1000*freq),...
            size(angle_deg,2));
        
        for k = 1:size(angle_deg,2)
            a=1;
            j = 1;
            i = 2;
            angle_deg_interp_ROI = k
            while i <= length(angle_deg_interp)-10
                %deltaf_interp (i,1) = i/freq;
                if (j*i2.msperline/1000 >= i/freq) && (j*i2.msperline/1000 <= i/freq+1/freq)...
                        && angle_deg_interp(i,k) == 0 %&& deltaf_interp(i-1,k) == 0
                    if j*i2.msperline-i/freq <= i+1/freq - j*i2.msperline
                        angle_deg_interp(i,k) = angle_deg(j,k);
                        if angle_deg(j,k)==0
                            zerodf(1,a) = i;
                            a=a+1;
                        end
                    else
                        angle_deg_interp(i+1,k) = angle_deg(j,k);
                        if angle_deg(j,k)==0
                            zerodf(1,a) = i+1;
                            a=a+1;
                        end
                    end
                    j=j+1;
                end
                i=i+1;
            end
        end
        
        angle_deg_interp_new = angle_deg_interp;
        %results.deltaf_interp_values(results.deltaf_interp_values==0)= NaN;
        for i = 1:size(angle_deg_interp,2)
            a=1;
            naninds = 0;
            for j = 1:length(angle_deg_interp)
                if j<length(angle_deg_interp)-forw
                    if sum(angle_deg_interp(j:j+forw,i))>0
                        curr = find(angle_deg_interp(j:j+forw,i)==0)+j-1;
                        c = length(curr);
                        naninds(1,a:a+c-1) = curr;
                        a=a+c;
                        %results.deltaf_interp_values(find(results.deltaf_interp_values(j:j+forw,i)==0)',i)= NaN;
                    end
                else
                    if angle_deg_interp(j,i) == 0
                        naninds(1,a) = j;
                        a=a+1;
                        %results.deltaf_interp_values(j,i) = NaN;
                    end
                end
            end
            
            %remove duplicates from naninds
            
            angle_deg_interp_new(unique(naninds),i)= NaN;
            
            angle_deg_interp_new(1:size(angle_deg_interp,1),i)...
                = inpaint_nans(angle_deg_interp_new(1:size(angle_deg_interp,1),i));
        end
        
                                             
        %%%%%%% offsets_interp
        offsets = i2.offsets;
        offsets_interp  = zeros(ceil(length(offsets)*i2.msperline/1000*freq),...
            size(offsets,2));
        
        for k = 1:size(offsets,2)
            a=1;
            j = 1;
            i = 2;
            offsets_interp_ROI = k
            while i <= length(offsets_interp)-10
                %deltaf_interp (i,1) = i/freq;
                if (j*i2.msperline/1000 >= i/freq) && (j*i2.msperline/1000 <= i/freq+1/freq)...
                        && offsets_interp(i,k) == 0 %&& deltaf_interp(i-1,k) == 0
                    if j*i2.msperline-i/freq <= i+1/freq - j*i2.msperline
                        offsets_interp(i,k) = offsets(j,k);
                        if offsets(j,k)==0
                            zerodf(1,a) = i;
                            a=a+1;
                        end
                    else
                        offsets_interp(i+1,k) = offsets(j,k);
                        if offsets(j,k)==0
                            zerodf(1,a) = i+1;
                            a=a+1;
                        end
                    end
                    j=j+1;
                end
                i=i+1;
            end
        end
        
        offsets_interp_new = offsets_interp;
        %results.deltaf_interp_values(results.deltaf_interp_values==0)= NaN;
        for i = 1:size(offsets_interp,2)
            a=1;
            naninds = 0;
            for j = 1:length(offsets_interp)
                if j<length(offsets_interp)-forw
                    if sum(offsets_interp(j:j+forw,i))>0
                        curr = find(offsets_interp(j:j+forw,i)==0)+j-1;
                        c = length(curr);
                        naninds(1,a:a+c-1) = curr;
                        a=a+c;
                        %results.deltaf_interp_values(find(results.deltaf_interp_values(j:j+forw,i)==0)',i)= NaN;
                    end
                else
                    if offsets_interp(j,i) == 0
                        naninds(1,a) = j;
                        a=a+1;
                        %results.deltaf_interp_values(j,i) = NaN;
                    end
                end
            end
            
            %remove duplicates from naninds
            
            offsets_interp_new(unique(naninds),i)= NaN;
            
            offsets_interp_new(1:size(offsets_interp,1),i)...
                = inpaint_nans(offsets_interp_new(1:size(offsets_interp,1),i));
        end
        
        wheel.offsets_interp_new = offsets_interp_new;
        wheel.angle_deg = angle_deg;
        wheel.angle_deg_raw = angle_deg_raw;
        wheel.angle_deg_interp_new = angle_deg_interp_new;
        
        
        
        if isstruct(tds) == 0
        else
            seiz_ons_offs = zeros(round(i2.movielengthsec*100),1);
            seiz_ons_offs(round(tds.sonms/10),1) = 400;
            seiz_ons_offs(round(tds.soffms/10),1) = -400;
            wheel.seiz_ons_offs = seiz_ons_offs;
            
            if length(smooth_abs_speed_exxtrap) < length(angle_deg)
                smooth_abs_speed_exxtrap(length(smooth_abs_speed_exxtrap)+1:length(angle_deg),1) = 0;
            end
            
            
            offsets_and_speed=zeros(length(offsets),3);
            offsets_and_speed = offsets;
            offsets_and_speed(:,3) = smooth_abs_speed_exxtrap(1:length(offsets),1);
            wheel.offsets_and_speed = offsets_and_speed;
            
            offs_x = offsets(:,1);
            offs_y = offsets(:,2);
            
            
            %variance of angle over time
            series = angle_deg;
            window_s = 0.5;
            angle_deg_var = vartime(series,window_s,initial);
            
            wheel.angle_deg_var = angle_deg_var;
            
            scatter3(angle_deg,angle_deg_var,smooth_abs_speed_exxtrap(1:length(angle_deg),1))
            
            
        end
    end
    
    wheel.smooth_abs_speed_exxtrap = smooth_abs_speed_exxtrap;
    
    wheel_mot = wheel.smooth_abs_speed_exxtrap;
    wheel_mot_min = wheel_mot-wheel_thr;%0.0107;
    wheel_mot_min(wheel_mot_min<0) = 0;
    wheel_mot_min_binary = wheel_mot_min;
    wheel_mot_min_binary(find(wheel_mot_min_binary)) = 1;
    wheel.wheel_mot_min_binary = wheel_mot_min_binary;
    wheel.wheel_mot_min = wheel_mot_min;
    
    for i = 1:10
        wheel_thrz = (0.1+0.1*(i-1))*wheel_thr;
        wheel_mot = wheel.smooth_abs_speed_exxtrap;
        wheel_mot_min = wheel_mot-wheel_thrz;%0.0107;
        wheel_mot_min(wheel_mot_min<0) = 0;
        wheel_mot_min_binary = wheel_mot_min;
        wheel_mot_min_binary(find(wheel_mot_min_binary)) = 1;
        wheel.wheel_mot_min_binarys(i).iteration = wheel_mot_min_binary;
        wheel.wheel_mot_mins(i).iteration = wheel_mot_min;
    end
    
    
    whisk_st_d=0;
    whisk_en_d=0;
    b=0;
    a=1;
    for i = 1:length(wheel_mot_min_binary)
        if i == 1
            if wheel_mot_min_binary(i,1)
                whisk_st_d(a,1) = i;
                b=1;
                a=a+1;
            end
        else
            if wheel_mot_min_binary(i,1)
                if b==1
                else
                    
                    whisk_st_d(a,1) = i;
                    b=1;
                    a=a+1;
                end
                
            else
                if b==1
                    b=0;
                    whisk_en_d(a-1,1) = i;
                end
            end
        end
    end
    
    wheel.wheel_st_d = whisk_st_d;
    wheel.wheel_en_d = whisk_en_d;
    
end





