function sig_v_noise =  plot_DF_oopsi_Sang(DF,FM,oopsi,sang,noisee,Folder,sf,initial,apm,sny,snn,aa,bb,use_line)

endframe = size(DF,2);
frames = length(DF);
ms=initial.msperline;
xsec = round(800*1000/ms);
if xsec>length(DF)
    xsec = length(DF);
end

%
% randr = randi(endframe,15);
% randrois = zeros(15,1);
% randrois(1,1) = randr(1,1);
%
% i=2
% j=1
% while i<16
%     if find(randrois(:,1) == randr(j));
%         j=j+1
%     else
%     randrois(i,1) = randr(j);
%     i=i+1
%     j=j+1
%     end
%end
a=1
b=1
c=1
d=1
sig_v_noise_no = 0;
sig_v_noise_yes = 0;
neurop_num_in = 0;
cell_num_in = 0;
for i = 1:endframe
    %i
    figure(100*i)
    subplot(5,1,1)
    plot(DF(1:xsec,i))%randrois(i,1)))
    axis([1 xsec -0.1 0.9])
    
    subplot(5,1,2)
    plot(FM(1:xsec,i))%randrois(i,1)))
    axis([1 xsec -0.1 0.9])
    
    subplot(5,1,3)
    plot(oopsi(1:xsec,i))%randrois(i,1)))
    axis([1 xsec -0.1 0.4])
    
    subplot(5,1,4)
    plot(sang(1:xsec,i))%randrois(i,1)))
    axis([1 xsec -0.1 0.15])
    
    subplot(5,1,5)
    xbins = [-0.5:0.01:1];
    hist(DF(:,i),xbins)%randrois(i,1)))
    hold on
    semilogy([noisee(i).thr_deltaf noisee(i).thr_deltaf],[ 0 10000],'Color',[1 0 0])
    hold on
    semilogy([noisee(i).avg_signal noisee(i).avg_signal],[ 0 10000],'Color',[0 1 0])
    hold on
    semilogy([noisee(i).std_deltaf noisee(i).std_deltaf],[ 0 10000],'Color',[0 0 1])

    axis([-0.2 1 0.1 length(DF)/5])
    
    if sf
        saveas (100*i,[Folder ' randrois_traces_ ' num2str(100*i) '.png' ],'png')
    end
    %close all
    
    if isempty(sny)
        sig_v_noise_yes = 0;
        
    else
        if isempty(snn)
            sig_v_noise_no = 0;
        end
        if ismember(i,sny)
            sig_v_noise_yes(a,2) =  noisee(i).std_deltaf;
            sig_v_noise_yes(a,1) = apm(1,i);
            a=a+1
        else
            if isempty(snn)
                sig_v_noise_no = 0;
            else
                if ismember(i,snn)
                    sig_v_noise_no(b,2) = noisee(i).std_deltaf;
                    sig_v_noise_no(b,1) = apm(1,i);
                    b=b+1
                end
            end
            
        end
    end
    
    if mod(i,2)==0
        compp = (aa-bb)*apm(1,i) + bb;
        if use_line
            if noisee(i).std_deltaf < compp
                cell_in(i,1) = 1;
                cell_num_in(c,1) = i;
                c=c+1;
            else
                cell_in(i,1) = 0;
            end
        else
            if ismember(i,sny)
                cell_in(i,1) = 1;
                cell_num_in(c,1) = i;
                c=c+1;
            else
                cell_in(i,1) = 0;
            end
            
            
            
            
        end
    else
        compp = (aa-bb)*apm(1,i) + bb;
        if use_line
            if noisee(i).std_deltaf < compp
                neurop_in(i,1) = 1;
                neurop_num_in(d,1) = i;
                d=d+1;
            else
                neurop_in(i,1) = 0;
            end
        else
            if ismember(i,sny)
                neurop_in(i,1) = 1;
                neurop_num_in(d,1) = i;
                d=d+1;
            else
                neurop_in(i,1) = 0;
            end
            
        end
    end
end



sig_v_noise.sig_v_noise_yes = sig_v_noise_yes;
sig_v_noise.sig_v_noise_no = sig_v_noise_no;
sig_v_noise.cell_in = cell_in;
sig_v_noise.cell_num_in = cell_num_in;
sig_v_noise.neurop_in = neurop_in;
sig_v_noise.neurop_num_in = neurop_num_in;

figure(890)
if sig_v_noise_yes
    scatter(sig_v_noise_yes(:,1),sig_v_noise_yes(:,2),'MarkerEdgeColor', [0 1 0])
end
if isempty(snn)
else
    hold on
    if sig_v_noise_no
        scatter(sig_v_noise_no(:,1),sig_v_noise_no(:,2),'MarkerEdgeColor', [1 0 0])
    end
end













