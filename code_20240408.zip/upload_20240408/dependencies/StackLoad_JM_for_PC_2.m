function [initiala,results] = StackLoad_JM_for_PC_2(iii,initial,Folder,xml_file,spof,avg_2_fr,fr_tr_PV,onep,onep_only_first_and_last)






if initial.no_imaging(1,iii) ==1 || onep ||initial.xml_file_corrupt
else
    if   strcmp(xml_file.PVScan.Attributes.version, '5.4.64.400')
        if initial.spiral_scan(1,iii)==1
            initial.dwell_time_us = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,5}.Attributes.value)
            initial.frame_period_from_prairie = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,6}.Attributes.value)
            initial.pockels_power = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,8}.IndexedValue.Attributes.value  )
            
            initial.linesperframe = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1, 9}.Attributes.value)
            
            initial.microns_per_pixel = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1, 11}.IndexedValue{1, 1}.Attributes.value  )
            initial.magnification = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1, 14}.Attributes.value  )
            initial.numerical_aperture = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1, 15}.Attributes.value  )
            initial.zoom = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1, 16}.Attributes.value  )
            initial.pixelsperline = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1, 17}.Attributes.value  )
            initial.PMT_voltage_1 = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1, 18}.IndexedValue{1, 1}.Attributes.value  )
            initial.x_position = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1, 19}.SubindexedValues{1, 1}.SubindexedValue.Attributes.value  )
            initial.y_position = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1, 19}.SubindexedValues{1, 2}.SubindexedValue.Attributes.value  )
            initial.z_position = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1, 19}.SubindexedValues{1, 3}.SubindexedValue.Attributes.value   )
            initial.scanlineperiod = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1, 25}.Attributes.value)
            initial.scan_rotation = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1, 24}.Attributes.value  )
            
            initial.PMT_voltage_2 = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1, 18}.IndexedValue{1, 2}.Attributes.value  )
            
        else
            initial.dwell_time_us = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,5}.Attributes.value)
            initial.frame_period_from_prairie = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,6}.Attributes.value)
            
            initial.pockels_power = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,8}.IndexedValue(1, 1).Attributes.value  )
            
            initial.linesperframe = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,9}.Attributes.value)
            initial.microns_per_pixel = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1, 12}.IndexedValue{1,1}.Attributes.value  )
            initial.numerical_aperture = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1, 15}.Attributes.value  )
            initial.zoom = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1, 16}.Attributes.value  )
            initial.magnification = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1, 14}.Attributes.value  )
            initial.pixelsperline = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1, 17}.Attributes.value  )
            initial.PMT_voltage_1 = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1, 18}.IndexedValue{1, 1}.Attributes.value  )
            initial.x_position = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1, 19}.SubindexedValues{1, 1}.SubindexedValue.Attributes.value  )
            initial.y_position = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1, 19}.SubindexedValues{1, 2}.SubindexedValue.Attributes.value  )
            frt =  class(xml_file.PVScan.PVStateShard.PVStateValue{1,19}.SubindexedValues{1,3}.SubindexedValue) ;
            %
            switch frt
                case 'cell'
                    initial.z_position = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,19}.SubindexedValues{1,3}.SubindexedValue{1,1}.Attributes.value)
                case 'struct'
                    initial.z_position = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,19}.SubindexedValues{1,3}.SubindexedValue.Attributes.value)
            end
            initial.rastersperframe = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1, 23}.Attributes.value  )
            initial.resonantsamplesperpixel = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1, 24}.Attributes.value  )
            
            initial.scanlineperiod = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1, 26}.Attributes.value)
            
            initial.scan_rotation = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1, 25}.Attributes.value  )
            
            initial.PMT_voltage_2 = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1, 18}.IndexedValue{1, 2}.Attributes.value  )
            
            
        end
        
        
    else
        
        
        
        if strcmp(xml_file.PVScan.Attributes.version, '4.3.1.8')
            
            initial.date_time = xml_file.PVScan.Attributes.date;
            initial.microns_per_pixel = str2num(xml_file.PVScan.Sequence.Frame{1,1}.PVStateShard.Key{1,19}.Attributes.value);
            initial.magnification = str2num(xml_file.PVScan.Sequence.Frame{1,1}.PVStateShard.Key{1,5}.Attributes.value);
            initial.zoom = str2num(xml_file.PVScan.Sequence.Frame{1,1}.PVStateShard.Key{1,18}.Attributes.value);
            initial.numerical_aperture = str2num(xml_file.PVScan.Sequence.Frame{1,1}.PVStateShard.Key{1,4}.Attributes.value);
            initial.dwell_time_us = str2num(xml_file.PVScan.Sequence.Frame{1,1}.PVStateShard.Key{1,11}.Attributes.value);
            initial.pockels_power = str2num(xml_file.PVScan.Sequence.Frame{1,1}.PVStateShard.Key{1,23}.Attributes.value);
            initial.x_position = str2num(xml_file.PVScan.Sequence.Frame{1,1}.PVStateShard.Key{1,13}.Attributes.value);
            initial.y_position = str2num(xml_file.PVScan.Sequence.Frame{1,1}.PVStateShard.Key{1,14}.Attributes.value);
            initial.z_position = str2num(xml_file.PVScan.Sequence.Frame{1,1}.PVStateShard.Key{1,15}.Attributes.value);
            initial.PMT_voltage_1 = str2num(xml_file.PVScan.Sequence.Frame{1,1}.PVStateShard.Key{1,21}.Attributes.value);
            initial.PMT_voltage_2 = str2num(xml_file.PVScan.Sequence.Frame{1,1}.PVStateShard.Key{1,22}.Attributes.value);
            initial.PMT_preamp_gain_1 = str2num(xml_file.PVScan.Sequence.Frame{1,1}.PVStateShard.Key{1,32}.Attributes.value);
            initial.PMT_preamp_gain_2 = str2num(xml_file.PVScan.Sequence.Frame{1,1}.PVStateShard.Key{1,33}.Attributes.value);
            initial.scan_rotation = str2num(xml_file.PVScan.Sequence.Frame{1,1}.PVStateShard.Key{1,17}.Attributes.value);
            initial.frame_period_from_prairie = str2num(xml_file.PVScan.Sequence.Frame{1,1}.PVStateShard.Key{1,9}.Attributes.value);
            
        else
            if strcmp(xml_file.PVScan.Attributes.version, '5.4.64.74') || strcmp(xml_file.PVScan.Attributes.version, '5.4.64.100')
                
                
                initial.dwell_time_us = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,5}.Attributes.value)
                initial.frame_period_from_prairie = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,6}.Attributes.value)
                
                initial.pockels_power = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,8}.IndexedValue{1, 1}.Attributes.value  )
                initial.linesperframe = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1, 10}.Attributes.value)
                initial.microns_per_pixel = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1, 12}.IndexedValue{1, 1}.Attributes.value  )
                initial.magnification = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1, 15}.Attributes.value  )
                initial.numerical_aperture = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1, 16}.Attributes.value  )
                initial.zoom = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1, 17}.Attributes.value  )
                initial.pixelsperline = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1, 18}.Attributes.value  )
                initial.PMT_voltage_1 = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1, 19}.IndexedValue{1, 1}.Attributes.value  )
                initial.x_position = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1, 20}.SubindexedValues{1, 1}.SubindexedValue.Attributes.value  )
                initial.y_position = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1, 20}.SubindexedValues{1, 2}.SubindexedValue.Attributes.value  )
                initial.z_position = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1, 20}.SubindexedValues{1, 3}.SubindexedValue.Attributes.value  )
                initial.scanlineperiod = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1, 25}.Attributes.value)
                initial.scan_rotation = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1, 24}.Attributes.value  )
                
                initial.PMT_voltage_2 = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1, 19}.IndexedValue{1, 2}.Attributes.value  )
                
                
                
                
            else
                if  ((strcmp(xml_file.PVScan.Attributes.version, '5.3.64.300')) && initial.spiral_scan(1,iii)==0) || ...
                        (initial.avg_2_fr(1,iii)==0 && initial.spiral_scan(1,iii)==0  &&(strcmp(xml_file.PVScan.Attributes.version, '5.3.64.300'))) || ...
                        ((strcmp(xml_file.PVScan.Attributes.version, '5.3.64.400')) && initial.spiral_scan(1,iii)==0)
                    
                    initial.dwell_time_us = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,3}.Attributes.value)
                    initial.frame_period_from_prairie = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,4}.Attributes.value)
                    initial.magnification = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,12}.Attributes.value)
                    initial.microns_per_pixel = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,9}.IndexedValue{1,1}.Attributes.value)
                    initial.zoom = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,14}.Attributes.value)
                    initial.numerical_aperture = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,13}.Attributes.value)
                    initial.pixelsperline = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,15}.Attributes.value)
                    initial.linesperframe = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,7}.Attributes.value)
                    initial.pockels_power = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,6}.IndexedValue.Attributes.value)
                    initial.PMT_voltage_1 = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,16}.IndexedValue{1,1}.Attributes.value)
                    initial.PMT_voltage_2 = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,16}.IndexedValue{1,2}.Attributes.value)
                    initial.x_position = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,17}.SubindexedValues{1,1}.SubindexedValue.Attributes.value)
                    
                    
                    initial.rastersperframe = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1, 21}.Attributes.value  )
                    
                    initial.y_position = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,17}.SubindexedValues{1,2}.SubindexedValue.Attributes.value)
                    
                    frt =  class(xml_file.PVScan.PVStateShard.PVStateValue{1,17}.SubindexedValues{1,3}.SubindexedValue) ;
                    
                    switch frt
                        case 'cell'
                            initial.z_position = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,17}.SubindexedValues{1,3}.SubindexedValue{1,1}.Attributes.value)
                        case 'struct'
                            initial.z_position = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,17}.SubindexedValues{1,3}.SubindexedValue.Attributes.value)
                            
                            
                    end
                    initial.scan_rotation = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,23}.Attributes.value)
                    
                    
                    
                    
                else
                    
                    if (strcmp(xml_file.PVScan.Attributes.version, '5.3.64.400') && initial.spiral_scan(1,iii)==0)
                        
                        if onep
                            
                        else
                            
                            initial.dwell_time_us = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,3}.Attributes.value)
                            initial.frame_period_from_prairie = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,4}.Attributes.value)
                            initial.magnification = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,12}.Attributes.value)
                            initial.microns_per_pixel = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,9}.IndexedValue{1,1}.Attributes.value)
                            initial.zoom = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,15}.Attributes.value)
                            initial.numerical_aperture = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,13}.Attributes.value)
                            initial.pixelsperline = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,15}.Attributes.value)
                            initial.linesperframe = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,7}.Attributes.value)
                            initial.pockels_power = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,6}.IndexedValue.Attributes.value)
                            initial.PMT_voltage_1 = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,16}.IndexedValue{1,1}.Attributes.value)
                            initial.PMT_voltage_2 = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,16}.IndexedValue{1,2}.Attributes.value)
                            initial.x_position = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,17}.SubindexedValues{1,1}.SubindexedValue.Attributes.value)
                            initial.y_position = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,17}.SubindexedValues{1,2}.SubindexedValue.Attributes.value)
                            initial.z_position = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,17}.SubindexedValues{1,3}.SubindexedValue{1,1}.Attributes.value)
                            initial.scan_rotation = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,23}.Attributes.value)
                        end
                    else
                        if (strcmp(xml_file.PVScan.Attributes.version, '5.3.64.400') && initial.spiral_scan(1,iii)==1)
                            
                            initial.dwell_time_us = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,3}.Attributes.value)
                            
                            initial.frame_period_from_prairie = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,4}.Attributes.value)
                            
                            initial.magnification = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,13}.Attributes.value)
                            
                            initial.microns_per_pixel = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,10}.IndexedValue{1,1}.Attributes.value)
                            
                            initial.zoom = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,15}.Attributes.value)
                            
                            initial.numerical_aperture = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,14}.Attributes.value)
                            
                            initial.pixelsperline = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,16}.Attributes.value)
                            
                            initial.linesperframe = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,8}.Attributes.value)
                            
                            initial.pockels_power = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,6}.IndexedValue.Attributes.value)
                            
                            initial.PMT_voltage_1 = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,17}.IndexedValue{1,1}.Attributes.value)
                            initial.PMT_voltage_2 = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,17}.IndexedValue{1,2}.Attributes.value)
                            
                            initial.x_position = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,18}.SubindexedValues{1,1}.SubindexedValue.Attributes.value)
                            initial.y_position = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,18}.SubindexedValues{1,2}.SubindexedValue.Attributes.value)
                            
                            if size(xml_file.PVScan.PVStateShard.PVStateValue{1,18}.SubindexedValues{1,3}.SubindexedValue,2) == 1
                                initial.z_position = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,18}.SubindexedValues{1,3}.SubindexedValue.Attributes.value)
                            else
                                initial.z_position = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,18}.SubindexedValues{1,3}.SubindexedValue{1,1}.Attributes.value)
                                
                            end
                            initial.scan_rotation = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,23}.Attributes.value)
                            
                            
                            
                        else
                            if  strcmp(xml_file.PVScan.Attributes.version, '5.1.64.100')
                                
                                initial.date_time = xml_file.PVScan.Attributes.date;
                                initial.microns_per_pixel = str2num(xml_file.PVScan.Sequence.Frame{1,1}.PVStateShard.Key{1,23}.Attributes.value);
                                initial.magnification = str2num(xml_file.PVScan.Sequence.Frame{1,1}.PVStateShard.Key{1,6}.Attributes.value);
                                initial.zoom = str2num(xml_file.PVScan.Sequence.Frame{1,1}.PVStateShard.Key{1,22}.Attributes.value);
                                initial.numerical_aperture = str2num(xml_file.PVScan.Sequence.Frame{1,1}.PVStateShard.Key{1,5}.Attributes.value);
                                initial.dwell_time_us = str2num(xml_file.PVScan.Sequence.Frame{1,1}.PVStateShard.Key{1,15}.Attributes.value);
                                initial.pockels_power = str2num(xml_file.PVScan.Sequence.Frame{1,1}.PVStateShard.Key{1,27}.Attributes.value);
                                initial.x_position = str2num(xml_file.PVScan.Sequence.Frame{1,1}.PVStateShard.Key{1,17}.Attributes.value);
                                initial.y_position = str2num(xml_file.PVScan.Sequence.Frame{1,1}.PVStateShard.Key{1,18}.Attributes.value);
                                initial.z_position = str2num(xml_file.PVScan.Sequence.Frame{1,1}.PVStateShard.Key{1,19}.Attributes.value);
                                initial.PMT_voltage_1 = str2num(xml_file.PVScan.Sequence.Frame{1,1}.PVStateShard.Key{1,25}.Attributes.value);
                                initial.PMT_voltage_2 = str2num(xml_file.PVScan.Sequence.Frame{1,1}.PVStateShard.Key{1,26}.Attributes.value);
                                initial.PMT_preamp_gain_1 = str2num(xml_file.PVScan.Sequence.Frame{1,1}.PVStateShard.Key{1,37}.Attributes.value);
                                initial.PMT_preamp_gain_2 = str2num(xml_file.PVScan.Sequence.Frame{1,1}.PVStateShard.Key{1,38}.Attributes.value);
                                initial.scan_rotation = str2num(xml_file.PVScan.Sequence.Frame{1,1}.PVStateShard.Key{1,21}.Attributes.value);
                                initial.frame_period_from_prairie = str2num(xml_file.PVScan.Sequence.Frame{1,1}.PVStateShard.Key{1,13}.Attributes.value);
                                initial.linesperframe = str2num(xml_file.PVScan.Sequence.Frame{1,1}.PVStateShard.Key{1,8}.Attributes.value);
                                initial.pixelsperline = str2num(xml_file.PVScan.Sequence.Frame{1,1}.PVStateShard.Key{1,7}.Attributes.value);
                                initial.laserwavelength = str2num(xml_file.PVScan.Sequence.Frame{1,1}.PVStateShard.Key{1,31}.Attributes.value);
                            else
                                
                                
                                if  strcmp(xml_file.PVScan.Attributes.version, '5.2.64.300')
                                    
                                    if initial.date<736008
                                        
                                        initial.dwell_time_us = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,4}.Attributes.value)
                                        
                                        initial.frame_period_from_prairie = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,5}.Attributes.value)
                                        
                                        initial.pockels_power = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,7}.IndexedValue.Attributes.value)
                                        
                                        initial.wavelength = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,8}.IndexedValue.Attributes.value)
                                        
                                        initial.linesperframe = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,9}.Attributes.value)
                                        
                                        initial.microns_per_pixel = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,11}.IndexedValue{1,1}.Attributes.value)
                                        
                                        initial.magnification = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,14}.Attributes.value)
                                        
                                        initial.numerical_aperture = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,15}.Attributes.value)
                                        
                                        initial.zoom = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,16}.Attributes.value)
                                        
                                        initial.pixelsperline = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,17}.Attributes.value)
                                        
                                        initial.PMT_voltage_1 = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,18}.IndexedValue{1,1}.Attributes.value)
                                        initial.PMT_voltage_2 = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,18}.IndexedValue{1,2}.Attributes.value)
                                        
                                        
                                        initial.x_position = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,19}.SubindexedValues{1,1}.SubindexedValue.Attributes.value)
                                        initial.y_position = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,19}.SubindexedValues{1,2}.SubindexedValue.Attributes.value)
                                        initial.z_position = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,19}.SubindexedValues{1,3}.SubindexedValue.Attributes.value)
                                        
                                        initial.scan_rotation = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,25}.Attributes.value)
                                        
                                        
                                        
                                        
                                    else
                                        
                                        initial.dwell_time_us = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,4}.Attributes.value)
                                        
                                        initial.frame_period_from_prairie = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,5}.Attributes.value)
                                        
                                        initial.pockels_power = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,7}.IndexedValue.Attributes.value)
                                        
                                        initial.wavelength = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,8}.IndexedValue.Attributes.value)
                                        
                                        initial.linesperframe = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,10}.Attributes.value)
                                        initial.microns_per_pixel = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,12}.IndexedValue{1,1}.Attributes.value)
                                        initial.magnification = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,15}.Attributes.value)
                                        initial.numerical_aperture = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,16}.Attributes.value)
                                        initial.zoom = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,17}.Attributes.value)
                                        initial.pixelsperline = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,18}.Attributes.value)
                                        
                                        initial.PMT_voltage_1 = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,19}.IndexedValue{1,1}.Attributes.value)
                                        initial.PMT_voltage_2 = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,19}.IndexedValue{1,2}.Attributes.value)
                                        
                                        
                                        initial.x_position = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,20}.SubindexedValues{1,1}.SubindexedValue.Attributes.value)
                                        initial.y_position = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,20}.SubindexedValues{1,2}.SubindexedValue.Attributes.value)
                                        initial.z_position = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,20}.SubindexedValues{1,3}.SubindexedValue.Attributes.value)
                                        
                                        initial.scan_rotation = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,25}.Attributes.value)
                                    end
                                else
                                    
                                    if initial.old_file ==0
                                        if initial.xml_file_corrupt
                                            initial.zoom = str2num(xml_file.PVStateShard{1,1}.Key{1,8}.ATTRIBUTE.value);
                                            initial.date_time = initial.xml_file_aux.ATTRIBUTE.date;
                                            initial.microns_per_pixel = str2num(xml_file.PVStateShard{1,1}.Key{1,53}.ATTRIBUTE.value);
                                            initial.magnification = str2num(xml_file.PVStateShard{1,1}.Key{1,33}.ATTRIBUTE.value);
                                            initial.numerical_aperture = str2num(xml_file.PVStateShard{1,1}.Key{1,41}.ATTRIBUTE.value);
                                            initial.dwell_time_us = str2num(xml_file.PVStateShard{1,1}.Key{1,51}.ATTRIBUTE.value);
                                            initial.pockels_power = str2num(xml_file.PVStateShard{1,1}.Key{1,205}.ATTRIBUTE.value);
                                            initial.x_position = str2num(xml_file.PVStateShard{1,1}.Key{1,222}.ATTRIBUTE.value);
                                            initial.y_position = str2num(xml_file.PVStateShard{1,1}.Key{1,4}.ATTRIBUTE.value);
                                            initial.z_position = str2num(xml_file.PVStateShard{1,1}.Key{1,166}.ATTRIBUTE.value);
                                            initial.PMT_voltage_1 = str2num(xml_file.PVStateShard{1,1}.Key{1,42}.ATTRIBUTE.value);
                                            initial.PMT_voltage_2 = str2num(xml_file.PVStateShard{1,1}.Key{1,43}.ATTRIBUTE.value);
                                            initial.PMT_preamp_gain_1 = str2num(xml_file.PVStateShard{1,1}.Key{1,139}.ATTRIBUTE.value);
                                            initial.PMT_preamp_gain_2 = str2num(xml_file.PVStateShard{1,1}.Key{1,112}.ATTRIBUTE.value);
                                            initial.scan_rotation = str2num(xml_file.PVStateShard{1,1}.Key{1,227}.ATTRIBUTE.value);
                                            initial.frame_rate_hz = str2num(xml_file.PVStateShard{1,1}.Key{1,24}.ATTRIBUTE.value);
                                        else
                                            
                                            
                                            % if initial.NB208
                                            
                                            
                                            
                                            if initial.date<73584 || initial.date >740000
                                                initial.date_time = xml_file.ATTRIBUTE.date;
                                                initial.microns_per_pixel = str2num(xml_file.Sequence{1,1}.Frame{1,1}.PVStateShard{1,1}.Key{1,17}.ATTRIBUTE.value);
                                                initial.magnification = str2num(xml_file.Sequence{1,1}.Frame{1,1}.PVStateShard{1,1}.Key{1,3}.ATTRIBUTE.value);
                                                initial.zoom = str2num(xml_file.Sequence{1,1}.Frame{1,1}.PVStateShard{1,1}.Key{1,16}.ATTRIBUTE.value);
                                                initial.numerical_aperture = str2num(xml_file.Sequence{1,1}.Frame{1,1}.PVStateShard{1,1}.Key{1,2}.ATTRIBUTE.value);
                                                initial.dwell_time_us = str2num(xml_file.Sequence{1,1}.Frame{1,1}.PVStateShard{1,1}.Key{1,9}.ATTRIBUTE.value);
                                                initial.pockels_power = str2num(xml_file.Sequence{1,1}.Frame{1,1}.PVStateShard{1,1}.Key{1,21}.ATTRIBUTE.value);
                                                initial.x_position = str2num(xml_file.Sequence{1,1}.Frame{1,1}.PVStateShard{1,1}.Key{1,11}.ATTRIBUTE.value);
                                                initial.y_position = str2num(xml_file.Sequence{1,1}.Frame{1,1}.PVStateShard{1,1}.Key{1,12}.ATTRIBUTE.value);
                                                initial.z_position = str2num(xml_file.Sequence{1,1}.Frame{1,1}.PVStateShard{1,1}.Key{1,13}.ATTRIBUTE.value);
                                                initial.PMT_voltage_1 = str2num(xml_file.Sequence{1,1}.Frame{1,1}.PVStateShard{1,1}.Key{1,19}.ATTRIBUTE.value);
                                                initial.PMT_voltage_2 = str2num(xml_file.Sequence{1,1}.Frame{1,1}.PVStateShard{1,1}.Key{1,20}.ATTRIBUTE.value);
                                                initial.PMT_preamp_gain_1 = str2num(xml_file.Sequence{1,1}.Frame{1,1}.PVStateShard{1,1}.Key{1,29}.ATTRIBUTE.value);
                                                initial.PMT_preamp_gain_2 = str2num(xml_file.Sequence{1,1}.Frame{1,1}.PVStateShard{1,1}.Key{1,30}.ATTRIBUTE.value);
                                                initial.scan_rotation = str2num(xml_file.Sequence{1,1}.Frame{1,1}.PVStateShard{1,1}.Key{1,15}.ATTRIBUTE.value);
                                                initial.frame_period_from_prairie = str2num(xml_file.Sequence{1,1}.Frame{1,1}.PVStateShard{1,1}.Key{1,7}.ATTRIBUTE.value);
                                                
                                                
                                                
                                                initial.date_time = xml_file.PVScan.Attributes.date;
                                                initial.microns_per_pixel = str2num(xml_file.PVScan.Sequence{1,1}.Frame{1,1}.PVStateShard{1,1}.Key{1,17}.Attributes.value);
                                                initial.magnification = str2num(xml_file.PVScan.Sequence{1,1}.Frame{1,1}.PVStateShard{1,1}.Key{1,3}.Attributes.value);
                                                initial.zoom = str2num(xml_file.PVScan.Sequence{1,1}.Frame{1,1}.PVStateShard{1,1}.Key{1,16}.Attributes.value);
                                                initial.numerical_aperture = str2num(xml_file.PVScan.Sequence{1,1}.Frame{1,1}.PVStateShard{1,1}.Key{1,2}.Attributes.value);
                                                initial.dwell_time_us = str2num(xml_file.PVScan.Sequence{1,1}.Frame{1,1}.PVStateShard{1,1}.Key{1,9}.Attributes.value);
                                                initial.pockels_power = str2num(xml_file.PVScan.Sequence{1,1}.Frame{1,1}.PVStateShard{1,1}.Key{1,21}.Attributes.value);
                                                initial.x_position = str2num(xml_file.PVScan.Sequence{1,1}.Frame{1,1}.PVStateShard{1,1}.Key{1,11}.Attributes.value);
                                                initial.y_position = str2num(xml_file.PVScan.Sequence{1,1}.Frame{1,1}.PVStateShard{1,1}.Key{1,12}.Attributes.value);
                                                initial.z_position = str2num(xml_file.PVScan.Sequence{1,1}.Frame{1,1}.PVStateShard{1,1}.Key{1,13}.Attributes.value);
                                                initial.PMT_voltage_1 = str2num(xml_file.PVScan.Sequence{1,1}.Frame{1,1}.PVStateShard{1,1}.Key{1,19}.Attributes.value);
                                                initial.PMT_voltage_2 = str2num(xml_file.PVScan.Sequence{1,1}.Frame{1,1}.PVStateShard{1,1}.Key{1,20}.Attributes.value);
                                                initial.PMT_preamp_gain_1 = str2num(xml_file.PVScan.Sequence{1,1}.Frame{1,1}.PVStateShard{1,1}.Key{1,29}.Attributes.value);
                                                initial.PMT_preamp_gain_2 = str2num(xml_file.PVScan.Sequence{1,1}.Frame{1,1}.PVStateShard{1,1}.Key{1,30}.Attributes.value);
                                                initial.scan_rotation = str2num(xml_file.PVScan.Sequence{1,1}.Frame{1,1}.PVStateShard{1,1}.Key{1,15}.Attributes.value);
                                                initial.frame_period_from_prairie = str2num(xml_file.PVScan.Sequence{1,1}.Frame{1,1}.PVStateShard{1,1}.Key{1,7}.Attributes.value);
                                                
                                            else
                                                %
                                                %                                                                                                             initial.date_time = xml_file.ATTRIBUTE.date;
                                                %                                                                                                            initial.microns_per_pixel_xaxis = str2num(xml_file.PVStateShard{1,1}.PVStateValue{1,12}.IndexedValue{1,1}.ATTRIBUTE.value);
                                                %
                                                %                                                                                                             initial.microns_per_pixel_yaxis = str2num(xml_file.PVStateShard{1,1}.PVStateValue{1,12}.IndexedValue{1,2}.ATTRIBUTE.value);
                                                %                                                                                                             initial.magnification = str2num(xml_file.PVStateShard{1,1}.PVStateValue{1,15}.ATTRIBUTE.value);
                                                %
                                                %                                                                                                             initial.pixelsperline = str2num(xml_file.PVStateShard{1,1}.PVStateValue{1,18}.ATTRIBUTE.value);
                                                %                                                                                                             initial.linesperframe = str2num(xml_file.PVStateShard{1,1}.PVStateValue{1,10}.ATTRIBUTE.value);
                                                %
                                                %                                                                                                             initial.zoom = str2num(xml_file.PVStateShard{1,1}.PVStateValue{1,17}.ATTRIBUTE.value);
                                                %                                                                                                             initial.numerical_aperture = str2num(xml_file.PVStateShard{1,1}.PVStateValue{1,16}.ATTRIBUTE.value);
                                                %
                                                %                                                                                                             initial.dwell_time_us = str2num(xml_file.PVStateShard{1,1}.PVStateValue{1,4}.ATTRIBUTE.value);
                                                %                                                                                                             initial.pockels_power = str2num(xml_file.PVStateShard{1,1}.PVStateValue{1,7}.IndexedValue{1,1}.ATTRIBUTE.value);
                                                %
                                                %                                                                                                             initial.wavelength = str2num(xml_file.PVStateShard{1,1}.PVStateValue{1,8}.IndexedValue{1,1}.ATTRIBUTE.value);
                                                %                                                                                                             initial.x_position = str2num(xml_file.PVStateShard{1,1}.PVStateValue{1,20}.SubindexedValues{1,1}.SubindexedValue{1,1}.ATTRIBUTE.value);
                                                %
                                                %                                                                                                             initial.y_position = str2num(xml_file.PVStateShard{1,1}.PVStateValue{1,20}.SubindexedValues{1,2}.SubindexedValue{1,1}.ATTRIBUTE.value);
                                                %                                                                                                             initial.z_position = str2num(xml_file.PVStateShard{1,1}.PVStateValue{1,20}.SubindexedValues{1,3}.SubindexedValue{1,1}.ATTRIBUTE.value);
                                                %
                                                %                                                                                                             initial.PMT_voltage_1 = str2num(xml_file.PVStateShard{1,1}.PVStateValue{1,19}.IndexedValue{1,1}.ATTRIBUTE.value);
                                                %                                                                                                             initial.PMT_voltage_2 = str2num(xml_file.PVStateShard{1,1}.PVStateValue{1,19}.IndexedValue{1,2}.ATTRIBUTE.value);
                                                %
                                                %                                                                                                             initial.PMT_preamp_gain_1 = str2num(xml_file.PVStateShard{1,1}.PVStateValue{1,22}.SubindexedValues{1,1}.SubindexedValue{1,1}.ATTRIBUTE.value);
                                                %                                                                                                             initial.PMT_preamp_gain_2 = str2num(xml_file.PVStateShard{1,1}.PVStateValue{1,22}.SubindexedValues{1,1}.SubindexedValue{1,2}.ATTRIBUTE.value);
                                                %
                                                %                                                                                                             initial.scan_rotation = str2num(xml_file.PVStateShard{1,1}.PVStateValue{1,25}.ATTRIBUTE.value);
                                                %                                                                                                             initial.frame_period_from_prairie = str2num(xml_file.PVStateShard{1,1}.PVStateValue{1,5}.ATTRIBUTE.value);
                                                %
                                                %                                                         %
                                                %
                                                %
                                                %                                                                                                             initial.date_time = xml_file.ATTRIBUTE.date; %ok
                                                %
                                                %                                                                                                             initial.microns_per_pixel_xaxis = str2num(xml_file.PVStateShard{1,1}.PVStateValue{1,11}.IndexedValue{1,1}.ATTRIBUTE.value); %ok
                                                %
                                                %                                                                                                             initial.microns_per_pixel_yaxis = str2num(xml_file.PVStateShard{1,1}.PVStateValue{1,11}.IndexedValue{1,2}.ATTRIBUTE.value);
                                                %
                                                %                                                                                                             initial.magnification = str2num(xml_file.PVStateShard{1,1}.PVStateValue{1,14}.ATTRIBUTE.value); %ok
                                                %
                                                %                                                                                                             initial.pixelsperline = str2num(xml_file.PVStateShard{1,1}.PVStateValue{1,17}.ATTRIBUTE.value);%ok
                                                %
                                                %                                                                                                             initial.linesperframe = str2num(xml_file.PVStateShard{1,1}.PVStateValue{1,9}.ATTRIBUTE.value);%ok
                                                %
                                                %                                                                                                             initial.zoom = str2num(xml_file.PVStateShard{1,1}.PVStateValue{1,16}.ATTRIBUTE.value); %ok
                                                %
                                                %                                                                                                             initial.numerical_aperture = str2num(xml_file.PVStateShard{1,1}.PVStateValue{1,15}.ATTRIBUTE.value); %ok
                                                %
                                                %                                                                                                             initial.dwell_time_us = str2num(xml_file.PVStateShard{1,1}.PVStateValue{1,4}.ATTRIBUTE.value); %ok
                                                %
                                                %                                                                                                             initial.pockels_power = str2num(xml_file.PVStateShard{1,1}.PVStateValue{1,7}.IndexedValue{1,1}.ATTRIBUTE.value); %ok
                                                %
                                                %                                                                                                             initial.x_position = str2num(xml_file.PVStateShard{1,1}.PVStateValue{1,19}.SubindexedValues{1,1}.SubindexedValue{1,1}.ATTRIBUTE.value); %ok
                                                %
                                                %                                                                                                             initial.y_position = str2num(xml_file.PVStateShard{1,1}.PVStateValue{1,19}.SubindexedValues{1,2}.SubindexedValue{1,1}.ATTRIBUTE.value); %ok
                                                %
                                                %                                                                                                             initial.z_position = str2num(xml_file.PVStateShard{1,1}.PVStateValue{1,19}.SubindexedValues{1,3}.SubindexedValue{1,1}.ATTRIBUTE.value); %ok
                                                %
                                                %                                                                                                             initial.PMT_voltage_1 = str2num(xml_file.PVStateShard{1,1}.PVStateValue{1,18}.IndexedValue{1,1}.ATTRIBUTE.value); %ok
                                                %
                                                %                                                                                                             initial.PMT_voltage_2 = str2num(xml_file.PVStateShard{1,1}.PVStateValue{1,18}.IndexedValue{1,2}.ATTRIBUTE.value); %ok
                                                %
                                                %                                                                                                             initial.PMT_preamp_gain_1 = str2num(xml_file.PVStateShard{1,1}.PVStateValue{1,19}.SubindexedValues{1,1}.SubindexedValue{1,1}.ATTRIBUTE.value); %ok
                                                %
                                                %                                                                                                             initial.PMT_preamp_gain_2 = str2num(xml_file.PVStateShard{1,1}.PVStateValue{1,19}.SubindexedValues{1,2}.SubindexedValue{1,1}.ATTRIBUTE.value); %ok
                                                %
                                                %                                                                                                             initial.scan_rotation = str2num(xml_file.PVStateShard{1,1}.PVStateValue{1,25}.ATTRIBUTE.value); %ok
                                                %
                                                %                                                                                                             initial.frame_period_from_prairie = str2num(xml_file.PVStateShard{1,1}.PVStateValue{1,5}.ATTRIBUTE.value); %ok
                                                %
                                                %
                                                %
                                                
                                                
                                                %initial.date_time = xml_file.PVScan.Attributes.date; %ok
                                                
                                                if initial.date > 736520 && initial.date < 737780
                                                    
                                                    if initial.date <737110
                                                        initial.dwell_time_us = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,3}.Attributes.value)
                                                        initial.frame_period_from_prairie = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,4}.Attributes.value)
                                                        initial.magnification = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,13}.Attributes.value)
                                                        initial.microns_per_pixel = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,10}.IndexedValue{1,1}.Attributes.value)
                                                        initial.zoom = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,15}.Attributes.value)
                                                        initial.numerical_aperture = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,14}.Attributes.value)
                                                        initial.pixelsperline = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,16}.Attributes.value)
                                                        initial.linesperframe = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,8}.Attributes.value)
                                                        initial.pockels_power = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,6}.IndexedValue.Attributes.value)
                                                        initial.PMT_voltage_1 = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,17}.IndexedValue{1,1}.Attributes.value)
                                                        initial.PMT_voltage_2 = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,17}.IndexedValue{1,2}.Attributes.value)
                                                        initial.x_position = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,18}.SubindexedValues{1,1}.SubindexedValue.Attributes.value)
                                                        initial.y_position = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,18}.SubindexedValues{1,2}.SubindexedValue.Attributes.value)
                                                        initial.z_position = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,18}.SubindexedValues{1,3}.SubindexedValue.Attributes.value)
                                                        initial.scan_rotation = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,23}.Attributes.value)
                                                        
                                                    else
                                                        
                                                        initial.dwell_time_us = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,3}.Attributes.value)
                                                        initial.frame_period_from_prairie = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,4}.Attributes.value)
                                                        initial.magnification = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,13}.Attributes.value)
                                                        initial.microns_per_pixel = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,10}.IndexedValue{1,1}.Attributes.value)
                                                        initial.zoom = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,15}.Attributes.value)
                                                        initial.numerical_aperture = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,14}.Attributes.value)
                                                        initial.pixelsperline = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,16}.Attributes.value)
                                                        initial.linesperframe = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,8}.Attributes.value)
                                                        initial.pockels_power = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,6}.IndexedValue.Attributes.value)
                                                        initial.PMT_voltage_1 = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,17}.IndexedValue{1,1}.Attributes.value)
                                                        initial.PMT_voltage_2 = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,17}.IndexedValue{1,2}.Attributes.value)
                                                        initial.x_position = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,18}.SubindexedValues{1,1}.SubindexedValue.Attributes.value)
                                                        initial.y_position = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,18}.SubindexedValues{1,2}.SubindexedValue.Attributes.value)
                                                        if size(xml_file.PVScan.PVStateShard.PVStateValue{1,18}.SubindexedValues{1,3}.SubindexedValue,2)>1
                                                            initial.z_position = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,18}.SubindexedValues{1,3}.SubindexedValue{1,1}.Attributes.value)
                                                        else
                                                            initial.z_position = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,18}.SubindexedValues{1,3}.SubindexedValue.Attributes.value)
                                                        end
                                                        initial.scan_rotation = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,23}.Attributes.value)
                                                        
                                                    end
                                                    %
                                                    
                                                    %initial.wavelength = str2num(xml_file.PVStateShard{1,1}.PVStateValue{1,8}.IndexedValue{1,1}.ATTRIBUTE.value);
                                                    
                                                    
                                                    %             initial.PMT_preamp_gain_1 = str2num(xml_file.PVStateShard{1,1}.PVStateValue{1,22}.SubindexedValues{1,1}.SubindexedValue{1,1}.ATTRIBUTE.value);
                                                    %             initial.PMT_preamp_gain_2 = str2num(xml_file.PVStateShard{1,1}.PVStateValue{1,22}.SubindexedValues{1,1}.SubindexedValue{1,2}.ATTRIBUTE.value);
                                                    %
                                                    
                                                    %
                                                    %
                                                    %             initial.date_time = xml_file.ATTRIBUTE.date; %ok
                                                    %
                                                else
                                                    
                                                    if initial.date >736545
                                                        
                                                        
                                                        initial.dwell_time_us = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,3}.Attributes.value)
                                                        initial.frame_period_from_prairie = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,4}.Attributes.value)
                                                        initial.magnification = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,12}.Attributes.value)
                                                        initial.microns_per_pixel = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,9}.IndexedValue{1,1}.Attributes.value)
                                                        initial.zoom = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,14}.Attributes.value)
                                                        initial.numerical_aperture = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,13}.Attributes.value)
                                                        initial.pixelsperline = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,15}.Attributes.value)
                                                        initial.linesperframe = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,7}.Attributes.value)
                                                        initial.pockels_power = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,6}.IndexedValue.Attributes.value)
                                                        initial.PMT_voltage_1 = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,16}.IndexedValue{1,1}.Attributes.value)
                                                        initial.PMT_voltage_2 = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,16}.IndexedValue{1,2}.Attributes.value)
                                                        initial.x_position = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,17}.SubindexedValues{1,1}.SubindexedValue.Attributes.value)
                                                        initial.y_position = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,17}.SubindexedValues{1,2}.SubindexedValue.Attributes.value)
                                                        initial.z_position = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,17}.SubindexedValues{1,3}.SubindexedValue{1,1}.Attributes.value)
                                                        initial.scan_rotation = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,23}.Attributes.value)
                                                        
                                                        %initial.rotation = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,7}.Attributes.value)
                                                        
                                                        
                                                    else
                                                        
                                                        
                                                        initial.dwell_time_us = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,3}.Attributes.value)
                                                        initial.frame_period_from_prairie = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,4}.Attributes.value)
                                                        initial.magnification = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,12}.Attributes.value)
                                                        initial.microns_per_pixel = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,9}.IndexedValue{1,1}.Attributes.value)
                                                        initial.zoom = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,14}.Attributes.value)
                                                        initial.numerical_aperture = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,13}.Attributes.value)
                                                        initial.pixelsperline = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,15}.Attributes.value)
                                                        initial.linesperframe = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,7}.Attributes.value)
                                                        initial.pockels_power = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,6}.IndexedValue.Attributes.value)
                                                        initial.PMT_voltage_1 = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,16}.IndexedValue{1,1}.Attributes.value)
                                                        initial.PMT_voltage_2 = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,16}.IndexedValue{1,2}.Attributes.value)
                                                        initial.x_position = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,17}.SubindexedValues{1,1}.SubindexedValue.Attributes.value)
                                                        initial.y_position = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,17}.SubindexedValues{1,2}.SubindexedValue.Attributes.value)
                                                        initial.z_position = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,17}.SubindexedValues{1,3}.SubindexedValue.Attributes.value)
                                                        initial.scan_rotation = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,23}.Attributes.value)
                                                        
                                                        
                                                        %                                                                         initial.microns_per_pixel = str2num(xml_file.PVScan.Sequence.Frame{1,1}.PVStateShard.Key{1,17}.Attributes.value); %ok
                                                        %                                                                         initial.magnification = str2num(xml_file.PVScan.Sequence.Frame{1,1}.PVStateShard.Key{1,3}.Attributes.value); %ok
                                                        %                                                                         initial.pixelsperline = str2num(xml_file.PVScan.Sequence.Frame{1,1}.PVStateShard.Key{1,4}.Attributes.value);%ok
                                                        %                                                                         initial.linesperframe = str2num(xml_file.PVScan.Sequence.Frame{1,1}.PVStateShard.Key{1,5}.Attributes.value);%ok
                                                        %                                                                         initial.zoom = str2num(xml_file.PVScan.Sequence.Frame{1,1}.PVStateShard.Key{1,16}.Attributes.value); %ok
                                                        %                                                                         initial.numerical_aperture = str2num(xml_file.PVScan.Sequence.Frame{1,1}.PVStateShard.Key{1,2}.Attributes.value); %ok
                                                        %                                                                         initial.dwell_time_us = str2num(xml_file.PVScan.Sequence.Frame{1,1}.PVStateShard.Key{1,9}.Attributes.value); %ok
                                                        %                                                                        initial.pockels_power = str2num(xml_file.PVScan.Sequence.Frame{1,1}.PVStateShard.Key{1,21}.Attributes.value); %ok
                                                        %                                                                         initial.x_position = str2num(xml_file.PVScan.Sequence.Frame{1,1}.PVStateShard.Key{1,11}.Attributes.value); %ok
                                                        %                                                                         initial.y_position = str2num(xml_file.PVScan.Sequence.Frame{1,1}.PVStateShard.Key{1,12}.Attributes.value); %ok
                                                        %                                                                         initial.z_position = str2num(xml_file.PVScan.Sequence.Frame{1,1}.PVStateShard.Key{1,13}.Attributes.value); %ok
                                                        %                                                                         initial.PMT_voltage_1 = str2num(xml_file.PVScan.Sequence.Frame{1,1}.PVStateShard.Key{1,19}.Attributes.value); %ok
                                                        %                                                                         initial.PMT_voltage_2 = str2num(xml_file.PVScan.Sequence.Frame{1,1}.PVStateShard.Key{1,20}.Attributes.value); %ok
                                                        %                                                                         %             initial.PMT_preamp_gain_1 = str2num(xml_file.PVScan.Sequence.Frame{1,1}.PVStateShard.Key{1,20}.Attributes.value); %ok
                                                        %                                                                         %             initial.PMT_preamp_gain_2 = str2num(xml_file.PVScan.Sequence.Frame{1,1}.PVStateShard.Key{1,21}.Attributes.value); %ok
                                                        %                                                                         initial.scan_rotation = str2num(xml_file.PVScan.Sequence.Frame{1,1}.PVStateShard.Key{1,15}.Attributes.value); %ok
                                                        %                                                                         initial.frame_period_from_prairie = str2num(xml_file.PVScan.Sequence.Frame{1,1}.PVStateShard.Key{1,7}.Attributes.value); %ok
                                                    end
                                                end
                                                
                                                
                                                %
                                                %         else
                                                %
                                                %                                 %
                                                %
                                                %                                                                                                             initial.date_time = xml_file.ATTRIBUTE.date;
                                                %
                                                %                                                                                                             initial.microns_per_pixel = str2num(xml_file.Sequence{1,1}.Frame{1,1}.PVStateShard{1,1}.Key{1,21}.ATTRIBUTE.value);
                                                %
                                                %                                                                                                             initial.magnification = str2num(xml_file.Sequence{1,1}.Frame{1,1}.PVStateShard{1,1}.Key{1,5}.ATTRIBUTE.value);
                                                %
                                                %                                                                                                             initial.pixelsperline = str2num(xml_file.Sequence{1,1}.Frame{1,1}.PVStateShard{1,1}.Key{1,6}.ATTRIBUTE.value);
                                                %
                                                %                                                                                                             initial.linesperframe = str2num(xml_file.Sequence{1,1}.Frame{1,1}.PVStateShard{1,1}.Key{1,7}.ATTRIBUTE.value);
                                                %
                                                %                                                                                                             initial.zoom = str2num(xml_file.Sequence{1,1}.Frame{1,1}.PVStateShard{1,1}.Key{1,20}.ATTRIBUTE.value);
                                                %
                                                %                                                                                                             initial.numerical_aperture = str2num(xml_file.Sequence{1,1}.Frame{1,1}.PVStateShard{1,1}.Key{1,4}.ATTRIBUTE.value);
                                                %
                                                %                                                                                                             initial.dwell_time_us = str2num(xml_file.Sequence{1,1}.Frame{1,1}.PVStateShard{1,1}.Key{1,13}.ATTRIBUTE.value);
                                                %
                                                %                                                                                                             initial.pockels_power = str2num(xml_file.Sequence{1,1}.Frame{1,1}.PVStateShard{1,1}.Key{1,25}.ATTRIBUTE.value);
                                                %
                                                %                                                                                                             initial.x_position = str2num(xml_file.Sequence{1,1}.Frame{1,1}.PVStateShard{1,1}.Key{1,15}.ATTRIBUTE.value);
                                                %
                                                %                                                                                                             initial.y_position = str2num(xml_file.Sequence{1,1}.Frame{1,1}.PVStateShard{1,1}.Key{1,16}.ATTRIBUTE.value);
                                                %
                                                %                                                                                                             initial.z_position = str2num(xml_file.Sequence{1,1}.Frame{1,1}.PVStateShard{1,1}.Key{1,17}.ATTRIBUTE.value);
                                                %
                                                %                                                                                                             initial.PMT_voltage_1 = str2num(xml_file.Sequence{1,1}.Frame{1,1}.PVStateShard{1,1}.Key{1,23}.ATTRIBUTE.value);
                                                %
                                                %                                                                                                             initial.PMT_voltage_2 = str2num(xml_file.Sequence{1,1}.Frame{1,1}.PVStateShard{1,1}.Key{1,24}.ATTRIBUTE.value);
                                                %
                                                %                                                                                                             initial.PMT_preamp_gain_1 = str2num(xml_file.Sequence{1,1}.Frame{1,1}.PVStateShard{1,1}.Key{1,33}.ATTRIBUTE.value);
                                                %
                                                %                                                                                                             initial.PMT_preamp_gain_2 = str2num(xml_file.Sequence{1,1}.Frame{1,1}.PVStateShard{1,1}.Key{1,34}.ATTRIBUTE.value);
                                                %
                                                %                                                                                                             initial.scan_rotation = str2num(xml_file.Sequence{1,1}.Frame{1,1}.PVStateShard{1,1}.Key{1,15}.ATTRIBUTE.value);
                                                %
                                                %                                                                                                             initial.frame_period_from_prairie = str2num(xml_file.Sequence{1,1}.Frame{1,1}.PVStateShard{1,1}.Key{1,11}.ATTRIBUTE.value);
                                                %                                                                                                             %                   %  end
                                                %                                     %                 %             %
                                                %                 %                 %             %
                                                % %                 %                 %             %
                                                % %                 %                 %
                                                %                                     % %
                                                %
                                                %                                                                                                             initial.date_time = xml_file.ATTRIBUTE.date;
                                                %
                                                %                                                                                                             initial.microns_per_pixel = str2num(xml_file.Sequence{1,1}.Frame{1,1}.PVStateShard{1,1}.Key{1,21}.ATTRIBUTE.value);
                                                %
                                                %                                                                                                             initial.magnification = str2num(xml_file.Sequence{1,1}.Frame{1,1}.PVStateShard{1,1}.Key{1,5}.ATTRIBUTE.value);
                                                %
                                                %                                                                                                             initial.pixelsperline = str2num(xml_file.Sequence{1,1}.Frame{1,1}.PVStateShard{1,1}.Key{1,6}.ATTRIBUTE.value);
                                                %
                                                %                                                                                                             initial.linesperframe = str2num(xml_file.Sequence{1,1}.Frame{1,1}.PVStateShard{1,1}.Key{1,7}.ATTRIBUTE.value);
                                                %
                                                %                                                                                                             initial.zoom = str2num(xml_file.Sequence{1,1}.Frame{1,1}.PVStateShard{1,1}.Key{1,20}.ATTRIBUTE.value);
                                                %
                                                %                                                                                                             initial.numerical_aperture = str2num(xml_file.Sequence{1,1}.Frame{1,1}.PVStateShard{1,1}.Key{1,4}.ATTRIBUTE.value);
                                                %
                                                %                                                                                                             initial.dwell_time_us = str2num(xml_file.Sequence{1,1}.Frame{1,1}.PVStateShard{1,1}.Key{1,13}.ATTRIBUTE.value);
                                                %
                                                %                                                                                                             initial.pockels_power = str2num(xml_file.Sequence{1,1}.Frame{1,1}.PVStateShard{1,1}.Key{1,25}.ATTRIBUTE.value);
                                                %
                                                %                                                                                                             initial.x_position = str2num(xml_file.Sequence{1,1}.Frame{1,1}.PVStateShard{1,1}.Key{1,15}.ATTRIBUTE.value);
                                                %
                                                %                                                                                                             initial.y_position = str2num(xml_file.Sequence{1,1}.Frame{1,1}.PVStateShard{1,1}.Key{1,16}.ATTRIBUTE.value);
                                                %
                                                %                                                                                                             initial.z_position = str2num(xml_file.Sequence{1,1}.Frame{1,1}.PVStateShard{1,1}.Key{1,17}.ATTRIBUTE.value);
                                                %
                                                %                                                                                                             initial.PMT_voltage_1 = str2num(xml_file.Sequence{1,1}.Frame{1,1}.PVStateShard{1,1}.Key{1,23}.ATTRIBUTE.value);
                                                %
                                                %                                                                                                             initial.PMT_voltage_2 = str2num(xml_file.Sequence{1,1}.Frame{1,1}.PVStateShard{1,1}.Key{1,24}.ATTRIBUTE.value);
                                                %
                                                %                                                                                                             initial.PMT_preamp_gain_1 = str2num(xml_file.Sequence{1,1}.Frame{1,1}.PVStateShard{1,1}.Key{1,33}.ATTRIBUTE.value);
                                                %
                                                %                                                                                                             initial.PMT_preamp_gain_2 = str2num(xml_file.Sequence{1,1}.Frame{1,1}.PVStateShard{1,1}.Key{1,34}.ATTRIBUTE.value);
                                                %
                                                %                                                                                                             initial.scan_rotation = str2num(xml_file.Sequence{1,1}.Frame{1,1}.PVStateShard{1,1}.Key{1,15}.ATTRIBUTE.value);
                                                %
                                                %                                                                                                             initial.frame_period_from_prairie = str2num(xml_file.Sequence{1,1}.Frame{1,1}.PVStateShard{1,1}.Key{1,11}.ATTRIBUTE.value);
                                                %
                                                %
                                                %                 %
                                                %
                                                
                                            end
                                            % end
                                            
                                        end
                                    else
                                        if initial.xml_file_corrupt
                                            initial.zoom = str2num(xml_file.PVStateShard{1,1}.Key{1,8}.ATTRIBUTE.value);
                                            initial.date_time = initial.xml_file_aux.ATTRIBUTE.date;
                                            initial.microns_per_pixel = str2num(xml_file.PVStateShard{1,1}.Key{1,53}.ATTRIBUTE.value);
                                            initial.magnification = str2num(xml_file.PVStateShard{1,1}.Key{1,33}.ATTRIBUTE.value);
                                            initial.numerical_aperture = str2num(xml_file.PVStateShard{1,1}.Key{1,41}.ATTRIBUTE.value);
                                            initial.dwell_time_us = str2num(xml_file.PVStateShard{1,1}.Key{1,51}.ATTRIBUTE.value);
                                            initial.pockels_power = str2num(xml_file.PVStateShard{1,1}.Key{1,205}.ATTRIBUTE.value);
                                            initial.x_position = str2num(xml_file.PVStateShard{1,1}.Key{1,222}.ATTRIBUTE.value);
                                            initial.y_position = str2num(xml_file.PVStateShard{1,1}.Key{1,4}.ATTRIBUTE.value);
                                            initial.z_position = str2num(xml_file.PVStateShard{1,1}.Key{1,166}.ATTRIBUTE.value);
                                            initial.PMT_voltage_1 = str2num(xml_file.PVStateShard{1,1}.Key{1,42}.ATTRIBUTE.value);
                                            initial.PMT_voltage_2 = str2num(xml_file.PVStateShard{1,1}.Key{1,43}.ATTRIBUTE.value);
                                            initial.PMT_preamp_gain_1 = str2num(xml_file.PVStateShard{1,1}.Key{1,139}.ATTRIBUTE.value);
                                            initial.PMT_preamp_gain_2 = str2num(xml_file.PVStateShard{1,1}.Key{1,112}.ATTRIBUTE.value);
                                            initial.scan_rotation = str2num(xml_file.PVStateShard{1,1}.Key{1,227}.ATTRIBUTE.value);
                                            initial.frame_rate_hz = str2num(xml_file.PVStateShard{1,1}.Key{1,24}.ATTRIBUTE.value);
                                        else
                                            initial.date_time = xml_file.ATTRIBUTE.date;
                                            initial.microns_per_pixel = str2num(xml_file.PVScan.Sequence.Frame{1,1}.PVStateShard.Key{1,19}.Attributes.value);
                                            initial.magnification = str2num(xml_file.PVScan.Sequence.Frame{1,1}.PVStateShard.Key{1,5}.Attributes.value);
                                            initial.zoom = str2num(xml_file.PVScan.Sequence.Frame{1,1}.PVStateShard.Key{1,18}.Attributes.value);
                                            initial.numerical_aperture = str2num(xml_file.PVScan.Sequence.Frame{1,1}.PVStateShard.Key{1,4}.Attributes.value);
                                            initial.dwell_time_us = str2num(xml_file.PVScan.Sequence.Frame{1,1}.PVStateShard.Key{1,11}.Attributes.value);
                                            initial.pockels_power = str2num(xml_file.PVScan.Sequence.Frame{1,1}.PVStateShard.Key{1,23}.Attributes.value);
                                            initial.x_position = str2num(xml_file.PVScan.Sequence.Frame{1,1}.PVStateShard.Key{1,13}.Attributes.value);
                                            initial.y_position = str2num(xml_file.PVScan.Sequence.Frame{1,1}.PVStateShard.Key{1,14}.Attributes.value);
                                            initial.z_position = str2num(xml_file.PVScan.Sequence.Frame{1,1}.PVStateShard.Key{1,15}.Attributes.value);
                                            initial.PMT_voltage_1 = str2num(xml_file.PVScan.Sequence.Frame{1,1}.PVStateShard.Key{1,21}.Attributes.value);
                                            initial.PMT_voltage_2 = str2num(xml_file.PVScan.Sequence.Frame{1,1}.PVStateShard.Key{1,22}.Attributes.value);
                                            initial.PMT_preamp_gain_1 = str2num(xml_file.PVScan.Sequence.Frame{1,1}.PVStateShard.Key{1,32}.Attributes.value);
                                            initial.PMT_preamp_gain_2 = str2num(xml_file.PVScan.Sequence.Frame{1,1}.PVStateShard.Key{1,33}.Attributes.value);
                                            initial.scan_rotation = str2num(xml_file.PVScan.Sequence.Frame{1,1}.PVStateShard.Key{1,17}.Attributes.value);
                                            initial.frame_period = str2num(xml_file.PVScan.Sequence.Frame{1,1}.PVStateShard.Key{1,9}.Attributes.value);
                                        end
                                    end
                                end
                            end
                        end
                    end
                end
            end
        end
    end
end







%PV_version = xml_file.PVScan.Attributes.version
results.slow_frames = 0;
if initial.datedr(1,iii)
    if initial.heka_or_winedr(1,iii)
        if initial.date<73584 || initial.date > 744000
            if isfield(initial, 'triggersync_hz') == 0
                if isfield(initial,'rawData2')
                    initial.triggersync_hz = initial.rawData2(1,1);
                    initial.sampl_fr = initial.rawData2(1,1);
                end
            end
        else
            initial.triggersync_hz = 1000/initial.rawData2(2,1);
            initial.sampl_fr =1000/initial.rawData2(2,1);
        end
        initial.sampl_fr = initial.triggersync_hz;
        if size(initial.rawData2,1) == 1
            samples = size(initial.voltage_trace,1);
        else
            samples = size(initial.rawData2,1);
        end
    else
        samples =length(initial.rawData2)% initial.samples;
        initial.sampl_fr = double(1/(initial.rawData2(samples,1)/samples));
    end
    initial.trig_factor = 1000/initial.triggersync_hz;
    trig_factor = initial.trig_factor;
    
end

if initial.no_imaging(1,iii)==0
    if initial.linescan ==0
        %clear image_frame image_frame_time
        if  initial.datedr(1,iii) == 0 % || size(initial.rawData2,2)<7 %initial.old_file(1,iii) || initial.datedr(1,iii) == 0
            if initial.no_imaging(1,iii)==1
            else
                if initial.xml_file_corrupt ==0
                    if initial.tif_or_txt
                        framenum = initial.max_frame;
                    else
                        framenum = size(initial.calciumsignal.data,1);
                    end
                    
                    if initial.date>730000
                        
                        for i = 1:framenum
                            frame_times(i) = str2num(xml_file.PVScan.Sequence(1,1).Frame{1,i}.Attributes.relativeTime);
                        end
                    else
                        for i = 1:framenum
                            frame_times(i) = str2num(xml_file.Sequence{1,1}.Frame{1,i}.ATTRIBUTE.relativeTime);
                        end
                    end
                    initial.frame_times = frame_times;
                    initial.msperline = 1000*(frame_times(end)-frame_times(1,1))/framenum;
                else
                    framenum = initial.max_frame;
                    if initial.BOT
                        for i = 1:framenum
                            frame_times(i) = (i-1)*str2num(xml_file.TSeries{1,1}.PVTSeriesElementSequenceBOT{1,1}.ATTRIBUTE.repetitionPeriod)+...
                                str2num(xml_file.TSeries{1,1}.PVTSeriesElementSequenceBOT{1,1}.ATTRIBUTE.repetitionPeriod)/2;
                        end
                    else
                        
                        for i = 1:framenum
                            frame_times(i) = (i-1)*str2num(xml_file.TSeries{1,1}.PVTSeriesElementSequenceTimed{1,1}.ATTRIBUTE.repetitionPeriod)+...
                                str2num(xml_file.TSeries{1,1}.PVTSeriesElementSequenceTimed{1,1}.ATTRIBUTE.repetitionPeriod)/2;
                        end
                    end
                    initial.framenum = framenum;
                    initial.frame_times = round(frame_times*1000/initial.trig_factor);
                    image_frame_time = frame_times;
                    initial.image_frame_time = image_frame_time;
                end
            end
            
            %
            %         if initial.datedr
            %             for i = 1: framenum-1
            %                 image_frame_time(i) = round((str2num(xml_file.Sequence{1,1}.Frame{1,i+1}.ATTRIBUTE.relativeTime)+str2num(xml_file.Sequence{1,1}.Frame{1,i}.ATTRIBUTE.relativeTime))*initial.sampl_fr/2);
            %                 image_frame(image_frame_time(i)) = 1;
            %             end
            %             image_frame_time(i+1) = str2num(xml_file.Sequence{1,1}.Frame{1,i}.ATTRIBUTE.relativeTime)+...
            %                 round((str2num(xml_file.Sequence{1,1}.Frame{1,i}.ATTRIBUTE.relativeTime)-str2num(xml_file.Sequence{1,1}.Frame{1,i-1}.ATTRIBUTE.relativeTime))*initial.sampl_fr/2);
            %             initial.image_frame = image_frame;
            %             initial.image_frame_time = image_frame_time;
            %             initial.trig_factor = 1000/initial.triggersync_hz;
            %
            %         end
            
        else
            if size(initial.rawData2,2)>6 || size(initial.rawData2,2) == 3
                if initial.spiral_scan(1,iii) == 0
                    
                    if isfield(initial, 'slow_galvo') == 0
                        if initial.heka_or_winedr(1,iii)
                            if onep
                                initial.galvo_1 = initial.rawData2(1:samples,5);
                            else
                                
                                if strcmp(xml_file.PVScan.Attributes.version,'5.3.64.400')
                                    if fr_tr_PV
                                        initial.galvo_1 = initial.rawData2(1:samples,4);
                                    else
                                        
                                        initial.galvo_1 = initial.rawData2(1:samples,5);
                                    end
                                else
                                    
                                    if initial.date < 738820 && initial.date > 736500
                                        initial.galvo_1 = initial.rawData2(1:samples,5);
                                    else
                                        if   strcmp(xml_file.PVScan.Attributes.version,'5.1.64.100')
                                            initial.galvo_1 = initial.rawData2(1:samples,5);
                                        else
                                            
                                            if strcmp(xml_file.PVScan.Attributes.version, '5.2.64.300')
                                                initial.galvo_1 = initial.rawData2(1:samples,2);
                                            else
                                                if initial.date<73584 || initial.date > 735000
                                                    initial.galvo_1 = initial.rawData2(1:samples,4);
                                                else
                                                    if size(initial.rawData2,2)==7
                                                        initial.galvo_1 = initial.rawData2(1:samples,4);
                                                    else
                                                        initial.galvo_1 = initial.rawData2(1:samples,5);
                                                    end
                                                end
                                            end
                                        end
                                    end
                                end
                            end
                        else
                            if initial.NB208
                                initial.galvo_1 = initial.rawData2(2:samples,5);
                            else
                                initial.galvo_1 = initial.rawData2(2:samples,4);
                            end
                        end
                    else
                        if isfield(initial, 'slow_galvo')
                            initial.galvo_1 = initial.slow_galvo;
                        end
                    end
                    %         initial.fast_galvo = initial.rawData2(2:samples,5);
                    
                    initial.trig_factor = 1000/initial.triggersync_hz;
                    
                    if onep
                        if initial.heka_or_winedr(1,iii)
                            galvo_thr = 1.5
                        else
                            galvo_thr = 1500;
                        end
                    else
                        if initial.heka_or_winedr(1,iii)
                            galvo_thr = 0.028; %was 0.034 20230323 JM
                        else
                            galvo_thr = 9.2;
                        end
                    end
                    
                    %find image frame times
                    clear mirror_frame_start mirror_start_time
                    x=1;
                    i=1;
                    
                    
                    if onep
                        if onep_only_first_and_last
                            
                            i=2
                            x=1
                            if initial.date>737348
                                t5 = 2
                            else
                                t5 = 1400
                            end
                            
                            while i<samples-401
                                if initial.galvo_1(i,1)<initial.galvo_1(i+2,1)-t5
                                    mirror_frame_start(i+1,1) = 10;
                                    mirror_start_time(x,1) = i+1;
                                    i = samples-402;
                                    io = mirror_start_time(1,1);
                                else
                                    i=i+1;
                                end
                            end
                            
                            i = samples-2
                            
                            while i>2
                                if initial.galvo_1(i-2,1)>initial.galvo_1(i,1)+t5
                                    mirror_start_time(onep_only_first_and_last,1) = i-1;
                                    tot_length = mirror_start_time(onep_only_first_and_last,1) - mirror_start_time(1,1);
                                    one_frame = tot_length/onep_only_first_and_last;
                                    i=1;
                                    
                                else
                                    i=i-1;
                                end
                            end
                            for g = 1:onep_only_first_and_last-1
                                mirror_frame_start(io+round(one_frame*g),1) = 10;
                                mirror_start_time(g+1,1) = io+round(one_frame*g);
                            end
                            
                            
                            
                        else
                            i = 50
                            
                            x=1;
                            i=50
                            
                            while i<samples-401
                                if (initial.galvo_1(i,1)<initial.galvo_1(i+2,1)-galvo_thr)
                                    mirror_frame_start(i+2,1) = 10;
                                    mirror_start_time(x,1) = i+2;
                                    x=x+1;
                                    i =  i+round(3*initial.sampl_fr/1000);
                                else
                                    i = i+1;
                                end
                            end
                            
                        end
                        
                    else
                        if initial.galvo_1(1,1)>-1.31
                            mirror_frame_start(1) = 10;
                            mirror_start_time(1) = 1;
                            x = 2;
                            i = 50;
                            while i<samples-401
                                if (initial.galvo_1(i,1)<initial.galvo_1(i+5,1)-galvo_thr) && (mean(initial.galvo_1(i+10:i+15,1))...
                                        -mean(initial.galvo_1(i-20:i-4,1))>galvo_thr/1.3)
                                    mirror_frame_start(i+2) = 10;
                                    mirror_start_time(x,1) = i+2;
                                    x=x+1;
                                    i =  i+round(15*initial.sampl_fr/1000);
                                else
                                    i = i+1;
                                end
                            end
                            
                        else
                            i = 50
                            if initial.heka_or_winedr(1,iii)
                                mirror_frame_start(1) = 10;
                                mirror_start_time(1) = 1;
                                x = 2;
                            else
                                x=1;
                                i=50
                            end
                            while i<samples-401
                                if (initial.galvo_1(i,1)<initial.galvo_1(i+5,1)-galvo_thr) && ...
                                        (mean(initial.galvo_1(i-51:i-28,1))...
                                        <initial.galvo_1(i+3,1) - galvo_thr/4)
                                    mirror_frame_start(i+2,1) = 10;
                                    mirror_start_time(x,1) = i+2;
                                    x=x+1;
                                    i =  i+round(15*initial.sampl_fr/1000);
                                else
                                    i = i+1;
                                end
                            end
                        end
                    end
                    
                    if onep
                        initial.date = initial.Stack_ch2(1).datenum;
                    end
                    
                    if avg_2_fr(1,iii) || (initial.date<73584 || initial.date>740000)
                        if initial.rastersperframe == 2 % str2num(xml_file.PVScan.PVStateShard.PVStateValue{1, 21}.Attributes.value)==2
                            %str2num(xml_file.Sequence{1,1}.Frame{1,1}.PVStateShard{1,1}.Key{1,9}.ATTRIBUTE.value)==2
                            
                            a=1;
                            for i = 1: length(mirror_frame_start)
                                if mirror_frame_start(i)
                                    if mod(a,2)==0
                                        mirror_frame_start(i) = 0;
                                    end
                                    a=a+1;
                                end
                            end
                            
                            for i = 2:2:length(mirror_start_time)
                                mirror_start_time(i) = 0;
                            end
                            
                            mirror_start_time(find(mirror_start_time==0)) = [];
                            
                            
                            initial.mirror_frame_start = mirror_frame_start;
                            initial.mirror_start_time = mirror_start_time;
                            initial.diff_mirror_start_time = diff(mirror_start_time);
                        end
                    else
                        
                        
                        initial.mirror_frame_start = mirror_frame_start;
                        initial.mirror_start_time = mirror_start_time;
                        initial.diff_mirror_start_time = diff(mirror_start_time);
                    end
                    
                    
                    image_frame_duration = (mirror_start_time(length(mirror_start_time),1)-mirror_start_time(1,1))/(length(mirror_start_time)-1);
                    initial.msperline = image_frame_duration*initial.trig_factor;
                    mirror_start_time = mirror_start_time';
                    for i = 1: length(mirror_start_time)
                        %i
                        image_frame_time(i,1) = round(mirror_start_time(1,i)+image_frame_duration/2);
                        image_frame(image_frame_time(i,1),1) = 1;
                    end
                    initial.frame_times = image_frame_time;
                    initial.image_frame = image_frame;
                    
                else
                    forww=0;
                    if initial.NB208 && size(initial.rawData2,2)<=5
                        initial.galvo_1 = initial.rawData2(:,2);
                        %thr=1.1
                        forww = initial.frame_period_from_prairie;
                    else
                        if initial.date > 736500
                            
                            if   initial.date<737550
                                thr=0.89;
                            else
                                thr=0.89;
                            end
                            initial.galvo_1 =  initial.rawData2(:,5);
                            if initial.xml_file_corrupt
                                forww = 0;
                            else
                                forww = initial.frame_period_from_prairie; % str2double(xml_file.PVScan.PVStateShard.PVStateValue{1, 24}.Attributes.value);
                            end
                        else
                            if initial.date<735545 &&initial.date>730030 %|| initial.heka_or_winedr(1,iii) == 0
                                initial.galvo_1 = initial.rawData2(:,4);
                            else
                                initial.galvo_1 = initial.rawData2(:,4);
                            end
                            %thr=500
                            forww = initial.frame_period_from_prairie;
                        end
                    end
                    %         initial.fast_galvo = initial.rawData2(2:samples,5);
                    ogf = 76*initial.sampl_fr;
                    ogp = 78*initial.sampl_fr;
                    dop = max(initial.galvo_1(ogf:ogp,1));
                    dog = min(initial.galvo_1(ogf:ogp,1));
                    
                    thr = (dop-dog)*0.4 %was 0.45
                    
                    if forww>0 && forww < 2
                        forww=round((0.89*forww)*initial.sampl_fr)
                    end
                    initial.trig_factor = 1000/initial.triggersync_hz;
                    initial.galvo_1 = initial.galvo_1 - mean(initial.galvo_1(900000:950000,1));
                    %find image frame times
                    clear mirror_frame_start mirror_start_time
                    
                    x=1;
                    i=1;
                    
                    
                    %i = round(20*initial.sampl_fr/1000);
                    if initial.heka_or_winedr(1,iii)
                        mirror_frame_start(1) = 100;
                        mirror_start_time(1) = 1;
                        i =  i+forww; %round((0.7*forww)*initial.sampl_fr/1000)%round(15*initial.sampl_fr/1000);
                    else
                        i = 5;
                        while abs(initial.galvo_1(i)-initial.galvo_1(i-2))<thr
                            i = i+1;
                        end
                        x = i
                        mirror_frame_start(x) = 100;   %change this according to specific recording
                        mirror_start_time(1) = x;
                        if forww
                            i = i+forww; %round((0.75*forww)*initial.sampl_fr/1000)
                        else
                            i = i+round(29*initial.sampl_fr/1000);
                        end
                    end
                    x = 2;
                    
                    fps = round(9*initial.sampl_fr/10000)  %was 7 08/29/2021
                    while i<length(initial.galvo_1)-100  %change this according to specific recording
                        if (initial.galvo_1(i,1)<initial.galvo_1(i+fps,1)-thr) && (sum(abs(initial.galvo_1(i-95:i-15,1)))...
                                <39*thr)
                            mirror_frame_start(i-1) = 100;
                            mirror_start_time(x) = i-1;
                            x=x+1;
                            if forww
                                i = i+forww; %round((0.75*forww)*initial.sampl_fr/1000)
                            else
                                i = i+round(29*initial.sampl_fr/1000);
                            end
                        else
                            i = i+1;
                        end
                    end
                    diff_mirror_start_time = diff(mirror_start_time);
                    
                    avg_fr = mean(diff_mirror_start_time(1,1:100));
                    u = 1
                    while u < length(diff_mirror_start_time)
                        if diff_mirror_start_time(1,u) > 3*avg_fr
                            framenum = u-1;
                            initial.numerofframes = u-1;
                            initial.numberofframes = u-1;
                            initial.max_frame = u-1;
                            initiala.numerofframes = u-1;
                            initiala.numberofframes = u-1;
                            initiala.max_frame = u-1;
                            u=1e8;
                        end
                        u=u+1
                    end
                    
                    initial.mirror_frame_start = 0;
                    initial.mirror_start_time = 0;
                    initial.mirror_frame_start = mirror_frame_start;
                    initial.mirror_start_time = mirror_start_time;
                    initial.diff_mirror_start_time = diff(mirror_start_time);
                    initial.frame_times = 0;
                    initial.image_frame = 0;
                    
                    image_frame_duration = (mirror_start_time(size(mirror_start_time,2))-mirror_start_time(1))/(size(mirror_start_time,2)-1);
                    initial.msperline = image_frame_duration*initial.trig_factor;
                    %clear  image_frame_time image frame
                    for i = 1: length(mirror_start_time)
                        image_frame_time(i) = round(mirror_start_time(i)+image_frame_duration/2);
                        image_frame(image_frame_time(i)) = 100;
                    end
                    initial.frame_times = image_frame_time;
                    initial.image_frame = image_frame;
                    
                end
                
            else
                %use xml file for frame times
                
                framenum = initial.numberofframes;
                %                     if initial.BOT
                %                         for i = 1:framenum
                %                             frame_times(i) = (i-1)*str2num(xml_file.TSeries{1,1}.PVTSeriesElementSequenceBOT{1,1}.ATTRIBUTE.repetitionPeriod)+...
                %                                 str2num(xml_file.TSeries{1,1}.PVTSeriesElementSequenceBOT{1,1}.ATTRIBUTE.repetitionPeriod)/2;
                %                         end
                %                     else
                
                if strcmp (xml_file.PVScan.Attributes.version,'5.1.64.100')
                    
                    frat = str2num(xml_file.PVScan.Sequence.Frame{1, 1000}.Attributes.relativeTime)/1000;
                    
                else
                    
                    frat = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,6}.Attributes.value);
                    
                end
                
                for i = 1:framenum
                    frame_times(i) = (i-1)*frat+...
                        frat/2;
                    
                    %str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,6}.Attributes.value)
                    
                end
                initial.msperline = 1000*(frame_times(framenum)/framenum);
                %end
                initial.framenum = framenum;
                initial.frame_times = round(frame_times*1000/initial.trig_factor);
                image_frame_time = frame_times;
                mirror_start_time = image_frame_time -  round(1000*(frat/(2*initial.trig_factor)));
                initial.image_frame_time = image_frame_time;
                initial.diff_mirror_start_time = diff(image_frame_time);
            end
            
            if initial.xml_file_corrupt && onep==0
                initial.diff_mirror_start_time = diff(image_frame_time);
            end
            
            
            figure(9899)
            plot (initial.diff_mirror_start_time)
            if spof
                saveas (9899,[Folder ' diff_mirror_start_time ' '.eps' ],'eps')
            end
        end
        
    else
        
        frame_start_ms(1) = 1;
        for i = 2:initial.max_frame
            frame_start_ms(i) = 1000*str2num(xml_file.Sequence{1,1}.Frame{1,i}.ATTRIBUTE.relativeTime);
        end
        
        initial.msperline = frame_start_ms(max_frame-1)/((max_frame-1)*initial.height);
        
    end
    
    if initial.old_file && initial.xml_file_corrupt
        initial.numberofframes = initial.framenum;
        initial.max_frame = initial.framenum;
    else
        if initial.old_file == 0 && initial.datedr(1,iii)
            initial.numberofframes = size(mirror_start_time,2);
            initial.max_frame = size(mirror_start_time,2);
        end
    end
    
    initial.samplingratehz = 1000/initial.msperline;
    
    if initial.linescan ==0
        
        if initial.xml_file_corrupt ==0 && initial.datedr(1,iii) && initial.old_file == 0
            if initial.tif_or_txt
                framenum = initial.max_frame;
            else
                Name2 = dir(strcat(Folder,'\Ti*.txt'));
                txtFileName = Name2.name
                cd(Folder)
                initial.calciumsignal =  importdata(txtFileName, '\t', 1);
                framenum = size(initial.calciumsignal.data,1);
            end
            %
            %     for i = 1:framenum
            %         frame_times(i) = str2num(xml_file.Sequence{1,1}.Frame{1,i}.ATTRIBUTE.relativeTime);
            %     end
            %initial.frame_times = frame_times;
            
            
            
            frame_times_diff = diff(diff(initial.frame_times));
            
            results.slow_frames = 0;
            results.slow_frame_vector = 0;
            results.number_slow_frames = 0;
            x = 1;
            
            if framenum>size(image_frame_time,2)
                fr = size(image_frame_time,2);
            else
                fr = framenum;
            end
            
            for i = 1:fr-2
                if abs(frame_times_diff(i))>1
                    results.slow_frame_vector(i) = 1;
                    results.slow_frames(x) = i;
                    results.number_slow_frames = results.number_slow_frames + 1;
                    x = x+1;
                end
            end
            
        else
            if initial.xml_file_corrupt
                results.xml_corrupt = 1;
            else
                results.old_file = 1;
            end
        end
    end
    
    
    initial.samplingratehz = (1000/initial.msperline);
    initial.numerofframes = framenum;
    
    initial.movielengthsec = (initial.msperline*initial.numberofframes)/1000;
    initial.tau = 1;
    movie = 1;
    %moviename = initial.moviename;
    initial.numberofmovies = 1;
else
    results=0;
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Hier bleibt
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% er immer
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% haengen!

%
% if initial.no_imaging(1,iii) ==1 || onep ||initial.xml_file_corrupt
% else
%
%     if strcmp(xml_file.PVScan.Attributes.version, '5.4.64.74') || strcmp(xml_file.PVScan.Attributes.version, '5.4.64.100')
%
%
%         initial.dwell_time_us = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,5}.Attributes.value)
%         initial.frame_period_from_prairie = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,6}.Attributes.value)
%         initial.pockels_power = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,8}.IndexedValue{1, 1}.Attributes.value  )
%         initial.linesperframe = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1, 10}.Attributes.value)
%         initial.microns_per_pixel = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1, 12}.IndexedValue{1, 1}.Attributes.value  )
%         initial.magnification = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1, 15}.Attributes.value  )
%         initial.numerical_aperture = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1, 16}.Attributes.value  )
%         initial.zoom = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1, 17}.Attributes.value  )
%         initial.pixelsperline = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1, 18}.Attributes.value  )
%         initial.PMT_voltage_1 = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1, 19}.IndexedValue{1, 1}.Attributes.value  )
%         initial.x_position = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1, 20}.SubindexedValues{1, 1}.SubindexedValue.Attributes.value  )
%         initial.y_position = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1, 20}.SubindexedValues{1, 2}.SubindexedValue.Attributes.value  )
%         initial.z_position = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1, 20}.SubindexedValues{1, 3}.SubindexedValue.Attributes.value  )
%         initial.scanlineperiod = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1, 25}.Attributes.value)
%         initial.scan_rotation = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1, 24}.Attributes.value  )
%
%         initial.PMT_voltage_2 = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1, 19}.IndexedValue{1, 2}.Attributes.value  )
%
%
%
%
%     else
%         if  ((strcmp(xml_file.PVScan.Attributes.version, '5.3.64.300')) && initial.spiral_scan(1,iii)==0) || ...
%                 (initial.avg_2_fr(1,iii)==0 && initial.spiral_scan(1,iii)==0  &&(strcmp(xml_file.PVScan.Attributes.version, '5.3.64.300'))) || ...
%                 (initial.avg_2_fr(1,iii)==0 && initial.spiral_scan(1,iii)==0  &&(strcmp(xml_file.PVScan.Attributes.version, '5.3.64.400')))
%
%             initial.dwell_time_us = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,3}.Attributes.value)
%             initial.frame_period_from_prairie = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,4}.Attributes.value)
%             initial.magnification = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,12}.Attributes.value)
%             initial.microns_per_pixel = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,9}.IndexedValue{1,1}.Attributes.value)
%             initial.zoom = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,14}.Attributes.value)
%             initial.numerical_aperture = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,13}.Attributes.value)
%             initial.pixelsperline = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,15}.Attributes.value)
%             initial.linesperframe = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,7}.Attributes.value)
%             initial.pockels_power = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,6}.IndexedValue.Attributes.value)
%             initial.PMT_voltage_1 = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,16}.IndexedValue{1,1}.Attributes.value)
%             initial.PMT_voltage_2 = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,16}.IndexedValue{1,2}.Attributes.value)
%             initial.x_position = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,17}.SubindexedValues{1,1}.SubindexedValue.Attributes.value)
%
%
%
%
%             initial.y_position = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,17}.SubindexedValues{1,2}.SubindexedValue.Attributes.value)
%
%             frt =  class(xml_file.PVScan.PVStateShard.PVStateValue{1,17}.SubindexedValues{1,3}.SubindexedValue) ;
%
%             switch frt
%                 case 'cell'
%                     initial.z_position = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,17}.SubindexedValues{1,3}.SubindexedValue{1,1}.Attributes.value)
%                 case 'struct'
%                     initial.z_position = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,17}.SubindexedValues{1,3}.SubindexedValue.Attributes.value)
%
%
%             end
%             initial.scan_rotation = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,23}.Attributes.value)
%
%
%
%
%         else
%
%             if (strcmp(xml_file.PVScan.Attributes.version, '5.3.64.400') && initial.spiral_scan(1,iii)==0)
%
%                 if onep
%
%                 else
%
%                     initial.dwell_time_us = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,3}.Attributes.value)
%                     initial.frame_period_from_prairie = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,4}.Attributes.value)
%                     initial.magnification = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,12}.Attributes.value)
%                     initial.microns_per_pixel = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,9}.IndexedValue{1,1}.Attributes.value)
%                     initial.zoom = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,15}.Attributes.value)
%                     initial.numerical_aperture = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,13}.Attributes.value)
%                     initial.pixelsperline = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,15}.Attributes.value)
%                     initial.linesperframe = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,7}.Attributes.value)
%                     initial.pockels_power = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,6}.IndexedValue.Attributes.value)
%                     initial.PMT_voltage_1 = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,16}.IndexedValue{1,1}.Attributes.value)
%                     initial.PMT_voltage_2 = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,16}.IndexedValue{1,2}.Attributes.value)
%                     initial.x_position = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,17}.SubindexedValues{1,1}.SubindexedValue.Attributes.value)
%                     initial.y_position = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,17}.SubindexedValues{1,2}.SubindexedValue.Attributes.value)
%                     initial.z_position = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,17}.SubindexedValues{1,3}.SubindexedValue{1,1}.Attributes.value)
%                     initial.scan_rotation = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,23}.Attributes.value)
%                 end
%             else
%
%                 if  strcmp(xml_file.PVScan.Attributes.version, '5.1.64.100')
%
%                     initial.date_time = xml_file.PVScan.Attributes.date;
%                     initial.microns_per_pixel = str2num(xml_file.PVScan.Sequence.Frame{1,1}.PVStateShard.Key{1,21}.Attributes.value);
%                     initial.magnification = str2num(xml_file.PVScan.Sequence.Frame{1,1}.PVStateShard.Key{1,5}.Attributes.value);
%                     initial.zoom = str2num(xml_file.PVScan.Sequence.Frame{1,1}.PVStateShard.Key{1,20}.Attributes.value);
%                     initial.numerical_aperture = str2num(xml_file.PVScan.Sequence.Frame{1,1}.PVStateShard.Key{1,4}.Attributes.value);
%                     initial.dwell_time_us = str2num(xml_file.PVScan.Sequence.Frame{1,1}.PVStateShard.Key{1,13}.Attributes.value);
%                     initial.pockels_power = str2num(xml_file.PVScan.Sequence.Frame{1,1}.PVStateShard.Key{1,25}.Attributes.value);
%                     initial.x_position = str2num(xml_file.PVScan.Sequence.Frame{1,1}.PVStateShard.Key{1,15}.Attributes.value);
%                     initial.y_position = str2num(xml_file.PVScan.Sequence.Frame{1,1}.PVStateShard.Key{1,16}.Attributes.value);
%                     initial.z_position = str2num(xml_file.PVScan.Sequence.Frame{1,1}.PVStateShard.Key{1,17}.Attributes.value);
%                     initial.PMT_voltage_1 = str2num(xml_file.PVScan.Sequence.Frame{1,1}.PVStateShard.Key{1,23}.Attributes.value);
%                     initial.PMT_voltage_2 = str2num(xml_file.PVScan.Sequence.Frame{1,1}.PVStateShard.Key{1,24}.Attributes.value);
%                     initial.PMT_preamp_gain_1 = str2num(xml_file.PVScan.Sequence.Frame{1,1}.PVStateShard.Key{1,32}.Attributes.value);
%                     initial.PMT_preamp_gain_2 = str2num(xml_file.PVScan.Sequence.Frame{1,1}.PVStateShard.Key{1,33}.Attributes.value);
%                     initial.scan_rotation = str2num(xml_file.PVScan.Sequence.Frame{1,1}.PVStateShard.Key{1,19}.Attributes.value);
%                     initial.frame_period = str2num(xml_file.PVScan.Sequence.Frame{1,1}.PVStateShard.Key{1,11}.Attributes.value);
%                     initial.linesperframe = str2num(xml_file.PVScan.Sequence.Frame{1,1}.PVStateShard.Key{1,7}.Attributes.value);
%                     initial.pixelsperline = str2num(xml_file.PVScan.Sequence.Frame{1,1}.PVStateShard.Key{1,6}.Attributes.value);
%                     initial.laserwavelength = str2num(xml_file.PVScan.Sequence.Frame{1,1}.PVStateShard.Key{1,29}.Attributes.value);
%                 else
%
%
%                     if  strcmp(xml_file.PVScan.Attributes.version, '5.2.64.300')
%
%                         if initial.date<736040
%
%                             initial.dwell_time_us = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,4}.Attributes.value)
%
%                             initial.frame_period_from_prairie = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,5}.Attributes.value)
%
%                             initial.pockels_power = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,7}.IndexedValue.Attributes.value)
%
%                             initial.wavelength = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,8}.IndexedValue.Attributes.value)
%
%                             initial.linesperframe = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,9}.Attributes.value)
%
%                             initial.microns_per_pixel = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,11}.IndexedValue{1,1}.Attributes.value)
%
%                             initial.magnification = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,14}.Attributes.value)
%
%                             initial.numerical_aperture = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,15}.Attributes.value)
%
%                             initial.zoom = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,16}.Attributes.value)
%
%                             initial.pixelsperline = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,17}.Attributes.value)
%
%                             initial.PMT_voltage_1 = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,18}.IndexedValue{1,1}.Attributes.value)
%                             initial.PMT_voltage_2 = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,18}.IndexedValue{1,2}.Attributes.value)
%
%
%                             initial.x_position = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,19}.SubindexedValues{1,1}.SubindexedValue.Attributes.value)
%                             initial.y_position = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,19}.SubindexedValues{1,2}.SubindexedValue.Attributes.value)
%                             initial.z_position = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,19}.SubindexedValues{1,3}.SubindexedValue.Attributes.value)
%
%                             initial.scan_rotation = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,25}.Attributes.value)
%
%
%
%
%                         else
%
%                             initial.dwell_time_us = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,4}.Attributes.value)
%
%                             initial.frame_period_from_prairie = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,5}.Attributes.value)
%
%                             initial.pockels_power = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,7}.IndexedValue.Attributes.value)
%
%                             initial.wavelength = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,8}.IndexedValue.Attributes.value)
%
%                             initial.linesperframe = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,10}.Attributes.value)
%                             initial.microns_per_pixel = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,12}.IndexedValue{1,1}.Attributes.value)
%                             initial.magnification = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,15}.Attributes.value)
%                             initial.numerical_aperture = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,16}.Attributes.value)
%                             initial.zoom = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,17}.Attributes.value)
%                             initial.pixelsperline = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,18}.Attributes.value)
%
%                             initial.PMT_voltage_1 = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,19}.IndexedValue{1,1}.Attributes.value)
%                             initial.PMT_voltage_2 = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,19}.IndexedValue{1,2}.Attributes.value)
%
%
%                             initial.x_position = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,20}.SubindexedValues{1,1}.SubindexedValue.Attributes.value)
%                             initial.y_position = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,20}.SubindexedValues{1,2}.SubindexedValue.Attributes.value)
%                             initial.z_position = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,20}.SubindexedValues{1,3}.SubindexedValue.Attributes.value)
%
%                             initial.scan_rotation = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,25}.Attributes.value)
%                         end
%                     else
%
%                         if initial.old_file ==0
%                             if initial.xml_file_corrupt
%                                 initial.zoom = str2num(xml_file.PVStateShard{1,1}.Key{1,8}.ATTRIBUTE.value);
%                                 initial.date_time = initial.xml_file_aux.ATTRIBUTE.date;
%                                 initial.microns_per_pixel = str2num(xml_file.PVStateShard{1,1}.Key{1,53}.ATTRIBUTE.value);
%                                 initial.magnification = str2num(xml_file.PVStateShard{1,1}.Key{1,33}.ATTRIBUTE.value);
%                                 initial.numerical_aperture = str2num(xml_file.PVStateShard{1,1}.Key{1,41}.ATTRIBUTE.value);
%                                 initial.dwell_time_us = str2num(xml_file.PVStateShard{1,1}.Key{1,51}.ATTRIBUTE.value);
%                                 initial.pockels_power = str2num(xml_file.PVStateShard{1,1}.Key{1,205}.ATTRIBUTE.value);
%                                 initial.x_position = str2num(xml_file.PVStateShard{1,1}.Key{1,222}.ATTRIBUTE.value);
%                                 initial.y_position = str2num(xml_file.PVStateShard{1,1}.Key{1,4}.ATTRIBUTE.value);
%                                 initial.z_position = str2num(xml_file.PVStateShard{1,1}.Key{1,166}.ATTRIBUTE.value);
%                                 initial.PMT_voltage_1 = str2num(xml_file.PVStateShard{1,1}.Key{1,42}.ATTRIBUTE.value);
%                                 initial.PMT_voltage_2 = str2num(xml_file.PVStateShard{1,1}.Key{1,43}.ATTRIBUTE.value);
%                                 initial.PMT_preamp_gain_1 = str2num(xml_file.PVStateShard{1,1}.Key{1,139}.ATTRIBUTE.value);
%                                 initial.PMT_preamp_gain_2 = str2num(xml_file.PVStateShard{1,1}.Key{1,112}.ATTRIBUTE.value);
%                                 initial.scan_rotation = str2num(xml_file.PVStateShard{1,1}.Key{1,227}.ATTRIBUTE.value);
%                                 initial.frame_rate_hz = str2num(xml_file.PVStateShard{1,1}.Key{1,24}.ATTRIBUTE.value);
%                             else
%
%
%                                 % if initial.NB208
%
%
%
%                                 if initial.date<73584 || initial.date >740000
%                                     initial.date_time = xml_file.ATTRIBUTE.date;
%                                     initial.microns_per_pixel = str2num(xml_file.Sequence{1,1}.Frame{1,1}.PVStateShard{1,1}.Key{1,17}.ATTRIBUTE.value);
%                                     initial.magnification = str2num(xml_file.Sequence{1,1}.Frame{1,1}.PVStateShard{1,1}.Key{1,3}.ATTRIBUTE.value);
%                                     initial.zoom = str2num(xml_file.Sequence{1,1}.Frame{1,1}.PVStateShard{1,1}.Key{1,16}.ATTRIBUTE.value);
%                                     initial.numerical_aperture = str2num(xml_file.Sequence{1,1}.Frame{1,1}.PVStateShard{1,1}.Key{1,2}.ATTRIBUTE.value);
%                                     initial.dwell_time_us = str2num(xml_file.Sequence{1,1}.Frame{1,1}.PVStateShard{1,1}.Key{1,9}.ATTRIBUTE.value);
%                                     initial.pockels_power = str2num(xml_file.Sequence{1,1}.Frame{1,1}.PVStateShard{1,1}.Key{1,21}.ATTRIBUTE.value);
%                                     initial.x_position = str2num(xml_file.Sequence{1,1}.Frame{1,1}.PVStateShard{1,1}.Key{1,11}.ATTRIBUTE.value);
%                                     initial.y_position = str2num(xml_file.Sequence{1,1}.Frame{1,1}.PVStateShard{1,1}.Key{1,12}.ATTRIBUTE.value);
%                                     initial.z_position = str2num(xml_file.Sequence{1,1}.Frame{1,1}.PVStateShard{1,1}.Key{1,13}.ATTRIBUTE.value);
%                                     initial.PMT_voltage_1 = str2num(xml_file.Sequence{1,1}.Frame{1,1}.PVStateShard{1,1}.Key{1,19}.ATTRIBUTE.value);
%                                     initial.PMT_voltage_2 = str2num(xml_file.Sequence{1,1}.Frame{1,1}.PVStateShard{1,1}.Key{1,20}.ATTRIBUTE.value);
%                                     initial.PMT_preamp_gain_1 = str2num(xml_file.Sequence{1,1}.Frame{1,1}.PVStateShard{1,1}.Key{1,29}.ATTRIBUTE.value);
%                                     initial.PMT_preamp_gain_2 = str2num(xml_file.Sequence{1,1}.Frame{1,1}.PVStateShard{1,1}.Key{1,30}.ATTRIBUTE.value);
%                                     initial.scan_rotation = str2num(xml_file.Sequence{1,1}.Frame{1,1}.PVStateShard{1,1}.Key{1,15}.ATTRIBUTE.value);
%                                     initial.frame_period = str2num(xml_file.Sequence{1,1}.Frame{1,1}.PVStateShard{1,1}.Key{1,7}.ATTRIBUTE.value);
%
%
%
%                                     initial.date_time = xml_file.PVScan.Attributes.date;
%                                     initial.microns_per_pixel = str2num(xml_file.PVScan.Sequence{1,1}.Frame{1,1}.PVStateShard{1,1}.Key{1,17}.Attributes.value);
%                                     initial.magnification = str2num(xml_file.PVScan.Sequence{1,1}.Frame{1,1}.PVStateShard{1,1}.Key{1,3}.Attributes.value);
%                                     initial.zoom = str2num(xml_file.PVScan.Sequence{1,1}.Frame{1,1}.PVStateShard{1,1}.Key{1,16}.Attributes.value);
%                                     initial.numerical_aperture = str2num(xml_file.PVScan.Sequence{1,1}.Frame{1,1}.PVStateShard{1,1}.Key{1,2}.Attributes.value);
%                                     initial.dwell_time_us = str2num(xml_file.PVScan.Sequence{1,1}.Frame{1,1}.PVStateShard{1,1}.Key{1,9}.Attributes.value);
%                                     initial.pockels_power = str2num(xml_file.PVScan.Sequence{1,1}.Frame{1,1}.PVStateShard{1,1}.Key{1,21}.Attributes.value);
%                                     initial.x_position = str2num(xml_file.PVScan.Sequence{1,1}.Frame{1,1}.PVStateShard{1,1}.Key{1,11}.Attributes.value);
%                                     initial.y_position = str2num(xml_file.PVScan.Sequence{1,1}.Frame{1,1}.PVStateShard{1,1}.Key{1,12}.Attributes.value);
%                                     initial.z_position = str2num(xml_file.PVScan.Sequence{1,1}.Frame{1,1}.PVStateShard{1,1}.Key{1,13}.Attributes.value);
%                                     initial.PMT_voltage_1 = str2num(xml_file.PVScan.Sequence{1,1}.Frame{1,1}.PVStateShard{1,1}.Key{1,19}.Attributes.value);
%                                     initial.PMT_voltage_2 = str2num(xml_file.PVScan.Sequence{1,1}.Frame{1,1}.PVStateShard{1,1}.Key{1,20}.Attributes.value);
%                                     initial.PMT_preamp_gain_1 = str2num(xml_file.PVScan.Sequence{1,1}.Frame{1,1}.PVStateShard{1,1}.Key{1,29}.Attributes.value);
%                                     initial.PMT_preamp_gain_2 = str2num(xml_file.PVScan.Sequence{1,1}.Frame{1,1}.PVStateShard{1,1}.Key{1,30}.Attributes.value);
%                                     initial.scan_rotation = str2num(xml_file.PVScan.Sequence{1,1}.Frame{1,1}.PVStateShard{1,1}.Key{1,15}.Attributes.value);
%                                     initial.frame_period = str2num(xml_file.PVScan.Sequence{1,1}.Frame{1,1}.PVStateShard{1,1}.Key{1,7}.Attributes.value);
%
%                                 else
%                                     %
%                                     %                                                                         initial.date_time = xml_file.ATTRIBUTE.date;
%                                     %                                                                        initial.microns_per_pixel_xaxis = str2num(xml_file.PVStateShard{1,1}.PVStateValue{1,12}.IndexedValue{1,1}.ATTRIBUTE.value);
%                                     %
%                                     %                                                                         initial.microns_per_pixel_yaxis = str2num(xml_file.PVStateShard{1,1}.PVStateValue{1,12}.IndexedValue{1,2}.ATTRIBUTE.value);
%                                     %                                                                         initial.magnification = str2num(xml_file.PVStateShard{1,1}.PVStateValue{1,15}.ATTRIBUTE.value);
%                                     %
%                                     %                                                                         initial.pixelsperline = str2num(xml_file.PVStateShard{1,1}.PVStateValue{1,18}.ATTRIBUTE.value);
%                                     %                                                                         initial.linesperframe = str2num(xml_file.PVStateShard{1,1}.PVStateValue{1,10}.ATTRIBUTE.value);
%                                     %
%                                     %                                                                         initial.zoom = str2num(xml_file.PVStateShard{1,1}.PVStateValue{1,17}.ATTRIBUTE.value);
%                                     %                                                                         initial.numerical_aperture = str2num(xml_file.PVStateShard{1,1}.PVStateValue{1,16}.ATTRIBUTE.value);
%                                     %
%                                     %                                                                         initial.dwell_time_us = str2num(xml_file.PVStateShard{1,1}.PVStateValue{1,4}.ATTRIBUTE.value);
%                                     %                                                                         initial.pockels_power = str2num(xml_file.PVStateShard{1,1}.PVStateValue{1,7}.IndexedValue{1,1}.ATTRIBUTE.value);
%                                     %
%                                     %                                                                         initial.wavelength = str2num(xml_file.PVStateShard{1,1}.PVStateValue{1,8}.IndexedValue{1,1}.ATTRIBUTE.value);
%                                     %                                                                         initial.x_position = str2num(xml_file.PVStateShard{1,1}.PVStateValue{1,20}.SubindexedValues{1,1}.SubindexedValue{1,1}.ATTRIBUTE.value);
%                                     %
%                                     %                                                                         initial.y_position = str2num(xml_file.PVStateShard{1,1}.PVStateValue{1,20}.SubindexedValues{1,2}.SubindexedValue{1,1}.ATTRIBUTE.value);
%                                     %                                                                         initial.z_position = str2num(xml_file.PVStateShard{1,1}.PVStateValue{1,20}.SubindexedValues{1,3}.SubindexedValue{1,1}.ATTRIBUTE.value);
%                                     %
%                                     %                                                                         initial.PMT_voltage_1 = str2num(xml_file.PVStateShard{1,1}.PVStateValue{1,19}.IndexedValue{1,1}.ATTRIBUTE.value);
%                                     %                                                                         initial.PMT_voltage_2 = str2num(xml_file.PVStateShard{1,1}.PVStateValue{1,19}.IndexedValue{1,2}.ATTRIBUTE.value);
%                                     %
%                                     %                                                                         initial.PMT_preamp_gain_1 = str2num(xml_file.PVStateShard{1,1}.PVStateValue{1,22}.SubindexedValues{1,1}.SubindexedValue{1,1}.ATTRIBUTE.value);
%                                     %                                                                         initial.PMT_preamp_gain_2 = str2num(xml_file.PVStateShard{1,1}.PVStateValue{1,22}.SubindexedValues{1,1}.SubindexedValue{1,2}.ATTRIBUTE.value);
%                                     %
%                                     %                                                                         initial.scan_rotation = str2num(xml_file.PVStateShard{1,1}.PVStateValue{1,25}.ATTRIBUTE.value);
%                                     %                                                                         initial.frame_period_from_prairie = str2num(xml_file.PVStateShard{1,1}.PVStateValue{1,5}.ATTRIBUTE.value);
%                                     %
%                                     %                                                         %
%                                     %
%                                     %
%                                     %                                                                         initial.date_time = xml_file.ATTRIBUTE.date; %ok
%                                     %
%                                     %                                                                         initial.microns_per_pixel_xaxis = str2num(xml_file.PVStateShard{1,1}.PVStateValue{1,11}.IndexedValue{1,1}.ATTRIBUTE.value); %ok
%                                     %
%                                     %                                                                         initial.microns_per_pixel_yaxis = str2num(xml_file.PVStateShard{1,1}.PVStateValue{1,11}.IndexedValue{1,2}.ATTRIBUTE.value);
%                                     %
%                                     %                                                                         initial.magnification = str2num(xml_file.PVStateShard{1,1}.PVStateValue{1,14}.ATTRIBUTE.value); %ok
%                                     %
%                                     %                                                                         initial.pixelsperline = str2num(xml_file.PVStateShard{1,1}.PVStateValue{1,17}.ATTRIBUTE.value);%ok
%                                     %
%                                     %                                                                         initial.linesperframe = str2num(xml_file.PVStateShard{1,1}.PVStateValue{1,9}.ATTRIBUTE.value);%ok
%                                     %
%                                     %                                                                         initial.zoom = str2num(xml_file.PVStateShard{1,1}.PVStateValue{1,16}.ATTRIBUTE.value); %ok
%                                     %
%                                     %                                                                         initial.numerical_aperture = str2num(xml_file.PVStateShard{1,1}.PVStateValue{1,15}.ATTRIBUTE.value); %ok
%                                     %
%                                     %                                                                         initial.dwell_time_us = str2num(xml_file.PVStateShard{1,1}.PVStateValue{1,4}.ATTRIBUTE.value); %ok
%                                     %
%                                     %                                                                         initial.pockels_power = str2num(xml_file.PVStateShard{1,1}.PVStateValue{1,7}.IndexedValue{1,1}.ATTRIBUTE.value); %ok
%                                     %
%                                     %                                                                         initial.x_position = str2num(xml_file.PVStateShard{1,1}.PVStateValue{1,19}.SubindexedValues{1,1}.SubindexedValue{1,1}.ATTRIBUTE.value); %ok
%                                     %
%                                     %                                                                         initial.y_position = str2num(xml_file.PVStateShard{1,1}.PVStateValue{1,19}.SubindexedValues{1,2}.SubindexedValue{1,1}.ATTRIBUTE.value); %ok
%                                     %
%                                     %                                                                         initial.z_position = str2num(xml_file.PVStateShard{1,1}.PVStateValue{1,19}.SubindexedValues{1,3}.SubindexedValue{1,1}.ATTRIBUTE.value); %ok
%                                     %
%                                     %                                                                         initial.PMT_voltage_1 = str2num(xml_file.PVStateShard{1,1}.PVStateValue{1,18}.IndexedValue{1,1}.ATTRIBUTE.value); %ok
%                                     %
%                                     %                                                                         initial.PMT_voltage_2 = str2num(xml_file.PVStateShard{1,1}.PVStateValue{1,18}.IndexedValue{1,2}.ATTRIBUTE.value); %ok
%                                     %
%                                     %                                                                         initial.PMT_preamp_gain_1 = str2num(xml_file.PVStateShard{1,1}.PVStateValue{1,19}.SubindexedValues{1,1}.SubindexedValue{1,1}.ATTRIBUTE.value); %ok
%                                     %
%                                     %                                                                         initial.PMT_preamp_gain_2 = str2num(xml_file.PVStateShard{1,1}.PVStateValue{1,19}.SubindexedValues{1,2}.SubindexedValue{1,1}.ATTRIBUTE.value); %ok
%                                     %
%                                     %                                                                         initial.scan_rotation = str2num(xml_file.PVStateShard{1,1}.PVStateValue{1,25}.ATTRIBUTE.value); %ok
%                                     %
%                                     %                                                                         initial.frame_period_from_prairie = str2num(xml_file.PVStateShard{1,1}.PVStateValue{1,5}.ATTRIBUTE.value); %ok
%                                     %
%                                     %
%                                     %
%
%
%                                     %initial.date_time = xml_file.PVScan.Attributes.date; %ok
%
%                                     if initial.date > 736520 && initial.date < 737780
%
%                                         if initial.date <737110
%                                             initial.dwell_time_us = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,3}.Attributes.value)
%                                             initial.frame_period_from_prairie = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,4}.Attributes.value)
%                                             initial.magnification = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,13}.Attributes.value)
%                                             initial.microns_per_pixel = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,10}.IndexedValue{1,1}.Attributes.value)
%                                             initial.zoom = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,15}.Attributes.value)
%                                             initial.numerical_aperture = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,14}.Attributes.value)
%                                             initial.pixelsperline = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,16}.Attributes.value)
%                                             initial.linesperframe = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,8}.Attributes.value)
%                                             initial.pockels_power = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,6}.IndexedValue.Attributes.value)
%                                             initial.PMT_voltage_1 = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,17}.IndexedValue{1,1}.Attributes.value)
%                                             initial.PMT_voltage_2 = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,17}.IndexedValue{1,2}.Attributes.value)
%                                             initial.x_position = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,18}.SubindexedValues{1,1}.SubindexedValue.Attributes.value)
%                                             initial.y_position = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,18}.SubindexedValues{1,2}.SubindexedValue.Attributes.value)
%                                             initial.z_position = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,18}.SubindexedValues{1,3}.SubindexedValue.Attributes.value)
%                                             initial.scan_rotation = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,23}.Attributes.value)
%
%                                         else
%
%                                             initial.dwell_time_us = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,3}.Attributes.value)
%                                             initial.frame_period_from_prairie = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,4}.Attributes.value)
%                                             initial.magnification = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,13}.Attributes.value)
%                                             initial.microns_per_pixel = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,10}.IndexedValue{1,1}.Attributes.value)
%                                             initial.zoom = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,15}.Attributes.value)
%                                             initial.numerical_aperture = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,14}.Attributes.value)
%                                             initial.pixelsperline = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,16}.Attributes.value)
%                                             initial.linesperframe = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,8}.Attributes.value)
%                                             initial.pockels_power = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,6}.IndexedValue.Attributes.value)
%                                             initial.PMT_voltage_1 = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,17}.IndexedValue{1,1}.Attributes.value)
%                                             initial.PMT_voltage_2 = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,17}.IndexedValue{1,2}.Attributes.value)
%                                             initial.x_position = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,18}.SubindexedValues{1,1}.SubindexedValue.Attributes.value)
%                                             initial.y_position = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,18}.SubindexedValues{1,2}.SubindexedValue.Attributes.value)
%                                             if size(xml_file.PVScan.PVStateShard.PVStateValue{1,18}.SubindexedValues{1,3}.SubindexedValue,2)>1
%                                                 initial.z_position = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,18}.SubindexedValues{1,3}.SubindexedValue{1,1}.Attributes.value)
%                                             else
%                                                 initial.z_position = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,18}.SubindexedValues{1,3}.SubindexedValue.Attributes.value)
%                                             end
%                                             initial.scan_rotation = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,23}.Attributes.value)
%
%                                         end
%                                         %
%
%                                         %initial.wavelength = str2num(xml_file.PVStateShard{1,1}.PVStateValue{1,8}.IndexedValue{1,1}.ATTRIBUTE.value);
%
%
%                                         %             initial.PMT_preamp_gain_1 = str2num(xml_file.PVStateShard{1,1}.PVStateValue{1,22}.SubindexedValues{1,1}.SubindexedValue{1,1}.ATTRIBUTE.value);
%                                         %             initial.PMT_preamp_gain_2 = str2num(xml_file.PVStateShard{1,1}.PVStateValue{1,22}.SubindexedValues{1,1}.SubindexedValue{1,2}.ATTRIBUTE.value);
%                                         %
%
%                                         %
%                                         %
%                                         %             initial.date_time = xml_file.ATTRIBUTE.date; %ok
%                                         %
%                                     else
%
%                                         if initial.date >736545
%
%
%                                             initial.dwell_time_us = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,3}.Attributes.value)
%                                             initial.frame_period_from_prairie = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,4}.Attributes.value)
%                                             initial.magnification = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,12}.Attributes.value)
%                                             initial.microns_per_pixel = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,9}.IndexedValue{1,1}.Attributes.value)
%                                             initial.zoom = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,14}.Attributes.value)
%                                             initial.numerical_aperture = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,13}.Attributes.value)
%                                             initial.pixelsperline = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,15}.Attributes.value)
%                                             initial.linesperframe = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,7}.Attributes.value)
%                                             initial.pockels_power = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,6}.IndexedValue.Attributes.value)
%                                             initial.PMT_voltage_1 = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,16}.IndexedValue{1,1}.Attributes.value)
%                                             initial.PMT_voltage_2 = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,16}.IndexedValue{1,2}.Attributes.value)
%                                             initial.x_position = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,17}.SubindexedValues{1,1}.SubindexedValue.Attributes.value)
%                                             initial.y_position = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,17}.SubindexedValues{1,2}.SubindexedValue.Attributes.value)
%                                             initial.z_position = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,17}.SubindexedValues{1,3}.SubindexedValue{1,1}.Attributes.value)
%                                             initial.scan_rotation = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,23}.Attributes.value)
%
%                                             %initial.rotation = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,7}.Attributes.value)
%
%
%                                         else
%
%
%                                             initial.dwell_time_us = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,3}.Attributes.value)
%                                             initial.frame_period_from_prairie = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,4}.Attributes.value)
%                                             initial.magnification = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,12}.Attributes.value)
%                                             initial.microns_per_pixel = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,9}.IndexedValue{1,1}.Attributes.value)
%                                             initial.zoom = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,14}.Attributes.value)
%                                             initial.numerical_aperture = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,13}.Attributes.value)
%                                             initial.pixelsperline = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,15}.Attributes.value)
%                                             initial.linesperframe = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,7}.Attributes.value)
%                                             initial.pockels_power = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,6}.IndexedValue.Attributes.value)
%                                             initial.PMT_voltage_1 = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,16}.IndexedValue{1,1}.Attributes.value)
%                                             initial.PMT_voltage_2 = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,16}.IndexedValue{1,2}.Attributes.value)
%                                             initial.x_position = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,17}.SubindexedValues{1,1}.SubindexedValue.Attributes.value)
%                                             initial.y_position = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,17}.SubindexedValues{1,2}.SubindexedValue.Attributes.value)
%                                             initial.z_position = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,17}.SubindexedValues{1,3}.SubindexedValue.Attributes.value)
%                                             initial.scan_rotation = str2num(xml_file.PVScan.PVStateShard.PVStateValue{1,23}.Attributes.value)
%
%                                             %
%                                             %                             initial.microns_per_pixel = str2num(xml_file.PVScan.Sequence.Frame{1,1}.PVStateShard.Key{1,17}.Attributes.value); %ok
%                                             %                             initial.magnification = str2num(xml_file.PVScan.Sequence.Frame{1,1}.PVStateShard.Key{1,3}.Attributes.value); %ok
%                                             %                             initial.pixelsperline = str2num(xml_file.PVScan.Sequence.Frame{1,1}.PVStateShard.Key{1,4}.Attributes.value);%ok
%                                             %                             initial.linesperframe = str2num(xml_file.PVScan.Sequence.Frame{1,1}.PVStateShard.Key{1,5}.Attributes.value);%ok
%                                             %                             initial.zoom = str2num(xml_file.PVScan.Sequence.Frame{1,1}.PVStateShard.Key{1,16}.Attributes.value); %ok
%                                             %                             initial.numerical_aperture = str2num(xml_file.PVScan.Sequence.Frame{1,1}.PVStateShard.Key{1,2}.Attributes.value); %ok
%                                             %                             initial.dwell_time_us = str2num(xml_file.PVScan.Sequence.Frame{1,1}.PVStateShard.Key{1,9}.Attributes.value); %ok
%                                             %                            initial.pockels_power = str2num(xml_file.PVScan.Sequence.Frame{1,1}.PVStateShard.Key{1,21}.Attributes.value); %ok
%                                             %                             initial.x_position = str2num(xml_file.PVScan.Sequence.Frame{1,1}.PVStateShard.Key{1,11}.Attributes.value); %ok
%                                             %                             initial.y_position = str2num(xml_file.PVScan.Sequence.Frame{1,1}.PVStateShard.Key{1,12}.Attributes.value); %ok
%                                             %                             initial.z_position = str2num(xml_file.PVScan.Sequence.Frame{1,1}.PVStateShard.Key{1,13}.Attributes.value); %ok
%                                             %                             initial.PMT_voltage_1 = str2num(xml_file.PVScan.Sequence.Frame{1,1}.PVStateShard.Key{1,19}.Attributes.value); %ok
%                                             %                             initial.PMT_voltage_2 = str2num(xml_file.PVScan.Sequence.Frame{1,1}.PVStateShard.Key{1,20}.Attributes.value); %ok
%                                             %                             %             initial.PMT_preamp_gain_1 = str2num(xml_file.PVScan.Sequence.Frame{1,1}.PVStateShard.Key{1,20}.Attributes.value); %ok
%                                             %                             %             initial.PMT_preamp_gain_2 = str2num(xml_file.PVScan.Sequence.Frame{1,1}.PVStateShard.Key{1,21}.Attributes.value); %ok
%                                             %                             initial.scan_rotation = str2num(xml_file.PVScan.Sequence.Frame{1,1}.PVStateShard.Key{1,15}.Attributes.value); %ok
%                                             %                             initial.frame_period_from_prairie = str2num(xml_file.PVScan.Sequence.Frame{1,1}.PVStateShard.Key{1,7}.Attributes.value); %ok
%                                         end
%                                     end
%
%
%                                     %
%                                     %         else
%                                     %
%                                     %                                 %
%                                     %
%                                     %                                                                         initial.date_time = xml_file.ATTRIBUTE.date;
%                                     %
%                                     %                                                                         initial.microns_per_pixel = str2num(xml_file.Sequence{1,1}.Frame{1,1}.PVStateShard{1,1}.Key{1,21}.ATTRIBUTE.value);
%                                     %
%                                     %                                                                         initial.magnification = str2num(xml_file.Sequence{1,1}.Frame{1,1}.PVStateShard{1,1}.Key{1,5}.ATTRIBUTE.value);
%                                     %
%                                     %                                                                         initial.pixelsperline = str2num(xml_file.Sequence{1,1}.Frame{1,1}.PVStateShard{1,1}.Key{1,6}.ATTRIBUTE.value);
%                                     %
%                                     %                                                                         initial.linesperframe = str2num(xml_file.Sequence{1,1}.Frame{1,1}.PVStateShard{1,1}.Key{1,7}.ATTRIBUTE.value);
%                                     %
%                                     %                                                                         initial.zoom = str2num(xml_file.Sequence{1,1}.Frame{1,1}.PVStateShard{1,1}.Key{1,20}.ATTRIBUTE.value);
%                                     %
%                                     %                                                                         initial.numerical_aperture = str2num(xml_file.Sequence{1,1}.Frame{1,1}.PVStateShard{1,1}.Key{1,4}.ATTRIBUTE.value);
%                                     %
%                                     %                                                                         initial.dwell_time_us = str2num(xml_file.Sequence{1,1}.Frame{1,1}.PVStateShard{1,1}.Key{1,13}.ATTRIBUTE.value);
%                                     %
%                                     %                                                                         initial.pockels_power = str2num(xml_file.Sequence{1,1}.Frame{1,1}.PVStateShard{1,1}.Key{1,25}.ATTRIBUTE.value);
%                                     %
%                                     %                                                                         initial.x_position = str2num(xml_file.Sequence{1,1}.Frame{1,1}.PVStateShard{1,1}.Key{1,15}.ATTRIBUTE.value);
%                                     %
%                                     %                                                                         initial.y_position = str2num(xml_file.Sequence{1,1}.Frame{1,1}.PVStateShard{1,1}.Key{1,16}.ATTRIBUTE.value);
%                                     %
%                                     %                                                                         initial.z_position = str2num(xml_file.Sequence{1,1}.Frame{1,1}.PVStateShard{1,1}.Key{1,17}.ATTRIBUTE.value);
%                                     %
%                                     %                                                                         initial.PMT_voltage_1 = str2num(xml_file.Sequence{1,1}.Frame{1,1}.PVStateShard{1,1}.Key{1,23}.ATTRIBUTE.value);
%                                     %
%                                     %                                                                         initial.PMT_voltage_2 = str2num(xml_file.Sequence{1,1}.Frame{1,1}.PVStateShard{1,1}.Key{1,24}.ATTRIBUTE.value);
%                                     %
%                                     %                                                                         initial.PMT_preamp_gain_1 = str2num(xml_file.Sequence{1,1}.Frame{1,1}.PVStateShard{1,1}.Key{1,33}.ATTRIBUTE.value);
%                                     %
%                                     %                                                                         initial.PMT_preamp_gain_2 = str2num(xml_file.Sequence{1,1}.Frame{1,1}.PVStateShard{1,1}.Key{1,34}.ATTRIBUTE.value);
%                                     %
%                                     %                                                                         initial.scan_rotation = str2num(xml_file.Sequence{1,1}.Frame{1,1}.PVStateShard{1,1}.Key{1,15}.ATTRIBUTE.value);
%                                     %
%                                     %                                                                         initial.frame_period_from_prairie = str2num(xml_file.Sequence{1,1}.Frame{1,1}.PVStateShard{1,1}.Key{1,11}.ATTRIBUTE.value);
%                                     %                                                                         %                   %  end
%                                     %                                     %                 %             %
%                                     %                 %                 %             %
%                                     % %                 %                 %             %
%                                     % %                 %                 %
%                                     %                                     % %
%                                     %
%                                     %                                                                         initial.date_time = xml_file.ATTRIBUTE.date;
%                                     %
%                                     %                                                                         initial.microns_per_pixel = str2num(xml_file.Sequence{1,1}.Frame{1,1}.PVStateShard{1,1}.Key{1,21}.ATTRIBUTE.value);
%                                     %
%                                     %                                                                         initial.magnification = str2num(xml_file.Sequence{1,1}.Frame{1,1}.PVStateShard{1,1}.Key{1,5}.ATTRIBUTE.value);
%                                     %
%                                     %                                                                         initial.pixelsperline = str2num(xml_file.Sequence{1,1}.Frame{1,1}.PVStateShard{1,1}.Key{1,6}.ATTRIBUTE.value);
%                                     %
%                                     %                                                                         initial.linesperframe = str2num(xml_file.Sequence{1,1}.Frame{1,1}.PVStateShard{1,1}.Key{1,7}.ATTRIBUTE.value);
%                                     %
%                                     %                                                                         initial.zoom = str2num(xml_file.Sequence{1,1}.Frame{1,1}.PVStateShard{1,1}.Key{1,20}.ATTRIBUTE.value);
%                                     %
%                                     %                                                                         initial.numerical_aperture = str2num(xml_file.Sequence{1,1}.Frame{1,1}.PVStateShard{1,1}.Key{1,4}.ATTRIBUTE.value);
%                                     %
%                                     %                                                                         initial.dwell_time_us = str2num(xml_file.Sequence{1,1}.Frame{1,1}.PVStateShard{1,1}.Key{1,13}.ATTRIBUTE.value);
%                                     %
%                                     %                                                                         initial.pockels_power = str2num(xml_file.Sequence{1,1}.Frame{1,1}.PVStateShard{1,1}.Key{1,25}.ATTRIBUTE.value);
%                                     %
%                                     %                                                                         initial.x_position = str2num(xml_file.Sequence{1,1}.Frame{1,1}.PVStateShard{1,1}.Key{1,15}.ATTRIBUTE.value);
%                                     %
%                                     %                                                                         initial.y_position = str2num(xml_file.Sequence{1,1}.Frame{1,1}.PVStateShard{1,1}.Key{1,16}.ATTRIBUTE.value);
%                                     %
%                                     %                                                                         initial.z_position = str2num(xml_file.Sequence{1,1}.Frame{1,1}.PVStateShard{1,1}.Key{1,17}.ATTRIBUTE.value);
%                                     %
%                                     %                                                                         initial.PMT_voltage_1 = str2num(xml_file.Sequence{1,1}.Frame{1,1}.PVStateShard{1,1}.Key{1,23}.ATTRIBUTE.value);
%                                     %
%                                     %                                                                         initial.PMT_voltage_2 = str2num(xml_file.Sequence{1,1}.Frame{1,1}.PVStateShard{1,1}.Key{1,24}.ATTRIBUTE.value);
%                                     %
%                                     %                                                                         initial.PMT_preamp_gain_1 = str2num(xml_file.Sequence{1,1}.Frame{1,1}.PVStateShard{1,1}.Key{1,33}.ATTRIBUTE.value);
%                                     %
%                                     %                                                                         initial.PMT_preamp_gain_2 = str2num(xml_file.Sequence{1,1}.Frame{1,1}.PVStateShard{1,1}.Key{1,34}.ATTRIBUTE.value);
%                                     %
%                                     %                                                                         initial.scan_rotation = str2num(xml_file.Sequence{1,1}.Frame{1,1}.PVStateShard{1,1}.Key{1,15}.ATTRIBUTE.value);
%                                     %
%                                     %                                                                         initial.frame_period_from_prairie = str2num(xml_file.Sequence{1,1}.Frame{1,1}.PVStateShard{1,1}.Key{1,11}.ATTRIBUTE.value);
%                                     %
%                                     %
%                                     %                 %
%                                     %
%
%                                 end
%                                 % end
%
%                             end
%                         else
%                             if initial.xml_file_corrupt
%                                 initial.zoom = str2num(xml_file.PVStateShard{1,1}.Key{1,8}.ATTRIBUTE.value);
%                                 initial.date_time = initial.xml_file_aux.ATTRIBUTE.date;
%                                 initial.microns_per_pixel = str2num(xml_file.PVStateShard{1,1}.Key{1,53}.ATTRIBUTE.value);
%                                 initial.magnification = str2num(xml_file.PVStateShard{1,1}.Key{1,33}.ATTRIBUTE.value);
%                                 initial.numerical_aperture = str2num(xml_file.PVStateShard{1,1}.Key{1,41}.ATTRIBUTE.value);
%                                 initial.dwell_time_us = str2num(xml_file.PVStateShard{1,1}.Key{1,51}.ATTRIBUTE.value);
%                                 initial.pockels_power = str2num(xml_file.PVStateShard{1,1}.Key{1,205}.ATTRIBUTE.value);
%                                 initial.x_position = str2num(xml_file.PVStateShard{1,1}.Key{1,222}.ATTRIBUTE.value);
%                                 initial.y_position = str2num(xml_file.PVStateShard{1,1}.Key{1,4}.ATTRIBUTE.value);
%                                 initial.z_position = str2num(xml_file.PVStateShard{1,1}.Key{1,166}.ATTRIBUTE.value);
%                                 initial.PMT_voltage_1 = str2num(xml_file.PVStateShard{1,1}.Key{1,42}.ATTRIBUTE.value);
%                                 initial.PMT_voltage_2 = str2num(xml_file.PVStateShard{1,1}.Key{1,43}.ATTRIBUTE.value);
%                                 initial.PMT_preamp_gain_1 = str2num(xml_file.PVStateShard{1,1}.Key{1,139}.ATTRIBUTE.value);
%                                 initial.PMT_preamp_gain_2 = str2num(xml_file.PVStateShard{1,1}.Key{1,112}.ATTRIBUTE.value);
%                                 initial.scan_rotation = str2num(xml_file.PVStateShard{1,1}.Key{1,227}.ATTRIBUTE.value);
%                                 initial.frame_rate_hz = str2num(xml_file.PVStateShard{1,1}.Key{1,24}.ATTRIBUTE.value);
%                             else
%                                 initial.date_time = xml_file.ATTRIBUTE.date;
%                                 initial.microns_per_pixel = str2num(xml_file.PVScan.Sequence.Frame{1,1}.PVStateShard.Key{1,19}.Attributes.value);
%                                 initial.magnification = str2num(xml_file.PVScan.Sequence.Frame{1,1}.PVStateShard.Key{1,5}.Attributes.value);
%                                 initial.zoom = str2num(xml_file.PVScan.Sequence.Frame{1,1}.PVStateShard.Key{1,18}.Attributes.value);
%                                 initial.numerical_aperture = str2num(xml_file.PVScan.Sequence.Frame{1,1}.PVStateShard.Key{1,4}.Attributes.value);
%                                 initial.dwell_time_us = str2num(xml_file.PVScan.Sequence.Frame{1,1}.PVStateShard.Key{1,11}.Attributes.value);
%                                 initial.pockels_power = str2num(xml_file.PVScan.Sequence.Frame{1,1}.PVStateShard.Key{1,23}.Attributes.value);
%                                 initial.x_position = str2num(xml_file.PVScan.Sequence.Frame{1,1}.PVStateShard.Key{1,13}.Attributes.value);
%                                 initial.y_position = str2num(xml_file.PVScan.Sequence.Frame{1,1}.PVStateShard.Key{1,14}.Attributes.value);
%                                 initial.z_position = str2num(xml_file.PVScan.Sequence.Frame{1,1}.PVStateShard.Key{1,15}.Attributes.value);
%                                 initial.PMT_voltage_1 = str2num(xml_file.PVScan.Sequence.Frame{1,1}.PVStateShard.Key{1,21}.Attributes.value);
%                                 initial.PMT_voltage_2 = str2num(xml_file.PVScan.Sequence.Frame{1,1}.PVStateShard.Key{1,22}.Attributes.value);
%                                 initial.PMT_preamp_gain_1 = str2num(xml_file.PVScan.Sequence.Frame{1,1}.PVStateShard.Key{1,32}.Attributes.value);
%                                 initial.PMT_preamp_gain_2 = str2num(xml_file.PVScan.Sequence.Frame{1,1}.PVStateShard.Key{1,33}.Attributes.value);
%                                 initial.scan_rotation = str2num(xml_file.PVScan.Sequence.Frame{1,1}.PVStateShard.Key{1,17}.Attributes.value);
%                                 initial.frame_period = str2num(xml_file.PVScan.Sequence.Frame{1,1}.PVStateShard.Key{1,9}.Attributes.value);
%                             end
%                         end
%                     end
%                 end
%             end
%         end
%     end
% end


initiala = initial;
end




