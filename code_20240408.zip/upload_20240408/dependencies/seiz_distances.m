function [seiz_dists] = seiz_distances (tds,initial,EEG_results,i2)

ns = length(tds.sond);

a=1;
b=1;
curr_ons = tds.sond(1,a);
curr_offs = tds.soffd(1,b);
clear next_ons_dists prev_offs_dists
prev_offs_dists = [];
next_ons_dists = [];
for i = 1:i2.numberofframes
    
    if a<ns
        if i >= tds.sond(1,a)
            a=a+1;
        end
    end
    
    if b<ns
        if i>=tds.soffd(1,b)
            b=b+1;
        end
    end
    curr_ons = tds.sond(1,a);
    curr_offs = tds.soffd(1,b);
    
    if a == 1
        if i < curr_ons
            %ictal(1,i) = 0;
            interictal(1,i) = 1;
        end
        
    else
        
        if i>tds.soffd(1,ns)
            % ictal(1,i) = 0;
            interictal(1,i) = 1;
        end
        if curr_offs < curr_ons
            % ictal(1,i) = 1;
            interictal(1,i) = 0;
        else
            interictal(1,i) = 1;
        end
        
        %if b>1
        %             if i<tds.sond(1,a) && i>tds.soffd(1,b)
        %                % ictal(1,i) = 0;
        %                 interictal(1,i) = 1;
        %             end
        %end
        
    end
    
    if i<tds.sond(1,ns)
        next_ons_dists(1,i) = tds.sond(a) - i;
    end
    
    if i>tds.soffd(1,1) && b>1
        prev_offs_dists(1,i) = i - tds.soffd(1,b-1);
    end
    
end


ictal = ones(size(interictal));
ictal = ictal-interictal;
seiz_dists.ictal = ictal;
seiz_dists.interictal = interictal;
seiz_dists.next_ons_dists = next_ons_dists;
seiz_dists.prev_offs_dists = prev_offs_dists;



clear next_ons_dists_extrap prev_offs_dists_extrap interictal_extrap
fac = 1/10;
sond = tds.sonms;
soffd = tds.soffms;

a=1;
b=1;
curr_ons = sond(1,a)*fac;
curr_offs = soffd(1,b)*fac;
mfeeg = length(EEG_results.deltaf_interp_values);

for i = 1:mfeeg
    
    if a<ns
        if i >= sond(1,a)*fac
            a=a+1;
        end
    end
    
    if b<ns
        if i>=soffd(1,b)*fac
            b=b+1;
        end
    end
    curr_ons = sond(1,a)*fac;
    curr_offs = soffd(1,b)*fac;
    
    if a == 1
        if i < curr_ons
            %ictal(1,i) = 0;
            interictal_extrap(1,i) = 1;
        end
        
    else
        
        if i>soffd(1,ns)*fac
            % ictal(1,i) = 0;
            interictal_extrap(1,i) = 1;
        end
        if curr_offs < curr_ons
            % ictal(1,i) = 1;
            interictal_extrap(1,i) = 0;
        else
            interictal_extrap(1,i) = 1;
        end
        
        %if b>1
        %             if i<tds.sond(1,a) && i>tds.soffd(1,b)
        %                % ictal(1,i) = 0;
        %                 interictal(1,i) = 1;
        %             end
        %end
        
    end
    
    if i<sond(1,ns)*fac
        next_ons_dists_extrap(1,i) = sond(a)*fac - i;
    end
    prev_offs_dists_extrap=0;
    if i>soffd(1,1)*fac && b>1
        prev_offs_dists_extrap(1,i) = i - soffd(1,b-1)*fac;
    end
    
end

freq = 100

prev_offs_dists = prev_offs_dists';

prev_offs_dists_extrap  = zeros(ceil(length(prev_offs_dists)*i2.msperline/1000*freq),1);

k = 1
j = 1;
i = 2;

while i <= length(prev_offs_dists_extrap)-10
    %deltaf_interp (i,1) = i/freq;
    if (j*i2.msperline/1000 >= i/freq) && (j*i2.msperline/1000 <= i/freq+1/freq)...
            && prev_offs_dists_extrap(i,k) == 0 % && results.cat_signal_interp(i-1,k) == 0
        if j*i2.msperline-i/freq <= i+1/freq - j*i2.msperline
            prev_offs_dists_extrap(i,k) = prev_offs_dists(j,k);
            if prev_offs_dists(j,k)==0
                zerocat(1,a) = i;
                a=a+1;
            end
        else
            prev_offs_dists_extrap(i+1,k) = prev_offs_dists(j,k);
            if prev_offs_dists(j,k)==0
                zerocat(1,a) = i+1;
                a=a+1;
            end
        end
        j=j+1;
    end
    i=i+1;
end


forw = ceil(i2.msperline/(1000/freq));


i = 1;
a=1;
naninds = 0;

for j = 1:length(prev_offs_dists_extrap)
    if j<length(prev_offs_dists_extrap)-forw
        if sum(prev_offs_dists_extrap(j:j+forw,i))>0
            curr = find(prev_offs_dists_extrap(j:j+forw,i)==0)+j-1;
            c = length(curr);
            naninds(1,a:a+c-1) = curr;
            a=a+c;
            %results.deltaf_interp_values(find(results.deltaf_interp_values(j:j+forw,i)==0)',i)= NaN;
        end
    else
        if prev_offs_dists_extrap(j,i) == 0;
            naninds(1,a) = j;
            a=a+1;
            %results.deltaf_interp_values(j,i) = NaN;
        end
    end
end

%remove duplicates from naninds
if naninds == 0
else
prev_offs_dists_extrap(unique(naninds),i)= NaN;
end


prev_offs_dists_extrap(1:size(prev_offs_dists_extrap,1),i)...
    = inpaint_nans(prev_offs_dists_extrap(1:size(prev_offs_dists_extrap,1),i));

prev_offs_dists_extrap(prev_offs_dists_extrap<0) = 0;



ictal_extrap = ones(size(interictal_extrap));
ictal_extrap = ictal_extrap-interictal_extrap;
seiz_dists.ictal_extrap = ictal_extrap;
seiz_dists.interictal_extrap = interictal_extrap;
seiz_dists.next_ons_dists_extrap = next_ons_dists_extrap;
seiz_dists.prev_offs_dists_extrap = prev_offs_dists_extrap';

