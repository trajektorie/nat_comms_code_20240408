
rec = ii;

%matrix = sdec_f_corr;
matrix = sdec;


start_pre = recordingc(rec).corr_results.beg_sec_1 ;
end_pre = recordingc(rec).corr_results.end_sec_1 ;

start_post = recordingc(rec).corr_results.beg_sec_2;
end_post = recordingc(rec).corr_results.end_sec_2;

fs=recording(rec).initial2.samplingratehz;
start_pre = round(start_pre*fs);
end_pre = min(round(end_pre*fs),size(matrix,2));
start_post = ceil(start_post*fs);
if start_post==0
    start_post=1
end
end_post = round(end_post*fs);

if start_pre>end_pre || end_pre - start_pre <11
    too_short = 1;
else
    too_short=0;
    
    
    if start_pre==0
        start_pre=1
    end
    matrix_pre = matrix(:,start_pre:end_pre);
    if end_post>size(matrix,2) || ((end_post - start_post)<20)
        matrix_post = matrix_pre;
        recordingc(rec).matrix_pre_and_post_are_the_same = 1;
    else
        if end_post==0
            matrix_post=0;
        else
            matrix_post = matrix(:,start_post:end_post);
        end
    end
    recordingc(rec).corr_results.matrix_pre = matrix_pre;
    recordingc(rec).corr_results.matrix_post = matrix_post;
    
    flip_colormap
    
    p1ms = 100
    p2ms = []
    p3ms = []
    p4ms = []
    
    %ictal here means post-seizure
    
    
    ihlo = 0;
    cs=1
    test=0
    norm=0;
    
    close all
    
    ictal = 0;
    
    alpha = 0.05;
    %bonferroni correction
    numpairs = ((endframe*endframe)-endframe)/2;
    alpha = alpha/(sqrt(numpairs));
    recordingc(rec).corr_results.numpairs = numpairs;
    recordingc(rec).corr_results.alpha = alpha;
    
    % load('cmap_19.mat')
    %
    % cmaipp = cmap19;
    
    ihcs = 0;
    ilcs = 0;
    neutrs = 1:1:endframe  %-10;  %changed 20221130 JM
    if ~onep
        nes = 0 %endframe-9:1:endframe;  %changed 20221130 JM
    else
        nes=0;
    end
    mot_EEGs = [];
    close all
    if min12>6
        
        matrixee = matrix_pre; %recording(i).S_dec;
        endframe = size(sdec,1);
        
        initial.msperline = recording(rec).initial2.msperline;
        [correlation_results_interict_deconv,correlation_results_interict_deconv_a] = ...
            correlation_matrix_general_11302016(initial,matrixee,Folder,iterations,ictal,ihlo,test,cmaipp,cs,ihcs,ilcs,neutrs,nes,mot_EEGs,norm,0,sf,...
            p1ms,p2ms,p3ms,p4ms,alpha,rd);                                                                                                   
        
        recordingc(rec).correlation_results_pre_seiz = correlation_results_interict_deconv;
        recordingc(rec).correlation_results_pre_seiz_a = correlation_results_interict_deconv_a;
        
    end
    
    
    close all
    if sum(sum(matrix_post))==0
    else
        
        ictal = 1;
        matrixee = matrix_post; %recording(i).S_dec;
        %endframe = size(recording(rec).S_dec,1);
        ihcs = 0;
        ilcs = 0;
        %neutrs = 1:1:endframe-10;
        if onep
            nes = []
        else
            %nes = endframe-9:1:endframe;
        end
        mot_EEGs = [];
        close all
        initial.msperline = recording(rec).initial2.msperline;
        pepe1 = round(p1ms/initial.msperline);
        if min12>6
            cr2int = correlation_results_interict_deconv_a;
        else
            cr2int(pepe1)=0;
        end
        [correlation_results_interict_deconv,correlation_results_interict_deconv_a] = ...
            correlation_matrix_general_03302016(initial,matrixee,Folder,iterations,ictal,ihlo,test,cmaipp,cs,ihcs,ilcs,neutrs,nes,mot_EEGs,norm,cr2int,sf,...
            p1ms,p2ms,p3ms,p4ms,alpha,rd);                                                                                                   
        
        recordingc(rec).correlation_results_post_seiz = correlation_results_interict_deconv;
        recordingc(rec).correlation_results_post_seiz_a = correlation_results_interict_deconv_a;
        
        
        
        corr_post = recordingc(rec).correlation_results_post_seiz; %("ictal")
    end
    
    
    if sum(sum(matrix_post))==0 || min12<6.1
    else
        
        corr_pre = recordingc(rec).correlation_results_pre_seiz; %("interictal")
        
        close all
        norm=0;
        %if isempty(neuropil_ROIs_red)
        neuropil_ROIs_red = 0;
        %end
        sf=1;
        ih=0;
        il=0;
        using_all_corrs_or_sig_only = 0;
        [correlation_results_2_S_dec_pre_post] = correlation_analysis_2(corr_post,corr_pre,Folder,cmaipp,ih,il,neuropil_ROIs_red'...
            ,neutrs,mot_EEGs,norm,sf,using_all_corrs_or_sig_only);
        
        recordingc(rec).correlation_results_2_S_dec_pre_post = correlation_results_2_S_dec_pre_post;
        
    end
    
    
    
    
    
    
    %
    % flip_colormap
    %
    % p1ms = 200
    % p2ms = 500
    % p3ms = 1000
    % p4ms = 2000
    %
    % ictal = 0;
    % iterations = 2000;
    % ihlo = 0;
    % cs=1
    % test=0
    % norm=0;
    % sf=0;
    %
    % for i = 1:num_rec
    %
    %     matrixee = recording(i).S_dec;
    %     endframe = size(recording(i).S_dec,1);
    %     ihcs = 0;
    %     ilcs = 0;
    %     neutrs = 1:1:endframe-10;
    %     nes = endframe-9:1:endframe;
    %     mot_EEGs = [];
    %     close all
    %     initial.msperline = initial2.msperline;
    %     [correlation_results_interict_deconv,correlation_results_interict_deconv_a] = ...
    %         correlation_matrix_general_03302016(initial,matrixee,Folder,iterations,ictal,ihlo,test,cmaipp,cs,ihcs,ilcs,neutrs,nes,mot_EEGs,norm,0,sf,...
    %         p1ms,p2ms,p3ms,p4ms);                                                                                                   
    %
    %     recording(i).correlation_results_interict_deconv=correlation_results_interict_deconv;
    %     recording(i).correlation_results_interict_deconv_a = correlation_results_interict_deconv_a;
    %
    % end
    
    
end
