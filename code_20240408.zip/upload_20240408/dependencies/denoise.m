function [oopsi_no_noise,activity_per_min_oopsi,deltaf_no_noise,activity_per_min_deltaf,noisee] = ...
denoise(initial, oopsi_spike_trace,deltaf_matrix,std_level,i2,just_oopsi_binedges)
%  denoise(recording(iii).initial,sdec,DF_fr_cdec,std_level,recording(iii).initial2);
%  initial=recording(iii).initial;
%  oopsi_spike_trace = sdec;
%  deltaf_matrix=DF_fr_cdec;
%  i2=recording(iii).initial2;
%  
%%%%%%%%%%%Yaksi-Friedrich iterative smoothing (here for stimcell only,
%%%%%%%%%%%later generalize for all cells!)

%filter with 4-pole butterworth filter cutoff at 0.2*intial.samplingratehz:

%
% Hd = lowpass_butter(initial);
%
% endframe = size(deltaf_cells,2);
%
% for i = 1:endframe
%
% x = deltaf_cells(:,i);
%
% y(:,i) = filter(Hd,x);
%
% end
%
%
%
% s_f = round(initial.samplingratehz/2);
%
% if mod(s_f,2)
% else
%     s_f = s_f + 1;
% end
%
% clear smooth_deltaf_matrix
%
% for i = 1:endframe
%     smooth_deltaf_matrix(:,i) = smooth(y(:,i),s_f);
% end
%
%
% fps = 1000/i2.msperline;
% traceOpt.trace_computation = 'oopsi';
% traces = smooth_deltaf_matrix;
% oopsi_spike_trace = filterTraces( traces, fps, traceOpt );
%results.oopsi_filtered_deltaf_matrix = oopsi_spike_trace;
% clear oopsi_spike_trace


%%%%%%%define noise level threshold:
endframe = size(oopsi_spike_trace,2);

%binedges = [-0.2:0.0005:1];

for i = 1:endframe
    %ignore Nan-containing ROI traces
    urt = round(0.95*size(oopsi_spike_trace,1));
    if sum(oopsi_spike_trace(12:urt,i))/urt < 1.88e-02 %==0
        noisee(i).inactive_ROI = 1;
    else
        
        aroundd = sort(oopsi_spike_trace(:,i));
        stt = length(aroundd);
        stt = length(aroundd);
        bot = prctile(aroundd,1);
        
        tob = prctile(aroundd,99);
        stob = (tob-bot)/100;
        binedges = [bot:stob:tob]
        %[N, edges] = histcounts(oopsi_spike_trace(:,i),binedges);
        
        [N, edges] = histcounts(aroundd(1:round(stt*0.25),1),binedges);
        noisee(i).oopsi_binedges = binedges;
        
        a=find(N == max(N));
        if length(a)>1
            a = a(1,2);
        end
        medi = edges(1,a);
        
        avg_oopsi(i,1) = medi;
        noisee(i).med_oopsi = avg_oopsi(i,1);
        
        noise_below_med = oopsi_spike_trace(find(oopsi_spike_trace(:,i)<avg_oopsi(i,1)),i);
        noisee(i).noiseoopsi = cat(1,noise_below_med, avg_oopsi(i,1)*2-noise_below_med);
        
        noisee(i).std_oopsi = std(noisee(i).noiseoopsi);
        if noisee(i).std_oopsi == 0 || isnan(noisee(i).std_oopsi)
            noisee(i).std_oopsi = 0.02;
        end
        noisee(i).thr_oopsi = avg_oopsi(i)+std_level*noisee(i).std_oopsi;
        if noisee(i).thr_oopsi==[]
            noisee(i).thr_oopsi = 0;
        end
        
        signal_oopsi = oopsi_spike_trace(find(oopsi_spike_trace(:,i)>2*noisee(i).thr_oopsi),i);
        
        avg_signal_oopsi(i,1) = mean(signal_oopsi);
        
        noisee(i).SNR_oopsi = avg_signal_oopsi(i,1)/noisee(i).std_oopsi;
    end
    
end

%noisee.noiseoopsi = noiseoopsi;
% noisee.std_oopsi = std_oopsi;
% noisee.thr_oopsi = thr_oopsi;

%compute activity by subtracting thr_oopsi and summating remaining
%datapoints



for i = 1:endframe
    if sum(oopsi_spike_trace(:,i))==0
    else
        if ~isfield(noisee(i),'thr_oopsi')
            noisee(i).thr_oopsi=0;
        else
            if isempty( noisee(i).thr_oopsi)
                noisee(i).thr_oopsi=0;
            end
        end
        oopsi_no_noise(:,i) = oopsi_spike_trace(:,i) - noisee(i).thr_oopsi;
    end
end


%oopsi_no_noise = results.oopsi_filtered_deltaf_matrix
movie_length_min = size(deltaf_matrix,1)/(60000/i2.msperline);
% if isfield(initial,'movielengthsec')
%     
% movie_length_min = initial.movielengthsec*60;  %size(deltaf_matrix,1)/(60000/i2.msperline);%*initial.samplingratehz);
% else
%     movie_length_min = i2.movielengthsec*60;
% end

endframe = size(oopsi_no_noise,2)
for i = 1:endframe
 
    for j= 1:size(oopsi_no_noise,1)
        if oopsi_no_noise(j,i)<0
            oopsi_no_noise(j,i) = 0;
        end
    end
    activity_per_min_oopsi(i) = sum(oopsi_no_noise(:,i))/movie_length_min; %*60000)/(size(oopsi_no_noise,1)*i2.msperline);
end

if ~just_oopsi_binedges
binedges = [-0.5:0.01:5];
end

deltaf_matrix(deltaf_matrix==Inf) = 30;
for i = 1:size(deltaf_matrix,2)
    
    
    
    aroundd = sort(deltaf_matrix(:,i));
    stt = length(aroundd);
     stt = length(aroundd);
      bot = prctile(aroundd,1);
      
    tob = prctile(aroundd,99);
    stob = (tob-bot)/100;
    binedges = [bot:stob:tob]
    noisee(i).DF_binedges = binedges;
     if sum(deltaf_matrix(12:urt,i))==0 || isempty(binedges)
         deltaf_matrix(:,i) = 0;
    else
    
    %[N, edges] = histcounts(deltaf_matrix(:,i),binedges);
    
    [N, edges] = histcounts(aroundd(1:round(stt*0.25),1),binedges);
    
    a=find(N == max(N));
    
    if length(a)>1
        a = a(1,2);
    end
    
    medi = edges(1,a);
    
    avg_deltaf(i,1) = medi;
    noisee(i).med_deltaf = avg_deltaf(i,1);
    
    noise_below_med = deltaf_matrix(find(deltaf_matrix(:,i)<avg_deltaf(i,1)),i);
    noisee(i).noisedeltaf = cat(1,noise_below_med, avg_deltaf(i,1)*2-noise_below_med);
    
    noisee(i).std_deltaf = std(noisee(i).noisedeltaf);
    
    if noisee(i).std_deltaf == 0 || isnan(noisee(i).std_deltaf)
        noisee(i).std_deltaf = 0.05;
    end
    
    
    noisee(i).thr_deltaf = avg_deltaf(i)+std_level*noisee(i).std_deltaf;
      if isempty(noisee(i).thr_deltaf)
        noisee(i).thr_deltaf = 0;
    end
    
    signal_ca = deltaf_matrix(find(deltaf_matrix(:,i)>2*noisee(i).thr_deltaf),i);
    
    avg_signal(i,1) = mean(signal_ca);
    
    noisee(i).SNR = avg_signal(i,1)/noisee(i).std_deltaf;
     end
    
end

% noisee.noisedeltaf = noise;
% noisee.std_deltaf = std_deltaf;
% noisee.thr_deltaf = thr_deltaf;
% 

%compute activity by subtracting thr_oopsi and summating remaining
%datapoints



for i = 1:size(deltaf_matrix,2)
     if sum(deltaf_matrix(:,i))==0
    else
    deltaf_no_noise(:,i) = deltaf_matrix(:,i) - noisee(i).thr_deltaf;
     end
end

noisee(1).deltaf_no_noise_not_zeroed = deltaf_no_noise;

%movie_length_min = size(deltaf_matrix,1)/(60000/i2.msperline);%*initial.samplingratehz);


for i = 1:size(deltaf_no_noise,2)
    for j= 1:size(deltaf_no_noise,1)
        if deltaf_no_noise(j,i)<0
            deltaf_no_noise(j,i) = 0;
        end
    end
    activity_per_min_deltaf(i) = sum(deltaf_no_noise(:,i))/movie_length_min; %*60000)/(size(deltaf_no_noise,1)*i2.msperline);  % movie_length_min;
end


end



