% (slmn,somn,initial,Folder,min_isi_ms,min_length_ms,sf,offs_thr,initial2, one_p_imaging)
% 
% seizure_lengths_ms = slmn;
% seizure_onsets_ms = somn;
% min_isi = min_isi_ms;
% min_length = min_length_ms;
% i2 = initial2;
% onep = one_p_imaging;

function [tds] = cons_seizures(seizure_lengths_ms,seizure_onsets_ms,initial,Folder,min_isi,min_length,suf,offs_thr,i2,onep)


if onep
    i2.offsets = zeros(i2.numerofframes,2);
end


seizure_lengths_in_ms_new = seizure_lengths_ms;
seizure_onsets_in_ms_new = seizure_onsets_ms;

le = length(seizure_onsets_in_ms_new)
b=1
td=0;
if initial.no_imaging == 1
else
    
    if size(seizure_onsets_in_ms_new,2)>1
        for iz = 1:2
            if seizure_onsets_in_ms_new(1,iz)<3000
                td(1,b) = 1;
                b=b+1
            end
        end
    end
    
    if le>30
        les = round(0.65*le);
    else
        if le<2
            les=1;
        else
            les = 2;
        end
    end
    for i = 1:les
        i
        if ((round(seizure_onsets_in_ms_new(1,le-i+1)+seizure_lengths_in_ms_new(1,le-i+1)+3000)/i2.msperline)...
                > length(i2.offsets))
            td(1,b) = le-i+1
            b=b+1
        end
    end
end


soimn = seizure_onsets_in_ms_new;
slimn = seizure_lengths_in_ms_new;
sofimn = soimn + slimn;

if td
    soimn(:,td) = [];
    slimn(:,td) = [];
    sofimn(:,td) = [];
end

seizure_onsets_in_ms_new = soimn;
seizure_lengths_in_ms_new = slimn;

for i=1:length(soimn)
    
    seize_1(i,1) = soimn(1,i)/1000;
    seize_1(i,2) = sofimn(1,i)/1000;
    
end


if initial.no_imaging ==1
    ts = 20
else
    ts = round(2000/i2.msperline);
end
ns = length(soimn);
offs_x_st = zeros(2*ts+1,ns);
offs_y_st = zeros(2*ts+1,ns);
offs_x_en = zeros(2*ts+1,ns);
offs_y_en = zeros(2*ts+1,ns);

sum_diff_x_st=0;
sum_diff_y_st=0;
sum_diff_x_en=0;
sum_diff_y_en=0;

if initial.no_imaging ==1
else
    xo = i2.offsets(:,1);
    yo = i2.offsets(:,2);
    
    for i = 1:ns
        if ((round(seize_1(i,1)*1000/i2.msperline)-ts) > 0) && (round(seize_1(i,2)*1000/i2.msperline)-ts >= 0)...
                && round(seize_1(i,2)*1000/i2.msperline)+ts < length(xo)
            seizure = i
            offs_x_st(:,i) = xo(round(seize_1(i,1)*1000/i2.msperline)-ts:round(seize_1(i,1)*1000/i2.msperline)+ts);
            sum_diff_x_st(1,i) = sum(diff(offs_x_st(:,i)).^2);
            offs_y_st(:,i) = yo(round(seize_1(i,1)*1000/i2.msperline)-ts:round(seize_1(i,1)*1000/i2.msperline)+ts);
            sum_diff_y_st(1,i) = sum(diff(offs_y_st(:,i)).^2);
            
            seizend = round(seize_1(i,2)*1000/i2.msperline)-ts
            offs_x_en(:,i) = xo(round(seize_1(i,2)*1000/i2.msperline)-ts:round(seize_1(i,2)*1000/i2.msperline)+ts);
            sum_diff_x_en(1,i) = sum(diff(offs_x_en(:,i)).^2);
            
            offs_y_en(:,i) = yo(round(seize_1(i,2)*1000/i2.msperline)-ts:round(seize_1(i,2)*1000/i2.msperline)+ts);
            sum_diff_y_en(1,i) = sum(diff(offs_y_en(:,i)).^2);
            
        end
    end
end
rev_corr_offsets.avg_offs_x_st = mean(offs_x_st,2);
rev_corr_offsets.avg_offs_y_st = mean(offs_y_st,2);

rev_corr_offsets.avg_offs_x_en = mean(offs_x_en,2);
rev_corr_offsets.avg_offs_y_en = mean(offs_y_en,2);


rev_corr_offsets.std_offs_x_st = std(offs_x_st,1,2);
rev_corr_offsets.std_offs_y_st = std(offs_y_st,1,2);

rev_corr_offsets.std_offs_x_en = std(offs_x_en,1,2);
rev_corr_offsets.std_offs_y_en = std(offs_y_en,1,2);

rev_corr_offsets.offs_x_st = offs_x_st;
rev_corr_offsets.offs_y_st = offs_y_st;
rev_corr_offsets.offs_x_en = offs_x_en;
rev_corr_offsets.offs_y_en = offs_y_en;

figure(112)
subplot(2,2,1)
errorbar(rev_corr_offsets.avg_offs_x_st,rev_corr_offsets.std_offs_x_st)
title('avg x offset, start')

subplot(2,2,2)
errorbar(rev_corr_offsets.avg_offs_y_st,rev_corr_offsets.std_offs_y_st)
title('avg y offset, start')

subplot(2,2,3)
errorbar(rev_corr_offsets.avg_offs_x_en,rev_corr_offsets.std_offs_x_en)
title('avg x offset, end')

subplot(2,2,4)
errorbar(rev_corr_offsets.avg_offs_y_en,rev_corr_offsets.std_offs_y_en)
title('avg y offset, end')
if suf
    saveas (112,[Folder 'avg_offsets_and_SD'  '.png' ],'png')
end

seizs = size(sum_diff_y_st,2);
a=1;
b=1;
x_offs_out=0;
y_offs_out=0;
if initial.no_imaging==1
else
    for i = 1:seizs
        %if max(rev_corr_offsets.offs_x_st(:,i))>5 || min(rev_corr_offsets.offs_x_st(:,i))<-5
        if  sum_diff_x_st(1,i)>offs_thr || sum_diff_x_en(1,i)>offs_thr
            x_offs_out(1,a) = i;
            a=a+1;
        end
        %if max(rev_corr_offsets.offs_y_st(:,i))>5 || min(rev_corr_offsets.offs_y_st(:,i))<-5
        if sum_diff_y_st(1,i)>offs_thr || sum_diff_y_en(1,i)>offs_thr
            y_offs_out(1,b) = i;
            b=b+1;
        end
    end
end
seizs_out = 0;
if sum(x_offs_out) ||sum(y_offs_out)
    seizs_out = union(x_offs_out,y_offs_out);
    seizs_out = seizs_out(find(seizs_out));
    soimn(:,seizs_out) = [];
    sofimn(:,seizs_out) = [];
    slimn(:,seizs_out) = [];
end
tds.sum_diff_x_st = sum_diff_x_st;
tds.sum_diff_x_en = sum_diff_x_en;
tds.sum_diff_y_st = sum_diff_y_st;
tds.sum_diff_y_en = sum_diff_y_en;

if size(seizure_onsets_in_ms_new,2)>0
    
    a=0
    for i = 1:1
        if seizure_onsets_in_ms_new(1,i)<2000
            a=a+1
        end
    end
    
    if a
        seizure_onsets_in_ms_new(:,1:a) = [];
        seizure_lengths_in_ms_new(:,1:a) = [];
    end
    
    
    
    if a && sum(seizs_out)
        
        tds.offset_seizures_out = union(seizs_out,1:1:a);
    else
        if seizs_out
            tds.offset_seizures_out = seizs_out;
        else
            if a
                tds.offset_seizures_out = a;
            else
                tds.offset_seizures_out = 0;
            end
        end
    end
    
    
    seizure_onsets_in_ms_1 = soimn;
    seizure_lengths_in_ms_1 = slimn;
    
    tds.sonms = seizure_onsets_in_ms_new;
    tds.slms = seizure_lengths_in_ms_new;
    tds.soffms = seizure_onsets_in_ms_new + seizure_lengths_in_ms_new;
    if initial.no_imaging==1
    else
        tds.sond = round(seizure_onsets_in_ms_new/i2.msperline);
        if tds.sond(1,1) == 0
            tds.sond(1,1) = 1;
        end
        tds.sld = round(seizure_lengths_in_ms_new/i2.msperline);
        tds.soffd = round(seizure_onsets_in_ms_new/i2.msperline + seizure_lengths_in_ms_new/i2.msperline);
    end
    
    %remove seizures that are too close together:
    a=1
    td=0;
    ISI = 0;
    for i = 2:size(seizure_onsets_in_ms_new,2)
        ISI(i-1) = seizure_onsets_in_ms_new(i)-(seizure_onsets_in_ms_new(i-1)+seizure_lengths_in_ms_new(i-1));
        if ISI(i-1)<min_isi
            td(1,a) = i-1
            a=a+1;
        end
    end
    
    tds.seiz_ISIs = ISI;
    
    %remove seizures that are too short:
    a=1
    ta=0;
    for i = 1:size(seizure_onsets_in_ms_1,2)
        %ISI(i-1) = seizure_onsets_in_ms_new(i)-seizure_onsets_in_ms_new(i-1)+seizure_lengths_in_ms_new(i-1);
        if seizure_lengths_in_ms_1(i)<min_length
            ta(a) = i
            a=a+1
        end
    end
    
    ts = tds.offset_seizures_out;
    soimn = seizure_onsets_in_ms_1;
    slimn = seizure_lengths_in_ms_1;
    if sum(td)||sum(ta) || sum(tds.offset_seizures_out)
        if sum(td) && sum(ta) && sum(tds.offset_seizures_out)
            ts = union(union(td,ta),tds.offset_seizures_out);
            ts = sort(ts,'ascend')
        else
            if sum(td) && sum(tds.offset_seizures_out)
                ts = union(td,tds.offset_seizures_out);
                ts = sort(ts,'ascend')
            else
                if sum(ta) && sum(tds.offset_seizures_out)
                    ts = union(ta,tds.offset_seizures_out);
                    ts = sort(ts,'ascend')
                else
                    
                    if sum(td) && sum(ta)
                        ts = union(td,ta);
                        ts = sort(ts,'ascend')
                    else
                        if sum(td)
                            ts = td
                            ts = sort(ts,'ascend')
                        end
                        if sum(ta)
                            ts = ta
                            ts = sort(ts,'ascend')
                        end
                    end
                end
            end
        end
        if numel(ts) ==1
            soimn(:,ts) = [];
            slimn(:,ts) = [];
        else
            for j=1:numel(ts)
                if ts(1,length(ts)-j+1)<=length(soimn)
                    soimn(:,ts(1,length(ts)-j+1)) = [];
                    slimn(:,ts(1,length(ts)-j+1)) = [];
                end
            end
        end
    end
    seizure_onsets_in_ms_2 = soimn;
    seizure_lengths_in_ms_2 = slimn;
    
    if initial.no_imaging==1
    else
        ECRmlengths_ISI.seizure_onsets_df = round(seizure_onsets_in_ms_2/i2.msperline);
        ECRmlengths_ISI.seizure_offsets_df =  round((seizure_onsets_in_ms_2+seizure_lengths_in_ms_2)/i2.msperline);
    end
    ECRmlengths_ISI.seizure_onsets_in_ms_new = seizure_onsets_in_ms_2;
    ECRmlengths_ISI.seizure_offsets_in_ms_new = seizure_onsets_in_ms_2 + seizure_lengths_in_ms_2;
    ECRmlengths_ISI.seizure_lengths_in_ms_new = ECRmlengths_ISI.seizure_offsets_in_ms_new - ECRmlengths_ISI.seizure_onsets_in_ms_new;
    
    tds.sonms_all_restricts = ECRmlengths_ISI.seizure_onsets_in_ms_new;
    tds.soffms_all_restricts = ECRmlengths_ISI.seizure_offsets_in_ms_new;
    tds.slms_all_restricts = ECRmlengths_ISI.seizure_offsets_in_ms_new - ECRmlengths_ISI.seizure_onsets_in_ms_new;
    
    if initial.no_imaging==1
    else
        tds.sond_all_restricts = ECRmlengths_ISI.seizure_onsets_df;
        tds.soffd_all_restricts = ECRmlengths_ISI.seizure_offsets_df;
        tds.sld_all_restricts = ECRmlengths_ISI.seizure_offsets_df - ECRmlengths_ISI.seizure_onsets_df;
    end
    
    tds.forb_seiz_inds = ts;
    
    tds.rev_corr_offsets = rev_corr_offsets;
    
else
    
    tds.sonms = 0;
end



