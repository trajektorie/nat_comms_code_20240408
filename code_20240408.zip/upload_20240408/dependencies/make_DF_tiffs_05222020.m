
function [tt,DYall] = make_DF_tiffs_05222020(onep,subfolders,files,Folder_master,recording,motion_correct,output_type,append,...
    batch_sec_f_detrend,initial2,write_tiffs,iii,detrend_sec)

%for iii = 1:length(subfolders)
    
    Folder = subfolders(iii).name;
    cd(Folder_master)
    
    %optional: make a df/f movie and write as tif file
    if onep
        foldername = Folder;
    else
        foldername = strcat(Folder_master,Folder,'\motion_corrected\ch2'); % 'F:\stargazer\stg-N1131\11-20-18\';
     end
%     if motion_correct
%         registered_files = subdir(fullfile(foldername,['*',append,'.',output_type]));  % list of registered files (modify this to list all the motion corrected files you need to process)
%     else
%         registered_files = subdir(fullfile(foldername,'*_mc.h5'));
%     end
    cd(foldername)
    FOV = size(read_file(files(1).name,1,1));
    fr =initial2.samplingratehz;                                         % frame rate
    tsub = 1;                                        % degree of downsampling (for 30Hz imaging rate you can try also larger, e.g. 8-10)
    if onep
        ds_filename = [Folder_master,'\ds_data.mat'];
    else
        ds_filename = [foldername,'\ds_data.mat'];
    end
    %data_type = class(read_file(registered_files(1).name,1,1));
    data_type = class(read_file(files(1).name,1,1));
    %data_temp = matfile(ds_filename,'Writable',true);
    %data_temp.Y  = zeros([FOV,0],data_type);
    %data_temp.DY = zeros([FOV,0],'double');
    DYall = zeros([FOV,0],'uint16');
    %data.Yr = zeros([prod(FOV),0],data_type);
    %data_temp.sizY = [FOV,0];
    F_dark = Inf;                                    % dark fluorescence (min of all data)
    numFiles = length(files);
    batch_size = round(fr*batch_sec_f_detrend); %2000;                               % read chunks of that size
    detrend_frs = round(fr*detrend_sec);
    batch_size = round(batch_size/tsub)*tsub;        % make sure batch_size is divisble by tsub
    Ts = zeros(numFiles,1);                          % store length of each file
    cnt = 0;                                         % number of frames processed so far
    tt1 = tic;
    
    i=1
    %for i = 1:numFiles
    %name = registered_files(i).name;
    name = files(i).name;
    info = h5info(name);
    dims = info.Datasets.Dataspace.Size;
    ndimsY = length(dims);                       % number of dimensions (data array might be already reshaped)
    Ts(i) = dims(end);
    %Ysub = zeros(FOV(1),FOV(2),floor(Ts(i)/tsub),data_type);
    %data_temp.DY(FOV(1),FOV(2),sum(floor(Ts/tsub))) = zeros(1,'double');
    %data.Yr(prod(FOV),sum(floor(Ts/tsub))) = zeros(1,data_type);
    %data_temp.DY = zeros([FOV,Ts(i)],'double');
    DYall = zeros([FOV,Ts(i)],'uint16');
    cnt_sub = 0;
    gh=1;
    batchnum=1;
    for t = 1:batch_size:Ts(i)
        batch_read = t
        clear Y YSmooth dw Y7p Y9p Y5p Y579m y5p y5pp dw
        endbatch = min(batch_size+t,Ts(i))
        batch_frs = min(batch_size,Ts(i)-t+1)
        Y = read_file(name,t,batch_frs);
        %
        %             Yad = adapthisteq(Y(:,:,1));
        %
        %
        %             %
        %             med_Y = double(median(Y,3));
        %
        %             med_Y(med_Y<400) = 1e5;
        %
        %             Y = double(Y);
        %             DY = double(zeros(FOV(1),FOV(2),min(batch_size,Ts(i)-t+1)));
        %
        %             DY = double(bsxfun(@rdivide, Y, med_Y)); % double(Y/med_Y);
        %
        
        
        sigma = 1;
        
        YSmooth = imgaussfilt3(Y, sigma);
        %             testYsmooth = YSmooth(:,:,89)
        %             imagesc(testYsmooth)
        Y = YSmooth;
        
        %med_Y = double(median(Y,3));
        
        Y7p = double(prctile(Y,7,3));
        
        Y9p = double(prctile(Y,9,3));
        
        Y5p = double(prctile(Y,5,3));
        
        Y579m = (Y5p+Y7p+Y9p)/3;
        
        y5p = reshape(Y579m,[],1);
        
        if onep
            y5pp = prctile(y5p,54);
        else
            y5pp = prctile(y5p,22);
        end
        
        dw = movmean(Y,detrend_frs,3);
        
        
       % dw = double(Y579m); %double(median(Y,3));
        
        dw(dw<y5pp) = 16000;
        
        
        Y = double(Y);
        DY = double(zeros(FOV(1),FOV(2),min(batch_size,Ts(i)-t+1)));
        
        DY = Y./dw;
        
        %DY = double(bsxfun(@rdivide, Y, dw)); % double(Y/med_Y);
        
        DY(DY>10) = 10;
        
        DY = DY-1;
        
        if strcmp(recording(iii).initial.indicator,'iGluSnfr')
        else
        DY(DY<0) = 0;
        end
        maxfac = 15000/mean(max(max(DY)))
        
        DY = DY*maxfac;
        
        tt(1).maxfac(1,t:endbatch) = maxfac;
        %tt.detrend_divisor(:,:,batchnum) = dw;
        tt(batchnum).detrend_divisor = dw;
        
        %F_dark = min(nanmin(Y(:)),F_dark);
        %ln = size(Y,ndimsY);
        %Y = reshape(Y,[FOV,ln]);
        %Y = cast(downsample_data(Y,'time',tsub),data_type);
        ln = size(Y,3)
        %Ysub(:,:,cnt_sub+1:cnt_sub+ln) = Y;
        cnt_sub = cnt_sub + ln;
        %data_temp.DY(:,:,1:ln) = DY;
        
        DYall(:,:,gh:gh+ln-1) = uint16(DY);
        gh=gh+ln
        batchnum = batchnum+1;
    end
    
    
    
    %data.Yr(:,cnt+1:cnt+cnt_sub) = reshape(Ysub,[],cnt_sub);
    toc(tt1);
    cnt = cnt + cnt_sub;
    %data_temp.sizY(1,3) = cnt;
    %end
    
    % tt.DYall = DYall;
    
    %DY = data_temp.DY;
    
    %     absmindy = min(min(min(DYall)))
    %     absmaxdy = max(max(max(DYall)))
    %
    %DYall(DYall>10) = 10;
    
    %DYall = DYall*1600;
    %DYall = DYall-32000;
    
    %DYall = uint16(DYall);
    
    if write_tiffs
        t = Tiff(['normcorred_DF' '.tif' ],'w8');
        tagstruct.ImageLength = size(DYall,1);
        tagstruct.ImageWidth = size(DYall,2);
        tagstruct.Photometric = Tiff.Photometric.MinIsBlack;
        tagstruct.BitsPerSample = 16;
        tagstruct.SamplesPerPixel = 1;
        tagstruct.PlanarConfiguration = Tiff.PlanarConfiguration.Chunky;
        tagstruct.Software = 'MATLAB';
        tagstruct.SampleFormat = Tiff.SampleFormat.Int;
        t.setTag(tagstruct);
        t.write(int16(DYall(:,:,1)));
        t.close();
        
        for i = 2:size(DYall,3)
            writing_tiff_g = i
            %t = Tiff(['motion_corrected_ch2.tif'],'a');
            t = Tiff(['normcorred_DF' '.tif'],'a');
            tagstruct.ImageLength = size(DYall,1);
            tagstruct.ImageWidth = size(DYall,2);
            tagstruct.Photometric = Tiff.Photometric.MinIsBlack;
            tagstruct.BitsPerSample = 16;
            tagstruct.SamplesPerPixel = 1;
            tagstruct.PlanarConfiguration = Tiff.PlanarConfiguration.Chunky;
            tagstruct.Software = 'MATLAB';
            tagstruct.SampleFormat = Tiff.SampleFormat.Int;
            t.setTag(tagstruct);
            t.write(int16(DYall(:,:,i)));
            t.close();
        end
    end
%end




