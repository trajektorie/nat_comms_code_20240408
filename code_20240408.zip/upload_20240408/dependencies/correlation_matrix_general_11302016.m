function [correlation_results,cr2] = correlation_matrix_general_11302016(initial,deltaf_matrix,Folder,iterations,ictal...
    ,ihlo,test,cmakp,corr_or_sync,ihcs,ilcs,neutrs,nes,moes,norm,cr2_int,sf,p1ms,p2ms,p3ms,p4ms,alpha,rd)
%
% s_f = round(initial.samplingratehz/2);
%
% if mod(s_f,2)
% else
%     s_f = s_f + 1;
% end
%
%
% for i = 1:endframe
%     smooth_deltaf_matrix(:,i) = smooth(deltaf_matrix(:,i),s_f);
% end
%
% fps = 1000/initial.msperline;
% traceOpt.trace_computation = 'oopsi';
% traces = smooth_deltaf_matrix;
% oopsi_spike_trace = filterTraces( traces, fps, traceOpt );
% results.oopsi_filtered_deltaf_matrix = oopsi_spike_trace;
% clear oopsi_spike_trace
%
% deltaf_matrix_oopsi = results.oopsi_filtered_deltaf_matrix;
%
%
% initial.samplingratehz = 1000/initial.msperline;
% %
% % clims = [0.05 0.6];
% % figure(100000)
% % imagesc(deltaf_matrix', clims);
% %



if ihlo == 1
    imm = 'ict_high_ROIs_only';
else
    if ihlo == 2
        imm = 'ict_low_ROIs_only';
    else
        imm = 'all_ROIs';
    end
end

clear  correlation_coefficient_vector

i = 1;

%     segment = size(deltaf_matrix_orisorted,1)/length(stim_params.orientations);
%     invraster2car = zeros(segment*2,size(deltaf_matrix_orisorted,2));
%     invraster2car(1:segment,:) = deltaf_matrix_orisorted((i-1)*segment+1:i*segment,:);
%     invraster2car(segment+1:segment*2,:) = deltaf_matrix_orisorted...
%         (1+(i-1+length(stim_params.orientations)/2)*segment:(i+length(stim_params.orientations)/2)*segment,:);
%     invraster2cat = invraster2car';
%
invraster2cat = deltaf_matrix;


%%%this section measures the correlation coefficient of the concatenated
%%%raster matrix invraster2cat.
%keep3 invraster2cat dname num_nonzero_firstcell invraster2 initial L2Matrix yyyyyy spiked_much_times

clear invraster2cat_binned
clear invraster3cat_binned
%clear positive_subtraction_row_matrix
%clear positive_subtraction_column_matrix
%clear color_of_correlations
pepe1 = round(p1ms/initial.msperline);
if pepe1==0
    pepe1=1;
end
pepe2 = round(p2ms/initial.msperline);
pepe3 = round(p3ms/initial.msperline);
pepe4 = round(p4ms/initial.msperline);



[a b] = size (invraster2cat);
% a = number of frames
% b = number of cells
correlation_coefficient_matrix = zeros (a,a,2,1);
%invraster2cat_binned2 = zeros (a,b,pepe4);
counter = 0


framesa = size(deltaf_matrix,2);
i=1;
while i < iterations+1
    x = randi(floor(framesa)-10)+7;
    %     if find(prohib == x)
    %     else
    shifts(i) = x;
    i=i+1;
    %end
end
%for bin =  [(pepe/16) (pepe/8) (pepe/4) (pepe/2) (pepe) (pepe*2)][
%for bin = [(pepe/8) (pepe/4) (pepe/2) (pepe) (pepe*2)]
for bin = [ pepe1 pepe2 pepe3 pepe4]
    if isempty(bin)
    else
        counter = counter +1
        invraster2cat_binned = zeros (a*bin,floor(b/bin));
        %invraster2cat_binned2 = zeros (a,floor(b/bin),bin);
        
        %%this sections bins the data according to the bin size set by bin
        if (bin == 1)
            invraster2cat_binned2(bin).matrix(:,:) = invraster2cat;
        else
            for cell_binned = 1:a
                invraster2cat_binned =reshape(invraster2cat(cell_binned,1:(floor (b/bin)*bin)),bin,floor (b/bin));
                %invraster2cat_binned2 (cell_binned,:,bin)= sum(invraster2cat_binned);
                invraster2cat_binned2(bin).matrix(cell_binned,:)= sum(invraster2cat_binned);
            end
        end
        
        if sum(ihcs)
            clear u
            u = squeeze(invraster2cat_binned2(bin).matrix(ihcs,:));
            cr2(bin).bin_matrix_avg_ih = mean(u,1);
        else
            cr2(bin).bin_matrix_avg_ih = [];
        end
        
        if sum(ilcs)
            clear u
            u = squeeze(invraster2cat_binned2(bin).matrix(ilcs,:));
            cr2(bin).bin_matrix_avg_il = mean(u,1);
        else
            cr2(bin).bin_matrix_avg_il = [];
        end
        if sum(neutrs)
        clear u
        u = squeeze(invraster2cat_binned2(bin).matrix(neutrs,:));
        cr2(bin).bin_matrix_avg_neutr = mean(u,1);
        else
        cr2(bin).bin_matrix_avg_neutr = 0;
        end
        
        if sum(nes)
        clear u
        u = squeeze(invraster2cat_binned2(bin).matrix(nes,:));
        cr2(bin).bin_matrix_avg_ne = mean(u,1);
        else
        cr2(bin).bin_matrix_avg_ne =0;
        end
        
        if isempty(moes)
        else
            clear u
            u = squeeze(invraster2cat_binned2(bin).matrix(moes(1,1),:));
            cr2(bin).bin_matrix_avg_mot = mean(u,1);
            
            clear u
            u = squeeze(invraster2cat_binned2(bin).matrix(moes(1,2),:));
            cr2(bin).bin_matrix_avg_eeg = mean(u,1);
        end
        
        if corr_or_sync
            if ictal==1
                figure(4738+bin)
                subplot(6,1,1)
                if sum(ihcs)
                    plot(cr2(bin).bin_matrix_avg_ih)
                    axis([0 length(cr2(bin).bin_matrix_avg_ih) 0 1])
                end
                subplot(6,1,2)
                if sum(ilcs)
                    plot(cr2(bin).bin_matrix_avg_il)
                    axis([0 length(cr2(bin).bin_matrix_avg_il) 0 1])
                end
                subplot(6,1,3)
                plot(cr2(bin).bin_matrix_avg_neutr)
                axis([0 length(cr2(bin).bin_matrix_avg_neutr) 0 1])
                subplot(6,1,4)
                plot(cr2(bin).bin_matrix_avg_ne)
                axis([0 length(cr2(bin).bin_matrix_avg_ne) 0 0.2])
                if isempty(moes)
                else
                    subplot(6,1,5)
                    plot(cr2(bin).bin_matrix_avg_mot)
                    if max(cr2(bin).bin_matrix_avg_mot)>0
                        popp = max(cr2(bin).bin_matrix_avg_mot);
                    else
                        popp=0.1;
                    end
                    axis([0 length(cr2(bin).bin_matrix_avg_mot) 0 popp])
                    subplot(6,1,6)
                    plot(cr2(bin).bin_matrix_avg_eeg)
                    axis([0 length(cr2(bin).bin_matrix_avg_eeg) 0 popp ])%max(cr2(bin).bin_matrix_avg_eeg)])
                end
                if sf
                    if norm
                        saveas (4738+bin,[Folder 'averages_of_binned_matrix_norm_tau_' int2str(bin) 'ictal' imm ],'png');
                    else
                        saveas (4738+bin,[Folder 'averages_of_binned_matrix_tau_' int2str(bin) 'ictal' imm ],'png');
                    end
                end
            else
                if ictal == 0
                    figure(4738+bin)
                    subplot(6,1,1)
                    if sum(ihcs)
                        plot(cr2(bin).bin_matrix_avg_ih)
                        axis([0 length(cr2(bin).bin_matrix_avg_ih) 0 1])
                    end
                    subplot(6,1,2)
                    if sum(ilcs)
                        plot(cr2(bin).bin_matrix_avg_il)
                        axis([0 length(cr2(bin).bin_matrix_avg_il) 0 1])
                    end
                    subplot(6,1,3)
                    plot(cr2(bin).bin_matrix_avg_neutr)
                    axis([0 length(cr2(bin).bin_matrix_avg_neutr) 0 1])
                    subplot(6,1,4)
                    plot(cr2(bin).bin_matrix_avg_ne)
                    axis([0 length(cr2(bin).bin_matrix_avg_ne) 0 0.2])
                    if isempty(moes)
                    else
                        subplot(6,1,5)
                        plot(cr2(bin).bin_matrix_avg_mot)
                        if  max(cr2(bin).bin_matrix_avg_mot)>0
                            bbn =  max(cr2(bin).bin_matrix_avg_mot);
                        else
                            bbn = 0.1
                        end
                        axis([0 length(cr2(bin).bin_matrix_avg_mot) 0 bbn])
                        subplot(6,1,6)
                        plot(cr2(bin).bin_matrix_avg_eeg)
                        axis([0 length(cr2(bin).bin_matrix_avg_eeg) 0 bbn ])%max(cr2(bin).bin_matrix_avg_eeg)])
                    end
                    if sf
                        if norm
                            saveas (4738+bin,[Folder 'averages_of_binned_matrix_norm_tau_' int2str(bin) 'interictal' imm ],'png');
                        else
                            saveas (4738+bin,[Folder 'averages_of_binned_matrix_tau_' int2str(bin) 'interictal' imm ],'png');
                        end
                    end
                end
            end
        end
        
        
        
        figure   (bin)
        load('deconv_cmap.mat')
        
        cmaipp = cmap;
        clim2 = max(max(invraster2cat_binned2(bin).matrix(:,:)))
        clims = [0 clim2/4];
        cr2(bin).clims = clims;
        if ictal
            clims = cr2_int(bin).clims;
        end
        twomin = (round(1000/initial.msperline)*120);
        if twomin>size(invraster2cat_binned2(bin).matrix,2)
            twomin=size(invraster2cat_binned2(bin).matrix,2)
        end
        imagesc (invraster2cat_binned2(bin).matrix(:,1:twomin) ,clims)
        colormap(cmaipp)
        colorbar
        if sf
            if corr_or_sync
                
                if ictal
                    if ictal == 1
                        if norm
                            saveas (bin,[Folder 'binned_matrix_norm_tau_' int2str(bin) 'ictal' imm ],'png');
                        else
                            saveas (bin,[Folder 'binned_matrix_tau_' int2str(bin) 'ictal' imm ],'png');
                        end
                    else
                        if norm
                            saveas (bin,[Folder 'binned_matrix_norm_tau_' int2str(bin) imm ],'png');
                        else
                            saveas (bin,[Folder 'binned_matrix_tau_' int2str(bin) imm ],'png');
                        end
                    end
                else
                    if norm
                        saveas (bin,[Folder 'binned_matrix_norm_tau_' int2str(bin) 'interictal' imm],'png');
                    else
                        saveas (bin,[Folder 'binned_matrix_tau_' int2str(bin) 'interictal' imm],'png');
                    end
                end
            else
                if ictal
                    if ictal == 1
                        if norm
                            saveas (bin,[Folder 'synchr_binned_matrix_norm_tau_' int2str(bin) 'ictal' imm ],'png');
                        else
                            saveas (bin,[Folder 'synchr_binned_matrix_tau_' int2str(bin) 'ictal' imm ],'png');
                        end
                    else
                        if norm
                            saveas (bin,[Folder 'synchr_binned_matrix_norm_tau_' int2str(bin) imm ],'png');
                        else
                            saveas (bin,[Folder 'synchr_binned_matrix_tau_' int2str(bin) imm ],'png');
                        end
                    end
                else
                    if norm
                        saveas (bin,[Folder 'synchr_binned_matrix_norm_tau_' int2str(bin) 'interictal' imm],'png');
                    else
                        saveas (bin,[Folder 'synchr_binned_matrix_tau_' int2str(bin) 'interictal' imm],'png');
                    end
                end
            end
        end
        if rd
        shuffled_correlation_coefficient =  vvar(a,a,iterations, 'double');  % % 
        else
            shuffled_correlation_coefficient =  zeros (a,a,iterations);
        end
        invraster2cat_binned_matrix = invraster2cat_binned2(bin).matrix(:,:) ;
        inv_invraster2cat =  invraster2cat_binned_matrix';
        
        if corr_or_sync
            [correlation_coefficient p_corrcoeff] = corrcoef (inv_invraster2cat);
        else
            correlation_coefficient = synchr_coefficients(inv_invraster2cat);
        end
        
        clear inv_invraster2cat
        
        figure(250*bin)
        clims = [-0.8, 0.8];
        imagesc (correlation_coefficient,clims);
        colormap(cmakp)
        colorbar
        if sf
            if corr_or_sync
                if ictal
                    if ictal == 1
                        if norm
                            saveas (250*bin,[Folder 'raw_corrcoeff_matrix_norm_tau_' int2str(bin) 'ictal' imm ],'png');
                        else
                            saveas (250*bin,[Folder 'raw_corrcoeff_matrix_tau_' int2str(bin) 'ictal' imm ],'png');
                        end
                    else
                        if norm
                            saveas (250*bin,[Folder 'raw_corrcoeff_matrix_norm_tau_' int2str(bin) imm ],'png');
                        else
                            saveas (250*bin,[Folder 'raw_corrcoeff_matrix_tau_' int2str(bin) imm ],'png');
                        end
                    end
                else
                    if norm
                        saveas (250*bin,[Folder 'raw_corrcoeff_matrix_norm_tau_' int2str(bin) 'interictal' imm],'png');
                    else
                        saveas (250*bin,[Folder 'raw_corrcoeff_matrix_tau_' int2str(bin) 'interictal' imm],'png');
                    end
                end
            else
                if ictal
                    if ictal == 1
                        if norm
                            saveas (250*bin,[Folder 'synchr_raw_corrcoeff_matrix_norm_tau_' int2str(bin) 'ictal' imm ],'png');
                        else
                            saveas (250*bin,[Folder 'synchr_raw_corrcoeff_matrix_tau_' int2str(bin) 'ictal' imm ],'png');
                        end
                    else
                        if norm
                            saveas (250*bin,[Folder 'synchr_raw_corrcoeff_matrix_norm_tau_' int2str(bin) imm ],'png');
                        else
                            saveas (250*bin,[Folder 'synchr_raw_corrcoeff_matrix_tau_' int2str(bin) imm ],'png');
                        end
                    end
                else
                    if norm
                        saveas (250*bin,[Folder 'synchr_raw_corrcoeff_matrix_norm_tau_' int2str(bin) 'interictal' imm],'png');
                    else
                        saveas (250*bin,[Folder 'synchr_raw_corrcoeff_matrix_tau_' int2str(bin) 'interictal' imm],'png');
                    end
                end
            end
        end
        %invraster3cat_binned = zeros (a*24,b);
        invraster3cat_binned2 = zeros (a,floor(b/bin));
        
        for iteration = 1:iterations
            iteration
            %large_raster_shuffle;
            
            
            for cell_binned = 1:a
                
                x = randi(iterations,1,iterations);
                ind_it = x(1,iteration);
                %
                %                     if iteration>iterations-a-1
                %                         ind_it = iteration-cell_binned*2;
                %                     else
                %                     ind_it = iteration+cell_binned;
                %                     end
                invraster2cats(cell_binned,1:framesa-shifts(ind_it)) = invraster2cat(cell_binned,shifts(ind_it)+1:framesa);
                invraster2cats(cell_binned,framesa-shifts(ind_it)+1:framesa) = invraster2cat(cell_binned,1:shifts(ind_it));
            end
            
            
            %[invraster3cat] = function_large_raster_shuffle (invraster2cat');
            %%here we bin the shuffled trace at the same bin as the original
            %%trace.
            if (bin == 1)
                invraster3cat_binned2 (:,:,1) = invraster2cats;
            else
                parfor cell_binned = 1:a
                    invraster3cat_binned =reshape(invraster2cats(cell_binned,1:(floor (b/bin)*bin)),bin,floor (b/bin));
                    
                    invraster3cat_binned2 (cell_binned,:)= sum(invraster3cat_binned);
                end
            end
            % clear invraster3cat_binned
            %invraster3cat_binned_matrix = invraster3cat_binned2 (:,:,bin);
            inv_invraster3cat =  invraster3cat_binned2';
            %shuffled_correlation_coefficient(:,:,iteration) = corrcoef (inv_invraster3cat);
            
            if corr_or_sync
                shuffled_correlation_coefficient(:,:,iteration) = corrcoef (inv_invraster3cat);
            else
                shuffled_correlation_coefficient(:,:,iteration) = synchr_coefficients (inv_invraster3cat);
            end
            
            
            % clear inv_invraster3cat
        end
        
        %     permuted_shuffled_correlation_coefficient = permute (shuffled_correlation_coefficient,[3,1,2]); %iteration is now the first dimension
        %     clear shuffled_correlation_coefficient
        %     sort_corr = sort (permuted_shuffled_correlation_coefficient);
        %     clear permuted_shuffled_correlation_coefficient
        %     ipermuted_sort_cor = ipermute (sort_corr,[3,1,2]);
        %     sort_95 = ipermuted_sort_cor (:,:,95);
        %     clear ipermuted_sort_cor sort_corr
        
        for cl = 1:a
            for dl = 1:a
                tosort = squeeze(shuffled_correlation_coefficient(cl,dl,:));
                sort_corr = sort(tosort);
                sort_95(cl,dl) = sort_corr(round((1-alpha)*iterations),1);
                sort_05(cl,dl) = sort_corr(max ([1, round(alpha*iterations)]),1);
                mean_sort = mean(sort_corr);
                corr_coeff_minus_avg_shuf_all(cl,dl) = correlation_coefficient(cl,dl) - mean_sort;
                if correlation_coefficient(cl,dl) > 0
                    subtraction(cl,dl) = correlation_coefficient(cl,dl) - sort_95(cl,dl);
                    if subtraction(cl,dl)>0
                        corr_coeff_minus_avg_shuf(cl,dl) = correlation_coefficient(cl,dl) - mean_sort;
                    else
                        corr_coeff_minus_avg_shuf(cl,dl) = 0;
                    end
                    
                else
                    subtraction(cl,dl) = -(correlation_coefficient(cl,dl) - sort_05(cl,dl));
                    if subtraction(cl,dl) > 0
                        corr_coeff_minus_avg_shuf(cl,dl) = correlation_coefficient(cl,dl) - mean_sort;
                    else
                        corr_coeff_minus_avg_shuf(cl,dl) = 0;
                    end
                end
                all_shuf_subtr(cl,dl) = mean_sort;
            end
            
        end
        
        %subtraction = correlation_coefficient - sort_95;
        
        [positive_subtraction_row positive_subtraction_column] = find(subtraction > 0);
        positive_subtraction_row_matrix (1:numel (positive_subtraction_row),bin) = positive_subtraction_row;
        positive_subtraction_column_matrix (1:numel (positive_subtraction_column),bin) = positive_subtraction_column;
        subtraction_index = find(subtraction>0);
        correlation_coefficient_matrix (:,:,bin) = correlation_coefficient;
        p_corrcoeff_matrix(:,:,bin) = p_corrcoeff;
        correlation_coefficient_matrix_min_avg_shuf(:,:,bin) = corr_coeff_minus_avg_shuf;
        correlation_coefficient_matrix_min_avg_shuf_all(:,:,bin) = corr_coeff_minus_avg_shuf_all;
        
        number_of_correlations_found (counter)= numel (positive_subtraction_row)/2;
        total_possible_correlations (counter)= ((a)*(a-1))/2;
        connection_ratio (counter)= number_of_correlations_found (counter)/total_possible_correlations (counter);
        mean_amplitude_correlations (counter)= mean (subtraction (subtraction_index));
        synchronicity_index (counter) = connection_ratio (counter)*mean_amplitude_correlations (counter);
    end
end


correlation_results.subtraction=subtraction;
correlation_results.invraster2cat_binned_matrix = invraster2cat_binned_matrix;
correlation_results.invraster2cat_binned2 = invraster2cat_binned2;
correlation_results.correlation_coefficient_matrix = correlation_coefficient_matrix;
correlation_results.p_corrcoeff_matrix = p_corrcoeff_matrix;
correlation_results.connection_ratio = connection_ratio;
correlation_results.mean_amplitude_correlations = mean_amplitude_correlations;
correlation_results.synchronicity_index = synchronicity_index;
correlation_results.correlation_coefficient_matrix_min_avg_shuf_sig_only = correlation_coefficient_matrix_min_avg_shuf;
correlation_results.correlation_coefficient_matrix_min_avg_shuf_all = correlation_coefficient_matrix_min_avg_shuf_all;
%
%     results.corcoef_num_cor_found_by_ori(:,i) = number_of_correlations_found;
%     results.corcoef_connection_ratio_by_ori(:,i) = connection_ratio;
%     results.corcoef_mean_amp_correlations_by_ori(:,i) = mean_amplitude_correlations;
%     results.corceof_synchronicity_index_by_ori(:,i) = synchronicity_index;
%     results.corcoef_correlations_by_ori = zeros(size(correlation_coefficient_matrix,1),size(correlation_coefficient_matrix,2)...
%         ,size(correlation_coefficient_matrix,3),size(correlation_coefficient_matrix,4));
%     results.corcoef_correlations_by_ori = correlation_coefficient_matrix;
%
[size_pos_row  size_pos_column] = size (positive_subtraction_row_matrix);
color_of_correlations = zeros (a,a,pepe4);
%close all


if ihlo == 1
    imm = 'ict_high_ROIs_only';
else
    if ihlo == 2
        imm = 'ict_low_ROIs_only';
    else
        imm = 'all_ROIs';
    end
end

%for bin = [(pepe/16) (pepe/8) (pepe/4) (pepe/2) (pepe) (pepe*2)]
%for bin = [(pepe/8) (pepe/4) (pepe/2) (pepe) (pepe*2)]
for bin = [pepe1 pepe2 pepe3 pepe4]
    if isempty(bin)
    else
        
        color_of_correlations = zeros (a,a,bin); %pepe4);
        
        for pixel = 1:numel (find(positive_subtraction_row_matrix (:,bin)));
            color_of_correlations (positive_subtraction_row_matrix (pixel,bin),positive_subtraction_column_matrix (pixel,bin),bin) = ...
                correlation_coefficient_matrix_min_avg_shuf (positive_subtraction_row_matrix (pixel,bin),positive_subtraction_column_matrix (pixel,bin),bin);
        end
        figure (1000+bin)
        clims = [-0.8, 0.8];
        if isempty(color_of_correlations)
        else
            imagesc (color_of_correlations (:,:,bin),clims);
            colormap(cmakp)
            colorbar
            % title ([initial.moviename ': tau: ' int2str(bin) ' frames'])
            title ([Folder ': tau: ' int2str(bin) ' frames'])
            %cd (Folder)
            %saveas (bin,[initial.moviename '_correlation_diagram_tau_' int2str(bin)],'png');
            if sf
                if corr_or_sync
                    if test
                        if ictal
                            if ictal == 1
                                if norm
                                    saveas (1000+bin,[Folder 'test_correlation_diagram_norm_tau_' int2str(bin) 'ictal' imm ],'png');
                                else
                                    saveas (1000+bin,[Folder 'test_correlation_diagram_tau_' int2str(bin) 'ictal' imm ],'png');
                                end
                            else
                                if norm
                                    saveas (1000+bin,[Folder 'test_correlation_diagram_norm_tau_' int2str(bin) imm ],'png');
                                else
                                    saveas (1000+bin,[Folder 'test_correlation_diagram_tau_' int2str(bin) imm ],'png');
                                end
                            end
                        else
                            if norm
                                saveas (1000+bin,[Folder 'test_correlation_diagram_norm_tau_' int2str(bin) 'interictal' imm],'png');
                            else
                                saveas (1000+bin,[Folder 'test_correlation_diagram_tau_' int2str(bin) 'interictal' imm],'png');
                            end
                        end
                    else
                        if ictal
                            if ictal == 1
                                if norm
                                    saveas (1000+bin,[Folder '_correlation_diagram_norm_tau_' int2str(bin) 'ictal' imm ],'png');
                                else
                                    saveas (1000+bin,[Folder '_correlation_diagram_tau_' int2str(bin) 'ictal' imm ],'png');
                                end
                            else
                                if norm
                                    saveas (1000+bin,[Folder '_correlation_diagram_norm_tau_' int2str(bin) imm ],'png');
                                else
                                    saveas (1000+bin,[Folder '_correlation_diagram_tau_' int2str(bin) imm ],'png');
                                end
                            end
                        else
                            if norm
                                saveas (1000+bin,[Folder '_correlation_diagram_norm_tau_' int2str(bin) 'interictal' imm],'png');
                            else
                                saveas (1000+bin,[Folder '_correlation_diagram_tau_' int2str(bin) 'interictal' imm],'png');
                                
                            end
                        end
                    end
                else
                    if test
                        if ictal
                            if ictal == 1
                                if norm
                                    saveas (1000+bin,[Folder 'synchr_test_correlation_diagram_norm_tau_' int2str(bin) 'ictal' imm ],'png');
                                else
                                    saveas (1000+bin,[Folder 'synchr_test_correlation_diagram_tau_' int2str(bin) 'ictal' imm ],'png');
                                end
                            else
                                if norm
                                    saveas (1000+bin,[Folder 'synchr_test_correlation_diagram_norm_tau_' int2str(bin) imm ],'png');
                                else
                                    saveas (1000+bin,[Folder 'synchr_test_correlation_diagram_tau_' int2str(bin) imm ],'png');
                                end
                            end
                        else
                            if norm
                                saveas (1000+bin,[Folder 'synchr_test_correlation_diagram_norm_tau_' int2str(bin) 'interictal' imm],'png');
                            else
                                saveas (1000+bin,[Folder 'synchr_test_correlation_diagram_tau_' int2str(bin) 'interictal' imm],'png');
                            end
                        end
                    else
                        if ictal
                            if ictal == 1
                                if norm
                                    saveas (1000+bin,[Folder 'synchr__correlation_diagram_norm_tau_' int2str(bin) 'ictal' imm ],'png');
                                else
                                    saveas (1000+bin,[Folder 'synchr__correlation_diagram_tau_' int2str(bin) 'ictal' imm ],'png');
                                end
                            else
                                if norm
                                    saveas (1000+bin,[Folder 'synchr__correlation_diagram_norm_tau_' int2str(bin) imm ],'png');
                                else
                                    saveas (1000+bin,[Folder 'synchr__correlation_diagram_tau_' int2str(bin) imm ],'png');
                                end
                            end
                        else
                            if norm
                                saveas (1000+bin,[Folder 'synchr__correlation_diagram_norm_tau_' int2str(bin) 'interictal' imm],'png');
                            else
                                saveas (1000+bin,[Folder 'synchr__correlation_diagram_tau_' int2str(bin) 'interictal' imm],'png');
                            end
                        end
                    end
                end
            end
            
            
            for t = 1:size(correlation_coefficient_matrix_min_avg_shuf,1)
                correlation_coefficient_vector(size(correlation_coefficient_matrix_min_avg_shuf,1)*(t-1)+1:size(correlation_coefficient_matrix_min_avg_shuf,1)*t,1) = ...
                    correlation_coefficient_matrix_min_avg_shuf(t,:,bin);
            end
            
            x = [-0.35 -0.3 -0.25 -0.2 -0.15 -0.1 -0.05 0 0.05 0.1 0.15 0.2 0.25 0.3 0.35 0.4 0.45 0.5 0.55 0.6 0.65 0.7 0.75 0.8 0.85 0.9 0.95 1 1.05 ];
            figure(9*bin)
            hist(correlation_coefficient_vector(:,1),x)
            if sf
                if corr_or_sync
                    if test
                        if ictal
                            if ictal ==1
                                if norm
                                    saveas (9*bin,[Folder 'test_correlation_coefficient_distribution_ictal_norm_' int2str(bin) imm ],'png');
                                else
                                    saveas (9*bin,[Folder 'test_correlation_coefficient_distribution_ictal_' int2str(bin) imm ],'png');
                                end
                            else
                                if norm
                                    saveas (9*bin,[Folder 'test_correlation_coefficient_distribution_norm_'  int2str(bin) imm ],'png');
                                else
                                    saveas (9*bin,[Folder 'test_correlation_coefficient_distribution_'  int2str(bin) imm ],'png');
                                end
                            end
                        else
                            if norm
                                saveas (9*bin,[Folder 'test_correlation_coefficient_distribution_interictal_norm_' int2str(bin) imm ],'png');
                            else
                                saveas (9*bin,[Folder 'test_correlation_coefficient_distribution_interictal_' int2str(bin) imm ],'png');
                            end
                        end
                    else
                        if ictal
                            if ictal ==1
                                if norm
                                    saveas (9*bin,[Folder '_correlation_coefficient_distribution_ictal_norm_' int2str(bin) imm ],'png');
                                else
                                    saveas (9*bin,[Folder '_correlation_coefficient_distribution_ictal_' int2str(bin) imm ],'png');
                                end
                            else
                                if norm
                                    saveas (9*bin,[Folder '_correlation_coefficient_distribution_norm_' int2str(bin) imm ],'png');
                                else
                                    saveas (9*bin,[Folder '_correlation_coefficient_distribution_' int2str(bin) imm ],'png');
                                end
                            end
                        else
                            if norm
                                saveas (9*bin,[Folder '_correlation_coefficient_distribution_interictal_norm_' int2str(bin) imm ],'png');
                            else
                                saveas (9*bin,[Folder '_correlation_coefficient_distribution_int_' int2str(bin) imm ],'png');
                            end
                        end
                    end
                else
                    if test
                        if ictal
                            if ictal ==1
                                if norm
                                    saveas (9*bin,[Folder 'synchr_test_correlation_coefficient_distribution_ictal_norm_' int2str(bin) imm ],'png');
                                else
                                    saveas (9*bin,[Folder 'synchr_test_correlation_coefficient_distribution_ictal_' int2str(bin) imm ],'png');
                                end
                            else
                                if norm
                                    saveas (9*bin,[Folder 'synchr_test_correlation_coefficient_distribution_norm_'  int2str(bin) imm ],'png');
                                else
                                    saveas (9*bin,[Folder 'synchr_test_correlation_coefficient_distribution_'  int2str(bin) imm ],'png');
                                end
                            end
                        else
                            if norm
                                saveas (9*bin,[Folder 'synchr_test_correlation_coefficient_distribution_interictal_norm_' int2str(bin) imm ],'png');
                            else
                                saveas (9*bin,[Folder 'synchr_test_correlation_coefficient_distribution_interictal_' int2str(bin) imm ],'png');
                            end
                        end
                    else
                        if ictal
                            if ictal ==1
                                if norm
                                    saveas (9*bin,[Folder 'synchr__correlation_coefficient_distribution_ictal_norm_' int2str(bin) imm ],'png');
                                else
                                    saveas (9*bin,[Folder 'synchr__correlation_coefficient_distribution_ictal_' int2str(bin) imm ],'png');
                                end
                            else
                                if norm
                                    saveas (9*bin,[Folder 'synchr__correlation_coefficient_distribution_norm_' int2str(bin) imm ],'png');
                                else
                                    saveas (9*bin,[Folder 'synchr__correlation_coefficient_distribution_' int2str(bin) imm ],'png');
                                end
                            end
                        else
                            if norm
                                saveas (9*bin,[Folder 'synchr__correlation_coefficient_distribution_interictal_norm_' int2str(bin) imm ],'png');
                            else
                                saveas (9*bin,[Folder 'synchr__correlation_coefficient_distribution_interictal_' int2str(bin) imm ],'png');
                            end
                        end
                    end
                end
            end
            correlation_results.correlation_coefficient_vector(:,bin) = correlation_coefficient_vector;
            
            
        end
        correlation_results.all_shuf_subtr = all_shuf_subtr;
    end
    
    
end


