
function [recordingc] = clustering_one_rec(recording,Folder_master,subfolders,corr_beg_sec_1,corr_end_sec_1,...
    corr_beg_sec_2,corr_end_sec_2,beg_sec_prez,end_sec_prez,beg_sec_postz,end_sec_postz,ict_or_int_or_all,...
    onep,onep_binned_twice,iterations,sf,ii,...
    excl_running,excl_whisking,i_h,wheel_thr,ernoiv,minds,sqrois,movie_avg_8,rd,onep_stg,ri)



%for ii = 1:size(recording,2) %3:4 %
close all
Folder = subfolders(ii).name;
cd(Folder_master)
folders = dir(Folder_master);

gha=0
for op = 1:size(folders,1)
    if strcmp(folders(op).name,Folder)
        gha=1;
    end
end
if gha==0
    
    mkdir(Folder);
end
cd(Folder)


if onep
    
    %concatenate LH, RH
    if sqrois
        sdec1 = recording(ii).onep_results_2.DF_sq_left_no_noise';
        recordingc(ii).LH_elements = 1:1:size(sdec1,1);
        sdec2 = recording(ii).onep_results_2.DF_sq_right_no_noise';
        recordingc(ii).RH_elements = 1:1:size(sdec2,1);
        sdec = cat(1,sdec1,sdec2);
        sdec(isnan(sdec)) = 0;
        cdec = sdec';
        sdec=cdec;
    else
           if onep_stg
            sdec = matrix;
            cdec=matrix;
        else
        if movie_avg_8==0
            sdec = recording(ii).S_dec';
            cdec = recording(ii).C_dec';
            sdec(isnan(sdec)) = 0;
        else
            if ~(sum(sum(ernoiv(:,1:3)))==0)
                sdec=ernoiv;
                sdec(isnan(sdec)) = 0;
                cdec=sdec;
            end
            
        end
           end
    end
else
    if ~(sum(ernoiv(:,1))==0)
        sdec=ernoiv';
        cdec=sdec;
    end
    
    %     if isfield(recording(ii),'suite2p_deconv')
    %         sdec = recording(ii).suite2p_deconv.sp_no_noise';
    %         cdec = recording(ii).suite2p_deconv.ca_no_noise';
    %     else
    %         sdec = real(recording(ii).S_dec);
    %         cdec = recording(ii).C_dec;
    %     end
    
    sdec(isnan(sdec)) = 0;
    if ~onep
        if isfield(recording(ii),'suite2p_deconv')
            if ~isempty(recording(ii).suite2p_deconv)
                if size(sdec,1)>size(recording(ii).suite2p_deconv.sp,2)
                    sdec(size(sdec,1)-9:end,:) = []; %sdec(size(recording(ii).F_full,1)+1:end,:) = [];
                end
            else
                sdec(size(sdec,1)-9:end,:) = [];
            end
        else
            sdec(size(sdec,1)-9:end,:) = [];
        end
    end
end

if ~onep
    sdecfp = sdec;
    sdecor = sdec;
end
%spks = spike_rates;
%size(cdec)
%size(sdec)
if size(sdec,1)==0
else
    
    endframe = size(sdec,1);
    if ~onep
        neuns = round(randi(endframe,1,12));
        fs = recording(ii).initial2.samplingratehz;
        lplo = round(90*fs);
        if lplo>size(sdec,2)
            lplo = size(sdec,2)
        end
        
        ge = 0;
        a=0;
        while ge == 0
            
            figure(456+a)
            for i = 1:12
                subplot(3,4,i)
                yyaxis left
                plot(cdec(neuns(1,i),1:lplo));
                hold on
                yyaxis right
                plot(sdecfp(neuns(1,i),1:lplo));
                hold on
                %         plot(spks(neuns(1,i),1:lplo));
                %         hold on
            end
            %
            std_level = 0;
            
            prompt = {'good enough (1) or not (0) ?'};
            dlg_title = '1 if ready to go, 0 if not';
            num_lines = 1;
            def = {'1'};
            answer = inputdlg(prompt,dlg_title,num_lines,def);
            answer = str2mat(answer);
            ge = str2num(answer);
            
            if ge==0
                a=a+1;
                std_level = std_level+1;
                
                sdec =sdecor;
                for ert = 1:size(sdec,1)
                    sdeccur = sdec(ert,:);
                    meas = median(sdeccur);
                    stds = std(sdeccur,0);
                    
                    sdeccur(sdeccur<meas+std_level*stds) = 0;
                    
                    %
                    sdec(ert,:) = sdeccur;
                    
                    sdeccur(sdeccur>0) = 0.4;
                    sdeccur(sdeccur<0) = 0;
                    sdecfp(ert,:) = sdeccur;
                end
                
                %         [smooth_avg_diffwhisk_extrap_no_noise,apm_diffwhisk,dw_nonoise,apmdw,noisedata_diffwhisk] = ...
                %         denoise(initial,smooth_avg_diffwhisk_extrap_interp(1:ffrsi,1),smooth_avg_diffwhisk_extrap_interp(1:ffrsi,1),...
                %         std_level,initial);
                %             dw_nonoise_binary = zeros(size(dw_nonoise));
                %             dw_nonoise_binary(find(dw_nonoise)) = 1;
                
            end
        end
        
        recordingc(ii).sdec_std_level = std_level;
    end
    recordingc(ii).sdec_thr = sdec;
    %
    %     %remove running wnd whisking indices from sdec, adjust
    %     %corr_beg_sec and corr_end_sec accordingly!
    
    if excl_running
        wheel_mot = recording(ii).wheel_new.smooth_abs_speed_extrap;
        wheel_mot_df = recording(ii).wheel_new.smooth_abs_speed_exxtrap;
        
        running = zeros(size(wheel_mot));
        running_df = zeros(size(wheel_mot_df));
        
        wheel_mot_min = wheel_mot-wheel_thr;%0.0107;
        wheel_mot_min(wheel_mot_min<0) = 0;
        
        wheel_mot_min_df = wheel_mot_df-wheel_thr;%0.0107;
        wheel_mot_min_df(wheel_mot_min_df<0) = 0;
        
        running(find(wheel_mot_min)) = 1;
        if length(running)>length(recording(ii).EEG_results_nonoise.oopsi_interp_values)
            running(length(recording(ii).EEG_results_nonoise.oopsi_interp_values)+1:length(running),:) = [];
        end
        recordingc(ii).running = running;
        [ru_inds ru] = find(running>0);
        
        ru_ind_locs = zeros(size(recording(ii).EEG_results_nonoise.oopsi_interp_values,1),1);
        ru_ind_locs(ru_inds,1) = 1;
        
        running_df(find(wheel_mot_min_df)) = 1;
        if length(running_df)>length(sdec)
            running_df(length(sdec)+1:length(running_df),:) = [];
        end
        recordingc(ii).running_df = running_df;
        [ru_inds_df, ru_df] = find(running_df>0);
    end
    
    if isfield(recording(ii),'whisking')
        if ~isempty(recording(ii).whisking)
            if excl_whisking
                wh_bin = recording(ii).whisking.dw_nonoise_binary;
                %bring to 100Hz:
                freqd=100;
                if i_h
                    
                    initiald.msperline = 1000/recording(ii).whisking.fr; %initial.msperline;
                    [wh_100,wh_100] = cat_and_deltaf_interp_05_2020...
                        (wh_bin,wh_bin,initiald,freqd,1);
                    recordingc(ii).whisking = wh_100;
                else
                    recordingc(ii).whisking = wh_bin;
                end
                [wh_inds wh] = find(recordingc(ii).whisking>0);
                
                wh_ind_locs = zeros(size(recording(ii).EEG_results_nonoise.oopsi_interp_values,1),1);
                wh_ind_locs(wh_inds,1) = 1;
                
                rwsmadenn = recording(ii).whisking.dw_nonoise_binary;
                rwsmadenn_extrap  = zeros(round(length(rwsmadenn)/(freqd/fs)),size(rwsmadenn,2));
                for i = 1: size(sdec,2)
                    if round((i-1)*freqd/fs)+1 <=length(rwsmadenn)
                        rwsmadenn_extrap(i,1) = rwsmadenn(round((i-1)*freqd/fs)+1,1);
                    end
                end
                [wh_inds_df wh_df] = find(rwsmadenn_extrap>0);
                
            end
        else
            wh_inds_df=[];
            wh_ind_locs = zeros(size(recording(ii).EEG_results_nonoise.oopsi_interp_values,1),1);
        end
    end
    
    
    
    %ADD exclude mean2min_inds here!!!
    
    if excl_running && excl_whisking
        to_remove = union(ru_inds_df,wh_inds_df);
        sdec(:,to_remove) = [];
        
        hgy = max(length(ru_ind_locs),length(wh_ind_locs));
        un_ind_locs = zeros(hgy,1);
        for ui=1:hgy
            if ui<=min(length(ru_ind_locs),length(wh_ind_locs))
                if ru_ind_locs(ui,1) || wh_ind_locs(ui,1)
                    un_ind_locs(ui,1) = 1;
                end
            else
                if length(ru_ind_locs)>length(wh_ind_locs)
                    if ru_ind_locs(ui,1)
                        un_ind_locs(ui,1) = 1;
                    end
                else
                    if wh_ind_locs(ui,1)
                        un_ind_locs(ui,1) = 1;
                    end
                end
            end
        end
        
        cbs1 = corr_beg_sec_1(1,ii);
        corr_beg_sec_1(1,ii) = cbs1 - sum(un_ind_locs(1:min(cbs1,length(un_ind_locs)/100)*100,1))/100;
        recordingc(ii).corr_results.corr_beg_sec_1_subtracted_frames_100Hz_wh_ru = sum(un_ind_locs(1:min(cbs1,length(un_ind_locs)/100)*100,1))/100;
        
        ces1 = corr_end_sec_1(1,ii);
        corr_end_sec_1(1,ii) = ces1 - sum(un_ind_locs(1:min(ces1,length(un_ind_locs)/100)*100,1))/100;
        recordingc(ii).corr_results.corr_end_sec_1_subtracted_frames_100Hz_wh_ru = sum(un_ind_locs(1:min(ces1,length(un_ind_locs)/100)*100,1))/100;
        
        cbs2 = corr_beg_sec_2(1,ii);
        corr_beg_sec_2(1,ii) = cbs2 - sum(un_ind_locs(1:min(cbs2,length(un_ind_locs)/100)*100,1))/100;
        recordingc(ii).corr_results.corr_beg_sec_2_subtracted_frames_100Hz_wh_ru = sum(un_ind_locs(1:min(cbs2,length(un_ind_locs)/100)*100,1))/100;
        
        ces2 = corr_end_sec_2(1,ii);
        corr_end_sec_2(1,ii) = ces2 - sum(un_ind_locs(1:min(ces2,length(un_ind_locs)/100)*100,1))/100;
        recordingc(ii).corr_results.corr_end_sec_2_subtracted_frames_100Hz_wh_ru = sum(un_ind_locs(1:min(ces2,length(un_ind_locs)/100)*100,1))/100;
        
%         corr_end_sec_2(1,ii) = ces2 - (sum(un_ind_locs(1:min(ces1,length(un_ind_locs)/100)*100,1))+...
%             sum(un_ind_locs(min(cbs2,length(un_ind_locs)/100)*100:min(ces2,length(un_ind_locs)/100)*100,1)))/100;         
        
    else
        if excl_running
            sdec(:,ru_inds_df) = [];
            
            
            cbs1 = corr_beg_sec_1(1,ii);
            %corr_end_sec_1(1,ii) = ces1 - sum(ru_ind_locs(1:ces1*100,1))/100;
            corr_beg_sec_1(1,ii) = cbs1 - sum(ru_ind_locs(1:min(cbs1,length(ru_ind_locs)/100)*100,1))/100;
            recordingc(ii).corr_results.corr_beg_sec_1_subtracted_frames_100Hz_ru = sum(ru_ind_locs(1:min(cbs1,length(ru_ind_locs)/100)*100,1))/100;
            
            ces1 = corr_end_sec_1(1,ii);
            %corr_end_sec_1(1,ii) = ces1 - sum(ru_ind_locs(1:ces1*100,1))/100;
            corr_end_sec_1(1,ii) = ces1 - sum(ru_ind_locs(1:min(ces1,length(ru_ind_locs)/100)*100,1))/100;
            recordingc(ii).corr_results.corr_end_sec_1_subtracted_frames_100Hz_ru = sum(ru_ind_locs(1:min(ces1,length(ru_ind_locs)/100)*100,1))/100;
            
            cbs2 = corr_beg_sec_2(1,ii);
            %corr_beg_sec_2(1,ii) = cbs2 - sum(ru_ind_locs(1:cbs2*100,1))/100;
            corr_beg_sec_2(1,ii) = cbs2 - sum(ru_ind_locs(1:min(cbs2,length(ru_ind_locs)/100)*100,1))/100;
            recordingc(ii).corr_results.corr_beg_sec_2_subtracted_frames_100Hz_ru = sum(ru_ind_locs(1:min(cbs2,length(ru_ind_locs)/100)*100,1))/100;
            
            ces2 = corr_end_sec_2(1,ii);
            %corr_end_sec_2(1,ii) = ces2 - (sum(ru_ind_locs(1:ces1*100,1))+sum(ru_ind_locs(cbs2*100:ces2*100)))/100;
            corr_end_sec_2(1,ii) = ces2 - sum(ru_ind_locs(1:min(ces2,length(ru_ind_locs)/100)*100,1))/100;
            recordingc(ii).corr_results.corr_end_sec_2_subtracted_frames_100Hz_ru = sum(ru_ind_locs(1:min(ces2,length(ru_ind_locs)/100)*100,1))/100;
        else
            if excl_whisking
                sdec(:,wh_inds_df) = [];
                
                
                ces1 = corr_end_sec_1(1,ii);
                corr_end_sec_1(1,ii) = ces1 - sum(wh_ind_locs(1:ces1*100,1))/100;
                
                cbs2 = corr_beg_sec_2(1,ii);
                corr_beg_sec_2(1,ii) = cbs2 - sum(wh_ind_locs(1:ces1*100,1))/100;
                
                ces2 = corr_end_sec_2(1,ii);
                corr_end_sec_2(1,ii) = ces2 - (sum(wh_ind_locs(1:ces1*100,1))+sum(wh_ind_locs(cbs2*100:ces2*100)))/100;
                
            end
        end
    end
    
    
    
    %downsample sdec from 100 Hz to recording(iii).initial2.samplingratehz
    if ~onep
        sdecin = sdec;
        sr=recording(ii).initial2.samplingratehz;
        totdur100 = length(sdecin);
        totdur_df = (totdur100/100)*sr;
        srq = 1/sr;
        clear timevector_in timevector_out sdec
        
        for uo=1:size(sdecin,1)
            
            timevector_in = 0.01:0.01:length(sdecin)/100;
            timevector_out = srq:srq:(totdur100/100);
            
            tsin = timeseries(sdecin(uo,:)',timevector_in);
            tsout = resample(tsin,timevector_out);
            sdec(:,uo) = squeeze(squeeze(tsout.Data));
            
        end
    end
    
    sdec = sdec';
    
    %%%%%%%%%%%%%%%%Pearson Correlation analysis across recordings
    
    %plot sdec to choose which parts of the session to analyze
    
    clims = [0 0.5]
    figure(1738)
    imagesc(sdec,clims)
    
    recordingc(ii).corr_results.beg_sec_1 = corr_beg_sec_1(1,ii);
    recordingc(ii).corr_results.end_sec_1 = corr_end_sec_1(1,ii);
    recordingc(ii).corr_results.beg_sec_2 = corr_beg_sec_2(1,ii);
    recordingc(ii).corr_results.end_sec_2 = corr_end_sec_2(1,ii);
    
    recordingc(ii).corr_results.beg_sec_1_acctg_f_ru_wh = corr_beg_sec_1(1,ii);
    recordingc(ii).corr_results.end_sec_1_acctg_f_ru_wh = corr_end_sec_1(1,ii);
    recordingc(ii).corr_results.beg_sec_2_acctg_f_ru_wh = corr_beg_sec_2(1,ii);
    recordingc(ii).corr_results.end_sec_2_acctg_f_ru_wh = corr_end_sec_2(1,ii);

    
    min1 = min(corr_beg_sec_1)
    min2 = min(corr_end_sec_1)
    min3 = min(corr_beg_sec_2)
    min4 = min(corr_end_sec_2)
    
    
    min12 =  corr_end_sec_1(1,ii) -  corr_beg_sec_1(1,ii);
    min34 =  corr_end_sec_2(1,ii) -  corr_beg_sec_2(1,ii);
    
    if min12<0
        recordingc(ii).corr_results.end_sec_1 = corr_end_sec_2(1,ii);
        recordingc(ii).corr_results.beg_sec_1 = corr_beg_sec_2(1,ii);
        recordingc(ii).both_halves_the_same = 1;
        
        beg_sec_prez(1,ii) = corr_beg_sec_2(1,ii); %[1,1,1,1];
        end_sec_prez(1,ii) = corr_beg_sec_2(1,ii) +60; %[60,60 ,60 ,60];
        
        
    end
    if min34<1
        recordingc(ii).corr_results.end_sec_2 = corr_end_sec_1(1,ii);
        recordingc(ii).corr_results.beg_sec_2 = corr_beg_sec_1(1,ii);
        recordingc(ii).both_halves_the_same = 1;
        
        beg_sec_postz(1,ii) = corr_beg_sec_1(1,ii); %[1302 ,1140 ,400 ,600];
        end_sec_postz(1,ii) = corr_beg_sec_1(1,ii) + 60;
    end
    
    minss=[min1 min2 min3 min4]
    if isempty(find(minss<0)) %&& sum(minss)>0
        
        % iterations = 500;
        
        close all
        %sf=0;
        
        corr_coeff_matrices_pre_and_post_seizure
        
        if too_short==1
            recordingc(ii).donotanalze = 1;
        else
            
            if isfield(recordingc(ii),'correlation_results_pre_seiz')
                inv2 = recordingc(ii).correlation_results_pre_seiz.invraster2cat_binned2;
            else
                inv2 = recordingc(ii).correlation_results_post_seiz.invraster2cat_binned2;
                
            end
            a=1;
            for v = 1:size(inv2,2)
                if isempty(inv2(v).matrix)
                else
                    bins(1,a) = v;
                    a=a+1;
                end
            end
            
            bin = bins(1,1);
            
            
            %if onep, split into intra- vs inter-hemispheric corrcoeffs
            if onep && sqrois
                cmatpe = squeeze(recordingc(ii).correlation_results_pre_seiz.correlation_coefficient_matrix_min_avg_shuf_sig_only(:,:,bin));
                cmatpo = squeeze(recordingc(ii).correlation_results_post_seiz.correlation_coefficient_matrix_min_avg_shuf_sig_only(:,:,bin));
                
                LH_num = size(sdec1,1);
                RH_num = size(sdec2,1);
                
                cmatpe_vec_LH = 0;
                cmatpo_vec_LH = 0;
                cmatpe_vec_RH = 0;
                cmatpo_vec_RH = 0;
                cmatpe_cross_vec = 0;
                cmatpo_cross_vec = 0;
                
                das = 1;
                des = 1;
                dis = 1;
                
                for td = 2:LH_num
                    cmatpe_vec_LH(1,das:das+td-2) = cmatpe(td,1:td-1);
                    cmatpo_vec_LH(1,das:das+td-2) = cmatpo(td,1:td-1);
                    das=das+1;
                end
                
                for td = LH_num+2:RH_num+LH_num
                    cmatpe_vec_RH(1,des:des+td-LH_num-2) = cmatpe(td,LH_num+1:td-1);
                    cmatpo_vec_RH(1,des:des+td-LH_num-2) = cmatpo(td,LH_num+1:td-1);
                    des = des+1;
                    
                end
                
                for td = LH_num+1:RH_num+LH_num
                    
                    cmatpe_cross_vec(1,dis:dis+LH_num-1) = cmatpe(td,1:LH_num);
                    cmatpo_cross_vec(1,dis:dis+LH_num-1) = cmatpe(td,1:LH_num);
                    dis=dis+LH_num;
                    
                end
                
                recordingc(ii).cmatpe_vec_LH = cmatpe_vec_LH;
                recordingc(ii).cmatpo_vec_LH = cmatpo_vec_LH;
                recordingc(ii).cmatpe_vec_RH = cmatpe_vec_RH;
                recordingc(ii).cmatpo_vec_RH = cmatpo_vec_RH;
                recordingc(ii).cmatpe_cross_vec = cmatpe_cross_vec;
                recordingc(ii).cmatpo_cross_vec = cmatpo_cross_vec;
                
                [cmatpe_LH_vs_cross_p,cmatpe_LH_vs_cross_h,cmatpe_LH_vs_cross_stats] = ranksum(cmatpe_vec_LH,cmatpe_cross_vec);
                [cmatpo_LH_vs_cross_p,cmatpo_LH_vs_cross_h,cmatpo_LH_vs_cross_stats] = ranksum(cmatpo_vec_LH,cmatpo_cross_vec);
                recordingc(ii).cmatpe_LH_vs_cross_p = cmatpe_LH_vs_cross_p;
                recordingc(ii).cmatpe_LH_vs_cross_h = cmatpe_LH_vs_cross_h;
                recordingc(ii).cmatpe_LH_vs_cross_stats = cmatpe_LH_vs_cross_stats;
                recordingc(ii).cmatpo_LH_vs_cross_p = cmatpo_LH_vs_cross_p;
                recordingc(ii).cmatpo_LH_vs_cross_h = cmatpo_LH_vs_cross_h;
                recordingc(ii).cmatpo_LH_vs_cross_stats = cmatpo_LH_vs_cross_stats;
                
                
                [cmatpe_RH_vs_cross_p,cmatpe_RH_vs_cross_h,cmatpe_RH_vs_cross_stats] = ranksum(cmatpe_vec_RH,cmatpe_cross_vec);
                [cmatpo_RH_vs_cross_p,cmatpo_RH_vs_cross_h,cmatpo_RH_vs_cross_stats] = ranksum(cmatpo_vec_RH,cmatpo_cross_vec);
                recordingc(ii).cmatpe_RH_vs_cross_p = cmatpe_RH_vs_cross_p;
                recordingc(ii).cmatpe_RH_vs_cross_h = cmatpe_RH_vs_cross_h;
                recordingc(ii).cmatpe_RH_vs_cross_stats = cmatpe_RH_vs_cross_stats;
                recordingc(ii).cmatpo_RH_vs_cross_p = cmatpo_RH_vs_cross_p;
                recordingc(ii).cmatpo_RH_vs_cross_h = cmatpo_RH_vs_cross_h;
                recordingc(ii).cmatpo_RH_vs_cross_stats = cmatpo_RH_vs_cross_stats;
                
                
            end
            
            
            
            
            
            
            if isfield(recordingc(ii),'correlation_results_pre_seiz')
                matrix_pre = squeeze(recordingc(ii).correlation_results_pre_seiz.correlation_coefficient_matrix_min_avg_shuf_sig_only(:,:,bin));
            else
                matrix_pre = squeeze(recordingc(ii).correlation_results_post_seiz.correlation_coefficient_matrix_min_avg_shuf_sig_only(:,:,bin));
                
            end
            
            
            matrix_pre(isnan(matrix_pre))=0;
            recordingc(ii).clust_results.matrix_pre = matrix_pre;
            matrix_pre_nonz = matrix_pre;
            matrix_pre_nonz(matrix_pre_nonz<0) = 0;
            recordingc(ii).clust_results.matrix_pre = matrix_pre_nonz;
            
            if recordingc(ii).corr_results.beg_sec_2 == 0
                matrix_post = 0;
                matrix_post_nonz = 0;
            else
                matrix_post = squeeze(recordingc(ii).correlation_results_post_seiz.correlation_coefficient_matrix_min_avg_shuf_sig_only(:,:,bin));
                matrix_post(isnan(matrix_post))=0;
                recordingc(ii).clust_results.matrix_post = matrix_post;
                matrix_post_nonz = matrix_post;
                matrix_post_nonz(matrix_post_nonz<0) = 0;
                recordingc(ii).clust_results.matrix_post = matrix_post_nonz;
                
            end
            
            Edge_pre = adj2gephilab('matrix_pre_nonz',matrix_pre_nonz);
            Edge_post = adj2gephilab('matrix_post_nonz',matrix_post_nonz);
            recordingc(ii).clust_results.Edge_pre = Edge_pre;
            recordingc(ii).clust_results.Edge_post = Edge_post;
            
            save Edge_pre.mat Edge_pre
            save Edge_post.mat Edge_post
            
            %save as tab-delimited txt file
            dlmwrite('Edge_pre', Edge_pre, 'delimiter', '\t');
            dlmwrite('Edge_post', Edge_post, 'delimiter', '\t');
            
            matrix_pre_nonz_bin = matrix_pre_nonz;
            matrix_pre_nonz_bin(matrix_pre_nonz>0) = 1;
            
            matrix_post_nonz_bin = matrix_post_nonz;
            matrix_post_nonz_bin(matrix_post_nonz>0) = 1;
            
            
            
            %%% Brain connectivity toolbox
            
            degrees_pre = degrees_und(matrix_pre);
            degrees_post = degrees_und(matrix_post);
            recordingc(ii).clust_results.degrees_pre_BCtb = degrees_pre;
            recordingc(ii).clust_results.degrees_post_BCtb = degrees_post;
            
            strengths_pre = strengths_und_sign(matrix_pre);
            strengths_post = strengths_und_sign(matrix_post);
            recordingc(ii).clust_results.strengths_pre_BCtb = strengths_pre;
            recordingc(ii).clust_results.strengths_post_BCtb = strengths_post;
            
            density_pre = density_und(matrix_pre);
            density_post = density_und(matrix_post);
            recordingc(ii).clust_results.density_pre_BCtb = density_pre;
            recordingc(ii).clust_results.density_post_BCtb = density_post;
            
            clustering_pre = clustering_coef_wu_sign(matrix_pre);
            clustering_post = clustering_coef_wu_sign(matrix_post);
            recordingc(ii).clust_results.clustering_pre_BCtb = clustering_pre;
            recordingc(ii).clust_results.clustering_post_BCtb = clustering_post;
            
            %%%%%%%%%%%%%%
            
            %%%% Louvain
            [community_l_pre_M,community_l_pre_Q] = community_louvain(matrix_pre_nonz,[],[],'negative_asym');
            [community_l_post_M,community_l_post_Q]  = community_louvain(matrix_post_nonz,[],[],'negative_asym');
            recordingc(ii).clust_results.community_l_pre_M = community_l_pre_M;
            recordingc(ii).clust_results.community_l_pre_Q = community_l_pre_Q;
            recordingc(ii).clust_results.community_l_post_M = community_l_post_M;
            recordingc(ii).clust_results.community_l_post_Q = community_l_post_Q;
            
            num_clusts_pre_louvain = max(community_l_pre_M);
            num_clusts_post_louvain = max(community_l_post_M);
            recordingc(ii).clust_results.num_clusts_pre_louvain = num_clusts_pre_louvain;
            recordingc(ii).clust_results.num_clusts_post_louvain = num_clusts_post_louvain;
            
            if sum(sum(matrix_pre)) == 0
                recordingc(ii).clust_results.rich_club_pre_BCT = 0;
            else
                rich_club_pre = rich_club_wu(matrix_pre);
                recordingc(ii).clust_results.rich_club_pre_BCT = rich_club_pre;
            end
            if sum(sum(matrix_post))==0
            else
                rich_club_post = rich_club_wu(matrix_post);
                recordingc(ii).clust_results.rich_club_post_BCT = rich_club_post;
            end
            
            
            
            charpath_lambda_pre = charpath(matrix_pre);
            charpath_lambda_post = charpath(matrix_post);
            recordingc(ii).clust_results.charpath_lambda_pre_BCT = charpath_lambda_pre;
            recordingc(ii).clust_results.charpath_lambda_post_BCT = charpath_lambda_post;
            
            %clustering
            if sum(sum(matrix_pre_nonz))==0
                recordingc(ii).clust_results.V_matrix_pre_nonx = 0;
                V_matrix_pre_nonz = 0;
            else
                V_matrix_pre_nonz=GCModulMax1(matrix_pre_nonz);
                recordingc(ii).clust_results.V_matrix_pre_nonz = V_matrix_pre_nonz;
            end
            if sum(sum(matrix_post_nonz))==0
                V_matrix_post_nonz = 0;
            else
                
                V_matrix_post_nonz=GCModulMax1(matrix_post_nonz);
                recordingc(ii).clust_results.V_matrix_post_nonz = V_matrix_post_nonz;
            end
            
            %%%%%%%%SBE toolbox
            
            sbeG_bin_pre = sparse(matrix_pre_nonz);
            sbeG_bin_post = sparse(matrix_post_nonz);
            
            sbeNode_pre = 1:1:size(sbeG_bin_pre,1);
            sbeNode_post = 1:1:size(sbeG_bin_post,1);
            
            smaxcl = length(int2str(max(sbeNode_pre)));
            smat = zeros(length(sbeNode_pre),3);
            for o = 1:length(sbeNode_pre)
                clear t
                t = int2str(sbeNode_pre(1,o));
                smat(o,2) = length(t);
                smat(o,1) = sbeNode_pre(1,o)*10^(smaxcl-smat(o,2));
                smat(o,3) = 10^(smaxcl-smat(o,2));
            end
            smat = sortrows(smat,1);
            sbeNode_sorted_pre = smat(:,1)./smat(:,3);
            
            sbeG_bin_pre_log = logical(sbeG_bin_pre);
            
            for o = 1:length(sbeNode_sorted_pre)
                sbeNode_sorted_cell_pre{o,1} = num2str(sbeNode_sorted_pre(o,1));
                
            end
            
            [msg_pre, moduleid_pre]=clusteronerun(sbeG_bin_pre_log,sbeNode_sorted_cell_pre);
            recordingc(ii).clust_results.moduleid_pre_clusterone = moduleid_pre;
            if sum(moduleid_pre)==0
                recordingc(ii).clust_results.G_num_pre_clusterone = 0;
            else
                [G_pre,G_num_pre]=moduleid2net(moduleid_pre,matrix_pre_nonz);
                recordingc(ii).clust_results.G_num_pre_clusterone = G_num_pre;
            end
            num_clusts_pre_SBE = max(moduleid_pre);
            recordingc(ii).num_clusts_pre_SBE = num_clusts_pre_SBE;
            
            smaxcl = length(int2str(max(sbeNode_post)));
            smat = zeros(length(sbeNode_post),3);
            for o = 1:length(sbeNode_post)
                clear t
                t = int2str(sbeNode_post(1,o));
                smat(o,2) = length(t);
                smat(o,1) = sbeNode_post(1,o)*10^(smaxcl-smat(o,2));
                smat(o,3) = 10^(smaxcl-smat(o,2));
            end
            smat = sortrows(smat,1);
            sbeNode_sorted_post = smat(:,1)./smat(:,3);
            
            sbeG_bin_post_log = logical(sbeG_bin_post);
            
            for o = 1:length(sbeNode_sorted_post)
                sbeNode_sorted_cell_post{o,1} = num2str(sbeNode_sorted_post(o,1));
                
            end
            
            if sum(sum(matrix_post_nonz))==0
                moduleid_post=0;
                G_num_post=0;
            else
                [msg_post, moduleid_post]=clusteronerun(sbeG_bin_post_log,sbeNode_sorted_cell_post);
                recordingc(ii).clust_results.moduleid_post_clusterone = moduleid_post;
                [G_post,G_num_post]=moduleid2net(moduleid_post,matrix_post_nonz);
                recordingc(ii).clust_results.G_num_post_clusterone = G_num_post;
                
                num_clusts_post_SBE = max(moduleid_post);
                recordingc(ii).num_clusts_post_SBE = num_clusts_post_SBE;
            end
            %%%%%%%%%%%%%%%%
            
            %binarize sdec
            sdec_bin = zeros(size(sdec));
            sdec_bin(sdec>0) = 1;
            recordingc(ii).clust_results.sdec_bin = sdec_bin;
            %visualize these clusterings with DF/F traces: sort S_dec matrix by the cluster_IDs;
            
            num_clusts_pre = max(V_matrix_pre_nonz);
            num_clusts_post = max(V_matrix_post_nonz);
            recordingc(ii).clust_results.num_clusts_pre_GCModul = num_clusts_pre;
            recordingc(ii).clust_results.num_clusts_post_GCModul = num_clusts_post;
            
            beg_sec_pre = beg_sec_prez(1,ii);
            end_sec_pre = end_sec_prez(1,ii);
            beg_sec_post = beg_sec_postz(1,ii);
            end_sec_post = end_sec_postz(1,ii);
            begfr_pre = round(beg_sec_pre*recording(ii).initial2.samplingratehz);
            endfr_pre = round(end_sec_pre*recording(ii).initial2.samplingratehz);
            if begfr_pre==0
                begfr_pre=1
            end
            if endfr_pre>size(sdec,2)
                endfr_pre = size(sdec,2);
            end
            recordingc(ii).clust_results.begfr_pre = begfr_pre;
            recordingc(ii).clust_results.endfr_pre = endfr_pre;
            
            begfr_post = round(beg_sec_post*recording(ii).initial2.samplingratehz);
            if begfr_post==0
                begfr_post=1;
            end
            endfr_post = min(size(sdec_bin,2),round(end_sec_post*recording(ii).initial2.samplingratehz));
            recordingc(ii).clust_results.begfr_post = begfr_post;
            recordingc(ii).clust_results.endfr_post = endfr_post;
            
            load('colorpal_neo.mat')
            
            colorpal_intz = colorpal_neo;
            colorpal_int = cat(1,colorpal_intz,colorpal_intz);
            colorpal_int=cat(1,colorpal_int,colorpal_int);
            colorpal_int=cat(1,colorpal_int,colorpal_int);
            colorpal_int=cat(1,colorpal_int,colorpal_int);
            
            
            %
            %             colorpal = colormap('colorcube');
            %             for o = 1:size(colorpal,1)-1
            %                 if o==1
            %                     tomean(1,:) = [0 0 0];
            %                     tomean(2,:) = colorpal(1,:);
            %                     colorpal_int(1,:) = mean(tomean,1);
            %                     tomean(1,:) = colorpal(2,:);
            %                     colorpal_int(2,:) = mean(tomean,1);
            %                 else
            %                     colorpal_int(o*2-1,:) = colorpal(o,:);
            %                     tomean(1,:) = colorpal(o,:);
            %                     tomean(2,:) = colorpal(o+1,:);
            %                     colorpal_int(o*2,:) = mean(tomean,1);
            %                 end
            %             end
            
            maxc = size(colorpal_int,1);
            %cs = maxc/num_clusts_pre;
            cs=1;
            recordingc(ii).clust_results.cs = cs;
            %cs_louvain = maxc/num_clusts_pre_louvain;
            cs_louvain = 1;
            recordingc(ii).clust_results.cs_louvain = cs_louvain;
            if num_clusts_pre_SBE==0
                cs_SBE = 0 %[0,0,0]
            else
                %cs_SBE = maxc/num_clusts_pre_SBE;
                cs_SBE = 1;
            end
            recordingc(ii).clust_results.cs_SBE = cs_SBE;
            
            
            
            %ROI_clust_mat: column 1 = ROI#, 2 = pre_cluster_ID, 3 = post_cluster_ID, 4
            %= colorpal # based on pre
            clear ROI_clust_mat ROI_clust_mat_louvain ROI_clust_mat_clusterone
            for iii = 1:endframe
                
                ROI_clust_mat_clusterone(iii,1) = iii;
                ROI_clust_mat_clusterone(iii,2) = moduleid_pre(iii,1);
                if size(moduleid_post,1) == 1 && size(moduleid_post,2)==1
                    ROI_clust_mat_clusterone(iii,3) = moduleid_pre(iii,1);
                else
                    ROI_clust_mat_clusterone(iii,3) = moduleid_post(iii,1);
                end
                ROI_clust_mat_clusterone(iii,4) = round(cs_SBE*moduleid_pre(iii,1));
                if size(moduleid_post,1) == 1 && size(moduleid_post,2)==1
                    ROI_clust_mat_clusterone(iii,7) =round(cs_SBE*moduleid_pre(iii,1));
                else
                    ROI_clust_mat_clusterone(iii,7) =round(cs_SBE*moduleid_post(iii,1));
                end
                % ROI_clust_mat_clusterone(iii,7) = round(cs_SBE*moduleid_post(iii,1));
                ROI_clust_mat_clusterone(iii,5) = degrees_pre(1,iii);
                if size(degrees_post) == [1,1]
                else
                    ROI_clust_mat_clusterone(iii,6) = degrees_post(1,iii);
                end
                
                ROI_clust_mat(iii,1) = iii;
                if size(V_matrix_pre_nonz) == [1,1]
                    ROI_clust_mat(iii,2) = 0;
                    ROI_clust_mat(iii,4) = 0;
                else
                    ROI_clust_mat(iii,2) = V_matrix_pre_nonz(iii,1);
                    ROI_clust_mat(iii,4) = round(cs*V_matrix_pre_nonz(iii,1));
                end
                if size(V_matrix_post_nonz) == [1,1]
                else
                    ROI_clust_mat(iii,3) = V_matrix_post_nonz(iii,1);
                end
                
                
                
                ROI_clust_mat_louvain(iii,1) = iii;
                ROI_clust_mat_louvain(iii,2) = community_l_pre_M(iii,1);
                if size(community_l_post_M) == [1,1]
                else
                    ROI_clust_mat_louvain(iii,3) = community_l_post_M(iii,1);
                end
                ROI_clust_mat_louvain(iii,4) = round(cs_louvain*community_l_pre_M(iii,1));
            end
            
            recordingc(ii).clust_results.ROI_clust_mat_clusterone = ROI_clust_mat_clusterone;
            recordingc(ii).clust_results.ROI_clust_mat_louvain = ROI_clust_mat_louvain;
            recordingc(ii).clust_results.ROI_clust_mat_GCModul = ROI_clust_mat;
            
            
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            
            clear ROI_clust_mat_sorted_pre_clusterone ROI_clust_mat_sorted_post_clusterone
            
            ROI_clust_mat_sorted_pre_clusterone = sortrows(ROI_clust_mat_clusterone,2);
            recordingc(ii).clust_results.ROI_clust_mat_sorted_pre_clusterone =  ROI_clust_mat_sorted_pre_clusterone;
            
            figure(5892)
            set(gcf,'color','w');
            for iii = 1:endframe
                roinum = ROI_clust_mat_sorted_pre_clusterone(iii,1);
                if ROI_clust_mat_sorted_pre_clusterone(iii,4) == 0
                    co = [0,0,0];
                else
                    co = colorpal_int(ROI_clust_mat_sorted_pre_clusterone(iii,4),:);
                    if sum(co) == 0
                        co = [0.3, 0.7, 0.2];
                    end
                end
                klo = sdec_bin(roinum,begfr_pre:endfr_pre)';
                
                gsu = subaxis (endframe,1,iii,'SpacingVert',0);
                
                plot(klo,'Color',co);
                %     gsu.XTick = [];
                %     gsu.YTick = [];
                ylim([0.3 1])
                set(gca,'xtick',[],'ytick',round(100*max(klo))/100)
                set(gca,'Yticklabel', num2str(round(100*max(klo))/100))
                
                %subaxis
                %set(gca,'visible', off)
                %ylabel(num2str(neuron_numbers(i,1)), 'FontName', 'Arial', 'FontSize', 12, 'FontWeight', 'bold');
                box off
                axis off
            end
            saveas(5892,[Folder 'ROI_clust_mat_sorted_pre_clusterone' ict_or_int_or_all '.png' ],'png');
            
            ROI_clust_mat_sorted_post_clusterone = sortrows(ROI_clust_mat_clusterone,3);
            recordingc(ii).clust_results.ROI_clust_mat_sorted_post_clusterone = ROI_clust_mat_sorted_post_clusterone;
            
            if endfr_post==0
            else
                figure(58912)
                set(gcf,'color','w');
                for iii = 1:endframe
                    roinum = ROI_clust_mat_sorted_post_clusterone(iii,1);
                    if ROI_clust_mat_sorted_post_clusterone(iii,7) == 0
                        co = [0,0,0];
                    else
                        co = colorpal_int(ROI_clust_mat_sorted_post_clusterone(iii,7),:);
                    end
                    klo = sdec_bin(roinum,begfr_post:endfr_post)';
                    
                    gsu = subaxis (endframe,1,iii,'SpacingVert',0);
                    
                    plot(klo,'Color',co);
                    %     gsu.XTick = [];
                    %     gsu.YTick = [];
                    ylim([0.3 1])
                    set(gca,'xtick',[],'ytick',round(100*max(klo))/100)
                    set(gca,'Yticklabel', num2str(round(100*max(klo))/100))
                    
                    %subaxis
                    %set(gca,'visible', off)
                    %ylabel(num2str(neuron_numbers(i,1)), 'FontName', 'Arial', 'FontSize', 12, 'FontWeight', 'bold');
                    box off
                    axis off
                end
                saveas(58912,[Folder 'ROI_clust_mat_sorted_post_clusterone' ict_or_int_or_all '.png' ],'png');
            end
            %%%%%%%%%%%%%%%%%%%%%%%%%%%
            
            clear ROI_clust_mat_sorted_pre ROI_clust_mat_sorted_post
            
            ROI_clust_mat_sorted_pre = sortrows(ROI_clust_mat,2);
            recordingc(ii).clust_results.ROI_clust_mat_sorted_pre_GCModul =  ROI_clust_mat_sorted_pre;
            
            close all
            figure(789)
            set(gcf,'color','w');
            for iii = 1:endframe
                roinum = ROI_clust_mat_sorted_pre(iii,1);
                if ROI_clust_mat_sorted_pre(iii,4) == 0
                    co = [0,0,0];
                else
                    co = colorpal_int(ROI_clust_mat_sorted_pre(iii,4),:);
                end
                klo = sdec_bin(roinum,begfr_pre:endfr_pre)';
                
                gsu = subaxis (endframe,1,iii,'SpacingVert',0);
                
                plot(klo,'Color',co);
                %     gsu.XTick = [];
                %     gsu.YTick = [];
                ylim([0.3 1])
                set(gca,'xtick',[],'ytick',round(100*max(klo))/100)
                set(gca,'Yticklabel', num2str(round(100*max(klo))/100))
                
                %subaxis
                %set(gca,'visible', off)
                %ylabel(num2str(neuron_numbers(i,1)), 'FontName', 'Arial', 'FontSize', 12, 'FontWeight', 'bold');
                box off
                axis off
            end
            saveas(789,[Folder 'ROI_clust_mat_sorted_GCModul_pre' ict_or_int_or_all '.png' ],'png');
            
            ROI_clust_mat_sorted_post = sortrows(ROI_clust_mat,3);
            recordingc(ii).clust_results.ROI_clust_mat_sorted_post_GCModul = ROI_clust_mat_sorted_post;
            
            if endfr_post==0
            else
                figure(7891)
                set(gcf,'color','w');
                for iii = 1:endframe
                    roinum = ROI_clust_mat_sorted_post(iii,1);
                    if ROI_clust_mat_sorted_post(iii,4) == 0
                        co = [0,0,0];
                    else
                        co = colorpal_int(ROI_clust_mat_sorted_post(iii,4),:);
                    end
                    klo = sdec_bin(roinum,begfr_post:endfr_post)';
                    
                    gsu = subaxis (endframe,1,iii,'SpacingVert',0);
                    
                    plot(klo,'Color',co);
                    %     gsu.XTick = [];
                    %     gsu.YTick = [];
                    ylim([0.3 1])
                    set(gca,'xtick',[],'ytick',round(100*max(klo))/100)
                    set(gca,'Yticklabel', num2str(round(100*max(klo))/100))
                    
                    %subaxis
                    %set(gca,'visible', off)
                    %ylabel(num2str(neuron_numbers(i,1)), 'FontName', 'Arial', 'FontSize', 12, 'FontWeight', 'bold');
                    box off
                    axis off
                end
                saveas(7891,[Folder 'ROI_clust_mat_sorted_GCModul_post' ict_or_int_or_all '.png' ],'png');
            end
            
            
            
            clear ROI_clust_mat_sorted_pre_louvain ROI_clust_mat_sorted_post_louvain
            
            ROI_clust_mat_sorted_pre_louvain = sortrows(ROI_clust_mat_louvain,2);
            recordingc(ii).clust_results.ROI_clust_mat_sorted_pre_louvain =  ROI_clust_mat_sorted_pre_louvain;
            
            figure(7892)
            set(gcf,'color','w');
            for iii = 1:endframe
                roinum = ROI_clust_mat_sorted_pre_louvain(iii,1);
                if ROI_clust_mat_sorted_pre_louvain(iii,4) == 0
                    co = [0,0,0];
                else
                    co = colorpal_int(ROI_clust_mat_sorted_pre_louvain(iii,4),:);
                end
                klo = sdec_bin(roinum,begfr_pre:endfr_pre)';
                
                gsu = subaxis (endframe,1,iii,'SpacingVert',0);
                
                plot(klo,'Color',co);
                %     gsu.XTick = [];
                %     gsu.YTick = [];
                ylim([0.3 1])
                set(gca,'xtick',[],'ytick',round(100*max(klo))/100)
                set(gca,'Yticklabel', num2str(round(100*max(klo))/100))
                
                %subaxis
                %set(gca,'visible', off)
                %ylabel(num2str(neuron_numbers(i,1)), 'FontName', 'Arial', 'FontSize', 12, 'FontWeight', 'bold');
                box off
                axis off
            end
            saveas(7892,[Folder 'ROI_clust_mat_sorted_pre_louvain' ict_or_int_or_all '.png' ],'png');
            
            ROI_clust_mat_sorted_post_louvain = sortrows(ROI_clust_mat_louvain,3);
            recordingc(ii).clust_results.ROI_clust_mat_sorted_post_louvain = ROI_clust_mat_sorted_post_louvain;
            
            if endfr_post==0
            else
                figure(78912)
                set(gcf,'color','w');
                for iii = 1:endframe
                    roinum = ROI_clust_mat_sorted_post_louvain(iii,1);
                    if ROI_clust_mat_sorted_post_louvain(iii,4) == 0
                        co = [0,0,0];
                    else
                        co = colorpal_int(ROI_clust_mat_sorted_post_louvain(iii,4),:);
                    end
                    klo = sdec_bin(roinum,begfr_post:endfr_post)';
                    
                    gsu = subaxis (endframe,1,iii,'SpacingVert',0);
                    
                    plot(klo,'Color',co);
                    %     gsu.XTick = [];
                    %     gsu.YTick = [];
                    ylim([0.3 1])
                    set(gca,'xtick',[],'ytick',round(100*max(klo))/100)
                    set(gca,'Yticklabel', num2str(round(100*max(klo))/100))
                    
                    %subaxis
                    %set(gca,'visible', off)
                    %ylabel(num2str(neuron_numbers(i,1)), 'FontName', 'Arial', 'FontSize', 12, 'FontWeight', 'bold');
                    box off
                    axis off
                end
                saveas(78912,[Folder 'ROI_clust_mat_sorted_post_louvain' ict_or_int_or_all '.png' ],'png');
            end
            
            
            close all
            %%%% plot clustered network as overlay on avg_ch1
            %
            %         if isfield(recording(ii),'movie_avg')
            %             movie_avg = recording(ii).movie_avg;
            %         else
            %             if isfield(recording(ii),'initial1')
            %                 if isfield(recording(ii).initial1,'g')
            %                     if recording(ii).initial1.g==0
            %                         movie_avg = imread('avg_ch2.tif');
            %                     else
            %                         movie_avg = squeeze(mean(recording(ii).initial1.g,3));
            %                     end
            %                 else
            %                     movie_avg = imread('avg_ch2.tif');
            %                 end
            %             else
            %                 movie_avg = imread('avg_ch2.tif');
            %             end
            %         end
            %
            
            
            if onep_binned_twice>0
                if movie_avg_8 ==0
                    if isfield(recording(ii),'movie_avg')
                        if ~isempty(recording(ii).movie_avg)
                            movie_avg = recording(ii).movie_avg;
                            movie_avg_resized = movie_avg;
                        end
                    else
                        if isfield(recording(ii),'crop')
                            load masked_g_bak.mat
                            %                 movie_avg = movie_avg(round(recording(ii).crop(1,2)):round(recording(ii).crop(1,2))+round(recording(ii).crop(1,4)),...
                            %                     round(recording(ii).crop(1,1)):round(recording(ii).crop(1,1))+round(recording(ii).crop(1,3)));
                            %add here: downsample movie_avg_for plotting!
                            movie_avg = masked_g_bak(:,:,1);
                            movie_avg_resized = imresize(movie_avg, 0.5, 'nearest');
                        else
                            masked_g = read_file('masked_g_nr.h5',1,20);
                            
                            movie_avg = masked_g(:,:,1);
                            movie_avg_resized = movie_avg; %imresize(movie_avg, 0.5, 'nearest');
                            
                        end
                        
                    end
                else
                    movie_avg_resized = movie_avg_8;
                end
                height = size(movie_avg_resized,1);
                width = size(movie_avg_resized,2);
                h = height;
                w = width;
                movie_avg = movie_avg_resized;
            else
                if movie_avg_8 == 0
                    
                    
                    if isfield(recording(ii),'movie_avg')
                        if ~isempty(recording(ii).movie_avg)
                            movie_avg = recording(ii).movie_avg;
                            movie_avg_resized = movie_avg;
                        else
                            
                            masked_g = read_file('masked_g_nr.h5',1,20);
                            
                            movie_avg = masked_g(:,:,1);
                            movie_avg_resized = movie_avg; %imresize(movie_avg, 0.5, 'nearest');
                            
                            
                        end
                    else
                        if isfield(recording(ii),'initial1')
                            if isfield(recording(ii).initial1,'g')
                                if recording(ii).initial1.g==0
                                    %movie_avg = imread('avg_ch2.tif');
                                    
                                    masked_g = read_file('masked_g_nr.h5',1,20);
                                    
                                    movie_avg = masked_g(:,:,1);
                                    movie_avg_resized = movie_avg; %imresize(movie_avg, 0.5, 'nearest');
                                    
                                else
                                    movie_avg = squeeze(mean(recording(ii).initial1.g,3));
                                end
                            else
                                movie_avg = imread('avg_ch2.tif');
                            end
                        else
                            movie_avg = imread('avg_ch2.tif');
                        end
                    end
                else
                    movie_avg_resized = movie_avg_8;
                    movie_avg = movie_avg_resized;
                    
                end
                movie_avg_resized=movie_avg;
                height = size(movie_avg,1);
                width = size(movie_avg,2);
                h = size(movie_avg,1);
                w = size(movie_avg,2);
            end
            
            
            
            
            h = size(movie_avg,1);
            w = size(movie_avg,2);
            clear oyt_vec p1 p2 c
            oyt_vec = reshape(movie_avg,h*w,1);
            p1 = prctile(oyt_vec,0.5)
            p2 = prctile(oyt_vec,99);
            
            if onep
                if sqrois
                    RI = recording(ii).onep_results_2.RL;
                else
                    if isfield(recording(ii).ta2,'ROI_list')
                        RI =  recording(ii).ta2.ROI_list
                    else
                        RI = recording(ii).ROI_list;
                    end
                end
            else
                RI = recording(ii).ROI_list;
            end
            
            if isfield(recording(ii),'Cn')
                Cn = recording(ii).Cn;
            else
                Cn = recording(ii).initial.height;
            end
            numrois = size(ROI_clust_mat_clusterone,1)
            
            %
            %         if onep_binned_twice
            %             movie_avg = movie_avg(round(recording(ii).crop(1,2)):round(recording(ii).crop(1,2))+round(recording(ii).crop(1,4)),...
            %                 round(recording(ii).crop(1,1)):round(recording(ii).crop(1,1))+round(recording(ii).crop(1,3)));
            %             %add here: downsample movie_avg_for plotting!
            %             movie_avg_resized = imresize(movie_avg, 0.5, 'nearest');
            %
            %
            %             height = size(movie_avg_resized,1);
            %             width = size(movie_avg_resized,2);
            %             h = height;
            %             w = width;
            %         else
            %             movie_avg_resized=movie_avg;
            %             height = size(movie_avg,1);
            %             width = size(movie_avg,2);
            %         end
            %
            %         %crop this image
            %
            %           movie_avg_resized = movie_avg_resized(round(recording(iii).crop(1,2)):round(recording(iii).crop(1,2))+round(recording(iii).crop(1,4)),...
            %             round(recording(iii).crop(1,1)):round(recording(iii).crop(1,1))+round(recording(iii).crop(1,3)));
            %
            
            figure(909)
            ima = imagesc(movie_avg_resized,[p1 p2])
            colormap(gray)
            hold on
            clear c
            transpline = 0.4;
            if onep
                if sqrois
                    transpline = 0.17;
                end
                if sqrois
                    for k = 1:size(ROI_clust_mat_clusterone,1)
                        
                        %convert k into the accepted ROI number first:
                        
                        ksz =  size(recording(ii).onep_results_2.accep_ROI_LH,2)+1;
                        if k<ksz
                            kk = recording(ii).onep_results_2.accep_ROI_LH(1,k);
                            
                        else
                            
                            kk = recording(ii).onep_results_2.accep_ROI_RH(1,1+k-ksz);
                            
                        end
                        
                        
                        %c1 = recording(ii).onep_results_2.RL.ROI_info(kk,1);
                        c3 = recording(ii).onep_results_2.RL.ROI_info(kk,3);
                        c4 = recording(ii).onep_results_2.RL.ROI_info(kk,4);
                        
                        midx = floor(c3); %floor((c1+c3)/2);
                        midy = floor(c4);
                        RI(k).centerPos(1,1) = midx;
                        RI(k).centerPos(1,2) = midy;
                        midpix = round((midy-1)*height+midx);
                        curr_pix = [midpix-1:1:midpix+1];
                        RI(k).pixel_list = curr_pix;
                    end
                end
            else
                   if onep_stg
                for k = 1:size(ROI_clust_mat_clusterone,1)

                    RI(k).centerPos(1,1) = ri(k).CenterPos(1,1)
                    RI(k).centerPos(1,2) = ri(k).CenterPos(1,2)

                end

            end
            end
            if ~isfield(RI(1),'pixel_list')
                for k = 1:size(ROI_clust_mat_clusterone,1)
                    
                    %convert k into the accepted ROI number first:
                    
                    midx=RI(k).centerPos(1,1)
                    midy=RI(k).centerPos(1,2)
                    midpix = round((midy-1)*height+midx);
                    curr_pix = [midpix-1:1:midpix+1];
                    RI(k).pixel_list = curr_pix;
                end
                
            end
            
            
            for k = 1:size(ROI_clust_mat_clusterone,1)
                dx = numrois/ROI_clust_mat_clusterone(k,5)
                if ROI_clust_mat_clusterone(k,2) == 0
                    c(k,:) = [17 17 17]/255
                else
                    c(k,:) = colorpal_int(ROI_clust_mat_clusterone(k,2),:)
                end
                clear curr_pix curr_pix_bin si curr_color ho
                
                %             if onep
                %                 c1 = recording(ii).onep_results_2.RL.ROI_info(k,1);
                %                 c3 = recording(ii).onep_results_2.RL.ROI_info(k,3);
                %                 c4 = recording(ii).onep_results_2.RL.ROI_info(k,4);
                %
                %                 midx = floor((c1+c3)/2);
                %                 midy = c4;
                %                 %RI(k).centerPos(1,1) = midx;
                %                 %RI(k).centerPos(1,2) = midy;
                %                 midpix = round(midy*height+midx);
                %                 curr_pix = [midpix-1:1:midpix+1];
                %                 %RI(k).pixel_list = curr_pix;
                %             else
                curr_pix = RI(k).pixel_list;
                % end
                
                if isfield(recording(ii).initial,'height')
                    rh = recording(ii).initial.height;
                    if onep_binned_twice
                        rh = h;
                    end
                else
                    rh = recording(ii).initial2.linesperframe;
                end
                
                if rh==size(Cn,1)
                    curr_pix_bin = zeros(h,w);
                else
                    curr_pix_bin = zeros(h,w);
                end
                
                for j = 1:size(RI(k).pixel_list,1)
                    prx = RI(k).pixel_list(j,1);
                    curr_pix_bin(RI(k).pixel_list(j,1)) = 1;
                end
                si = size(curr_pix_bin);
                curr_color = cat(3,ones(si)*c(k,1),ones(si)*c(k,2),ones(si)*c(k,3));
                ho = imshow(curr_color);
                set(ho, 'AlphaData', curr_pix_bin/1.9)%/dx)
                hold on
                
                edgmult = 15;
                if onep
                    if sqrois
                        edgmult = 2;
                    else
                        edgmult = 14;
                    end
                end
                %now add lines between significantly connected ROIs
                if k<size(matrix_pre_nonz,2)
                    
                    %new approach: search for other ROIS with the same
                    %moduleID, then add them to  a vector containing all
                    %moduleID numbers and for the next one ake sure it's not
                    %already in that vector...
                    
                    
                    for l = k+1:size(matrix_pre_nonz,2)
                        if matrix_pre_nonz(k,l)>0  && ROI_clust_mat_clusterone(k,2) == ROI_clust_mat_clusterone(l,2)...
                                && ROI_clust_mat_clusterone(k,2) > 0 && ROI_clust_mat_clusterone(l,2) > 0
                            %added the last 2 terms of above line 10/10/2020
                            if matrix_pre_nonz(k,l)>0 && (l-1)<length(RI)
                                
                                edgewidthy = ceil(matrix_pre_nonz(k,l)*edgmult);
                                if onep
                                    x1 = RI(k).centerPos(1,2);
                                    y1 = RI(k).centerPos(1,1);
                                    x2 = RI(l).centerPos(1,2);
                                    y2 = RI(l).centerPos(1,1);
                                    
                                else
                                    x1 = RI(k).centerPos(1,2);
                                    y1 = RI(k).centerPos(1,1);
                                    x2 = RI(l).centerPos(1,2);
                                    y2 = RI(l).centerPos(1,1);
                                end
                                recordingc(ii).edgewidth(k,l) = edgewidthy;
                                recordingc(ii).edgecolor(k).c = c;
                                L =  line([x1 x2],[y1 y2],'Color',c(k,:),'LineWidth',edgewidthy);
                                L.Color(4) = transpline;
                            end
                        end
                    end
                    
                    
                    %
                    %                 for l = k+1:size(matrix_pre_nonz,2)
                    %                     if matrix_pre_nonz(k,l)>0  && ROI_clust_mat_clusterone(k,2) > 0 && ROI_clust_mat_clusterone(l,2) > 0
                    %                         %added the last 2 terms of above line 10/10/2020
                    %                         if matrix_pre_nonz(k,l)>0 && (l-1)<length(RI)
                    %
                    %                             edgewidthy = ceil(matrix_pre_nonz(k,l)*edgmult);
                    %                             if onep
                    %                                 x1 = RI(k).centerPos(1,2);
                    %                                 y1 = RI(k).centerPos(1,1);
                    %                                 x2 = RI(l).centerPos(1,2);
                    %                                 y2 = RI(l).centerPos(1,1);
                    %
                    %                             else
                    %                                 x1 = RI(k).centerPos(1,2);
                    %                                 y1 = RI(k).centerPos(1,1);
                    %                                 x2 = RI(l).centerPos(1,2);
                    %                                 y2 = RI(l).centerPos(1,1);
                    %                             end
                    %                             recordingc(ii).edgewidth(k,l) = edgewidthy;
                    %                             recordingc(ii).edgecolor(k).c = c;
                    %                             L =  line([x1 x2],[y1 y2],'Color',c(k,:),'LineWidth',edgewidthy);
                    %                             L.Color(4) = transpline;
                    %                         end
                    %                     end
                    %                 end
                end
            end
            saveas(909,[Folder 'ROIs_clusters_pre_SBE' ict_or_int_or_all '.png' ],'png');
            
            if endfr_post==0
            else
                figure(9091)
                ima = imagesc(movie_avg_resized,[p1 p2])
                recordingc(ii).movie_avg = movie_avg;
                colormap(gray)
                hold on
                clear c
                for k = 1:size(ROI_clust_mat_clusterone,1)
                    dx = numrois/ROI_clust_mat_clusterone(k,6);
                    if ROI_clust_mat_clusterone(k,3) == 0
                        c(k,:) = [17 17 17]/255;
                    else
                        c(k,:) = colorpal_int(ROI_clust_mat_clusterone(k,3),:);
                    end
                    clear curr_pix curr_pix_bin si curr_color ho
                    curr_pix = RI(k).pixel_list;
                    if rh==size(Cn,1)
                        curr_pix_bin = zeros(h,w);
                    else
                        curr_pix_bin = zeros(h,w);
                    end
                    for j = 1:size(RI(k).pixel_list,1)
                        curr_pix_bin(RI(k).pixel_list(j,1)) = 1;
                    end
                    si = size(curr_pix_bin);
                    curr_color = cat(3,ones(si)*c(k,1),ones(si)*c(k,2),ones(si)*c(k,3));
                    ho = imshow(curr_color);
                    set(ho, 'AlphaData', curr_pix_bin/1.9)%/dx)
                    hold on
                    
                    %now add lines between significantly connected ROIs
                    for l = k+1:size(matrix_post_nonz,2)
                        if matrix_post_nonz(k,l)>0  && ROI_clust_mat_clusterone(k,3) == ROI_clust_mat_clusterone(l,3)...
                                && ROI_clust_mat_clusterone(k,3) > 0 && ROI_clust_mat_clusterone(l,3) > 0
                            %added the last 2 terms of above line 10/10/2020
                            if matrix_post_nonz(k,l)>0 && (l-1)<length(RI)
                                
                                edgewidthp = ceil(matrix_post_nonz(k,l)*edgmult);
                                if onep
                                    x1 = RI(k).centerPos(1,2);
                                    y1 = RI(k).centerPos(1,1);
                                    x2 = RI(l).centerPos(1,2);
                                    y2 = RI(l).centerPos(1,1);
                                    
                                else
                                    x1 = RI(k).centerPos(1,2);
                                    y1 = RI(k).centerPos(1,1);
                                    x2 = RI(l).centerPos(1,2);
                                    y2 = RI(l).centerPos(1,1);
                                end
                                recordingc(ii).edgewidthp(k,l) = edgewidthp;
                                recordingc(ii).edgecolor(k).c = c;
                                L =  line([x1 x2],[y1 y2],'Color',c(k,:),'LineWidth',edgewidthp);
                                L.Color(4) = transpline;
                            end
                        end
                    end
                    
                    %%%%%%%%%%%%%%%%%%%%%%%%%%% replaced this part 01/24/2022
                    
                    %
                    %                 if k<size(matrix_post_nonz,2)
                    %                     for l = k+1:size(matrix_post_nonz,2)
                    %                         if matrix_post_nonz(k,l) && ROI_clust_mat_clusterone(k,3) > 0 && ROI_clust_mat_clusterone(l,3) > 0
                    %                             %added the last 2 terms of above line 10/10/2020
                    %                             if (l+1)<length(RI)
                    %                                 edgewidth = ceil(matrix_post_nonz(k,l)*edgmult);
                    %                                 x1 = RI(k).centerPos(1,2);
                    %                                 y1 = RI(k).centerPos(1,1);
                    %                                 x2 = RI(l).centerPos(1,2);
                    %                                 y2 = RI(l).centerPos(1,1);
                    %
                    %                                 L =  line([x1 x2],[y1 y2],'Color',c(k,:),'LineWidth',edgewidth);
                    %                                 L.Color(4) = transpline;
                    %                             end
                    %                         end
                    %                     end
                    %                 end
                    %
                    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                    
                    
                end
                saveas(9091,[Folder 'ROIs_clusters_post_SBE' ict_or_int_or_all '.png' ],'png');
            end
        end
    else
        recordingc(ii).donotanalze = 1;
    end
end
end
%end


