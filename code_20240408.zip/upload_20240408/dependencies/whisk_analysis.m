function [whisking] = whisk_analysis(Folder,initial,cam_fr,filtmat_red,cam_st_man,imaged,...
    onep,mst,sf,iii,cam15Hz,imf,i2,dropped_frames,recording)

clear whisk wh

Foldera =  [Folder '\whisk\'];
cd(Foldera)
Stack = dir('*.tif'); % dir(strcat(Folder,'\whisk\*.tif'));

info = imfinfo(Stack(1,1).name);

width = info.Width;

height = info.Height;

numberofmovies = 1;

%%%%%%%%%%%%%%%% load tiff files %%%%%%%%%%%%%%%%%%%%%%%
max_frame = size(Stack,1);
a_h=1;
if initial.no_imaging(1,iii)
    cam_fr  = max_frame/(length(i2.rawData2)/i2.sampl_fr);
    initial.movielengthsec = length(i2.rawData2)/i2.sampl_fr;
else
    if  onep
        if isfield(recording(iii),'whisking_videocam_indices_fr_winedr')
            wvi = recording(iii).whisking_videocam_indices_fr_winedr;
            real_triggered_frame_num = length(wvi);
            real_tot_length_sampl = wvi(real_triggered_frame_num,1) - wvi(1,1)
            real_tot_length_s = real_tot_length_sampl/sf;
            cam_fr = real_triggered_frame_num/real_tot_length_s
            
            whisking.cam_fr_times = wvi;
        else
            cam_fr  = max_frame/initial.movielengthsec;
            real_triggered_frame_num = max_frame;
        end
    else
        cam_fr  = max_frame/initial.movielengthsec;
        real_triggered_frame_num = max_frame;
    end
end
for frame = 1:max_frame
    if a_h == 1 || a_h == 0
        fram = frame;
    else
        if a_h == 2
            fram = max_frame+frame;
        end
    end
    if size(imread (Stack(fram,1).name, 'tif'),1) == height
        fram=frame
        wh = imread (Stack(fram,1).name, 'tif');
        whisk (:,:,frame) = wh(:,:,1);% imread (Stack(fram,1).name, 'tif');
    end
end

if dropped_frames(1,iii) || size(whisk,3)<real_triggered_frame_num
    %
    if ~isfield(recording(iii),'whisking_videocam_indices_fr_winedr')
        if size(initial.heka_or_winedr,1)>size(initial.heka_or_winedr,2)
            how = initial.heka_or_winedr(iii,1);
        else
            how = initial.heka_or_winedr(1,iii);
            
        end
        
        if how
            thrcam=1;
        else
            thrcam=500;
        end
        
        cam_frs =  i2.rawData2(:,4);
        diffcamfrs = diff(cam_frs);
        pf = zeros(size(diffcamfrs));
        pf(find(diffcamfrs>thrcam)) = 1;
        pfs = diff(pf);
        
        [cam_fr_times cam_fr_inds] = find(pfs==1);
        whisking.cam_fr_times = cam_fr_times;
    end
    %whisking.cam_fr_times = wvi;
    
    
    %interpolate whisk to # am_fr_times
    
    clear whisk_ts
    whisk_ts = zeros(size(whisk,1),size(whisk,2),length(whisking.cam_fr_times));
    for ou = 1:size(whisk,1)
        fd = squeeze(whisk(ou,:,:));
        fda = imresize(fd,'OutputSize',[size(whisk,2),length(whisking.cam_fr_times)],'method', 'bilinear');
        whisk_ts(ou,:,:) = fda;
    end
    whisk = whisk_ts;
    
end


whisking.max_frame = size(whisk,3); %max_frame
diffwhisk = diff(whisk,1,3);
avg_diffwhisk = squeeze(mean(mean(diffwhisk,1),2));
smooth_avg_diffwhisk = smooth(avg_diffwhisk,3);


if initial.no_imaging(1,iii)
    cam_fr  = max_frame/(length(i2.rawData2)/i2.sampl_fr);
    initial.movielengthsec = length(i2.rawData2)/i2.sampl_fr;
else
    %cam_fr  = size(whisk,3)/initial.movielengthsec;
end

approx_sec_per_frame = 1/cam_fr%initial.movielengthsec/max_frame

if approx_sec_per_frame > 0.059
    cam15Hz(1,iii) = 1;
end



if cam_st_man(1,iii)
    actual_cam_samplrate = 1/(initial.movielengthsec/length(whisk))
    actualmsperline = 1000/actual_cam_samplrate
    fr = actual_cam_samplrate
    whisking.actual_cam_samplrate = actual_cam_samplrate;
else
    if ~isfield(recording(iii),'whisking_videocam_indices_fr_winedr')
        
        if size(initial.heka_or_winedr,1)>size(initial.heka_or_winedr,2)
            how = initial.heka_or_winedr(iii,1);
        else
            how = initial.heka_or_winedr(1,iii);
            
        end
        
        if how
            thrcam=1;
        else
            thrcam=500;
        end
        
        cam_frs =  i2.rawData2(:,4);
        diffcamfrs = diff(cam_frs);
        pf = zeros(size(diffcamfrs));
        pf(find(diffcamfrs>thrcam)) = 1;
        pfs = diff(pf);
        
        [cam_fr_times cam_fr_inds] = find(pfs==1);
        whisking.cam_fr_times = cam_fr_times;
    end
    
    if cam15Hz(1,iii)
        cam_fr_timees = cam_fr_times;
        if mod(length(cam_fr_timees),2)
            cam_fr_timees(2:2:end-1,:) = [];
        else
            cam_fr_timees(2:2:end,:) = [];
        end
    else
        cam_fr_timees = zeros(length(whisking.cam_fr_times)+1,1);
        cam_fr_timees(2:length(whisking.cam_fr_times)+1,1) = whisking.cam_fr_times;
        cam_fr_timees(1,1) = 1;
    end
    whisking.cam_fr_timees = cam_fr_timees;
    if length(cam_fr_timees) > size(whisk,3)
        buf_frames = length(cam_fr_timees) - size(whisk,3);
        
        adx = zeros(buf_frames+length(avg_diffwhisk) ,1);
        sadx = zeros( buf_frames+length(avg_diffwhisk) ,1);
        
        adx(buf_frames+1:buf_frames+length(avg_diffwhisk),1) = avg_diffwhisk;
        sadx(buf_frames+1:buf_frames+length(smooth_avg_diffwhisk),1) = smooth_avg_diffwhisk;
        
        avg_diffwhisk = adx;
        smooth_avg_diffwhisk = sadx;
    end
    mxs = round(length(cam_fr_timees)*0.9);
    
    timx = cam_fr_timees(mxs,1);
    
    samppfr = timx/mxs;
    
    fr = initial.sampl_fr/samppfr;
    whisking.fr = fr;
    
    if onep
        sec_offs = mst/sf;
        fr_offs = round(sec_offs*fr) %-fr*(whisking.cam_fr_times(1,1)/initial.sampl_fr) %HERE: ADD cam_fr_times(1,1) (in fr time)
        whisking.fr_offs = fr_offs;
        
        
        whisk(:,:,1:fr_offs) = [];
        avg_diffwhisk(1:fr_offs,:) = [];
        smooth_avg_diffwhisk(1:fr_offs,:) = [];
        
    end
    whisk_bak = whisk;
    avg_diffwhisk_bak = avg_diffwhisk;
    smooth_avg_diffwhisk_bak = smooth_avg_diffwhisk;
    %fr = cam_fr;
end

whisking.whisk = whisk;
whisking.avg_diffwhisk = avg_diffwhisk;
whisking.smooth_avg_diffwhisk = smooth_avg_diffwhisk;
whisking.whisk_bak = whisk;
whisking.avg_diffwhisk_bak = avg_diffwhisk;
whisking.smooth_avg_diffwhisk_bak = smooth_avg_diffwhisk;


if imaged
    freq = initial.samplingratehz
    
    if fr/freq<1
        smooth_avg_diffwhisk_extrap  = zeros(ceil(length(smooth_avg_diffwhisk)*(freq/fr)),1);
        ix = round((freq/fr)/2);
        smooth_avg_diffwhisk_extrap(1:2,1) = smooth_avg_diffwhisk(1,1);
        for i = 3: size(smooth_avg_diffwhisk_extrap,1)-1
            if i ==1
                ix=0;
            end
            smooth_avg_diffwhisk_extrap(i,1) = mean(smooth_avg_diffwhisk(ceil(i*fr/freq):ceil(i*fr/freq),1)); % (round(i/(freq/fr))-ix:round(i/(freq/fr))+ix,1));    %(ceil(i*freq/fr):ceil(i*freq/fr),1));
        end
    else
        smooth_avg_diffwhisk_extrap  = zeros(ceil(length(smooth_avg_diffwhisk)/(fr/freq)),1);
        for i = 1: size(smooth_avg_diffwhisk_extrap,1)-1
            smooth_avg_diffwhisk_extrap(i,1) = mean(smooth_avg_diffwhisk(round(i*fr/freq):ceil(i*fr/freq),1));
        end
    end
    
    whisking.fr = fr;
    whisking.smooth_avg_diffwhisk_extrap = smooth_avg_diffwhisk_extrap;
    
    if cam_st_man(1,iii)
        %         actual_cam_samplrate = 1/(initial.movielengthsec/length(whisk));
        %         actualmsperline = 1000/actual_cam_samplrate;
        freqd=100;
        %if actual_cam_samplrate<cam_fr || actual_cam_samplrate>cam_fr
        
        
        initiald.msperline = initial.msperline %actualmsperline;
        [smooth_avg_diffwhisk_extrap_interp,smooth_avg_diffwhisk_extrap_new] = ...
            cat_and_deltaf_interp(smooth_avg_diffwhisk_extrap,smooth_avg_diffwhisk_extrap,initiald,freqd,0);
        %cat_and_deltaf_interp(smooth_avg_diffwhisk_extrap,smooth_avg_diffwhisk_extrap,initiald,freqd,0);
        
        
        %
        %         frz = 100;
        %         freqz = cam_fr;
        %         smooth_avg_diffwhisk_extrap  = zeros(ceil(length(smooth_avg_diffwhisk_extrap_interp)/(frz/freqz)),1);
        %
        %         for i = 1: size(smooth_avg_diffwhisk_extrap,1)-1
        %             smooth_avg_diffwhisk_extrap(i,1) = mean(smooth_avg_diffwhisk_extrap_interp(floor(i*frz/freqz):ceil(i*frz/freqz),1));
        %         end
        
        %
        %         smooth_avg_diffwhisk_extrap_interp  = zeros(ceil(length(smooth_avg_diffwhisk_extrap)/actual_cam_samplrate*cam_fr),size(smooth_avg_diffwhisk_extrap,2));
        %
        %         for k = 1:size(smooth_avg_diffwhisk_extrap,2)
        %             j = 1;
        %             i = 2;
        %             cat_signal_interp_ROI = k
        %             while i <= length(smooth_avg_diffwhisk_extrap_interp)-10
        %                 %deltaf_interp (i,1) = i/freq;
        %                 if (j*actualmsperline/1000 >= i/cam_fr) && (j*actualmsperline/1000 <= i/cam_fr+1/cam_fr)...
        %                         && smooth_avg_diffwhisk_extrap_interp(i,k) == 0 % && results.cat_signal_interp(i-1,k) == 0
        %                     if j*actualmsperline-i/cam_fr <= i+1/cam_fr - j*actualmsperline
        %                         smooth_avg_diffwhisk_extrap_interp(i,k) = smooth_avg_diffwhisk_extrap(j,k);
        %                         if smooth_avg_diffwhisk_extrap(j,k)==0
        %                             zerocat(1,a) = i;
        %                             a=a+1;
        %                         end
        %                     else
        %                         smooth_avg_diffwhisk_extrap_interp(i+1,k) = smooth_avg_diffwhisk_extrap(j,k);
        %                         if smooth_avg_diffwhisk_extrap(j,k)==0
        %                             zerocat(1,a) = i+1;
        %                             a=a+1;
        %                         end
        %                     end
        %                     j=j+1;
        %                 end
        %                 i=i+1;
        %             end
        %         end
        %
        %         forw = ceil(actualmsperline/(1000/cam_fr));
        %
        %         for i = 1:size(smooth_avg_diffwhisk_extrap_interp,2)
        %             a=1;
        %             naninds = 0;
        %             inpaint_nans_cat_signal_ROI = i
        %             for j = 1:length(smooth_avg_diffwhisk_extrap_interp)
        %                 if j<length(smooth_avg_diffwhisk_extrap_interp)-forw
        %                     if sum(smooth_avg_diffwhisk_extrap_interp(j:j+forw,i))>0
        %                         curr = find(smooth_avg_diffwhisk_extrap_interp(j:j+forw,i)==0)+j-1;
        %                         c = length(curr);
        %                         naninds(1,a:a+c-1) = curr;
        %                         a=a+c;
        %                     end
        %                 else
        %                     if smooth_avg_diffwhisk_extrap_interp(j,i) == 0;
        %                         naninds(1,a) = j;
        %                         a=a+1;
        %                     end
        %                 end
        %             end
        %             %remove duplicates from naninds
        %             smooth_avg_diffwhisk_extrap_interp(unique(naninds),i)= NaN;
        %             smooth_avg_diffwhisk_extrap_interp(1:size(smooth_avg_diffwhisk_extrap_interp,1),i)...
        %                 = inpaint_nans(smooth_avg_diffwhisk_extrap_interp(1:size(smooth_avg_diffwhisk_extrap_interp,1),i));
        %         end
        
        
        whisking.smooth_avg_diffwhisk_extrap = smooth_avg_diffwhisk_extrap;
        % end
    else
        
        freqd=100;
        initiald.msperline = initial.msperline;
        
        freqor = 1000/initiald.msperline;
        
        if freqor/freqd<1
            
            [smooth_avg_diffwhisk_extrap_interp,smooth_avg_diffwhisk_extrap_new] = cat_and_deltaf_interp...
                (smooth_avg_diffwhisk_extrap,smooth_avg_diffwhisk_extrap,initiald,freqd,1);
        else
            
            smooth_avg_diffwhisk_extrap_interp  = zeros(ceil(length(smooth_avg_diffwhisk_extrap)/(freqor/freqd)),1);
            for i = 1: size(smooth_avg_diffwhisk_extrap_interp,1)-1
                smooth_avg_diffwhisk_extrap_interp(i,1) = mean(smooth_avg_diffwhisk_extrap(round(i*freqor/freqd):ceil(i*freqor/freqd),1));
            end
            
        end
        
        
        
        
        
        
    end
    
    ffrs = length(filtmat_red);
    
    if ffrs==0
        ffrs = imf
        
    end
    facc = freqd/(1000/initial.msperline);
    ffrsi = round(ffrs*facc);
    
    
    if length(smooth_avg_diffwhisk_extrap)<ffrs
        smooth_avg_diffwhisk_extrap(length(smooth_avg_diffwhisk_extrap)+1:ffrs,1) = 0;
        whisking.smooth_avg_diffwhisk_extrap = smooth_avg_diffwhisk_extrap;
        smooth_avg_diffwhisk_extrap_interp(length(smooth_avg_diffwhisk_extrap_interp)+1:ffrsi,1) = 0;
    end
    
    std_level = 0.5;
    %     [smooth_avg_diffwhisk_extrap_no_noise,apm_diffwhisk,dw_nonoise,apmdw,noisedata_diffwhisk] = ...
    %         denoise(initial,smooth_avg_diffwhisk_extrap(1:length(filtmat_red),1),smooth_avg_diffwhisk_extrap(1:length(filtmat_red),1),...
    %         std_level,initial);
    
    [smooth_avg_diffwhisk_extrap_no_noise,apm_diffwhisk,dw_nonoise,apmdw,noisedata_diffwhisk] = ...
        denoise(initial,smooth_avg_diffwhisk_extrap_interp(1:ffrsi,1),smooth_avg_diffwhisk_extrap_interp(1:ffrsi,1),...
        std_level,initial,0);
    
    dw_nonoise_binary = zeros(size(dw_nonoise));
    dw_nonoise_binary(find(dw_nonoise)) = 1;
    
    ge = 0;
    a=9009
    
    madei = max(smooth_avg_diffwhisk_extrap_interp);
    
    while ge == 0
        
        f = figure(a);
        plot(dw_nonoise_binary)
        hold on
        plot(smooth_avg_diffwhisk_extrap_interp)
        axis([1 round(length(smooth_avg_diffwhisk_extrap_interp)/2) 0 madei*1.55])
        f.WindowStyle = 'normal';
        
        prompt = {'good enough (1) or not (0) ?'};
        dlg_title = '1 if ready to go, 0 if not';
        num_lines = 1;
        def = {'1'};
        answer = inputdlg(prompt,dlg_title,num_lines,def);
        answer = str2mat(answer);
        ge = str2num(answer);
        
        
        
        if ge==0
            a=a+1
            prompt = {'pick an SD level (e.g. 10)'};
            dlg_title = '1 if ready to go, 0 if not';
            num_lines = 1;
            def = {'10'};
            answer = inputdlg(prompt,dlg_title,num_lines,def);
            answer = str2mat(answer);
            gu = str2num(answer);
            
            
            %
            %             a=a+1;
            std_level = gu % std_level+1;
            [smooth_avg_diffwhisk_extrap_no_noise,apm_diffwhisk,dw_nonoise,apmdw,noisedata_diffwhisk] = ...
                denoise(initial,smooth_avg_diffwhisk_extrap_interp(1:ffrsi,1),smooth_avg_diffwhisk_extrap_interp(1:ffrsi,1),...
                std_level,initial,0);
            dw_nonoise_binary = zeros(size(dw_nonoise));
            dw_nonoise_binary(find(dw_nonoise)) = 2;
            
            
        end
        
        %
        %         if ge==0
        %             a=a+1;
        %             std_level = std_level+0.25;
        %             [smooth_avg_diffwhisk_extrap_no_noise,apm_diffwhisk,dw_nonoise,apmdw,noisedata_diffwhisk] = ...
        %                 denoise(initial,smooth_avg_diffwhisk_extrap_interp(1:ffrsi,1),smooth_avg_diffwhisk_extrap_interp(1:ffrsi,1),...
        %                 std_level,initial,0);
        %             dw_nonoise_binary = zeros(size(dw_nonoise));
        %             dw_nonoise_binary(find(dw_nonoise)) = 2;
        %
        %         end
    end
    
    whisking.std_level = std_level;
    whisking.smooth_avg_diffwhisk_extrap_interp = smooth_avg_diffwhisk_extrap_interp;
    whisking.smooth_avg_diffwhisk_extrap = smooth_avg_diffwhisk_extrap;
    whisking.smooth_avg_diffwhisk_extrap_no_noise = smooth_avg_diffwhisk_extrap_no_noise;
    
    
    
    whisking.dw_nonoise_binary = dw_nonoise_binary;
    
    b=0;
    a=1;
    for i = 1:length(dw_nonoise_binary)
        if i == 1
            if dw_nonoise_binary(i,1)
                whisk_st_d(a,1) = i;
                b=1;
                a=a+1;
            end
        else
            if dw_nonoise_binary(i,1)
                if b==11
                else
                    
                    whisk_st_d(a,1) = i;
                    b=1;
                    a=a+1;
                end
                
            else
                if b==1
                    b=0;
                    whisk_en_d(a-1,1) = i;
                end
            end
        end
    end
    
    whisking.whisk_st_d = whisk_st_d;
    whisking.whisk_en_d = whisk_en_d;
    whisking.whisk = 0;
    
    
    
    
else
    
    
    
    std_level = 0.5;
    %     [smooth_avg_diffwhisk_extrap_no_noise,apm_diffwhisk,dw_nonoise,apmdw,noisedata_diffwhisk] = ...
    %         denoise(initial,smooth_avg_diffwhisk_extrap(1:length(filtmat_red),1),smooth_avg_diffwhisk_extrap(1:length(filtmat_red),1),...
    %         std_level,initial);
    
    [smooth_avg_diffwhisk_no_noise,apm_diffwhisk,dw_nonoise,apmdw,noisedata_diffwhisk] = ...
        denoise(initial,smooth_avg_diffwhisk,smooth_avg_diffwhisk,...
        std_level,initial,0);
    
    dw_nonoise_binary = zeros(size(dw_nonoise));
    dw_nonoise_binary(find(dw_nonoise)) = 1;
    
    ge = 0;
    a=9009
    
    madei = max(smooth_avg_diffwhisk);
    
    while ge == 0
        
        f = figure(a);
        plot(dw_nonoise_binary)
        hold on
        plot(smooth_avg_diffwhisk)
        axis([1 round(length(smooth_avg_diffwhisk)/2) 0 madei*1.55])
        f.WindowStyle = 'normal';
        
        prompt = {'good enough (1) or not (0) ?'};
        dlg_title = '1 if ready to go, 0 if not';
        num_lines = 1;
        def = {'1'};
        answer = inputdlg(prompt,dlg_title,num_lines,def);
        answer = str2mat(answer);
        ge = str2num(answer);
        
        if ge==0
            
            
            prompt = {'pick an SD level (e.g. 10)'};
            dlg_title = '1 if ready to go, 0 if not';
            num_lines = 1;
            def = {'10'};
            answer = inputdlg(prompt,dlg_title,num_lines,def);
            answer = str2mat(answer);
            gu = str2num(answer);
            
            
            %
            %             a=a+1;
            std_level = gu % std_level+1;
            [smooth_avg_diffwhisk_no_noise,apm_diffwhisk,dw_nonoise,apmdw,noisedata_diffwhisk] = ...
                denoise(initial,smooth_avg_diffwhisk,smooth_avg_diffwhisk,...
                std_level,initial,0);
            dw_nonoise_binary = zeros(size(dw_nonoise));
            dw_nonoise_binary(find(dw_nonoise)) = 1;
            
        end
    end
    
    whisking.std_level = std_level;
    whisking.smooth_avg_diffwhisk = smooth_avg_diffwhisk;
    %whisking.smooth_avg_diffwhisk_extrap = smooth_avg_diffwhisk_extrap;
    whisking.smooth_avg_diffwhisk_no_noise = smooth_avg_diffwhisk_no_noise;
    
    
    
    whisking.dw_nonoise_binary = dw_nonoise_binary;
    
    b=0;
    a=1;
    for i = 1:length(dw_nonoise_binary)
        if i == 1
            if dw_nonoise_binary(i,1)
                whisk_st_d(a,1) = i;
                b=1;
                a=a+1;
            end
        else
            if dw_nonoise_binary(i,1)
                if b==11
                else
                    
                    whisk_st_d(a,1) = i;
                    b=1;
                    a=a+1;
                end
                
            else
                if b==1
                    b=0;
                    whisk_en_d(a-1,1) = i;
                end
            end
        end
    end
    
    whisking.whisk_st_d = whisk_st_d;
    whisking.whisk_en_d = whisk_en_d;
    whisking.whisk = 0;
    
    
end












