
function [dist_to_next_onset, dist_from_prev_offset, ROI,p_ks, p_correct,...
    onset_cluster_ROI,offset_cluster_ROI,ict_high,interict_high,ict_high_bin,interict_high_bin,synchr,ns_interict_high,ns_ict_high] = ...
    calc_an_shuf_new_whole_ict_int_ranksum(bkiip,p_ictntrict,tds,sec_plot,an_shuf,Folder,dist_plots,initial,...
    iterations,ks_alpha,minseiz,matrix,filtmat,...
    lazyROIs,burst_SD,seiz_dists,deconv,no_mot,tsb,i2)

%this is filtmat_red (right now)
damatrix = matrix;

%this is Filtmat2_3000 (right now)
matrix = filtmat;

endframe = size(matrix,2);
%run dist_plots for burst activity and synchrony!
cells = setdiff(1:1:endframe,lazyROIs);

matrix_bursts = zeros(size(matrix,1),length(cells));
%changed to only L23(cells)
%identify bursts
if endframe < 6 || deconv
    matrix_bursts = matrix;
    display('using matrix as matrix_bursts for synchr computation')
else
    for i =1:length(cells)
        if length(cells) < 6
            binedges = [-0.01:0.005:1]
        else
            binedges = [-0.5:0.01:5];
        end
        [N, edges] = histcounts(matrix(:,cells(i)),binedges);
        a=find(N == max(N));
        if length(a)>1
            a = a(1,2);
        end
        medi = edges(1,a);
        avg_oopsi(i,1) = medi;
        noisee(i).med_oopsi = avg_oopsi(i,1);
        inds = find(matrix(:,cells(i))<avg_oopsi(i,1));
        noise_below_med = matrix(inds,cells(i));
        noisee(i).noiseoopsi = cat(1,noise_below_med, avg_oopsi(i,1)*2-noise_below_med);
        if isnan(std(noisee(i).noiseoopsi))
            noisee(i).std_oopsi = 0;
        else
        noisee(i).std_oopsi = std(noisee(i).noiseoopsi);
        end
        noisee(i).thr_oopsi = avg_oopsi(i)+burst_SD*noisee(i).std_oopsi;
        
        matrix_bursts(:,i) = matrix(:,cells(i)) - noisee(i).thr_oopsi;
        
        for j = 1: size(matrix_bursts,1)
            if matrix_bursts(j,i)<0
                matrix_bursts(j,i) = 0;
            end
        end
    end
end
matrix_bursts(isnan(matrix_bursts))=0;
matrix = matrix_bursts;

frames = size(matrix,1);
ns = size(tds.soffd,2);
clear twosec_prev_out onesec_prev_out threesec_prev_out interict_act ict_act

tensec = round(10000/i2.msperline)
interict_bursts = [];
ict_bursts = [];
%identify all interictal activity (but take out seizures with bad motion
%artifacts!
endframe = size(matrix,2)
for i = 1:endframe
    sk = 1
    curseiz = 1
    z=1
    j=tds.soffd(1,1)
    
    while j<tds.sond(1,ns) && j<length(matrix)+1
        
        if j>tds.sond(1,curseiz+1)-1
            curseiz = curseiz+1;
        end
        
        if seiz_dists.interictal(1,j) && ismember(curseiz,tds.offset_seizures_out) == 0
            interict_bursts(z,1) = matrix(j,i);
            
            z = z+1;
        else
            if ismember(curseiz,tds.offset_seizures_out)
                skipped_seiz(1,sk) = curseiz;
                sk=sk+1
            end
        end
        j = j+1;
    end
    
    %identify ictal periods
    zi=1
    ji=tds.sond(1,1)
    a = 1;
    curseizi = 1
    while ji<length(matrix)+1 && ji<length(seiz_dists.ictal)  %ji<tds.soffd(1,ns) && 
        if curseizi<ns
            if ji>tds.sond(1,curseizi+1)-1
                curseizi = curseizi+1
            end
        end
        
        if seiz_dists.ictal(1,ji) && ismember(curseizi,tds.offset_seizures_out) == 0
            ict_bursts(zi,1) = matrix(ji,i);
            iain1(1,zi) = matrix(ji,i);
            if ji > tds.soffd(a)
                a=a+1;
            end
            
            zi = zi+1;
        end
        ji = ji+1;
    end
    ROI(i).all_interict_bursts = interict_bursts;
    ROI(i).all_ict_bursts = ict_bursts;
end

%compute synchrony, interict vs. ictal
ns_interict_high = zeros(1,6);
if size(matrix_bursts,2)<9
    dist_to_next_onset=[]; 
    dist_from_prev_offset=[]; 
    p_ks=[];
    p_correct=[];
    onset_cluster_ROI=[];
    offset_cluster_ROI=[];
    ict_high=[];
    interict_high=[];
    ict_high_bin=[];
    interict_high_bin=[];
    synchr=[];
    ns_interict_high=[];
    ns_ict_high=[];
else
    ns_ict_high=[];
    matrix_bursts(:,size(matrix_bursts,2)-9:size(matrix_bursts,2)) = [];
    
    bursts_binary = zeros(size(matrix_bursts));
    for i = 1:size(matrix_bursts,2)
        curr_burst_binary_ROI = i
        for j = 1:size(matrix_bursts,1)
            if sum(matrix_bursts(j,i))
                bursts_binary(j,i) = 1;
            end
        end
    end
    
    for i = 1:size(bursts_binary,1)
        burst_synchrony(i) = sum(bursts_binary(i,:));
    end
    burst_synchrony = burst_synchrony'/max(burst_synchrony);
    synchr = burst_synchrony;
    sk = 1
    i=1
    curseiz = 1
    z=1
    j=tds.soffd(1,1)
    interict_synchrony = [];
    ict_synchrony = [];
    while j<tds.sond(1,ns) && j<length(burst_synchrony)+1
        
        if j>tds.sond(1,curseiz+1)-1
            curseiz = curseiz+1;
        end
        
        if seiz_dists.interictal(1,j) && ismember(curseiz,tds.offset_seizures_out) == 0
            interict_synchrony(1,z,i) = burst_synchrony(j,i);
            
            z = z+1;
        else
            if ismember(curseiz,tds.offset_seizures_out)
                skipped_seiz(1,sk) = curseiz;
                sk=sk+1
            end
        end
        j = j+1;
    end
    
    %identify ictal periods
    zi=1
    ji=tds.sond(1,1)
    a = 1;
    curseizi = 1
    while ji<length(burst_synchrony)+1 && ji<length(seiz_dists.ictal) %ji<tds.soffd(1,ns) && 
        if curseizi<ns
            if ji>tds.sond(1,curseizi+1)-1
                curseizi = curseizi+1
            end
        end
        
        if seiz_dists.ictal(1,ji) && ismember(curseizi,tds.offset_seizures_out) == 0
            ict_synchrony(1,zi,i) = burst_synchrony(ji,i);
            iain1(1,zi) = burst_synchrony(ji,i);
            if ji > tds.soffd(a)
                a=a+1;
            end
            
            zi = zi+1;
        end
        ji = ji+1;
    end
    ROI(i).all_interict_synchrony = interict_synchrony;
    ROI(i).all_ict_synchrony = ict_synchrony;
    
    if dist_plots.all_interict_act == 0
        dist_to_next_onset = [];
        dist_from_prev_offset = [];
    else
        dist_to_next_onset = squeeze(dist_plots.all_interict_act(2,:,i));
        dist_from_prev_offset = squeeze(dist_plots.all_interict_act(3,:,i));
    end
    
    
    
    %damatrix is filtmat_red (right now)
    
    matrix = damatrix;
    endframe = size(matrix,2);
    onset_cluster_ROI(1).init = 1
    offset_cluster_ROI(1).init = 1
    p_correct = 0;
    %
    % prompt = {'plot results (1) or not (0) ?'};
    % dlg_title = '1 if plots, 0 if no plots';
    % num_lines = 1;
    % def = {'1'};
    % answerp = inputdlg(prompt,dlg_title,num_lines,def);
    % answerp = str2mat(answerp);
    plot_results =1% str2num(answerp);
    
    
        
    for i = 1:endframe
        i
        if dist_plots.all_interict_act == 0
            ROI(i).all_interict_act = 0;
            ROI(i).all_ict_act = 0;
        else
        if no_mot
            ROI(i).all_interict_act = squeeze(dist_plots.all_interict_act_no_mot(1,:,i));
            ROI(i).all_ict_act = squeeze(dist_plots.all_ict_act_no_mot(1,:,i));
        else
            ROI(i).all_interict_act = squeeze(dist_plots.all_interict_act(1,:,i));
            ROI(i).all_ict_act = squeeze(dist_plots.all_ict_act(1,:,i));
        end
        end
    end
    
    for i = 1:endframe
        if length(matrix)<tds.soffd(1,size(tds.soffd,2))
            huhh = length(matrix);
        else
            huhh = tds.soffd(1,size(tds.soffd,2));
            
        end
        filtmatavg(1,i) = mean(matrix(tds.sond(1,1):huhh,i));
    end
    if bkiip
        %compute corrected p-value for each cell, and each bin
        endframe = length(an_shuf);
        
        for i = 1:endframe
            
            curr_shuf_ks = squeeze(an_shuf(i).shuf_vs_all_shuf_stat_ks_aft_onset(1,:));
            roi_p = squeeze(an_shuf(i).bin_stat_ks_aft_onset(i,1));
            p_ks(i).aft_onset(1,1) = length(find(curr_shuf_ks > roi_p))/iterations;
            if p_ks(i).aft_onset(1,1) == 0
                p_ks(i).aft_onset(1,1) = 0.5/iterations;
            end
            
            curr_shuf_ks = squeeze(an_shuf(i).shuf_vs_all_shuf_stat_ks_aft_offset(1,:));
            roi_p = squeeze(an_shuf(i).bin_stat_ks_aft_offset(i,1));
            p_ks(i).aft_offset(1,1) = length(find(curr_shuf_ks > roi_p))/iterations;
            if p_ks(i).aft_offset(1,1) == 0
                p_ks(i).aft_offset(1,1) = 0.5/iterations;
            end
            
        end
        
        
        p_ictnterict = p_ictntrict/2;
        plot_seizs_over_time = 0;
        
        
        %which ROIs were biased from the 2-bin KS distance analysis?
        clear interict_high ict_high
        a=1;
        b=1;
        
        for i =1:size(ROI,2)
            if p_ks(i).aft_onset<p_ictnterict || p_ks(i).aft_offset<p_ictnterict
                
                
                aina = ROI(i).all_interict_act;
                aia = ROI(i).all_ict_act;
                
                if mean(aina) > mean(aia)
                    interict_high_bin(a,1) = i;
                    interict_high_bin(a,2) = mean(aina) -...
                        median(aia);%/median(ROI_activity_00017(i).all_ict_act);
                    interict_high_bin(a,3) = mean(aia);
                    interict_high_bin(a,4) = mean(aina);
                    interict_high_bin(a,5) = mean(aina) - filtmatavg(1,i);%
                    interict_high_bin(a,6) = min(p_ks(i).aft_onset,p_ks(i).aft_offset);
                    %interict_high(a,7) =  median(HL);
                    a=a+1;
                else
                    ict_high_bin(b,1) = i;
                    ict_high_bin(b,5) = mean(aia) - filtmatavg(1,i);%...
                    %mean(ROI_activity_00017(i).all_interict_act));%/median(ROI_activity_00017(i).all_interict_act);
                    ict_high_bin(b,2) = mean(aia) - ...
                        median(aina);%/median(ROI_activity_00017(i).all_interict_act);
                    ict_high_bin(b,3) = mean(aia);
                    ict_high_bin(b,4) = mean(aina);
                    ict_high_bin(b,6) = min(p_ks(i).aft_onset,p_ks(i).aft_offset);
                    %ict_high(a,7) =  median(HL);
                    b=b+1;
                end
            end
        end
    else
        ict_high_bin = 0;
        interict_high_bin = 0;
        p_ks = 0;
    end
    
    
    ict_high = 0;
    interict_high = 0;
    p_ictnterict = p_ictntrict/endframe;
    %now the same for ict-vs-int- KS analysis
    a=1
    b=1
    c=1
    d=1
    for i =1:endframe
        
        aina = ROI(i).all_interict_act;
        aia = ROI(i).all_ict_act;
        %     aina_sort = sort(aina);
        %     aia_sort = sort(aia);
        %     aina_zer = length(find(aina_sort == 0));
        %     aia_zer = length(find(aia_sort == 0));
        %
        %     if aina_zer>aia_zer
        %         aina = aina_sort(1,aia_zer+1:length(aina_sort));
        %         aia = aia_sort(1,aia_zer+1:length(aia_sort));
        %     else
        %         aina = aina_sort(1,aia_zer+1:length(aina_sort));
        %         aia = aia_sort(1,aia_zer+1:length(aia_sort));
        %     end
        
        if tsb
            
            twosec = 2000/i2.msperline;
            
            rest = mod((length(aina)*i2.msperline/1000),2);
            binns = (length(aina)*i2.msperline/1000-rest)/2;
            
            aa = 1;
            if binns == 0
                aina_tsb = 0;
            else
                for l = 1:binns
                    if aa+round(twosec)<length(aina)+1
                        aina_tsb(1,l) = mean(aina(1,aa:aa+round(twosec)));
                        aa=round(l*twosec)+1;
                    else
                        aina_tsb = 0;
                    end
                end
            end
            
            rest = mod((length(aia)*i2.msperline/1000),2);
            binns = (length(aia)*i2.msperline/1000-rest)/2;
            
            aa = 1;
            if binns==0
                aia_tsb = 0;
            else
                for l = 1:binns
                    if aa+round(twosec)<length(aia)+1
                        aia_tsb(1,l) = mean(aia(1,aa:aa+round(twosec)));
                        aa=round(l*twosec)+1;
                    else
                        aia_tsb = 0;
                    end
                end
            end
            
            aina = aina_tsb;
            aia = aia_tsb;
            
            ROI(i).all_interict_act_2sec_bins = aina_tsb;
            ROI(i).all_ict_act_2sec_bins = aia_tsb;
            
        end
        
        
        
        current_ROI = i;
        [o,h] = ranksum(aina,aia);
        p(1,i) = o;
        p_correct(1,i) = p(1,i);
        
        %     [h,p,ks2stat] = kstest2(aina,aia);
        %     ks_ict_vs_int_real(1,i) = ks2stat;
        %
        %     parfor ipp = 1:iterations
        %         current_ROI = i
        %         iteration = ipp
        %         aina_cat = [aina aia];
        %         aina_cat_perm = aina_cat(1,randperm(size(aina_cat,2)));
        %         ainashuf = aina_cat_perm(1,1:size(aina,2));
        %         aiashuf = aina_cat_perm(1,size(aina,2)+1:size(aina_cat_perm,2));
        %         [h,p,ks2stat] = kstest2(ainashuf,aiashuf);
        %         ks_ict_vs_int_shuf(ipp,i) = ks2stat;
        %     end
        %
        %     p(1,i) = length(find(ks_ict_vs_int_shuf(:,i)>ks_ict_vs_int_real(1,i)))/iterations;
        %     if p(1,i) == 0
        %         p(1,i) = 0.5/iterations;
        %     end
        
        
        if p(1,i)<p_ictnterict
            
            %calculate the HL-statistic
            %
            %         HL = zeros(1,length(aina)*length(aia));
            %         for pl = 1:length(aia)
            %             HL(1,1+(pl-1)*length(aina):pl*length(aina)) = aia(1,pl) - aina;
            %         end
            %
            if mean(aina) > mean(aia)
                interict_high(a,1) = i;
                interict_high(a,2) = mean(aina) -...
                    mean(aia);%/median(ROI_activity_00017(i).all_ict_act);
                interict_high(a,3) = mean(aia);
                interict_high(a,4) = mean(aina);
                interict_high(a,5) = mean(aina) - filtmatavg(1,i);%
                interict_high(a,6) = p(1,i);
                %interict_high(a,7) =  median(HL);
                a=a+1;
            else
                
                ict_high(b,1) = i;
                ict_high(b,5) = mean(aia) - filtmatavg(1,i);%...
                %mean(ROI_activity_00017(i).all_interict_act));%/median(ROI_activity_00017(i).all_interict_act);
                ict_high(b,2) = mean(aia) - ...
                    mean(aina);%/median(ROI_activity_00017(i).all_interict_act);
                ict_high(b,3) = mean(aia);
                ict_high(b,4) = mean(aina);
                ict_high(b,6) = p(1,i);
                %ict_high(a,7) =  median(HL);
                b=b+1;
            end
            
            
        else
            
            
            if mean(aina) > mean(aia)
                ns_interict_high(c,1) = i;
                ns_interict_high(c,2) = mean(aina) -...
                    mean(aia);%/median(ROI_activity_00017(i).all_ict_act);
                ns_interict_high(c,3) = mean(aia);
                ns_interict_high(c,4) = mean(aina);
                ns_interict_high(c,5) = mean(aina) - filtmatavg(1,i);%
                ns_interict_high(c,6) = p(1,i);
                %interict_high(a,7) =  median(HL);
                c=c+1;
            else
                
                ns_ict_high(d,1) = i;
                ns_ict_high(d,5) = mean(aia) - filtmatavg(1,i);%...
                %mean(ROI_activity_00017(i).all_interict_act));%/median(ROI_activity_00017(i).all_interict_act);
                ns_ict_high(d,2) = mean(aia) - ...
                    mean(aina);%/median(ROI_activity_00017(i).all_interict_act);
                ns_ict_high(d,3) = mean(aia);
                ns_ict_high(d,4) = mean(aina);
                ns_ict_high(d,6) = p(1,i);
                %ict_high(a,7) =  median(HL);
                d=d+1;
            end
            
            
            
        end
    end
end


