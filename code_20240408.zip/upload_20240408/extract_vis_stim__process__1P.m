
close all

for iii=1:size(subfolders,2)

    Folder = subfolders(iii).name;
    cd(Folder_master)
    cd(Folder)
    close all
    initial = recording(iii).initial;
    Namestim = dir('Gr*.mat')
    FileNamestim = Namestim.name
    stim = load (FileNamestim);
    initial.trig_factor = 1000/recording(iii).initial2.triggersync_hz        %0.1;
    % populate stimulation parameters field
    b = isfield(stim, 'stim');
    if b
        m = max(size(stim.stim.params.trials));
        %m=2
        stim_params.stim_time = stim.stim.params.trials(1,m).stimFrames*1000/(60*initial.trig_factor);
        stim_params.blank_time = stim.stim.params.trials(1,m).blankFrames*1000/(60*initial.trig_factor);
        stim_params.total_time = stim.stim.params.trials(1,m).stimulusTime*1000/initial.trig_factor;
        stim_params.repetitions = stim_params.total_time/(stim_params.stim_time+stim_params.blank_time);
        stim_params.spatial_freq = stim.stim.params.trials(1,m).spatialFreq;
        stim_params.temp_freq = stim.stim.params.trials(1,m).tempoFreq;
        stim_params.contrasts = stim.stim.params.trials(1,m).contrast;
        stim_params.orientations = stim.stim.params.trials(1,m).orientation;
    else
        m = max(size(stim.params.trials));
        %m=2
        stim_params.stim_time = stim.params.trials(1,m).stimFrames*1000/(60*initial.trig_factor);
        stim_params.blank_time = stim.params.trials(1,m).blankFrames*1000/(60*initial.trig_factor);
        stim_params.total_time = stim.params.trials(1,m).stimulusTime*1000/initial.trig_factor;
        stim_params.repetitions = stim_params.total_time/(stim_params.stim_time+stim_params.blank_time);
        stim_params.spatial_freq = stim.params.trials(1,m).spatialFreq;
        stim_params.temp_freq = stim.params.trials(1,m).tempoFreq;
        stim_params.contrasts = stim.params.trials(1,m).contrast;
        stim_params.orientations = stim.params.trials(1,m).orientation;
    end
    %Name3 = dir(strcat(Folder,'/00*.nex'));
    Name3 = dir('00*.nex')
    nex_FileName = Name3.name
    s = nex2mat(Folder,nex_FileName);
    %set the timestamp in data struct. sortStimEvent will do a length check on the ts array with event array
    timestamps = 1:stim_params.repetitions;
    s = setTimeStamp(s,timestamps);
    %retrieve the full set of stimulus events lookup table from s.
    %retrieve marker from nex file
    marker = s.nexData.markers{1};
    %stim variable set
    encode_vars = cell(1,length(marker.values));
    for j = 1 : length(marker.values)
        encode_vars{j} = marker.values{j}.name;
    end
    %keywords for event-sorting. full set of LUT returned when all variables
    %are true, i.e, '>0'
    event = struct;
    for j = 1 : length(encode_vars)
        event(j).type = encode_vars{j};
        event(j).string = '>0';
        event(j).operator = '&';
    end
    %retrive the full set of stim-event-lookup table.
    [stim_params.t_SETS,stim_params.StimEventLUT] = sortStimEvent(s,event);
    % stim_params.t_SETS = timestamps;
    % stim_params.StimEventLUT = codes;
    t_SETS = stim_params.t_SETS;
    StimEventLUT = stim_params.StimEventLUT;
    stim_params.StimEventLUT = StimEventLUT;
    %cell = results.cellnumber;
    clear smoothrawData2 flatrawData2 results
    smoothrawData2 (:,1) = smooth (recording(iii).initial.rawData2 (:,3), length(recording(iii).initial.rawData2(:,1))/(30/initial.trig_factor));
    flatrawData2 (:,1) = recording(iii).initial.rawData2 (:,3) - smoothrawData2 (:,1) ;
    results.flat_PD_trace = flatrawData2;
    figure(235)
    plot(results.flat_PD_trace)
    pause
    clear answer
    prompt = {'mute rest of flat PD trace (cutoff)?'};
    dlg_title = 'PD trace cutoff';
    num_lines = 1;
    def = {'15000000,0'};
    answer = inputdlg(prompt,dlg_title,num_lines,def);
    cutofff = str2num(answer{1})
    cutoff = cutofff(1,1);
    level = cutofff(1,2);
    results.flat_PD_trace(cutoff:size(results.flat_PD_trace,1),1) = level;
    initial2=recording(iii).initial2;
    prompt = {'how many ms maximum after stim offset for analysis?'};
    dlg_title = 'max. analysis ms';
    num_lines = 1;
    def = {'1500'};
    answer = inputdlg(prompt,dlg_title,num_lines,def);
    analysis_ms = str2num(answer{1});
    analysis_ms_1 = stim_params.stim_time*initial.trig_factor + analysis_ms;
    %analysis_ms_1 = stim_params.stim_time*initial.trig_factor + stim_params.blank_time*initial.trig_factor;
    analysis_period = ceil(analysis_ms_1/initial2.msperline);
    results.flat_PD_trace(1:initial2.mirror_start_time(1,1) ,:) = [];
    clear sorted_start start_thr i
    %get the stimulus onet times from teh photodiode trace
    sorted_start = sort(results.flat_PD_trace(1100/initial.trig_factor:round(75000/initial.trig_factor)),'descend');
    start_thr = mean(sorted_start(round(40/initial.trig_factor):round(80/initial.trig_factor)))*0.85;
    %

    if m == 1
        i = round(8000/initial.trig_factor);
    else
        i =round( 1300/initial.trig_factor);
    end
    while results.flat_PD_trace(i,1)<start_thr
        i=i+1;
    end

    results.thresh_PD = max(results.flat_PD_trace(i-round(2700/initial.trig_factor):i+round(700/initial.trig_factor),1))*0.6;
    i = round(i-round(200/initial.trig_factor));
    while results.flat_PD_trace(i,1)<results.thresh_PD
        i=i+1;
    end
    start = i
    clear  onset_time_vector ...
        onset_time_vector_deltaf stim_onset_times stim_onset_times_deltaf
    stim_onset_times(1,1) = start;
    stim_onset_times_deltaf(1,1) = round(start/(initial2.msperline/initial.trig_factor));
    onset_time_vector(1,start) = 10;
    onset_time_vector_deltaf(1,round(start/(initial2.msperline/initial.trig_factor))) = 10;
    j = round(start);
    for i = 1:stim_params.repetitions-1
        i
        if j+stim_params.stim_time+stim_params.blank_time-stim_params.blank_time/10<length(results.flat_PD_trace)
            j = round(j + stim_params.stim_time + stim_params.blank_time - round(stim_params.blank_time/6));
            while results.flat_PD_trace(j,1)<results.thresh_PD && j<length(results.flat_PD_trace)
                if j<length(results.flat_PD_trace)
                    j=j+1;
                end
            end
            stim_onset_times(1,i+1)=j;
            stim_onset_times_deltaf(1,i+1) = round(j/(initial2.msperline/initial.trig_factor));
            onset_time_vector(1,j) = 10;
            onset_time_vector_deltaf(1,round(j/(initial2.msperline/initial.trig_factor))) = 10;
        end
    end
    results.stim_onset_times_deltaf=stim_onset_times_deltaf;
    results.onset_time_vector= onset_time_vector;
    results.onset_time_vector_deltaf=onset_time_vector_deltaf;
    results.stim_onset_times= stim_onset_times;
    results.diff_stim_onset_times = diff(results.stim_onset_times);
    results.diff_stim_onset_times_deltaf = diff(results.stim_onset_times_deltaf);
    figure(909)
    plot(results.diff_stim_onset_times_deltaf)
    options.WindowStyle = 'normal';
    prompt = {'does this look right?'};
    dlg_title = 'diff_stim_frames';
    num_lines = 1;
    def = {'1'};
    answer = inputdlg(prompt,dlg_title,num_lines,def,options);
    wer = str2mat(answer);
    wer = str2num(wer);
    pause % on

    results.stim_params = stim_params;
    recording(iii).vis_results = results;
    block_reps = stim_params.repetitions/(length(stim_params.orientations)*length(stim_params.contrasts))
    recording(iii).vis_results.block_reps = block_reps;
    %for visually-evoked motif analysis: extract chunks of frames from the
    %normcorred.h5 file and save as separate tiffs (or mat-files, or both?)
    foldername = strcat(Folder_master,Folder); % 'F:\stargazer\stg-N1131\11-20-18\';
    gdir=dir('normcorred_DF.h5')
    if isempty(gdir)
        registered_files = subdir(fullfile(foldername,['*',append,'*','.',output_type]));  % list of registered files (modify this to list all the motion corrected files you need to process)

        i=1
        name = registered_files(i).name;
        info = h5info(name);
        dims = info.Datasets.Dataspace.Size;
        fr = recording(iii).initial2.samplingratehz;                                         % frame rate
        tsub = 1;                                        % degree of downsampling (for 30Hz imaging rate you can try also larger, e.g. 8-10)
        ds_filename = [foldername,'\ds_data.mat'];
        data_type = class(read_file(registered_files(1).name,1,1));
        %data_temp = matfile(ds_filename,'Writable',true);
        %data_temp.Y  = zeros([FOV,0],data_type);
        %data_temp.DY = zeros([FOV,0],'double');
        FOV = [dims(1,1) dims(1,2)];% size(masked_g,3)]; %size(read_file(files(1).name,1,1));
        % DYall = zeros([FOV,0],'double');
        %data.Yr = zeros([prod(FOV),0],data_type);
        %data_temp.sizY = [FOV,0];
        F_dark = Inf;                                    % dark fluorescence (min of all data)
        batch_size = round(fr*batch_sec_f_detrending); %2000;                               % read chunks of that size
        batch_size = round(batch_size/tsub)*tsub;        % make sure batch_size is divisble by tsub
        Ts = zeros(numFiles,1);                          % store length of each file
        cnt = 0;                                         % number of frames processed so far
        tt1 = tic;
        %  for i = 1:1%numFiles
        name = registered_files(i).name;
        info = h5info(name);
        dims = info.Datasets.Dataspace.Size;
        ndimsY = length(dims);                       % number of dimensions (data array might be already reshaped)
        Ts(i) = dims(end);
        %Ysub = zeros(FOV(1),FOV(2),floor(Ts(i)/tsub),data_type);
        %data_temp.DY(FOV(1),FOV(2),sum(floor(Ts/tsub))) = zeros(1,'double');
        %data.Yr(prod(FOV),sum(floor(Ts/tsub))) = zeros(1,data_type);
        %data_temp.DY = zeros([FOV,Ts(i)],'double');
        DYall =  vvar(FOV(1,1),FOV(1,2),Ts(i),'double');
        %DYall = zeros([FOV,Ts(i)],'double');
        cnt_sub = 0;
        gh=1;
        for t = 1:batch_size:Ts(i)
            batch_read = t
            clear Y YSmooth dw Y7p Y9p Y5p Y579m y5p y5pp dw
            Y = read_file(name,t,min(batch_size,Ts(i)-t+1));
            sigma = 1;
            YSmooth = imgaussfilt3(Y, sigma);
            %             testYsmooth = YSmooth(:,:,89)
            %             imagesc(testYsmooth)
            Y = YSmooth;
            %med_Y = double(median(Y,3));
            Y7p = double(prctile(Y,7,3));
            Y9p = double(prctile(Y,9,3));
            Y5p = double(prctile(Y,5,3));
            Y579m = (Y5p+Y7p+Y9p)/3;
            y5p = reshape(Y579m,[],1);
            if onep
                y5pp = prctile(y5p,45);
            else
                y5pp = prctile(y5p,25);
            end
            dw = double(Y579m); %double(median(Y,3));
            dw(dw<y5pp) = 16000;
            Y = double(Y);
            DY = double(zeros(FOV(1),FOV(2),min(batch_size,Ts(i)-t+1)));
            DY = double(bsxfun(@rdivide, Y, dw)); % double(Y/med_Y);
            %F_dark = min(nanmin(Y(:)),F_dark);
            %ln = size(Y,ndimsY);
            %Y = reshape(Y,[FOV,ln]);
            %Y = cast(downsample_data(Y,'time',tsub),data_type);
            ln = size(Y,3);
            %Ysub(:,:,cnt_sub+1:cnt_sub+ln) = Y;
            cnt_sub = cnt_sub + ln;
            %data_temp.DY(:,:,1:ln) = DY;
            DY(DY>10) = 10;
            DY = DY*1600;
            DYall(:,:,gh:gh+ln-1) = DY;
            gh=gh+ln
        end
        %data.Yr(:,cnt+1:cnt+cnt_sub) = reshape(Ysub,[],cnt_sub);
        toc(tt1);
        cnt = cnt + cnt_sub;
        data_temp.sizY(1,3) = cnt;
        %  end
        %DY = data_temp.DY;
        %
        %     absmindy = min(min(min(DYall)))
        %     absmaxdy = max(max(max(DYall)))
        %
        %  DYall(DYall>10) = 10;
        %  DYall = DYall*1600;
        %DYall = DYall-16000;
        h5create('normcorred_DF.h5','/DS1',size(DYall))
        dim1 = size(DYall,1);
        dim2 = size(DYall,2);
        yuhinf = h5info('normcorred_DF.h5')
        ats=1;
        clear DYallp
        for t = 1:batch_size:Ts(i)
            t
            DYallp = DYall(:,:,t:t+min(batch_size,Ts(i)-t+1)-1);
            DYallp = uint16(DYallp);
            h5write('normcorred_DF.h5','/DS1',DYallp,[1 1 ats],[dim1 dim2 size(DYallp,3)])
            ats=t;
        end
        recording(iii).DYall = DYall;
        clear DYall
    end

    foldername = strcat(Folder_master,Folder); % 'F:\stargazer\stg-N1131\11-20-18\';
    registered_files = subdir(fullfile(foldername,['*','DF','*','.',output_type]))  % list of registered files (modify this to list all the motion corrected files you need to process)
    i=1
    name = registered_files(i).name;
    info = h5info(name);
    dims = info.Datasets.Dataspace.Size;
    % registered_files = 'normcorred_DF.h5';
    % %subdir(fullfile(foldername,['*',append,'.',output_type]));
    % data_type = class(read_file(registered_files,1,1));
    % info = h5info(registered_files);
    % dims = info.Datasets.Dataspace.Size;
    ndimsY = length(dims)                       % number of dimensions (data array might be already reshaped)
    Ts = dims(end)
    chksiz = analysis_period+1;
    ori_contr_combs = length(stim_params.orientations)*length(stim_params.contrasts)
    recording(iii).vis_results = results;
    recording(iii).vis_results.ori_contr_combs = ori_contr_combs;
    for j = 1:ori_contr_combs
        j_ori_contr_comb_inc = find(StimEventLUT(:,7) == j)
        Ysub = zeros(dims(1),dims(2),chksiz);
        Y_ori_contr = zeros(dims(1),dims(2),chksiz,block_reps);
        ori_ind = StimEventLUT(j_ori_contr_comb_inc(1,1),3);
        contr_ind = StimEventLUT(j_ori_contr_comb_inc(1,1),1);
        ori = stim.stim.params.trials.orientation(1,ori_ind)
        contr = stim.stim.params.trials.contrast(1,contr_ind)
        for jj = 1:length(j_ori_contr_comb_inc)
            if j_ori_contr_comb_inc(jj,1)+1 < length(results.stim_onset_times_deltaf)
                startfr = results.stim_onset_times_deltaf(1,j_ori_contr_comb_inc(jj,1))
                endfr = startfr + analysis_period
                Ysub = read_file(registered_files.name,startfr,analysis_period+1);
                for k = 1:size(Ysub,3)
                    lop = squeeze(Ysub(:,:,k));
                    lop = fliplr(lop);
                    lop = flipud(lop);
                    Ysub(:,:,k) = lop;
                end
                Y_ori_contr(:,:,:,jj) = Ysub;
                t = Tiff(['Ysub_ori_' num2str(ori) '_contr_' num2str(contr) '_iter_' num2str(jj) '.tif' ],'w8');
                tagstruct.ImageLength = size(Ysub,1);
                tagstruct.ImageWidth = size(Ysub,2);
                tagstruct.Photometric = Tiff.Photometric.MinIsBlack;
                tagstruct.BitsPerSample = 16;
                tagstruct.SamplesPerPixel = 1;
                tagstruct.PlanarConfiguration = Tiff.PlanarConfiguration.Chunky;
                tagstruct.Software = 'MATLAB';
                tagstruct.SampleFormat = Tiff.SampleFormat.Int;
                t.setTag(tagstruct);
                t.write(int16(Ysub(:,:,1)));
                t.close();
                for i = 2:size(Ysub,3)
                    writing_tiff_g = i
                    %t = Tiff(['motion_corrected_ch2.tif'],'a');
                    t = Tiff(['Ysub_ori_' num2str(ori) '_contr_' num2str(contr) '_iter_' num2str(jj) '.tif'],'a');
                    tagstruct.ImageLength = size(Ysub,1);
                    tagstruct.ImageWidth = size(Ysub,2);
                    tagstruct.Photometric = Tiff.Photometric.MinIsBlack;
                    tagstruct.BitsPerSample = 16;
                    tagstruct.SamplesPerPixel = 1;
                    tagstruct.PlanarConfiguration = Tiff.PlanarConfiguration.Chunky;
                    tagstruct.Software = 'MATLAB';
                    tagstruct.SampleFormat = Tiff.SampleFormat.Int;
                    t.setTag(tagstruct);
                    t.write(int16(Ysub(:,:,i)));
                    t.close();
                end
            end
        end
        Y_ori_contr_mean = mean(Y_ori_contr,4);
        filename = ['Y_ori_contr_and_mean_combo_' num2str(j) '.mat']
        save (filename,'Y_ori_contr','Y_ori_contr_mean','StimEventLUT','stim')
        t = Tiff(['Y_ori_' num2str(ori) '_contr_' num2str(contr) '_mean' '.tif' ],'w8');
        tagstruct.ImageLength = size(Y_ori_contr_mean,1);
        tagstruct.ImageWidth = size(Y_ori_contr_mean,2);
        tagstruct.Photometric = Tiff.Photometric.MinIsBlack;
        tagstruct.BitsPerSample = 16;
        tagstruct.SamplesPerPixel = 1;
        tagstruct.PlanarConfiguration = Tiff.PlanarConfiguration.Chunky;
        tagstruct.Software = 'MATLAB';
        tagstruct.SampleFormat = Tiff.SampleFormat.Int;
        t.setTag(tagstruct);
        t.write(int16(Y_ori_contr_mean(:,:,1)));
        t.close();
        for i = 2:size(Y_ori_contr_mean,3)
            writing_tiff_g = i
            %t = Tiff(['motion_corrected_ch2.tif'],'a');
            t = Tiff(['Y_ori_' num2str(ori) '_contr_' num2str(contr) '_mean' '.tif'],'a');
            tagstruct.ImageLength = size(Y_ori_contr_mean,1);
            tagstruct.ImageWidth = size(Y_ori_contr_mean,2);
            tagstruct.Photometric = Tiff.Photometric.MinIsBlack;
            tagstruct.BitsPerSample = 16;
            tagstruct.SamplesPerPixel = 1;
            tagstruct.PlanarConfiguration = Tiff.PlanarConfiguration.Chunky;
            tagstruct.Software = 'MATLAB';
            tagstruct.SampleFormat = Tiff.SampleFormat.Int;
            t.setTag(tagstruct);
            t.write(int16(Y_ori_contr_mean(:,:,i)));
            t.close();
        end
    end
    clear Ysub
    %analysis of spontaneous activity patterns as a function of tumor distance
    xsec = 300  %how many seconds of spont activity for analysis?
    first_spont_fr = recording(iii).vis_results.stim_onset_times_deltaf(1,end) + round(20*recording(iii).initial2.samplingratehz);
    thuns = round(xsec*recording(iii).initial2.samplingratehz)
    last_spont_fr = first_spont_fr+thuns;
    recording(iii).first_spont_fr = first_spont_fr;
    recording(iii).last_spont_fr = last_spont_fr;
    if size(recording(iii).C_dec,2) > last_spont_fr %first_spont_fr+thuns
        Ysub = read_file(registered_files.name,first_spont_fr,thuns);
        % xsec=10
        t = Tiff(['Ysub_spont_' num2str(xsec) '_seconds_' '.tif' ],'w8');
        tagstruct.ImageLength = size(Ysub,1);
        tagstruct.ImageWidth = size(Ysub,2);
        tagstruct.Photometric = Tiff.Photometric.MinIsBlack;
        tagstruct.BitsPerSample = 16;
        tagstruct.SamplesPerPixel = 1;
        tagstruct.PlanarConfiguration = Tiff.PlanarConfiguration.Chunky;
        tagstruct.Software = 'MATLAB';
        tagstruct.SampleFormat = Tiff.SampleFormat.Int;
        t.setTag(tagstruct);
        t.write(int16(Ysub(:,:,1)));
        t.close();
        for i = 2:size(Ysub,3)
            writing_tiff_g = i
            %t = Tiff(['motion_corrected_ch2.tif'],'a');
            t = Tiff(['Ysub_spont_' num2str(xsec) '_seconds_' '.tif' ],'a');
            tagstruct.ImageLength = size(Ysub,1);
            tagstruct.ImageWidth = size(Ysub,2);
            tagstruct.Photometric = Tiff.Photometric.MinIsBlack;
            tagstruct.BitsPerSample = 16;
            tagstruct.SamplesPerPixel = 1;
            tagstruct.PlanarConfiguration = Tiff.PlanarConfiguration.Chunky;
            tagstruct.Software = 'MATLAB';
            tagstruct.SampleFormat = Tiff.SampleFormat.Int;
            t.setTag(tagstruct);
            t.write(int16(Ysub(:,:,i)));
            t.close();
        end
    else
        recording(iii).no_spont_act = 1;
    end

end
%load tumorlight tif, average frames, downsample to match Ysub, then save
%as tif and process in imagej or open in imagetool and threshold in matlab
%and save as tumor mask? then downsample Ysub and tumor mask further,
%compute distances from tumor for each pixel to plot DF/F (mean, std, etc)
%as gunction of tumor dist.

for iii=1:size(subfolders,2)
    Folder = subfolders(iii).name;
    cd(Folder_master)
    cd(Folder)
    ysfile = dir('Ysub_spont*.tif')
    info = imfinfo(ysfile.name);
    clear ys
    ys=zeros(info(1).Height,info(1).Width,size(info,1));
    for yu=1:100 %size(info,1)
        yu
        ys(:,:,yu) = imread(ysfile.name,'Index',yu);
    end

    oytfile = dir('w*light*.tif')
    if isempty(oytfile)
        cd('window')
        oytfile = dir('window*.tif')
        oyt = imread(oytfile.name);
        cd(Folder_master)
        cd(Folder)
    else
        oyt = imread(oytfile.name);
    end
    %oytavg = mean(oyt,3);
    d1=size(oyt,1)
    d2 = size(oyt,2);
    dysub1 = size(ys,1)
    dysub2 = size(ys,2);
    rat1=d1/dysub1;
    if rat1>7 && rat1<10
        dwnsmpl_rat=8
    else
        if rat1>3.979 && rat1<6.5
            dwnsmpl_rat = 4
        else
            dwnsmpl_rat=2
        end
    end
    oytres = imresize(oyt,(1/dwnsmpl_rat));
    close all
    % figure(42)
    % imagesc(oytres)
    figure(54)
    imagesc(mean(ys(:,:,1:50),3))
    %do i need to re-crop and/or translate?
    figure(57)
    imtool(oytres)
    options.WindowStyle = 'normal';
    prompt = {'point coordinates (x1,y1,x2,y2) of the tumor image?'};
    dlg_title = 'raw crop coordinates';
    num_lines = 1;
    def = {'0'};
    answer = inputdlg(prompt,dlg_title,num_lines,def,options);
    rd = str2mat(answer);
    rd = str2num(rd);
    pause % on

    options.WindowStyle = 'normal';
    prompt = {'point coordinates (x1,y1,x2,y2) of the Ysub image?'};
    dlg_title = 'raw crop coordinates';
    num_lines = 1;
    def = {'0'};
    answer = inputdlg(prompt,dlg_title,num_lines,def,options);
    re = str2mat(answer);
    re = str2num(re);
    pause % on
    close all
    %now calculate x/y translation, then adjust canvas size(?), translate, crop
    %and save tumor image.
    dy1 = re(1,1) - rd(1,1)
    dy2 = re(1,3) - rd(1,3)
    dy = round(mean([dy1 dy2]))
    dx1 = re(1,2) - rd(1,2);
    dx2 = re(1,4) - rd(1,4);
    dx = round(mean([dx1 dx2]))
    oytres_bak = oytres;
    if dx>0
        %pad first dx lines with zeros
        oytres(1+dx:size(oytres,1)+dx,:) = oytres;
    else
        if dx==0
        else
            %delete the first dx lines
            oytres(1:abs(dx),:) = [];
        end
    end
    if dy>0
        %pad first dy columns with zeros
        oytres(:,1+dy:size(oytres,2)+dy) = oytres;
    else
        if dy==0
        else
            %delete first dy columns
            oytres(:,1:abs(dy)) = [];
        end
    end
    %then cut or pad remaining x/y margins to match Ysub dimensions
    d1o = size(oytres,1)
    d2o = size(oytres,2)
    d1Y = size(ys,1)
    d2Y = size(ys,2)
    if d1o<d1Y
        oytres(d1o+1:d1Y,:) = 0;
    else
        if d1o==d1Y
        else
            oytres(d1Y+1:d1o,:) = [];
        end
    end
    if d2o<d2Y
        oytres(:,d2o+1:d2Y) = 0;
    else
        if d2o==d2Y
        else
            oytres(:,d2Y+1:d2o) = [];
        end
    end
    t = Tiff(['tumor_light_rescaled'  '.tif' ],'w8');
    tagstruct.ImageLength = size(oytres,1);
    tagstruct.ImageWidth = size(oytres,2);
    tagstruct.Photometric = Tiff.Photometric.MinIsBlack;
    tagstruct.BitsPerSample = 16;
    tagstruct.SamplesPerPixel = 1;
    tagstruct.PlanarConfiguration = Tiff.PlanarConfiguration.Chunky;
    tagstruct.Software = 'MATLAB';
    tagstruct.SampleFormat = Tiff.SampleFormat.Int;
    t.setTag(tagstruct);
    t.write(int16(oytres));
    t.close();
end
%now line them up, scale them equally and make tumor_mask.tif images, then load those back into workspace,
%downsample again, load Ysub, downsample, and then sort pixels by tumor
%distance and plot as DF traces, quantify mean activity, variance, etc...
Ysub_tiff_or_h5=1
dropped_frames = zeros(1,size(subfolders,2));
use_PD_f_align = zeros(1,size(subfolders,2));
winedrpresent=ones(1,size(subfolders,2));
%adjust accordingly
for iii=1:size(subfolders,2)
    Folder = subfolders(iii).name;
    cd(Folder_master)
    cd(Folder)
    tfile = dir('tumor_mask.tif')
    if isempty(tfile)
        tfile = dir('tumor_mask_fake.tif')
    end
    if ~isempty(tfile)
        tmask = imread(tfile.name);
        if sum(sum(tmask))>0
            ysfile = dir('Ysub_spont*.tif')
            info = imfinfo(ysfile.name);
            clear ys
            ys=zeros(info(1).Height,info(1).Width,size(info,1));
            if Ysub_tiff_or_h5
                for yu=1:size(info,1)
                    yu
                    ys(:,:,yu) = imread(ysfile.name,'Index',yu);
                end
            else
                %convert Ysub_spont tif file into 7500-frame h5 files.
                h5_filenames_ch2 = dir('Ysub*.h5')
                h5_files = size(h5_filenames_ch2,1);
                tot_frs = 0;
                for i = 1:h5_files
                    info = h5info(h5_filenames_ch2(i).name);
                    if size(info.Groups(2).Datasets,1) ==1
                        igdds = info.Groups(2).Datasets(1).Dataspace.Size;
                        if size(igdds,2)>2
                            dims = info.Groups(2).Datasets(1).Dataspace.Size;
                        else
                            dims(1,1:2) = info.Groups(2).Datasets(1).Dataspace.Size;
                            siG =  size(info.Groups);
                            dims(1,3) =  siG(1,1);
                        end
                    else
                        dims(1,1:2) = info.Groups(2).Datasets(1).Dataspace.Size;
                        dims(1,3) = size(info.Groups(2).Datasets,1);
                    end
                    frames = dims(1,3);
                    frames_h5(1,i) = frames;
                    tot_frs = tot_frs+frames;
                    if i==1
                        blockframes = frames;
                    end
                    if i == h5_files
                        lastblockframes = frames;
                    end
                    initial1.max_frame = tot_frs;
                    xf = h5_files;
                    initial1.frames_h5 = frames_h5;
                end
                initial.height = dims(1,2);
                initial.width = dims(1,1);
                initial.max_frame = tot_frs;
                hei    = initial.height;
                wid    = initial.width;
                ys = vvar(hei,wid,initial1.max_frame,'uint16');
                for block = 1:xf
                    cd(Folder_master)
                    cd(Folder)
                    if block == xf && block >1
                        blockfr = lastblockframes;
                        currest = 0;
                        g = vvar(hei,wid,lastblockframes,'uint16');
                    else
                        blockfr = blockframes;

                        currest = 0;
                        g = vvar(hei,wid,blockfr,'uint16');
                    end
                    name = h5_filenames_ch2(block,1).name;
                    frames =frames_h5(1,block);
                    g = h5read(name,'/t0/channel0');
                    meang=mean(mean(g));
                    if meang>32000
                        g = g-32768;
                    end
                    if  size(g,1)~=size(ys,1) || recording(iii).initial.date<737700 && recording(iii).initial.date>736000
                        clear gu
                        for pu = 1: size(g,3)
                            jh=squeeze(g(:,:,pu));
                            I2 = rot90(fliplr(jh),1);
                            gu(:,:,pu) = I2;
                        end
                        g=gu;
                    end
                    ys(:,:,(block-1)*blockframes+1:(block-1)*blockframes+size(g,3)) = int16(g);
                    clear g r
                end
            end
            clear ys_ds
            for yi = 1:size(ys,3)
                yi
                ys_ds(:,:,yi) = imresize(ys(:,:,yi), 0.125, 'bilinear');
            end
            recording(iii).initial2.microns_per_pixel_orig = recording(iii).initial2.microns_per_pixel;
            recording(iii).initial2.mppds = recording(iii).initial2.microns_per_pixel*8;
            ys_ds_bak = ys_ds;
            %temp dwnsmpl to 20Hz
            scfc = recording(iii).initial2.samplingratehz/20;
            newlength = round(size(ys,3)/scfc);
            clear ys_ds_ts ys
            for ou = 1:size(ys_ds,1)
                fd = squeeze(ys_ds(ou,:,:));
                fda = imresize(fd,'OutputSize',[size(ys_ds,2),newlength],'method', 'bilinear');
                ys_ds_ts(ou,:,:) = fda;
            end
            tmask_ds = imresize(tmask,0.125,'nearest');
            [tpx tpy] = find(tmask_ds); %switched 06-25-20 JM.  switched back 02/18/2022 JM
            ys_dsa = mean(ys_ds_ts,3);

            k=1; x=1;
            clear ROI_list ta2 F ROIs
            skipped_pixels=0
            for a = 1:size(ys_dsa,1)
                for b =1:size(ys_dsa,2)
                    if ys_dsa(a,b)>0.05*max(max(ys_dsa)) && isempty(find(isnan(squeeze(ys_ds_ts(a,b,:))))) && length(find(ys_ds_ts(a,b,:)==0))<20
                        ROI_list(k).centerPos = [a,b];
                        ROI_list(k).cat_signal = squeeze(ys_ds_ts(a,b,:));
                        F(:,k) = squeeze(ys_ds_ts(a,b,:));
                        k=k+1
                    else
                        skipped_pixels(x,1:2) = [a b]
                        x=x+1;
                    end
                end
            end
            ta2.height_ds_x_dim1 = size(ys_dsa,1);
            ta2.width_ds_y_dim2 = size(ys_dsa,2);
            ta2.tot_num_pixs = size(ys_dsa,1)*size(ys_dsa,2);
            ta2.skipped_pixels= skipped_pixels;
            ta2.dists_to_tumor=[];
            ta2.closest_tumor_xy=[];
            F=F';
            for k = 1:length(ROI_list)
                clear t_dist B J
                cp = ROI_list(k).centerPos ;
                ROI = k
                parfor ll = 1:length(tpx)
                    t_dist(ll,1) = sqrt((cp(1,1)-tpx(ll,1))^2 + (cp(1,2)-tpy(ll,1))^2);
                end
                [B,J] = sort(t_dist,'ascend');
                ROIs(k).tumor_pix_dists = t_dist;
                ROIs(k).sorted_pix_dists_and_inds = cat(2,B,J);
                ta2.dists_to_tumor(k,1) = B(1,1);
                ta2.closest_tumor_xy(k,1:2) = cat(2,tpx(J(1,1),1),tpy(J(1,1),1));
            end
            ta2.ROIs = ROIs;
            clear RS RI
            [RS, RI] = sort(ta2.dists_to_tumor,'ascend');
            ta2.ROI_inds_sorted_by_tumor_dist = RI;
            ta2.ROI_dists_sorted = RS;
            options = CNMFSetParms(...
                'd1', size(ys_dsa,1),'d2', size(ys_dsa,2),...
                'deconv_method','constrained_foopsi',...    % neural activity deconvolution method
                'p',2,...                                   % order of calcium dynamics
                'ssub',1,...                                % spatial downsampling when processing
                'tsub',1,...                                % further temporal downsampling when processing
                'merge_thr',0.85,...                   % merging threshold
                'gSig',0.2,...
                'max_size_thr',40,'min_size_thr',2,...    % max/min acceptable size for each component
                'spatial_method','regularized',...          % method for updating spatial components
                'df_prctile',20,...                         % take the median of background fluorescence to compute baseline fluorescence
                'fr',20/1,...                            % downsamples
                'space_thresh',0.4,...                     % space correlation acceptance threshold
                'min_SNR',2,...                           % trace SNR acceptance threshold
                'cnn_thr',0.2,...                           % cnn classifier acceptance threshold
                'nb',1,...                                  % number of background components per patch
                'gnb',1,...                                 % number of global background components
                'decay_time',1.3,...                         % length of typical transient for the indicator used
                'refine_flag',true...
                );
            %             if add_params.last_frame(1,iii)>0
            %                 options.refine_flag = false;
            %             end
            options.this_one_serial = 0 %~use_parallel_CPU
            %options.add_params=add_params;
            options.iii=iii;
            options.onep = 1;
            recording(iii).options=options;
            recording(iii).options.df_window = round(size(F,2)*0.3);
            F=double(F);recording(iii).options.df_prctile=20
            %recording(iii).options.df_window=[];
            Fd = prctfilt(F,recording(iii).options.df_prctile,recording(iii).options.df_window);                             % detrended fluorescence
            %  F0 = prctfilt((A'*b)*f,recording(iii).options.df_prctile,recording(iii).options.df_window,[],0) + (F-Fd);       % background + baseline for each component
            F0 = (F-Fd);       % background + baseline for each component
            F_dff = Fd./F0;
            F_dff = full(F_dff);
            N = size(F_dff,1);
            T = size(F_dff,2);
            C_dec = zeros(N,T);         % deconvolved DF/F traces
            S_dec = zeros(N,T);         % deconvolved neural activity
            bl = zeros(N,1);            % baseline for each trace (should be close to zero since traces are DF/F)
            neuron_sn = zeros(N,1);     % noise level at each trace
            g = cell(N,1);              % discrete time constants for each trace
            %if p == 1; model_ar = 'ar1'; elseif p == 2; model_ar = 'ar2'; else; error('This order of dynamics is not supported'); end
            model_ar='exp2';
            for i = 1:N
                nanx = isnan(F_dff(i,:));
                if sum(nanx)>0.2*size(F_dff,2)
                else
                    spkmin = recording(iii).options.spk_SNR*GetSn(F_dff(i,:));
                    lam = choose_lambda(exp(-1/(20*recording(iii).options.decay_time)),...
                        GetSn(F_dff(i,:)),recording(iii).options.lam_pr);
                    [cc,spk,opts_oasis] = deconvolveCa(F_dff(i,:),model_ar,'method','foopsi','optimize_pars',true,'maxIter',20,...
                        'window',150,'lambda',lam,'smin',spkmin);
                    bl(i) = opts_oasis.b;
                    C_dec(i,:) = cc(:)' + bl(i);
                    S_dec(i,:) = spk(:);
                    neuron_sn(i) = opts_oasis.sn;
                    g{i} = opts_oasis.pars(:)';
                    disp(['Performing deconvolution. Trace ',num2str(i),' out of ',num2str(N),' finished processing.'])
                end
            end
            xroi = 143
            figure(456)
            subplot(5,1,1)
            plot(F(xroi,:));
            hold on
            subplot(5,1,2)
            plot(F0(xroi,:));
            hold on
            subplot(5,1,3)
            plot(F_dff(xroi,:));
            hold on
            subplot(5,1,4)
            plot(C_dec(xroi,:));
            hold on
            subplot(5,1,5)
            plot(S_dec(xroi,:));
            recording(iii).ta2 = ta2;
            recording(iii).ta2.neuron_sn = neuron_sn;
            recording(iii).ta2.neuron_baseline = bl;
            recording(iii).ta2.neuron_timeconstant = g;
            recording(iii).ta2.S_dec = S_dec;
            recording(iii).ta2.C_dec = C_dec;
            %[neuropil_matrix,neuropil_results] = calciumsignalcalculator_matlab(initial,Folder,0,RL,baseline_tconst_ms,0,initial2);
            close all
            baseline_tconst_ms = 15000
            butterfilt = 0.32;
            maxcount = 3000; %maximum yaksi-friedrich iteration #
            in2.msperline = 50
            in2.samplingratehz = 20
            tbin = 50/1000;
            tau = 1.5;
            thrup = 5;  %estimated noise level in %DF/F
            apm = zeros(1,size(F',2));
            innn.indicator = 'GCaMP8m';
            innn.msperline = 50;
            [DeconvMat3000,FiltMat3000,FiltMat2_3000,deconv_adaptive] = CaDeconvStandAlone_onep(apm,...
                innn,F',tau,thrup,0,2,0,maxcount,tbin,butterfilt,baseline_tconst_ms,in2);
            DeconvMat3000(find(isnan(DeconvMat3000))) = 0;
            FiltMat3000(find(isnan(FiltMat3000))) = 0;
            FiltMat2_3000(find(isnan(FiltMat2_3000))) = 0;
            DeconvMat3000(find(DeconvMat3000==Inf)) = 30;
            FiltMat3000(find(FiltMat3000==Inf)) = 30;
            FiltMat2_3000(find(FiltMat2_3000==0)) = 30;

            %%%%%%% denoise DF/F traces
            std_level = 3;
            [deconv_no_noise,activity_per_min_deconv,deltaf_no_noise,activity_per_min_deltaf,noisedata] = ...
                denoise( innn,DeconvMat3000,FiltMat2_3000,std_level,in2,0);
            deltaf_no_noise(find(isnan(deltaf_no_noise))) = 0;
            deconv_no_noise(find(isnan(deconv_no_noise))) = 0;
            %re-run smoothing
            [DeconvMat5000_2,FiltMat5000_2,FiltMat2_5000_2,deconv_adaptive] = CaDeconvStandAlone_onep(activity_per_min_deltaf,...
                innn,F',tau,thrup,0,1,1,5000,tbin,0.16,baseline_tconst_ms,in2);
            %re-run denoising
            close all
            DeconvMat5000_2(find(isnan(DeconvMat5000_2))) = 0;
            FiltMat2_5000_2(find(isnan(FiltMat2_5000_2))) = 0;
            deconv_matrix = DeconvMat5000_2;
            deltaf_sd = 3;
            deconv_sd = 3;
            [deconv_no_noise,activity_per_min_deconv,deltaf_no_noise,activity_per_min_deltaf,noisedata] = ...
                deconvolution_Bernhard(innn,deconv_matrix,FiltMat2_5000_2,deconv_sd,deltaf_sd,in2);
            recording(iii).results.DeconvMat5000_2 = DeconvMat5000_2;
            recording(iii).results.FiltMat5000_2 = FiltMat5000_2;
            recording(iii).results.deconv_adaptive = deconv_adaptive;
            recording(iii).results.deconv_no_noise = deconv_no_noise;
            recording(iii).results.activity_per_min_deconv = activity_per_min_deconv;
            recording(iii).results.deltaf_no_noise = deltaf_no_noise;
            recording(iii).results.activity_per_min_deltaf = activity_per_min_deltaf;
            recording(iii).results.noisedata = noisedata;

            xroi = 133
            figure(457)
            subplot(5,1,1)
            plot(FiltMat3000(:,xroi));
            hold on
            subplot(5,1,2)
            plot(FiltMat2_5000_2(:,xroi));
            hold on
            subplot(5,1,3)
            plot(DeconvMat5000_2(:,xroi));
            hold on
            subplot(5,1,4)
            plot(deltaf_no_noise(:,xroi));
            hold on
            subplot(5,1,5)
            plot(deconv_no_noise(:,xroi));

            xroi = 67
            figure(557)
            subplot(5,1,1)
            plot(FiltMat3000(:,xroi));
            hold on
            subplot(5,1,2)
            plot(FiltMat2_5000_2(:,xroi));
            hold on
            subplot(5,1,3)
            plot(DeconvMat5000_2(:,xroi));
            hold on
            subplot(5,1,4)
            plot(deltaf_no_noise(:,xroi));
            hold on
            subplot(5,1,5)
            plot(deconv_no_noise(:,xroi));

            xroi = 4
            figure(657)
            subplot(5,1,1)
            plot(FiltMat3000(:,xroi));
            hold on
            subplot(5,1,2)
            plot(FiltMat2_5000_2(:,xroi));
            hold on
            subplot(5,1,3)
            plot(DeconvMat5000_2(:,xroi));
            hold on
            subplot(5,1,4)
            plot(deltaf_no_noise(:,xroi));
            hold on
            subplot(5,1,5)
            plot(deconv_no_noise(:,xroi));

            xroi = 312
            figure(757)
            subplot(5,1,1)
            plot(FiltMat3000(:,xroi));
            hold on
            subplot(5,1,2)
            plot(FiltMat2_5000_2(:,xroi));
            hold on
            subplot(5,1,3)
            plot(DeconvMat5000_2(:,xroi));
            hold on
            subplot(5,1,4)
            plot(deltaf_no_noise(:,xroi));
            hold on
            subplot(5,1,5)
            plot(deconv_no_noise(:,xroi));

            %add skipped pixels and delete matrix rows based on SNR
            recording(iii).ta2.skipped_pixels_bak = recording(iii).ta2.skipped_pixels;
            s =   [recording(iii).results.noisedata(:).SNR];
            s3 = prctile(s,1)
            s80 = prctile(s,85)
            clear todelmat
            k=1;
            d1 = recording(iii).ta2.height_ds_x_dim1;
            d2 = recording(iii).ta2.width_ds_y_dim2;
            spmax = size(recording(iii).ta2.skipped_pixels,1);
            for j = 1:length(s)
                if s(1,j)<s3 || s(1,j)>s80
                    rest = mod(j,d1);
                    a = (j-rest)/d1+1;
                    b = rest;
                    recording(iii).ta2.skipped_pixels(spmax+k,:) = [a b];
                    todelmat(k,1) = j;
                    k=k+1
                end
            end
            recording(iii).ta2.skipped_pixels_incl_add= recording(iii).ta2.skipped_pixels;
            recording(iii).ta2.ROI_list = ROI_list;
            for y = 1:size( recording(iii).results.deconv_no_noise,2)
                if ismember(y,todelmat)
                    F_dff(y,:) = 0;
                    recording(iii).results.deconv_no_noise(:,y) = 0;
                    recording(iii).results.deltaf_no_noise(:,y) = 0;
                    recording(iii).ta2.ROI_list(y).F_df = F_dff(y,:);
                    recording(iii).ta2.ROI_list(y).deconv_no_noise_point125dwnsmpl_3SD =  recording(iii).results.deconv_no_noise(:,y);
                    recording(iii).ta2.ROI_list(y).deltaf_no_noise_point125dwnsmpl_3SD =  recording(iii).results.deltaf_no_noise(:,y);

                else
                    recording(iii).ta2.ROI_list(y).F_df = F_dff(y,:);
                    recording(iii).ta2.ROI_list(y).deconv_no_noise_point125dwnsmpl_3SD =  recording(iii).results.deconv_no_noise(:,y);
                    recording(iii).ta2.ROI_list(y).deltaf_no_noise_point125dwnsmpl_3SD =  recording(iii).results.deltaf_no_noise(:,y);
                end
            end
            if isfield(recording(iii),'first_spont_fr')
                first_spont_fr = recording(iii).first_spont_fr;
            else
                first_spont_fr = recording(iii).vis_results.stim_onset_times_deltaf(1,end) + round(20*recording(iii).initial2.samplingratehz);
            end
            thuns = round(xsec*recording(iii).initial2.samplingratehz)
            last_spont_fr = first_spont_fr+thuns;
            recording(iii).ta2.first_spont_fr = first_spont_fr;
            recording(iii).ta2.last_spont_fr = last_spont_fr;
            %redo wheel_new  to make sure they're aligned!
            wheel_added_to_winedr = 0;
            tds=0
            cam_fr = 30;
            cd(Folder_master)

            wheel_thr = 0.043;
            [wheel_new] = wheel_analysis_81516(recording(iii).initial,Folder,cam_fr,tds,wheel_thr,100,0,...
                recording(iii).initial2,wheel_added_to_winedr,iii,onep,recording(iii).initial2.mirror_start_time(1,1));
            recording(iii).wheel_new = wheel_new;
            cd(Folder_master)
            Folder = subfolders(iii).name;
            cd(Folder)
            close all
            integrate_winedr_data_into_rawData2
            close all
            cam_fr = 30;
            imaged = 1;
            cd(Folder_master)
            Folder = subfolders(iii).name;
            close all
            cam_st_man = zeros(1,size(subfolders,2));
            cam15Hz = zeros(size(subfolders,2));
            %dropped_frames = zeros(1,10)
            recording(iii).initial2.no_imaging = recording(iii).initial.no_imaging;
            recording(iii).initial2.heka_or_winedr = recording(iii).initial.heka_or_winedr;
            [whisking] = whisk_analysis(Folder,recording(iii).initial2,cam_fr,recording(iii).C_dec,cam_st_man,imaged,onep,...
                recording(iii).whisking_offset_samples,recording(iii).initial2.sampl_fr,iii,cam15Hz,0,recording(iii).initial2,dropped_frames,recording);
            recording(iii).whisking = whisking;
            whs = recording(iii).whisking.smooth_avg_diffwhisk_extrap;
            wns = recording(iii).wheel_new.smooth_abs_speed_exxtrap;
            wdw = recording(iii).whisking.dw_nonoise_binary;
            whw = recording(iii).wheel_new.wheel_mot_min_binary;
            %whw = wheel_new.wheel_mot_min_binary;
            size(wdw)
            close all
            figure(296)
            plot(whs)
            hold on
            plot(wns)
            options.WindowStyle = 'normal';
            prompt = {'does this look right?'};
            dlg_title = 'diff_stim_frames';
            num_lines = 1;
            def = {'1'};
            answer = inputdlg(prompt,dlg_title,num_lines,def,options);
            wer = str2mat(answer);
            wer = str2num(wer);
            pause
            %dwnsmpl to 20Hz, restrict to Ysub frames, then identify whisk only,
            %run only, run+whisk, quiet periods, split up DF trace accordingly.
            wdw_spont =wdw(recording(iii).ta2.first_spont_fr:min([recording(iii).ta2.last_spont_fr,size(wdw,1),size(whw,1)]),1 );
            whw_spont = whw(recording(iii).ta2.first_spont_fr:min([recording(iii).ta2.last_spont_fr,size(whw,1),size(wdw,1)]),1 );
            close all
            wdw_res  = zeros(round(length(wdw_spont)/(recording(iii).initial2.samplingratehz/20)),1);
            for i = 1: size(wdw_res,1)
                wdw_res(i) = wdw_spont(round((i-1)*recording(iii).initial2.samplingratehz/20)+1);
            end
            whw_res  = zeros(round(length(whw_spont)/(recording(iii).initial2.samplingratehz/20)),1);
            for i = 1: size(whw_res,1)
                whw_res(i) = whw_spont(round((i-1)*recording(iii).initial2.samplingratehz/20)+1);
            end
            matrix = real(recording(iii).results.deltaf_no_noise);
            clear wdw_p_whw
            wdw_p_whw = wdw_res + whw_res;
            aa=1;    bb=1;    cc=1;    dd=1;
            curr_mat_walking = [];
            curr_mat_whisking = [];
            curr_mat_whisking_and_walking = [];
            curr_mat_quiet = [];
            for pio = 1:size(matrix,1)
                gef = wdw_p_whw(pio,1);
                switch gef
                    case 0
                        % quiet
                        curr_mat_quiet(aa,:) = matrix(pio,:);
                        aa=aa+1
                    case 1
                        if wdw_res(pio,1)==1
                            %walking only
                            curr_mat_walking(bb,:) = matrix(pio,:);
                            bb=bb+1
                        else
                            %whisking only
                            curr_mat_whisking(cc,:) = matrix(pio,:);
                            cc=cc+1
                        end
                    case 2
                        %whisking and walking
                        curr_mat_whisking_and_walking(dd,:) = matrix(pio,:);
                        dd=dd+1
                end
            end
            recording(iii).ta2.spont_mat_quiet = curr_mat_quiet;
            recording(iii).ta2.spont_mat_walking = curr_mat_walking;
            recording(iii).ta2.spont_mat_whisking = curr_mat_whisking;
            recording(iii).ta2.spont_mat_walk_whisk = curr_mat_whisking_and_walking;
            %now run ca_stats for the 4 different cases, and
            i2 = recording(iii).initial2;
            in2.microns_per_pixel =  i2.microns_per_pixel
            fr = 20; %recording(iii).initial2.samplingratehz; %100; %set to 0 if analyzing non-interpolated matrix!
            if isfield(recording(iii),'movie_avg')
                FOV = [size(recording(iii).movie_avg,1),size(recording(iii).movie_avg,2)];
            else
                FOV = [size(recording(iii).Cn,1),size(recording(iii).Cn,2)];

            end
            curr_mat = curr_mat_quiet;
            clear ca_stats
            [ca_stats] = basic_ca_stats_f_epilepsy(Folder,in2,curr_mat,fr,onep,FOV,0);
            recording(iii).ta2.ca_stats_deltaf_no_noise_point125dwnsmpl_3SD_quiet = ca_stats;
            if isempty(curr_mat_walking)
            else
                curr_mat = curr_mat_walking;
                clear ca_stats
                [ca_stats] = basic_ca_stats_f_epilepsy(Folder,in2,curr_mat,fr,onep,FOV,0);
                recording(iii).ta2.ca_stats_deltaf_no_noise_point125dwnsmpl_3SD_walking = ca_stats;
            end
            if isempty(curr_mat_whisking)
            else
                curr_mat = curr_mat_whisking;
                clear ca_stats
                [ca_stats] = basic_ca_stats_f_epilepsy(Folder,in2,curr_mat,fr,onep,FOV,0);
                recording(iii).ta2.ca_stats_deltaf_no_noise_point125dwnsmpl_3SD_whisking = ca_stats;
            end
            if isempty(curr_mat_whisking_and_walking)
            else
                curr_mat = curr_mat_whisking_and_walking;
                clear ca_stats
                [ca_stats] = basic_ca_stats_f_epilepsy(Folder,in2,curr_mat,fr,onep,FOV,0);
                recording(iii).ta2.ca_stats_deltaf_no_noise_point125dwnsmpl_3SD_walk_whisk = ca_stats;
            end
        else
            recording(iii).spont_but_no_tumor = 1
        end
    else
        recording(iii).spont_but_no_tumor = 1
    end
end

cd(Folder_master)
save workspace.mat -v7.3


%split into whisking, running, still
%also take out anything with SNR <20
%make a linear fit, calculate R^2, bootstrap each parameter to create
%shuffled null distributions to compute significance.
%Then take each pixel over time and plot its activity versus chaging
%distancs to tumor


bin_um = 750
for iii = 1:size(subfolders,2)
    if isempty(recording(iii).ta2)
    else
        Folder = subfolders(iii).name;
        cd(Folder_master)
        cd(Folder)
        recording(iii).ta2.quiet.dist_vs_act = [];
        recording(iii).ta2.quiet.dist_vs_act(:,1) = recording(iii).ta2.dists_to_tumor;
        %shuffle these distances randomly and assign them to the otehr
        %parameters (10,000 times?)
        recording(iii).ta2.quiet.dist_vs_act(:,2) = [recording(iii).results.noisedata.SNR]';
        recording(iii).ta2.quiet.dist_vs_act(:,3) = [recording(iii).results.noisedata.thr_deltaf]';
        recording(iii).ta2.quiet.dist_vs_act(:,4) = ...
            recording(iii).results.activity_per_min_deltaf;
        recording(iii).ta2.quiet.dist_vs_act(:,5) = ...
            recording(iii).ta2.ca_stats_deltaf_no_noise_point125dwnsmpl_3SD_quiet.ROI_events.mean_IEI_length_ms;
        recording(iii).ta2.quiet.dist_vs_act(:,6) = ...
            recording(iii).ta2.ca_stats_deltaf_no_noise_point125dwnsmpl_3SD_quiet.ROI_events.events_per_sec;
        recording(iii).ta2.quiet.dist_vs_act(:,7) = ...
            recording(iii).ta2.ca_stats_deltaf_no_noise_point125dwnsmpl_3SD_quiet.ROI_events.mean_event_length_ms;
        recording(iii).ta2.quiet.dist_vs_act(:,8) = ...
            recording(iii).ta2.ca_stats_deltaf_no_noise_point125dwnsmpl_3SD_quiet.ROI_events.mean_IEI_length_ms;
        recording(iii).ta2.quiet.dist_vs_act(:,9) = ...
            recording(iii).ta2.ca_stats_deltaf_no_noise_point125dwnsmpl_3SD_quiet.ROI_events.mean_event_amplitude;
        recording(iii).ta2.quiet.dist_vs_act(:,10) = ...
            recording(iii).ta2.ca_stats_deltaf_no_noise_point125dwnsmpl_3SD_quiet.ROI_events.mean_event_area;
        recording(iii).initial2.microns_per_pixel_orig = recording(iii).initial2.microns_per_pixel;
        recording(iii).initial2.mppds = recording(iii).initial2.microns_per_pixel*8;
        for oo = 1:size(recording(iii).ta2.quiet.dist_vs_act,1)
            bin_int_pix = bin_um/recording(iii).initial2.mppds;
            sdd = recording(iii).ta2.quiet.dist_vs_act(oo,1);
            sdf = mod(sdd,bin_int_pix);
            sdg = (sdd-sdf)/bin_int_pix+1;
            recording(iii).ta2.quiet.dist_vs_act(oo,11) = sdg;
        end
        purp = recording(iii).ta2.ca_stats_deltaf_no_noise_point125dwnsmpl_3SD_quiet.ROI_events.mean_IEI_length_ms;
        clear rhythm
        for erw = 1:size(purp,1)
            yt = recording(iii).ta2.ca_stats_deltaf_no_noise_point125dwnsmpl_3SD_quiet.ROI_events(erw).IEI_length_ms;
            myt = mean(yt);
            Cyt = std(yt,0)/myt;
            rhythm(erw,1) = 1/Cyt;
            if rhythm(erw,1)==Inf
                rhythm(erw,1) = 0;
            end
        end
        recording(iii).ta2.quiet.dist_vs_act(:,12) = rhythm;
        nanx= find(isnan(recording(iii).ta2.quiet.dist_vs_act(:,2)));
        recording(iii).ta2.quiet.dist_vs_act_nonans = recording(iii).ta2.quiet.dist_vs_act;
        recording(iii).ta2.quiet.dist_vs_act_nonans(nanx,:) = [];
        close all
        figure(345)
        plotmatrix(recording(iii).ta2.quiet.dist_vs_act(:,1),recording(iii).ta2.quiet.dist_vs_act(:,2:12))
        saveas (345,[Folder 'plotmatrix_dist_vs_act_rec_' num2str(iii) '.fig' ],'fig')
        saveas (345,[Folder 'plotmatrix_dist_vs_act_rec_' num2str(iii) '.png' ],'png')
    end
end

clear maxbiniii
for iii = 1:size(subfolders,2)
    if  isempty(recording(iii).ta2)
        maxbiniii(1,iii) = NaN;
    else
        maxbiniii(1,iii) = max(recording(iii).ta2.quiet.dist_vs_act_nonans(:,11))
    end
end
numbins=max(maxbiniii)

cd(Folder_master)
save workspace.mat -v7.3


repp=500000
clear dva_shuf_2 dva_shuf_4 dva_shuf_6 dva_shuf_9 dva_shuf_10 dva_shuf_12
for ei = 1:repp
    dva_shuf_2(ei).rsquare_real = 0;
    dva_shuf_2(ei).adjrsquare_real = 0;
    dva_shuf_2(ei).sse_real = 0;
    dva_shuf_2(ei).rmse_real = 0;
    dva_shuf_2(ei).nanpixs = 0;
    dva_shuf_4(ei).rsquare_real = 0;
    dva_shuf_4(ei).adjrsquare_real = 0;
    dva_shuf_4(ei).sse_real = 0;
    dva_shuf_4(ei).rmse_real = 0;
    dva_shuf_4(ei).nanpixs = 0;
    dva_shuf_6(ei).rsquare_real = 0;
    dva_shuf_6(ei).adjrsquare_real = 0;
    dva_shuf_6(ei).sse_real = 0;
    dva_shuf_6(ei).rmse_real = 0;
    dva_shuf_6(ei).nanpixs = 0;
    dva_shuf_9(ei).rsquare_real = 0;
    dva_shuf_9(ei).adjrsquare_real = 0;
    dva_shuf_9(ei).sse_real = 0;
    dva_shuf_9(ei).rmse_real = 0;
    dva_shuf_9(ei).nanpixs = 0;
    dva_shuf_10(ei).rsquare_real = 0;
    dva_shuf_10(ei).adjrsquare_real = 0;
    dva_shuf_10(ei).sse_real = 0;
    dva_shuf_10(ei).rmse_real = 0;
    dva_shuf_10(ei).nanpixs = 0;
    dva_shuf_12(ei).rsquare_real = 0;
    dva_shuf_12(ei).adjrsquare_real = 0;
    dva_shuf_12(ei).sse_real = 0;
    dva_shuf_12(ei).rmse_real = 0;
    dva_shuf_12(ei).nanpixs = 0;
end

for iii=1:size(subfolders,2)
    bootsr_rec=iii
    if isempty(recording(iii).ta2)
    else
        clear dist_vs_SNR_adjrsquare_shuff dist_vs_SNR_rmse_shuff
        indz=find(isnan(recording(iii).ta2.quiet.dist_vs_act(:,2)));
        indz2=find(recording(iii).ta2.quiet.dist_vs_act(:,4)==0);
        indz=union(indz,indz2);
        bat = recording(iii).ta2.quiet.dist_vs_act(:,2);
        bat(indz,:) = [];
        hat = recording(iii).ta2.quiet.dist_vs_act(:,1);
        hat(indz,:) = [];
        [curvefit,gof,output] = ...
            fit(hat,bat,'poly1','normalize','off');
        dva_shuf_2(1).rsquare_real = gof.rsquare;
        dva_shuf_2(1).adjrsquare_real = gof.adjrsquare;
        dva_shuf_2(1).sse_real = gof.sse;
        dva_shuf_2(1).rmse_real = gof.rmse;
        dva_shuf_2(1).nanpixs = indz;
        ei=1
        x = hat;
        xshuf = circshift(x,ei); %x(randperm(length(x)));
        [curvefit,gof,output] = fit(xshuf,bat,'poly1','normalize','off');
        dva_shuf_2(ei).rsquare = gof.rsquare;
        dva_shuf_2(ei).adjrsquare = gof.adjrsquare;
        dva_shuf_2(ei).sse = gof.sse;
        dva_shuf_2(ei).rmse = gof.rmse;
        dist_vs_SNR_adjrsquare_shuff(ei,1) = dva_shuf_2(ei).adjrsquare;
        dist_vs_SNR_rmse_shuff(ei,1) = dva_shuf_2(ei).rmse;
        parfor ei = 2:repp
            %shuf_rep = ei
            x = hat;
            xshuf = circshift(x,ei); %x(randperm(length(x)));
            [curvefit,gof,output] = fit(xshuf,bat,'poly1','normalize','off');
            dva_shuf_2(ei).rsquare = gof.rsquare;
            dva_shuf_2(ei).adjrsquare = gof.adjrsquare;
            dva_shuf_2(ei).sse = gof.sse;
            dva_shuf_2(ei).rmse = gof.rmse;
            dist_vs_SNR_adjrsquare_shuff(ei,1) = dva_shuf_2(ei).adjrsquare;
            dist_vs_SNR_rmse_shuff(ei,1) = dva_shuf_2(ei).rmse;
        end
        recording(iii).ta2.dva_shuf_2 = dva_shuf_2;
        recording(iii).ta2.dist_vs_SNR_adjrsquare_shuff = dist_vs_SNR_adjrsquare_shuff;
        recording(iii).ta2.dist_vs_SNR_rmse_shuff = dist_vs_SNR_rmse_shuff;
        indz=find(isnan(recording(iii).ta2.quiet.dist_vs_act(:,4)));
        indz2=find(recording(iii).ta2.quiet.dist_vs_act(:,4)==0);
        indz=union(indz,indz2);
        bat = recording(iii).ta2.quiet.dist_vs_act(:,4);
        bat(indz,:) = [];
        hat = recording(iii).ta2.quiet.dist_vs_act(:,1);
        hat(indz,:) = [];
        [curvefit,gof,output] = ...
            fit(hat,bat,'poly1','normalize','off');
        figure(90905)
        histogram(output.residuals)
        dva_shuf_4(1).rsquare_real = gof.rsquare;
        dva_shuf_4(1).adjrsquare_real = gof.adjrsquare;
        dva_shuf_4(1).sse_real = gof.sse;
        dva_shuf_4(1).rmse_real = gof.rmse;
        dva_shuf_4(1).nanpixs = indz;
        ein=1
        x = hat;
        xshuf = circshift(x,ein);%(randperm(length(x)));
        [curvefit,gof,output] = fit(xshuf,bat,'poly1','normalize','off');
        dva_shuf_4(ein).rsquare = gof.rsquare;
        dva_shuf_4(ein).adjrsquare = gof.adjrsquare;
        dva_shuf_4(ein).sse = gof.sse;
        dva_shuf_4(ein).rmse = gof.rmse;
        dist_vs_act_per_min_adjrsquare_shuff(ein,1) = dva_shuf_4(ein).adjrsquare;
        dist_vs_act_per_min_rmse_shuff(ein,1) = dva_shuf_4(ein).rmse;
        parfor ein = 2:repp
            %shuf_rep = ein
            x = hat;
            xshuf = circshift(x,ein);%(randperm(length(x)));
            [curvefit,gof,output] = fit(xshuf,bat,'poly1','normalize','off');
            dva_shuf_4(ein).rsquare = gof.rsquare;
            dva_shuf_4(ein).adjrsquare = gof.adjrsquare;
            dva_shuf_4(ein).sse = gof.sse;
            dva_shuf_4(ein).rmse = gof.rmse;
            dist_vs_act_per_min_adjrsquare_shuff(ein,1) = dva_shuf_4(ein).adjrsquare;
            dist_vs_act_per_min_rmse_shuff(ein,1) = dva_shuf_4(ein).rmse;
        end
        recording(iii).ta2.dva_shuf_4 = dva_shuf_4;
        recording(iii).ta2.dist_vs_act_per_min_adjrsquare_shuff = dist_vs_act_per_min_adjrsquare_shuff;
        recording(iii).ta2.dist_vs_act_per_min_rmse_shuff = dist_vs_act_per_min_rmse_shuff;
        indz=find(isnan(recording(iii).ta2.quiet.dist_vs_act(:,6)));
        indz2=find(recording(iii).ta2.quiet.dist_vs_act(:,4)==0);
        indz=union(indz,indz2);
        bat = recording(iii).ta2.quiet.dist_vs_act(:,6);
        bat(indz,:) = [];
        hat = recording(iii).ta2.quiet.dist_vs_act(:,1);
        hat(indz,:) = [];
        [curvefit,gof,output] = ...
            fit(hat,bat,'poly1','normalize','off');
        dva_shuf_6(1).rsquare_real = gof.rsquare;
        dva_shuf_6(1).adjrsquare_real = gof.adjrsquare;
        dva_shuf_6(1).sse_real = gof.sse;
        dva_shuf_6(1).rmse_real = gof.rmse;
        dva_shuf_6(1).nanpixs = indz;
        eil=1
        x = hat;
        xshuf = circshift(x,eil);%(randperm(length(x)));
        [curvefit,gof,output] = fit(xshuf,bat,'poly1','normalize','off');
        dva_shuf_6(eil).rsquare = gof.rsquare;
        dva_shuf_6(eil).adjrsquare = gof.adjrsquare;
        dva_shuf_6(eil).sse = gof.sse;
        dva_shuf_6(eil).rmse = gof.rmse;
        dist_vs_events_p_s_adjrsquare_shuff(eil,1) = dva_shuf_6(eil).adjrsquare;
        dist_vs_events_p_s_rmse_shuff(eil,1) = dva_shuf_6(eil).rmse;
        parfor eil = 2:repp
            %shuf_rep = eil
            x = hat;
            xshuf = circshift(x,eil);%(randperm(length(x)));
            [curvefit,gof,output] = fit(xshuf,bat,'poly1','normalize','off');
            dva_shuf_6(eil).rsquare = gof.rsquare;
            dva_shuf_6(eil).adjrsquare = gof.adjrsquare;
            dva_shuf_6(eil).sse = gof.sse;
            dva_shuf_6(eil).rmse = gof.rmse;
            dist_vs_events_p_s_adjrsquare_shuff(eil,1) = dva_shuf_6(eil).adjrsquare;
            dist_vs_events_p_s_rmse_shuff(eil,1) = dva_shuf_6(eil).rmse;
        end
        recording(iii).ta2.dva_shuf_6 = dva_shuf_6;
        recording(iii).ta2.dist_vs_events_p_s_adjrsquare_shuff = dist_vs_events_p_s_adjrsquare_shuff;
        recording(iii).ta2.dist_vs_events_p_s_rmse_shuff = dist_vs_events_p_s_rmse_shuff;
        indz=find(isnan(recording(iii).ta2.quiet.dist_vs_act(:,9)));
        indz2=find(recording(iii).ta2.quiet.dist_vs_act(:,4)==0);
        indz=union(indz,indz2);
        bat = recording(iii).ta2.quiet.dist_vs_act(:,9);
        bat(indz,:) = [];
        hat = recording(iii).ta2.quiet.dist_vs_act(:,1);
        hat(indz,:) = [];
        [curvefit,gof,output] = ...
            fit(hat,bat,'poly1','normalize','off');
        dva_shuf_9(1).rsquare_real = gof.rsquare;
        dva_shuf_9(1).adjrsquare_real = gof.adjrsquare;
        dva_shuf_9(1).sse_real = gof.sse;
        dva_shuf_9(1).rmse_real = gof.rmse;
        dva_shuf_9(1).nanpixs = indz;
        eir=1
        x = hat;
        xshuf = circshift(x,eir);%(randperm(length(x)));
        [curvefit,gof,output] = fit(xshuf,bat,'poly1','normalize','off');
        dva_shuf_9(eir).rsquare = gof.rsquare;
        dva_shuf_9(eir).adjrsquare = gof.adjrsquare;
        dva_shuf_9(eir).sse = gof.sse;
        dva_shuf_9(eir).rmse = gof.rmse;
        dist_vs_amplitude_adjrsquare_shuff(eir,1) = dva_shuf_9(eir).adjrsquare;
        dist_vs_amplitude_rmse_shuff(eir,1) = dva_shuf_9(eir).rmse;
        parfor eir = 2:repp
            %shuf_rep = eir
            x = hat;
            xshuf = circshift(x,eir);%(randperm(length(x)));
            [curvefit,gof,output] = fit(xshuf,bat,'poly1','normalize','off');
            dva_shuf_9(eir).rsquare = gof.rsquare;
            dva_shuf_9(eir).adjrsquare = gof.adjrsquare;
            dva_shuf_9(eir).sse = gof.sse;
            dva_shuf_9(eir).rmse = gof.rmse;
            dist_vs_amplitude_adjrsquare_shuff(eir,1) = dva_shuf_9(eir).adjrsquare;
            dist_vs_amplitude_rmse_shuff(eir,1) = dva_shuf_9(eir).rmse;
        end
        recording(iii).ta2.dva_shuf_9 = dva_shuf_9;
        recording(iii).ta2.dist_vs_amplitude_adjrsquare_shuff = dist_vs_amplitude_adjrsquare_shuff;
        recording(iii).ta2.dist_vs_amplitude_rmse_shuff = dist_vs_amplitude_rmse_shuff;
        indz=find(isnan(recording(iii).ta2.quiet.dist_vs_act(:,10)));
        indz2=find(recording(iii).ta2.quiet.dist_vs_act(:,4)==0);
        indz=union(indz,indz2);
        bat = recording(iii).ta2.quiet.dist_vs_act(:,10);
        bat(indz,:) = [];
        hat = recording(iii).ta2.quiet.dist_vs_act(:,1);
        hat(indz,:) = [];
        [curvefit,gof,output] = ...
            fit(hat,bat,'poly1','normalize','off');
        dva_shuf_10(1).rsquare_real = gof.rsquare;
        dva_shuf_10(1).adjrsquare_real = gof.adjrsquare;
        dva_shuf_10(1).sse_real = gof.sse;
        dva_shuf_10(1).rmse_real = gof.rmse;
        dva_shuf_10(1).nanpixs = indz;
        eit=1
        x = hat;
        xshuf = circshift(x,eit);%(randperm(length(x)));
        [curvefit,gof,output] = fit(xshuf,bat,'poly1','normalize','off');
        dva_shuf_10(eit).rsquare = gof.rsquare;
        dva_shuf_10(eit).adjrsquare = gof.adjrsquare;
        dva_shuf_10(eit).sse = gof.sse;
        dva_shuf_10(eit).rmse = gof.rmse;
        dist_vs_event_area_adjrsquare_shuff(eit,1) = dva_shuf_10(eit).adjrsquare;
        dist_vs_event_area_rmse_shuff(eit,1) = dva_shuf_10(eit).rmse;
        parfor eit = 2:repp
            %shuf_rep = eit
            x = hat;
            xshuf = circshift(x,eit);%(randperm(length(x)));
            [curvefit,gof,output] = fit(xshuf,bat,'poly1','normalize','off');
            dva_shuf_10(eit).rsquare = gof.rsquare;
            dva_shuf_10(eit).adjrsquare = gof.adjrsquare;
            dva_shuf_10(eit).sse = gof.sse;
            dva_shuf_10(eit).rmse = gof.rmse;
            dist_vs_event_area_adjrsquare_shuff(eit,1) = dva_shuf_10(eit).adjrsquare;
            dist_vs_event_area_rmse_shuff(eit,1) = dva_shuf_10(eit).rmse;
        end
        recording(iii).ta2.dva_shuf_10 = dva_shuf_10;
        recording(iii).ta2.dist_vs_area_adjrsquare_shuff = dist_vs_event_area_adjrsquare_shuff;
        recording(iii).ta2.dist_vs_area_rmse_shuff = dist_vs_event_area_rmse_shuff;
        indz=find(isnan(recording(iii).ta2.quiet.dist_vs_act(:,12)));
        indz2=find(recording(iii).ta2.quiet.dist_vs_act(:,4)==0);
        indz=union(indz,indz2);
        bat = recording(iii).ta2.quiet.dist_vs_act(:,12);
        bat(indz,:) = [];
        hat = recording(iii).ta2.quiet.dist_vs_act(:,1);
        hat(indz,:) = [];
        bat(bat==Inf) = 0;
        [curvefit,gof,output] = ...
            fit(hat,bat,'poly1','normalize','off');
        dva_shuf_12(1).rsquare_real = gof.rsquare;
        dva_shuf_12(1).adjrsquare_real = gof.adjrsquare;
        dva_shuf_12(1).sse_real = gof.sse;
        dva_shuf_12(1).rmse_real = gof.rmse;
        dva_shuf_12(1).nanpixs = indz;
        eig=1
        x = hat;
        xshuf = circshift(x,eig); %x(randperm(length(x)));
        [curvefit,gof,output] = fit(xshuf,bat,'poly1','normalize','off');
        dva_shuf_12(eig).rsquare = gof.rsquare;
        dva_shuf_12(eig).adjrsquare = gof.adjrsquare;
        dva_shuf_12(eig).sse = gof.sse;
        dva_shuf_12(eig).rmse = gof.rmse;
        dist_vs_event_rhythm_adjrsquare_shuff(eig,1) = dva_shuf_12(eig).adjrsquare;
        dist_vs_event_rhythm_rmse_shuff(eig,1) = dva_shuf_12(eig).rmse;
        parfor eig = 2:repp
            %shuf_rep = eig
            x = hat;
            xshuf = circshift(x,eig); %x(randperm(length(x)));
            [curvefit,gof,output] = fit(xshuf,bat,'poly1','normalize','off');
            dva_shuf_12(eig).rsquare = gof.rsquare;
            dva_shuf_12(eig).adjrsquare = gof.adjrsquare;
            dva_shuf_12(eig).sse = gof.sse;
            dva_shuf_12(eig).rmse = gof.rmse;
            dist_vs_event_rhythm_adjrsquare_shuff(eig,1) = dva_shuf_12(eig).adjrsquare;
            dist_vs_event_rhythm_rmse_shuff(eig,1) = dva_shuf_12(eig).rmse;
        end
        recording(iii).ta2.dva_shuf_12 = dva_shuf_12;
        recording(iii).ta2.dist_vs_rhythm_adjrsquare_shuff = dist_vs_event_rhythm_adjrsquare_shuff;
        recording(iii).ta2.dist_vs_rhythm_rmse_shuff = dist_vs_event_rhythm_rmse_shuff;
    end
end


%calculate real and bootstrapped p-valuedistributions:
cd(Folder_master)
p_adjrsquare_SNR_all_recs = zeros(size(subfolders,2),1)
p_adjrsquare_apm_all_recs = zeros(size(subfolders,2),1)
p_adjrsquare_eps_all_recs = zeros(size(subfolders,2),1)
p_adjrsquare_amplitude_all_recs = zeros(size(subfolders,2),1)
p_adjrsquare_area_all_recs = zeros(size(subfolders,2),1)
p_adjrsquare_rhythm_all_recs = zeros(size(subfolders,2),1)
for iii = 1:size(subfolders,2)
    if  isempty(recording(iii).ta2)
        p_adjrsquare_SNR_all_recs(iii,1) = NaN
        p_adjrsquare_apm_all_recs(iii,1) = NaN
        p_adjrsquare_eps_all_recs(iii,1) = NaN
        p_adjrsquare_amplitude_all_recs(iii,1) = NaN
        p_adjrsquare_area_all_recs(iii,1) = NaN
        p_adjrsquare_rhythm_all_recs(iii,1) = NaN
    else
        iii
        SNR = recording(iii).ta2.dva_shuf_2.adjrsquare_real;
        shufz = recording(iii).ta2.dist_vs_SNR_adjrsquare_shuff;
        gh = shufz>SNR;
        recording(iii).ta2.p_adjrsquare_SNR = sum(gh)/repp;
        p_adjrsquare_SNR_all_recs(iii,1) = max(1/repp,sum(gh)/repp);
        recording(iii).ta2.p_adjrsquare_SNR_all_recs = p_adjrsquare_SNR_all_recs;
        figure(675+iii)
        hiss = histogram_JM_072419(shufz,'numbins',15,'Type','RelFrequency')
        hold on
        line([SNR SNR],[0 1],'Color','red','LineStyle','--')
        saveas(675+iii,[Folder 'adjrsquare_SNR_shuf_vs_real_rec_' num2str(iii) '.png' ],'png')
        %bootstrapped
        recording(iii).ta2.p_adjrsquare_SNR_boots = 0
        for l = 1:repp/2
            btstrping=l
            SNRs = recording(iii).ta2.dist_vs_SNR_adjrsquare_shuff(l,1);
            shufz = recording(iii).ta2.dist_vs_SNR_adjrsquare_shuff;
            gh = shufz>SNRs;
            recording(iii).ta2.p_adjrsquare_SNR_boots(l,1) = sum(gh)/repp;
        end
        apm = recording(iii).ta2.dva_shuf_4.adjrsquare_real;
        shufz = recording(iii).ta2.dist_vs_act_per_min_adjrsquare_shuff;
        gh = shufz>apm;
        recording(iii).ta2.p_adjrsquare_apm = sum(gh)/repp;
        p_adjrsquare_apm_all_recs(iii,1) = max(1/repp,sum(gh)/repp);
        recording(iii).ta2.p_adjrsquare_apm_all_recs = p_adjrsquare_apm_all_recs;
        figure(775+iii)
        hiss = histogram_JM_072419(shufz,'numbins',15,'Type','RelFrequency')
        hold on
        line([apm apm],[0 1],'Color','red','LineStyle','--')
        saveas(775+iii,[Folder 'adjrsquare_apm_shuf_vs_real_rec_' num2str(iii) '.png' ],'png')
        %bootstrapped
        for l = 1:repp
            bootstrapping=l
            SNRs = recording(iii).ta2.dist_vs_act_per_min_adjrsquare_shuff(l,1);
            shufz = recording(iii).ta2.dist_vs_act_per_min_adjrsquare_shuff;
            gh = shufz>SNRs;
            recording(iii).ta2.p_adjrsquare_apm_boots(l,1) = sum(gh)/repp;
        end
        eps = recording(iii).ta2.dva_shuf_6.adjrsquare_real;
        shufz = recording(iii).ta2.dist_vs_events_p_s_adjrsquare_shuff;
        gh = shufz>eps;
        recording(iii).ta2.p_adjrsquare_eps = sum(gh)/repp;
        p_adjrsquare_eps_all_recs(iii,1) = max(1/repp,sum(gh)/repp);
        recording(iii).ta2.p_adjrsquare_eps_all_recs = p_adjrsquare_eps_all_recs;
        figure(875+iii)
        hiss = histogram_JM_072419(shufz,'numbins',15,'Type','RelFrequency')
        hold on
        line([eps eps],[0 1],'Color','red','LineStyle','--')
        saveas(875+iii,[Folder 'adjrsquare_eps_shuf_vs_real_rec_' num2str(iii) '.png' ],'png')
        amp = recording(iii).ta2.dva_shuf_9.adjrsquare_real;
        shufz = recording(iii).ta2.dist_vs_amplitude_adjrsquare_shuff;
        gh = shufz>amp;
        recording(iii).ta2.p_adjrsquare_amp = sum(gh)/repp;
        p_adjrsquare_amplitude_all_recs(iii,1) = max(1/repp,sum(gh)/repp);
        recording(iii).ta2.p_adjrsquare_amplitude_all_recs = p_adjrsquare_amplitude_all_recs;
        figure(975+iii)
        hiss = histogram_JM_072419(shufz,'numbins',15,'Type','RelFrequency')
        hold on
        line([amp amp],[0 1],'Color','red','LineStyle','--')
        saveas(975+iii,[Folder 'adjrsquare_amplitude_shuf_vs_real_rec_' num2str(iii) '.png' ],'png')
        area = recording(iii).ta2.dva_shuf_10.adjrsquare_real;
        shufz = recording(iii).ta2.dist_vs_area_adjrsquare_shuff;
        gh = shufz>area;
        recording(iii).ta2.p_adjrsquare_area = sum(gh)/repp;
        p_adjrsquare_area_all_recs(iii,1) = max(1/repp,sum(gh)/repp);
        recording(iii).ta2.p_adjrsquare_area_all_recs = p_adjrsquare_area_all_recs;
        figure(1075+iii)
        hiss = histogram_JM_072419(shufz,'numbins',15,'Type','RelFrequency')
        hold on
        line([area area],[0 1],'Color','red','LineStyle','--')
        saveas(1075+iii,[Folder 'adjrsquare_area_shuf_vs_real_rec_' num2str(iii) '.png' ],'png')
        rhythm = recording(iii).ta2.dva_shuf_12.adjrsquare_real;
        shufz = recording(iii).ta2.dist_vs_rhythm_adjrsquare_shuff;
        gh = shufz>rhythm;
        recording(iii).ta2.p_adjrsquare_rhythm = sum(gh)/repp;
        p_adjrsquare_rhythm_all_recs(iii,1) = max(1/repp,sum(gh)/repp);
        recording(iii).ta2.p_adjrsquare_rhythm_all_recs = p_adjrsquare_rhythm_all_recs;
        figure(1175+iii)
        hiss = histogram_JM_072419(shufz,'numbins',15,'Type','RelFrequency')
        hold on
        line([rhythm rhythm],[0 1],'Color','red','LineStyle','--')
        saveas(1175+iii,[Folder 'adjrsquare_rhythm_shuf_vs_real_rec_' num2str(iii) '.png' ],'png')
    end
end

%plot significance over time:
day_P = [xxxxxxxxx];
recording(1).day_P = day_P
a=1;
clear p_adjrsquare_SNR_all_recs_f_p p_adjrsquare_apm_all_recs_f_p p_adjrsquare_eps_all_recs_f_p...
    p_adjrsquare_amplitude_all_recs_f_p p_adjrsquare_area_all_recs_f_p p_adjrsquare_rhythm_all_recs_f_p...
    day_P_f_p
for s = 1:size(day_P,2)
    if isnan(p_adjrsquare_SNR_all_recs(s,1))
    else
        day_P_f_p(a,1) = day_P(1,s);
        p_adjrsquare_SNR_all_recs_f_p(a,1) = p_adjrsquare_SNR_all_recs(s,1);
        p_adjrsquare_apm_all_recs_f_p(a,1) = p_adjrsquare_apm_all_recs(s,1);
        p_adjrsquare_eps_all_recs_f_p(a,1) = p_adjrsquare_eps_all_recs(s,1);
        p_adjrsquare_amplitude_all_recs_f_p(a,1) = p_adjrsquare_amplitude_all_recs(s,1);
        p_adjrsquare_area_all_recs_f_p(a,1) = p_adjrsquare_area_all_recs(s,1);
        p_adjrsquare_rhythm_all_recs_f_p(a,1) = p_adjrsquare_rhythm_all_recs(s,1);
        a=a+1;
    end
end
recording(1).ta2.day_P_f_p = day_P_f_p;
recording(1).ta2.p_adjrsquare_SNR_all_recs_f_p = p_adjrsquare_SNR_all_recs_f_p;
recording(1).ta2.p_adjrsquare_apm_all_recs_f_p = p_adjrsquare_apm_all_recs_f_p;
recording(1).ta2.p_adjrsquare_eps_all_recs_f_p = p_adjrsquare_eps_all_recs_f_p;
recording(1).ta2.p_adjrsquare_amplitude_all_recs_f_p = p_adjrsquare_amplitude_all_recs_f_p;
recording(1).ta2.p_adjrsquare_area_all_recs_f_p = p_adjrsquare_area_all_recs_f_p;
recording(1).ta2.p_adjrsquare_rhythm_all_recs_f_p = p_adjrsquare_rhythm_all_recs_f_p;
close all
figure(897)
plot(day_P_f_p,p_adjrsquare_SNR_all_recs_f_p)
hold on
plot(day_P_f_p,p_adjrsquare_apm_all_recs_f_p)
hold on
plot(day_P_f_p,p_adjrsquare_eps_all_recs_f_p)
hold on
plot(day_P_f_p,p_adjrsquare_amplitude_all_recs_f_p)
hold on
plot(day_P_f_p,p_adjrsquare_area_all_recs_f_p)
hold on
plot(day_P_f_p,p_adjrsquare_rhythm_all_recs_f_p)
for iii=1:size(subfolders,2)
    if  isempty(recording(iii).ta2)
    else
        pval_contr(iii,1) = 0.05/sqrt(size(recording(iii).ta2.spont_mat_quiet,2))
    end
end
recording(1).pval_contr=pval_contr;

load('ccmap_adj.mat')
load('ccmap_15bins.mat')
%first compute al the clims across all recordings for each animal...
clear maxapm maxeps maxamp maxare maxrhy maxbin
for iii = 1:size(subfolders,2)
    if  isempty(recording(iii).ta2)
    else
        %act_per_min
        maxapm(1,iii) = prctile(recording(iii).ta2.quiet.dist_vs_act(:,4),95)
        %events_per_sec
        maxeps(1,iii) = prctile(recording(iii).ta2.quiet.dist_vs_act(:,6),95)
        %amplitude
        maxamp(1,iii) = prctile(recording(iii).ta2.quiet.dist_vs_act(:,9),80)
        %area
        maxare(1,iii) = prctile(recording(iii).ta2.quiet.dist_vs_act(:,10),95)
        %rhythmicity
        maxrhy(1,iii) = prctile(recording(iii).ta2.quiet.dist_vs_act(:,12),95)
        %12binbands
        maxbin(1,iii) = prctile(recording(iii).ta2.quiet.dist_vs_act(:,11),100)
    end
end

close all
for iii = 1:size(subfolders,2)
    close all
    if isempty(recording(iii).ta2)
    else
        iii
        Folder = subfolders(iii).name;
        cd(Folder_master)
        cd(Folder)
        tfile = dir('tumor_mask.tif')
        if isempty(tfile)
            tfile = dir('tumor_mask_fake.tif')
        end
        tmask = imread(tfile.name);
        tmask_ds = imresize(tmask,0.125,'nearest');
        %Or instead, try upsampling the activity plots!
        m=1
        clear tcoord
        for j = 1:size(tmask,1)
            for k = 1:size(tmask,2)
                if tmask(j,k)>0
                    tcoord(m,1:2) = [j,k];
                    m = m+1
                end
            end
        end
        recording(iii).tumor_coord = tcoord;
        recording(iii).tumor_prct_cov = 100*(m-1)/(size(tmask,1)*size(tmask,2));
        tgon = polyshape(tcoord);
        BW = imbinarize(tmask);
        [B,L] = bwboundaries(BW)
        sp = recording(iii).ta2.skipped_pixels;
        
        %plot act_per_min, amplitude, rhythmicity color coded as pixel maps, and then an outline of the
        %tumor(s) on top
        cm1 = zeros(recording(iii).ta2.height_ds_x_dim1,recording(iii).ta2.width_ds_y_dim2);
        x = 4
        j=1;
        k=1;
        clear color_mat colormat_us
        color_mat = cm1;
        for a = 1:recording(iii).ta2.height_ds_x_dim1
            for b = 1:recording(iii).ta2.width_ds_y_dim2
                curr_pix = (a-1)*recording(iii).ta2.width_ds_y_dim2+b;
                if k<size(sp,1)+1
                    if a== sp(k,1)&& b==sp(k,2)
                        color_mat(a,b) = 0;
                        k=k+1;
                    else
                        color_mat(a,b) = recording(iii).ta2.quiet.dist_vs_act(j,x);
                        j=j+1;
                    end
                else
                    color_mat(a,b) = recording(iii).ta2.quiet.dist_vs_act(j,x);
                    j=j+1;
                end
            end
        end
        recording(iii).ta2.act_per_min_mat = color_mat;
        colormat_us = imresize(color_mat,8,'nearest');
        figure(99883)
        %imshow(colormat_us,ccmap)
        imagesc(colormat_us,[0 prctile(maxapm,80)])
        colormap(ccmap_15bins)
        colorbar
        hold on
        for k = 1:length(B)
            boundary = B{k};
            plot(boundary(:,2), boundary(:,1), 'w', 'LineWidth', 2)
        end
        saveas (99883,[Folder 'colormat_act_per_min_dist_vs_act_rec_' num2str(iii) '.png' ],'png')
        
        x = 6
        j=1;
        k=1;
        clear color_mat colormat_us
        color_mat = cm1;
        for a = 1:recording(iii).ta2.height_ds_x_dim1
            for b = 1:recording(iii).ta2.width_ds_y_dim2
                curr_pix = (a-1)*recording(iii).ta2.width_ds_y_dim2+b;
                if k<size(sp,1)+1
                    if a== sp(k,1)&& b==sp(k,2)
                        color_mat(a,b) = 0;
                        k=k+1;
                    else
                        color_mat(a,b) = recording(iii).ta2.quiet.dist_vs_act(j,x);
                        j=j+1;
                    end
                else
                    color_mat(a,b) = recording(iii).ta2.quiet.dist_vs_act(j,x);
                    j=j+1;
                end
            end
        end
        recording(iii).ta2.events_per_sec_mat = color_mat;
        colormat_us = imresize(color_mat,8,'nearest');
        figure(99884)
        %imshow(colormat_us,ccmap)
        imagesc(colormat_us,[0 prctile(maxeps,80)])
        colormap(ccmap_15bins)
        colorbar
        hold on
        for k = 1:length(B)
            boundary = B{k};
            plot(boundary(:,2), boundary(:,1), 'w', 'LineWidth', 2)
        end
        saveas (99884,[Folder 'colormat_events_per_sec_dist_vs_act_rec_' num2str(iii) '.png' ],'png')
        
        x = 9
        j=1;
        k=1;
        clear color_mat colormat_us
        color_mat = cm1;
        for a = 1:recording(iii).ta2.height_ds_x_dim1
            for b = 1:recording(iii).ta2.width_ds_y_dim2
                curr_pix = (a-1)*recording(iii).ta2.width_ds_y_dim2+b;
                if k<size(sp,1)+1
                    if a== sp(k,1)&& b==sp(k,2)
                        color_mat(a,b) = 0;
                        k=k+1;
                    else
                        color_mat(a,b) = recording(iii).ta2.quiet.dist_vs_act(j,x);
                        j=j+1;
                    end
                else
                    color_mat(a,b) = recording(iii).ta2.quiet.dist_vs_act(j,x);
                    j=j+1;
                end
            end
        end
        recording(iii).ta2.amplitude_mat = color_mat;
        colormat_us = imresize(color_mat,8,'nearest');
        figure(99885)
        %imshow(colormat_us,ccmap)
        imagesc(colormat_us,[0 prctile(maxamp,80)])
        colormap(ccmap_15bins)
        colorbar
        hold on
        for k = 1:length(B)
            boundary = B{k};
            plot(boundary(:,2), boundary(:,1), 'w', 'LineWidth', 2)
        end
        saveas (99885,[Folder 'colormat_amplitude_dist_vs_act_rec_' num2str(iii) '.png' ],'png')
        
        x = 10
        j=1;
        k=1;
        clear color_mat colormat_us
        color_mat = cm1;
        for a = 1:recording(iii).ta2.height_ds_x_dim1
            for b = 1:recording(iii).ta2.width_ds_y_dim2
                curr_pix = (a-1)*recording(iii).ta2.width_ds_y_dim2+b;
                if k<size(sp,1)+1
                    if a== sp(k,1)&& b==sp(k,2)
                        color_mat(a,b) = 0;
                        k=k+1;
                    else
                        color_mat(a,b) = recording(iii).ta2.quiet.dist_vs_act(j,x);
                        j=j+1;
                    end
                else
                    color_mat(a,b) = recording(iii).ta2.quiet.dist_vs_act(j,x);
                    j=j+1;
                end
            end
        end
        recording(iii).ta2.area_mat = color_mat;
        colormat_us = imresize(color_mat,8,'nearest');
        figure(99886)
        %imshow(colormat_us,ccmap)
        imagesc(colormat_us,[0 prctile(maxare,80)])
        colormap(ccmap_15bins)
        colorbar
        hold on
        for k = 1:length(B)
            boundary = B{k};
            plot(boundary(:,2), boundary(:,1), 'w', 'LineWidth', 2)
        end
        saveas (99886,[Folder 'colormat_area_dist_vs_act_rec_' num2str(iii) '.png' ],'png')
        
        x = 12
        j=1;
        k=1;
        clear color_mat colormat_us
        color_mat = cm1;
        for a = 1:recording(iii).ta2.height_ds_x_dim1
            for b = 1:recording(iii).ta2.width_ds_y_dim2
                curr_pix = (a-1)*recording(iii).ta2.width_ds_y_dim2+b;
                if k<size(sp,1)+1
                    if a== sp(k,1)&& b==sp(k,2)
                        color_mat(a,b) = 0;
                        k=k+1;
                    else
                        color_mat(a,b) = recording(iii).ta2.quiet.dist_vs_act(j,x);
                        j=j+1;
                    end
                else
                    color_mat(a,b) = recording(iii).ta2.quiet.dist_vs_act(j,x);
                    j=j+1;
                end
            end
        end
        recording(iii).ta2.rhythm_mat = color_mat;
        colormat_us = imresize(color_mat,8,'nearest');
        figure(99887)
        %imshow(colormat_us,ccmap)
        imagesc(colormat_us,[0 prctile(maxrhy,80)])
        colormap(ccmap_15bins)
        colorbar
        hold on
        for k = 1:length(B)
            boundary = B{k};
            plot(boundary(:,2), boundary(:,1), 'w', 'LineWidth', 2)
        end
        saveas (99887,[Folder 'colormat_rhythmicity_rec_' num2str(iii) '.png' ],'png')
        
        x = 11
        j=1;
        k=1;
        clear color_mat colormat_us
        color_mat = cm1;
        for a = 1:recording(iii).ta2.height_ds_x_dim1
            for b = 1:recording(iii).ta2.width_ds_y_dim2
                curr_pix = (a-1)*recording(iii).ta2.width_ds_y_dim2+b;
                if k<size(sp,1)+1
                    if a== sp(k,1)&& b==sp(k,2)
                        color_mat(a,b) = 0;
                        k=k+1;
                    else
                        color_mat(a,b) = recording(iii).ta2.quiet.dist_vs_act(j,x);
                        j=j+1;
                    end
                else
                    color_mat(a,b) = recording(iii).ta2.quiet.dist_vs_act(j,x);
                    j=j+1;
                end
            end
        end
        recording(iii).ta2.binbands_mat = color_mat;
        colormat_us = imresize(color_mat,8,'nearest');
        figure(99888)
        %imshow(colormat_us,ccmap)
        imagesc(colormat_us,[0 max(maxbin)*0.95])
        colormap(ccmap_15bins)
        colorbar
        hold on
        for k = 1:length(B)
            boundary = B{k};
            plot(boundary(:,2), boundary(:,1), 'w', 'LineWidth', 2)
        end
        saveas (99888,[Folder 'colormat_12binbands_rec_' num2str(iii) '.png' ],'png')
    end
end

% also calculate activity changes over time for the same pixels and
%color code by distance
cd(Folder_master)
close all
figure(8969)
clear mean_dist_vs_act_per_min_over_time sem_dist_vs_act_per_min_over_time
for iii = 1:size(subfolders,2)
    if isempty(recording(iii).ta2)
    else
        recording(iii).ta2.bin_means=[];
        iii
        %act_per_min
        clear y_data_binned
        y_data = recording(iii).ta2.quiet.dist_vs_act_nonans(:,4);
        x_data = day_P(1,iii);
        c_data = recording(iii).ta2.quiet.dist_vs_act_nonans(:,11);
        for pl = 1:min(numbins,max(recording(iii).ta2.quiet.dist_vs_act_nonans(:,11)))
            a=1;
            b_a = 0;
            for il = 1:size(c_data,1)
                if c_data(il,1)==pl
                    b_a(a,1) = y_data(il,1)
                    a=a+1;
                end
            end
            recording(iii).ta2.bin_means(pl).act_per_min = b_a;
            mean_b_a = mean(b_a)
            y_data_binned(pl,1) = mean_b_a;
            sem_b_a = std(b_a,0)/sqrt(a-1);
            recording(iii).ta2.quiet.dist_vs_act_per_min.binned_mean_sem(pl,1) = mean_b_a;
            recording(iii).ta2.quiet.dist_vs_act_per_min.binned_mean_sem(pl,2) = sem_b_a;
            mean_dist_vs_act_per_min_over_time(pl,iii) = mean_b_a;
            sem_dist_vs_act_per_min_over_time(pl,iii) = mean_b_a;
        end
        for ru = 1:size(y_data_binned,1)
            scatter(x_data,y_data_binned(ru,1),[],ccmap_15bins(round(ru),:))
            hold on
        end
    end
end
saveas (8969,['binned_mean_act_per_min_scatter_over_time' '.png' ],'png')
figure(3524)
for j = 1:numbins
    H = shadedErrorBar(day_P,mean_dist_vs_act_per_min_over_time(j,:),sem_dist_vs_act_per_min_over_time(j,:),'g');
    H.mainLine.Color = ccmap_15bins(j+1,:)
    H.mainLine.LineWidth = 2
    H.patch.FaceColor = ccmap_15bins(j+1,:)
    H.patch.FaceAlpha = 0.3
    H.edge(1,1).Color = ccmap_15bins(j+1,:)
    H.edge(1,2).Color = ccmap_15bins(j+1,:)
    hold on
end
saveas (3524,['binned_mean_act_per_min_shad_errbar_over_time' '.png' ],'png')
%rhythmicity
close all
figure(8975)
clear mean_dist_vs_rhythm_over_time sem_dist_vs_rhythm_over_time
for iii = 1:size(subfolders,2)
    if isempty(recording(iii).ta2)
    else
        iii
        clear y_data_binned
        y_data = recording(iii).ta2.quiet.dist_vs_act_nonans(:,12);
        x_data = day_P(1,iii);
        c_data = recording(iii).ta2.quiet.dist_vs_act_nonans(:,11);
        for pl = 1:min(numbins,max(recording(iii).ta2.quiet.dist_vs_act_nonans(:,11)))
            a=1;
            b_a = 0;
            for il = 1:size(c_data,1)
                if c_data(il,1)==pl
                    b_a(a,1) = y_data(il,1)
                    a=a+1;
                end
            end
            recording(iii).ta2.bin_means(pl).rhythm = b_a;
            mean_b_a = mean(b_a)
            y_data_binned(pl,1) = mean_b_a;
            sem_b_a = std(b_a,0)/sqrt(a-1);
            recording(iii).ta2.quiet.dist_vs_rhythm.binned_mean_sem(pl,1) = mean_b_a;
            recording(iii).ta2.quiet.dist_vs_rhythm.binned_mean_sem(pl,2) = sem_b_a;
            mean_dist_vs_rhythm_over_time(pl,iii) = mean_b_a;
            sem_dist_vs_rhythm_over_time(pl,iii) = mean_b_a;
        end
        for ru = 1:size(y_data_binned,1)
            scatter(x_data,y_data_binned(ru,1),[],ccmap_15bins(round(ru),:))
            hold on
        end
    end
end
saveas (8975,[ 'binned_mean_rhythm_scatter_over_time' '.png' ],'png')
figure(3525)
for j = 1:numbins
    H = shadedErrorBar(day_P,mean_dist_vs_rhythm_over_time(j,:),sem_dist_vs_rhythm_over_time(j,:),'g');
    H.mainLine.Color = ccmap_15bins(j+1,:)
    H.mainLine.LineWidth = 2
    H.patch.FaceColor = ccmap_15bins(j+1,:)
    H.patch.FaceAlpha = 0.3
    H.edge(1,1).Color = ccmap_15bins(j+1,:)
    H.edge(1,2).Color = ccmap_15bins(j+1,:)
    hold on
end
saveas (3525,[Folder 'binned_mean_rhythm_shad_errbar_over_time' '.png' ],'png')

cd(Folder_master)
close all
figure(8979)
clear mean_dist_vs_amplitude_over_time sem_dist_vs_amplitude_over_time
for iii = 1:size(subfolders,2)
    if isempty(recording(iii).ta2)
    else
        iii
        %amplitude
        recording(iii).ta2.binned_matrices = [];
        clear y_data_binned
        y_data = recording(iii).ta2.quiet.dist_vs_act_nonans(:,9);
        x_data = day_P(1,iii);
        c_data = recording(iii).ta2.quiet.dist_vs_act_nonans(:,11);
        for pl = 1:min(numbins,max(recording(iii).ta2.quiet.dist_vs_act_nonans(:,11)))
            a=1;
            b_a = 0;
            for il = 1:size(c_data,1)
                if c_data(il,1)==pl
                    b_a(a,1) = y_data(il,1)
                    recording(iii).ta2.binned_matrices(pl).deltaf_nonoise(:,a) = ...
                        recording(iii).ta2.ROI_list(il).deltaf_no_noise_point125dwnsmpl_3SD;
                    a=a+1;
                end
            end
            recording(iii).ta2.bin_means(pl).amplitude = b_a;
            mean_b_a = mean(b_a)
            y_data_binned(pl,1) = mean_b_a;
            sem_b_a = std(b_a,0)/sqrt(a-1);
            recording(iii).ta2.quiet.dist_vs_amplitude.binned_mean_sem(pl,1) = mean_b_a;
            recording(iii).ta2.quiet.dist_vs_amplitude.binned_mean_sem(pl,2) = sem_b_a;
            mean_dist_vs_amplitude_over_time(pl,iii) = mean_b_a;
            sem_dist_vs_amplitude_over_time(pl,iii) = mean_b_a;
        end
        for ru = 1:size(y_data_binned,1)
            scatter(x_data,y_data_binned(ru,1),[],ccmap_15bins(round(ru),:))
            hold on
        end
    end
end
saveas (8979,[Folder 'binned_mean_amplitude_scatter_over_time' '.png' ],'png')
figure(3526)
for j = 1:numbins
    H = shadedErrorBar(day_P,mean_dist_vs_amplitude_over_time(j,:),sem_dist_vs_amplitude_over_time(j,:),'g');
    H.mainLine.Color = ccmap_15bins(j+1,:)
    H.mainLine.LineWidth = 2
    H.patch.FaceColor = ccmap_15bins(j+1,:)
    H.patch.FaceAlpha = 0.3
    H.edge(1,1).Color = ccmap_15bins(j+1,:)
    H.edge(1,2).Color = ccmap_15bins(j+1,:)
    hold on
end
saveas (3526,[Folder 'binned_mean_amplitude_shad_errbar_over_time' '.png' ],'png')

close all
figure(8980)
clear mean_dist_vs_eps_over_time sem_dist_vs_eps_over_time
for iii = 1:size(subfolders,2)
    if isempty(recording(iii).ta2)
    else
        iii
        %amplitude
        clear y_data_binned
        y_data = recording(iii).ta2.quiet.dist_vs_act_nonans(:,6);
        x_data = day_P(1,iii);
        c_data = recording(iii).ta2.quiet.dist_vs_act_nonans(:,11);
        for pl = 1:min(numbins,max(recording(iii).ta2.quiet.dist_vs_act_nonans(:,11)))
            a=1;
            b_a = 0;
            for il = 1:size(c_data,1)
                if c_data(il,1)==pl
                    b_a(a,1) = y_data(il,1)
                    a=a+1;
                end
            end
            recording(iii).ta2.bin_means(pl).eps = b_a;
            mean_b_a = mean(b_a)
            y_data_binned(pl,1) = mean_b_a;
            sem_b_a = std(b_a,0)/sqrt(a-1);
            recording(iii).ta2.quiet.dist_vs_amplitude.binned_mean_sem(pl,1) = mean_b_a;
            recording(iii).ta2.quiet.dist_vs_amplitude.binned_mean_sem(pl,2) = sem_b_a;
            mean_dist_vs_eps_over_time(pl,iii) = mean_b_a;
            sem_dist_vs_eps_over_time(pl,iii) = mean_b_a;
        end
        for ru = 1:size(y_data_binned,1)
            scatter(x_data,y_data_binned(ru,1),[],ccmap_15bins(round(ru),:))
            hold on
        end
    end
end
saveas (8980,[Folder 'binned_mean_events_per_sec_scatter_over_time' '.png' ],'png')
figure(3527)
for j = 1:numbins
    H = shadedErrorBar(day_P,mean_dist_vs_eps_over_time(j,:),sem_dist_vs_eps_over_time(j,:),'g');
    H.mainLine.Color = ccmap_15bins(j+1,:)
    H.mainLine.LineWidth = 2
    H.patch.FaceColor = ccmap_15bins(j+1,:)
    H.patch.FaceAlpha = 0.3
    H.edge(1,1).Color = ccmap_15bins(j+1,:)
    H.edge(1,2).Color = ccmap_15bins(j+1,:)
    hold on
end
saveas (3527,[Folder 'binned_mean_events_per_sec_shad_errbar_over_time' '.png' ],'png')

%area
close all
figure(8981)
clear mean_dist_vs_area_over_time sem_dist_vs_area_over_time
for iii = 1:size(subfolders,2)
    if isempty(recording(iii).ta2)
    else
        iii
        clear y_data_binned
        y_data = recording(iii).ta2.quiet.dist_vs_act_nonans(:,10);
        x_data = day_P(1,iii);
        c_data = recording(iii).ta2.quiet.dist_vs_act_nonans(:,11);
        for pl = 1:min(numbins,max(recording(iii).ta2.quiet.dist_vs_act_nonans(:,11)))
            a=1;
            b_a = 0;
            for il = 1:size(c_data,1)
                if c_data(il,1)==pl
                    b_a(a,1) = y_data(il,1)
                    a=a+1;
                end
            end
            recording(iii).ta2.bin_means(pl).area = b_a;
            mean_b_a = mean(b_a)
            y_data_binned(pl,1) = mean_b_a;
            sem_b_a = std(b_a,0)/sqrt(a-1);
            recording(iii).ta2.quiet.dist_vs_area.binned_mean_sem(pl,1) = mean_b_a;
            recording(iii).ta2.quiet.dist_vs_area.binned_mean_sem(pl,2) = sem_b_a;
            mean_dist_vs_area_over_time(pl,iii) = mean_b_a;
            sem_dist_vs_area_over_time(pl,iii) = mean_b_a;
        end
        for ru = 1:size(y_data_binned,1)
            scatter(x_data,y_data_binned(ru,1),[],ccmap_15bins(round(ru),:))
            hold on
        end
    end
end
saveas (8981,[ 'binned_mean_area_scatter_over_time' '.png' ],'png')
figure(3531)
for j = 1:numbins
    H = shadedErrorBar(day_P,mean_dist_vs_area_over_time(j,:),sem_dist_vs_area_over_time(j,:),'g');
    H.mainLine.Color = ccmap_15bins(j+1,:)
    H.mainLine.LineWidth = 2
    H.patch.FaceColor = ccmap_15bins(j+1,:)
    H.patch.FaceAlpha = 0.3
    H.edge(1,1).Color = ccmap_15bins(j+1,:)
    H.edge(1,2).Color = ccmap_15bins(j+1,:)
    hold on
end
saveas (3531,[Folder 'binned_mean_area_shad_errbar_over_time' '.png' ],'png')


%now plot the mean +/-sem of the binned deltaf traces
totsec = 120
freq = 20
totfrs = totsec*freq
close all
clear matrix meanmat semmat matmat maxmatmat
%first compute global YLim
for iii = 1:size(subfolders,2)
    if  isempty(recording(iii).ta2)
    else
        binsinuse = size(recording(iii).ta2.binned_matrices,2)
        for ref = 1:binsinuse
            if ~isempty(recording(iii).ta2.binned_matrices(ref).deltaf_nonoise)
                matrix = recording(iii).ta2.binned_matrices(ref).deltaf_nonoise(60*freq:60*freq+totfrs,:);
                meanmat = mean(matrix,2);
                semmat = std(matrix,0,2);
                semmat = semmat/sqrt(size(matrix,2));
                matmat=meanmat+semmat;
                maxmatmat(ref,iii) = max(matmat);
            end
        end
    end
end
globylim = max(max((maxmatmat)))

for iii = 1:size(subfolders,2)
    if isempty(recording(iii).ta2)
    else
        Folder = subfolders(iii).name;
        cd(Folder_master)
        cd(Folder)
        binsinuse = size(recording(iii).ta2.binned_matrices,2)
        figure(386+iii)
        set(gcf,'color','w');
        for ref = 1:binsinuse
            if ~isempty(recording(iii).ta2.binned_matrices(ref).deltaf_nonoise)
                matrix = recording(iii).ta2.binned_matrices(ref).deltaf_nonoise(60*freq:60*freq+totfrs,:);
                meanmat = mean(matrix,2);
                semmat = std(matrix,0,2);
                semmat = semmat/sqrt(size(matrix,2));
                gsu = subaxis (binsinuse,1,ref,'SpacingVert',0);
                H = shadedErrorBar([1:1:length(meanmat)],meanmat,semmat,'g');
                H.mainLine.Color = ccmap_15bins(ref+1,:);  %(round(ref*15/binsinuse)+1,:)
                H.mainLine.LineWidth = 1
                H.patch.FaceColor = ccmap_15bins(ref+1,:);   %(round(ref*15/binsinuse)+1,:)
                H.patch.FaceAlpha = 0.3
                H.edge(1,1).Color = ccmap_15bins(ref+1,:);   %(round(ref*15/binsinuse)+1,:)
                H.edge(1,2).Color = ccmap_15bins(ref+1,:);   %(round(ref*15/binsinuse)+1,:)
                %klo = EEG_results_nonoise.cat_signal_interp_values(beg_sec*100:endsecc*100,RI(ref,1));
                %plot(klo,'Color',c(ref,:));
                %     gsu.XTick = [];
                %     gsu.YTick = [];
                set(gca,'xtick',[],'ytick',round(100*max(meanmat))/100)
                set(gca,'Yticklabel', num2str(round(100*max(meanmat))/100))
                gsu.YLim = [0 globylim];
                %subaxis
                %set(gca,'visible', off)
                %ylabel(num2str(neuron_numbers(i,1)), 'FontName', 'Arial', 'FontSize', 12, 'FontWeight', 'bold');
                box off
                axis off
                hold on
            end
        end
        saveas (386+iii,[Folder 'binned_deltaf_traces_rec_' num2str(iii) '_' num2str(totsec) '_sec' '.png' ],'png')
    end
end

%plot overlapping histograms of binned means
%first get binedges across recordings
%area
cd(Folder_master)
close all
for iii = 1:size(subfolders,2)
    if isempty(recording(iii).ta2)
    else
        figure(3199+iii)
        for pl= 1:size(recording(iii).ta2.bin_means,2)
            b_a = recording(iii).ta2.bin_means(pl).area;
            hiss = histogram_JM_072419(b_a,'numbins',10,'Type','RelFrequency') %,'Edgealpha',0.6, 'FaceAlpha',0.6,'Edgecolor',ccmap_15bins(round(pl),:),...
            %'FaceColor',ccmap_15bins(round(pl),:))
            hiss.FaceColor = ccmap_15bins(round(pl+1),:);
            hiss.FaceAlpha = 0.6;
            hiss.EdgeColor = ccmap_15bins(round(pl+1),:);
            hold on
        end
        saveas(3199+iii,[Folder 'binned_area_histograms__rec_' num2str(iii) '.png' ],'png')
        
        figure(3299+iii)
        for pl= 1:size(recording(iii).ta2.bin_means,2)
            b_a = recording(iii).ta2.bin_means(pl).eps;
            hiss = histogram_JM_072419(b_a,'numbins',10,'Type','RelFrequency') %,'Edgealpha',0.6, 'FaceAlpha',0.6,'Edgecolor',ccmap_15bins(round(pl),:),...
            %'FaceColor',ccmap_15bins(round(pl),:))
            hiss.FaceColor = ccmap_15bins(round(pl+1),:);
            hiss.FaceAlpha = 0.6;
            hiss.EdgeColor = ccmap_15bins(round(pl+1),:);
            hold on
        end
        saveas(3299+iii,[Folder 'binned_eps_histograms__rec_' num2str(iii) '.png' ],'png')
        
        figure(3399+iii)
        for pl= 1:size(recording(iii).ta2.bin_means,2)
            b_a = recording(iii).ta2.bin_means(pl).amplitude;
            hiss = histogram_JM_072419(b_a,'numbins',10,'Type','RelFrequency') %,'Edgealpha',0.6, 'FaceAlpha',0.6,'Edgecolor',ccmap_15bins(round(pl),:),...
            %'FaceColor',ccmap_15bins(round(pl),:))
            hiss.FaceColor = ccmap_15bins(round(pl+1),:);
            hiss.FaceAlpha = 0.6;
            hiss.EdgeColor = ccmap_15bins(round(pl+1),:);
            hold on
        end
        saveas(3399+iii,[Folder 'binned_amplitude_histograms__rec_' num2str(iii) '.png' ],'png')
        
        
        figure(3499+iii)
        for pl= 1:size(recording(iii).ta2.bin_means,2)
            b_a = recording(iii).ta2.bin_means(pl).rhythm;
            hiss = histogram_JM_072419(b_a,'numbins',10,'Type','RelFrequency') %,'Edgealpha',0.6, 'FaceAlpha',0.6,'Edgecolor',ccmap_15bins(round(pl),:),...
            %'FaceColor',ccmap_15bins(round(pl),:))
            hiss.FaceColor = ccmap_15bins(round(pl+1),:);
            hiss.FaceAlpha = 0.6;
            hiss.EdgeColor = ccmap_15bins(round(pl+1),:);
            hold on
        end
        saveas(3499+iii,[Folder 'binned_rhythm_histograms__rec_' num2str(iii) '.png' ],'png')
        
        figure(3599+iii)
        for pl= 1:size(recording(iii).ta2.bin_means,2)
            b_a = recording(iii).ta2.bin_means(pl).act_per_min;
            hiss = histogram_JM_072419(b_a,'numbins',10,'Type','RelFrequency') %,'Edgealpha',0.6, 'FaceAlpha',0.6,'Edgecolor',ccmap_15bins(round(pl),:),...
            %'FaceColor',ccmap_15bins(round(pl),:))
            hiss.FaceColor = ccmap_15bins(round(pl+1),:);
            hiss.FaceAlpha = 0.6;
            hiss.EdgeColor = ccmap_15bins(round(pl+1),:);
            hold on
        end
        saveas(3599+iii,[Folder 'binned_act_per_min_histograms__rec_' num2str(iii) '.png' ],'png')
    end
end

%make 2 new matrices to compare activity patterns over distances for each
%rec, and over recordings for each dsitance bins, then correlate those with
%tumor coverage

cd(Folder_master)
close all
%across recordings
for iii = 1:size(subfolders,2)
    if isempty(recording(iii).ta2)
    else
        Folder = subfolders(iii).name;
        cd(Folder_master)
        cd(Folder)
        clear sizzes maxsz binz
        binz = size(recording(iii).ta2.bin_means,2)
        for pl= 1:binz
            b_a = recording(iii).ta2.bin_means(pl).act_per_min;
            sizzes(pl,1) = size(b_a,1);
        end
        maxsz = max(sizzes)
        recording(iii).ta2.act_per_min_vs_distbin = ones(maxsz,binz)*11111;
        for pl = 1:binz
            recording(iii).ta2.act_per_min_vs_distbin(1:sizzes(pl,1),pl) =  recording(iii).ta2.bin_means(pl).act_per_min;
        end
        recording(iii).ta2.act_per_min_vs_distbin(recording(iii).ta2.act_per_min_vs_distbin==11111) = NaN;
        close all
        [p1,t1,stats1] = kruskalwallis(recording(iii).ta2.act_per_min_vs_distbin);
        [comparison,means,H,gnames1] = multcompare(stats1);
        recording(1).ta2.act_per_min_distbins(iii,1) = binz;
        recording(iii).ta2.act_per_min_vs_distbin_stats.anova_p = p1;
        recording(iii).ta2.act_per_min_vs_distbin_stats.anova_tab = t1;
        recording(iii).ta2.act_per_min_vs_distbin_stats.mult_comparison = comparison;
        recording(iii).ta2.act_per_min_vs_distbin_stats.mult_means = means;
        recording(iii).ta2.act_per_min_vs_distbin_stats.stats1 = stats1;
        saveas(H,['act_per_min_vs_distbin_multcomp' '.png'], 'png')
        
        clear sizzes maxsz binz
        binz = size(recording(iii).ta2.bin_means,2)
        for pl= 1:binz
            b_a = recording(iii).ta2.bin_means(pl).rhythm;
            sizzes(pl,1) = size(b_a,1);
        end
        maxsz = max(sizzes)
        recording(iii).ta2.rhythm_vs_distbin = ones(maxsz,binz)*11111;
        for pl = 1:binz
            recording(iii).ta2.rhythm_vs_distbin(1:sizzes(pl,1),pl) =  recording(iii).ta2.bin_means(pl).rhythm;
        end
        recording(iii).ta2.rhythm_vs_distbin(recording(iii).ta2.rhythm_vs_distbin==11111) = NaN;
        close all
        [p1,t1,stats1] = kruskalwallis(recording(iii).ta2.rhythm_vs_distbin);
        [comparison,means,H,gnames1] = multcompare(stats1);
        recording(1).ta2.rhythm_distbins(iii,1) = binz;
        recording(iii).ta2.rhythm_vs_distbin_stats.anova_p = p1;
        recording(iii).ta2.rhythm_vs_distbin_stats.anova_tab = t1;
        recording(iii).ta2.rhythm_vs_distbin_stats.mult_comparison = comparison;
        recording(iii).ta2.rhythm_vs_distbin_stats.mult_means = means;
        recording(iii).ta2.rhythm_vs_distbin_stats.stats1 = stats1;
        saveas(H,['rhythm_vs_distbin_multcomp' '.png'], 'png')
        
        clear sizzes maxsz binz
        binz = size(recording(iii).ta2.bin_means,2)
        for pl= 1:binz
            b_a = recording(iii).ta2.bin_means(pl).amplitude;
            sizzes(pl,1) = size(b_a,1);
        end
        maxsz = max(sizzes)
        recording(iii).ta2.amplitude_vs_distbin = ones(maxsz,binz)*11111;
        for pl = 1:binz
            recording(iii).ta2.amplitude_vs_distbin(1:sizzes(pl,1),pl) =  recording(iii).ta2.bin_means(pl).amplitude;
        end
        recording(iii).ta2.amplitude_vs_distbin(recording(iii).ta2.amplitude_vs_distbin==11111) = NaN;
        close all
        [p1,t1,stats1] = kruskalwallis(recording(iii).ta2.amplitude_vs_distbin);
        [comparison,means,H,gnames1] = multcompare(stats1);
        recording(1).ta2.amplitude_distbins(iii,1) = binz;
        recording(iii).ta2.amplitude_vs_distbin_stats.anova_p = p1;
        recording(iii).ta2.amplitude_vs_distbin_stats.anova_tab = t1;
        recording(iii).ta2.amplitude_vs_distbin_stats.mult_comparison = comparison;
        recording(iii).ta2.amplitude_vs_distbin_stats.mult_means = means;
        recording(iii).ta2.amplitude_vs_distbin_stats.stats1 = stats1;
        saveas(H,['amplitude_vs_distbin_multcomp' '.png'], 'png')
        
        clear sizzes maxsz binz
        binz = size(recording(iii).ta2.bin_means,2)
        for pl= 1:binz
            b_a = recording(iii).ta2.bin_means(pl).area;
            sizzes(pl,1) = size(b_a,1);
        end
        maxsz = max(sizzes)
        recording(iii).ta2.area_vs_distbin = ones(maxsz,binz)*11111;
        for pl = 1:binz
            recording(iii).ta2.area_vs_distbin(1:sizzes(pl,1),pl) =  recording(iii).ta2.bin_means(pl).area;
        end
        recording(iii).ta2.area_vs_distbin(recording(iii).ta2.area_vs_distbin==11111) = NaN;
        close all
        [p1,t1,stats1] = kruskalwallis(recording(iii).ta2.area_vs_distbin);
        [comparison,means,H,gnames1] = multcompare(stats1);
        recording(1).ta2.area_distbins(iii,1) = binz;
        recording(iii).ta2.area_vs_distbin_stats.anova_p = p1;
        recording(iii).ta2.area_vs_distbin_stats.anova_tab = t1;
        recording(iii).ta2.area_vs_distbin_stats.mult_comparison = comparison;
        recording(iii).ta2.area_vs_distbin_stats.mult_means = means;
        recording(iii).ta2.area_vs_distbin_stats.stats1 = stats1;
        saveas(H,['area_vs_distbin_multcomp' '.png'], 'png')
        
        clear sizzes maxsz binz
        binz = size(recording(iii).ta2.bin_means,2)
        for pl= 1:binz
            b_a = recording(iii).ta2.bin_means(pl).eps;
            sizzes(pl,1) = size(b_a,1);
        end
        maxsz = max(sizzes)
        recording(iii).ta2.eps_vs_distbin = ones(maxsz,binz)*11111;
        for pl = 1:binz
            recording(iii).ta2.eps_vs_distbin(1:sizzes(pl,1),pl) =  recording(iii).ta2.bin_means(pl).eps;
        end
        recording(iii).ta2.eps_vs_distbin(recording(iii).ta2.eps_vs_distbin==11111) = NaN;
        close all
        [p1,t1,stats1] = kruskalwallis(recording(iii).ta2.eps_vs_distbin);
        [comparison,means,H,gnames1] = multcompare(stats1);
        recording(1).ta2.eps_distbins(iii,1) = binz;
        recording(iii).ta2.eps_vs_distbin_stats.anova_p = p1;
        recording(iii).ta2.eps_vs_distbin_stats.anova_tab = t1;
        recording(iii).ta2.eps_vs_distbin_stats.mult_comparison = comparison;
        recording(iii).ta2.eps_vs_distbin_stats.mult_means = means;
        recording(iii).ta2.eps_vs_distbin_stats.stats1 = stats1;
        saveas(H,['eps_vs_distbin_multcomp' '.png'], 'png')
    end
end

cd(Folder_master)
close all
%across distance bins for each parameter separately
recording(1).ta2.act_per_min_across_distbin = [];
recording(1).ta2.across_distbin=[];
for pl= 1:max(recording(1).ta2.act_per_min_distbins)
    clear sizzes maxsz binz b_a
    todel=0
    b=1;
    binz = size(subfolders,2)
    for iii = 1:binz
        if ~isfield(recording(iii).ta2,'bin_means')
        else
            if size(recording(iii).ta2.bin_means,2)<pl || ~isempty(recording(iii).no_spont_act)
            else
                b_a = recording(iii).ta2.bin_means(pl).act_per_min;
                sizzes(iii,1) = size(b_a,1);
            end
        end
    end
    maxsz = max(sizzes)
    recording(1).ta2.across_distbin(pl).act_per_min_vs_recording = ones(maxsz,binz)*11111;
    for iii = 1:binz
        if ~isfield(recording(iii).ta2,'bin_means')
        else
            if size(recording(iii).ta2.bin_means,2)<pl || ~isempty(recording(iii).no_spont_act)
            else
                recording(1).ta2.across_distbin(pl).act_per_min_vs_recording(1:sizzes(iii,1),iii) = ...
                    recording(iii).ta2.bin_means(pl).act_per_min;
                recording(1).ta2.act_per_min_across_distbin(pl).tumor_cov_vs_act_per_min_means(iii,1) = recording(iii).tumor_prct_cov;
                recording(1).ta2.act_per_min_across_distbin(pl).tumor_cov_vs_act_per_min_means(iii,2) = mean(recording(iii).ta2.bin_means(pl).act_per_min);
            end
        end
    end
    recording(1).ta2.across_distbin(pl).act_per_min_vs_recording(recording(1).ta2.across_distbin(pl).act_per_min_vs_recording==11111) = NaN;
    close all
    [p1,t1,stats1] = kruskalwallis(recording(1).ta2.across_distbin(pl).act_per_min_vs_recording);
    if size(stats1.meanranks,2)>1
        [comparison,means,H,gnames1] = multcompare(stats1);
        recording(1).ta2.act_per_min_across_distbin(pl).stats.anova_p = p1;
        recording(1).ta2.act_per_min_across_distbin(pl).stats.anova_tab = t1;
        recording(1).ta2.act_per_min_across_distbin(pl).stats.mult_comparison = comparison;
        recording(1).ta2.act_per_min_across_distbin(pl).stats.mult_means = means;
        recording(1).ta2.act_per_min_across_distbin(pl).stats.stats1 = stats1;
        saveas(H,['act_per_min_vs_rec_distbin_' num2str(pl) '_multcomp' '.png'], 'png')
    end
    plerp =recording(1).ta2.act_per_min_across_distbin(pl).tumor_cov_vs_act_per_min_means;
    for sd = 1:size(plerp,1)
        if plerp(sd,1)==0 &&plerp(sd,2)==0
            todel(b,1)=sd;
            b=b+1
        end
    end
    if sum(todel)
        plerp(todel,:) = [];
    end
    recording(1).ta2.act_per_min_across_distbin(pl).tumor_cov_vs_act_per_min_means_corrcoef = ...
        corrcoef(plerp);
end

a=1;
cc_over_dist_tumor_cov_vs_act_per_min = 0;
for pl = 1:max(recording(1).ta2.act_per_min_distbins)
    o = recording(1).ta2.act_per_min_across_distbin;
    if size(o(pl).tumor_cov_vs_act_per_min_means_corrcoef,1)>1
        cc_over_dist_tumor_cov_vs_act_per_min(a,1) = o(pl).tumor_cov_vs_act_per_min_means_corrcoef(1,2);
        a=a+1;
    end
end
recording(1).ta2.cc_over_dist_tumor_cov_vs_act_per_min = cc_over_dist_tumor_cov_vs_act_per_min;
h=figure(5983)
plot(cc_over_dist_tumor_cov_vs_act_per_min)
h.CurrentAxes.YLim = [-1,1]
saveas(5983,['cc_over_dist_tumor_cov_vs_act_per_min' '.png'], 'png')

%eps
recording(1).ta2.eps_across_distbin=[];
for pl= 1:max(recording(1).ta2.eps_distbins)
    clear sizzes maxsz binz
    todel=0
    b=1;
    binz = size(subfolders,2)
    for iii = 1:binz
        if ~isfield(recording(iii).ta2,'bin_means')
        else
            if size(recording(iii).ta2.bin_means,2)<pl || ~isempty(recording(iii).no_spont_act)
            else
                b_a = recording(iii).ta2.bin_means(pl).eps;
                sizzes(iii,1) = size(b_a,1);
            end
        end
    end
    maxsz = max(sizzes)
    recording(1).ta2.across_distbin(pl).eps_vs_recording = ones(maxsz,binz)*11111;
    for iii = 1:binz
        if ~isfield(recording(iii).ta2,'bin_means')
        else
            if size(recording(iii).ta2.bin_means,2)<pl || ~isempty(recording(iii).no_spont_act)
            else
                recording(1).ta2.across_distbin(pl).eps_vs_recording(1:sizzes(iii,1),iii) = ...
                    recording(iii).ta2.bin_means(pl).eps;
                recording(1).ta2.eps_across_distbin(pl).tumor_cov_vs_eps_means(iii,1) = recording(iii).tumor_prct_cov;
                recording(1).ta2.eps_across_distbin(pl).tumor_cov_vs_eps_means(iii,2) = mean(recording(iii).ta2.bin_means(pl).eps);
            end
        end
    end
    recording(1).ta2.across_distbin(pl).eps_vs_recording(recording(1).ta2.across_distbin(pl).eps_vs_recording==11111) = NaN;
    close all
    [p1,t1,stats1] = kruskalwallis(recording(1).ta2.across_distbin(pl).eps_vs_recording);
    if size(stats1.meanranks,2)>1
        [comparison,means,H,gnames1] = multcompare(stats1);
        recording(1).ta2.eps_across_distbin(pl).stats.anova_p = p1;
        recording(1).ta2.eps_across_distbin(pl).stats.anova_tab = t1;
        recording(1).ta2.eps_across_distbin(pl).stats.mult_comparison = comparison;
        recording(1).ta2.eps_across_distbin(pl).stats.mult_means = means;
        recording(1).ta2.eps_across_distbin(pl).stats.stats1 = stats1;
        saveas(H,['eps_vs_rec_distbin_' num2str(pl) '_multcomp' '.png'], 'png')
    end
    plerp =recording(1).ta2.eps_across_distbin(pl).tumor_cov_vs_eps_means;
    for sd = 1:size(plerp,1)
        if plerp(sd,1)==0 &&plerp(sd,2)==0
            todel(b,1)=sd;
            b=b+1
        end
    end
    if sum(todel)
        plerp(todel,:) = [];
    end
    recording(1).ta2.eps_across_distbin(pl).tumor_cov_vs_eps_means_corrcoef = ...
        corrcoef(plerp);
end

a=1;
cc_over_dist_tumor_cov_vs_eps = 0
for pl = 1:max(recording(1).ta2.eps_distbins)
    o = recording(1).ta2.eps_across_distbin;
    if size(o(pl).tumor_cov_vs_eps_means_corrcoef,1)>1
        cc_over_dist_tumor_cov_vs_eps(a,1) = o(pl).tumor_cov_vs_eps_means_corrcoef(1,2);
        a=a+1;
    end
end
recording(1).ta2.cc_over_dist_tumor_cov_vs_eps = cc_over_dist_tumor_cov_vs_eps;
h=figure(4983)
plot(cc_over_dist_tumor_cov_vs_eps)
h.CurrentAxes.YLim = [-1,1]
saveas(4983,['cc_over_dist_tumor_cov_vs_eps' '.png'], 'png')


%area
recording(1).ta2.area_across_distbin=[];
for pl= 1:max(recording(1).ta2.area_distbins)
    clear sizzes maxsz binz
    todel=0
    b=1;
    binz = size(subfolders,2)
    for iii = 1:binz
        if ~isfield(recording(iii).ta2,'bin_means')
        else
            if size(recording(iii).ta2.bin_means,2)<pl || ~isempty(recording(iii).no_spont_act)
            else
                b_a = recording(iii).ta2.bin_means(pl).area;
                sizzes(iii,1) = size(b_a,1);
            end
        end
    end
    maxsz = max(sizzes)
    recording(1).ta2.across_distbin(pl).area_vs_recording = ones(maxsz,binz)*11111;
    for iii = 1:binz
        if ~isfield(recording(iii).ta2,'bin_means')
        else
            if size(recording(iii).ta2.bin_means,2)<pl || ~isempty(recording(iii).no_spont_act)
            else
                recording(1).ta2.across_distbin(pl).area_vs_recording(1:sizzes(iii,1),iii) = ...
                    recording(iii).ta2.bin_means(pl).area;
                recording(1).ta2.area_across_distbin(pl).tumor_cov_vs_area_means(iii,1) = recording(iii).tumor_prct_cov;
                recording(1).ta2.area_across_distbin(pl).tumor_cov_vs_area_means(iii,2) = mean(recording(iii).ta2.bin_means(pl).area);
            end
        end
    end
    recording(1).ta2.across_distbin(pl).area_vs_recording(recording(1).ta2.across_distbin(pl).area_vs_recording==11111) = NaN;
    close all
    [p1,t1,stats1] = kruskalwallis(recording(1).ta2.across_distbin(pl).area_vs_recording);
    if size(stats1.meanranks,2)>1
        [comparison,means,H,gnames1] = multcompare(stats1);
        recording(1).ta2.area_across_distbin(pl).stats.anova_p = p1;
        recording(1).ta2.area_across_distbin(pl).stats.anova_tab = t1;
        recording(1).ta2.area_across_distbin(pl).stats.mult_comparison = comparison;
        recording(1).ta2.area_across_distbin(pl).stats.mult_means = means;
        recording(1).ta2.area_across_distbin(pl).stats.stats1 = stats1;
        saveas(H,['area_vs_rec_distbin_' num2str(pl) '_multcomp' '.png'], 'png')
    end
    plerp =recording(1).ta2.area_across_distbin(pl).tumor_cov_vs_area_means;
    for sd = 1:size(plerp,1)
        if plerp(sd,1)==0 &&plerp(sd,2)==0
            todel(b,1)=sd;
            b=b+1
        end
    end
    if sum(todel)
        plerp(todel,:) = [];
    end
    recording(1).ta2.area_across_distbin(pl).tumor_cov_vs_area_means_corrcoef = ...
        corrcoef(plerp);
end

a=1;
cc_over_dist_tumor_cov_vs_area = 0
for pl = 1:max(recording(1).ta2.area_distbins)
    o = recording(1).ta2.area_across_distbin;
    if size(o(pl).tumor_cov_vs_area_means_corrcoef,1)>1
        cc_over_dist_tumor_cov_vs_area(a,1) = o(pl).tumor_cov_vs_area_means_corrcoef(1,2);
        a=a+1;
    end
end
h=figure(3983)
plot(cc_over_dist_tumor_cov_vs_area)
h.CurrentAxes.YLim = [-1,1]
recording(1).ta2.cc_over_dist_tumor_cov_vs_area = cc_over_dist_tumor_cov_vs_area;
saveas(3983,['cc_over_dist_tumor_cov_vs_area' '.png'], 'png')


%amplitude
recording(1).ta2.amplitude_across_distbin=[];
for pl= 1:max(recording(1).ta2.amplitude_distbins)
    clear sizzes maxsz binz
    todel=0
    b=1
    binz = size(subfolders,2)
    for iii = 1:binz
        if ~isfield(recording(iii).ta2,'bin_means')
        else
            if size(recording(iii).ta2.bin_means,2)<pl || ~isempty(recording(iii).no_spont_act)
            else
                b_a = recording(iii).ta2.bin_means(pl).amplitude;
                sizzes(iii,1) = size(b_a,1);
            end
        end
    end
    maxsz = max(sizzes)
    recording(1).ta2.across_distbin(pl).amplitude_vs_recording = ones(maxsz,binz)*11111;
    for iii = 1:binz
        if ~isfield(recording(iii).ta2,'bin_means')
        else
            if size(recording(iii).ta2.bin_means,2)<pl || ~isempty(recording(iii).no_spont_act)
            else
                recording(1).ta2.across_distbin(pl).amplitude_vs_recording(1:sizzes(iii,1),iii) = ...
                    recording(iii).ta2.bin_means(pl).amplitude;
                recording(1).ta2.amplitude_across_distbin(pl).tumor_cov_vs_amplitude_means(iii,1) = recording(iii).tumor_prct_cov;
                recording(1).ta2.amplitude_across_distbin(pl).tumor_cov_vs_amplitude_means(iii,2) = mean(recording(iii).ta2.bin_means(pl).amplitude);
            end
        end
    end
    recording(1).ta2.across_distbin(pl).amplitude_vs_recording(recording(1).ta2.across_distbin(pl).amplitude_vs_recording==11111) = NaN;
    close all
    [p1,t1,stats1] = kruskalwallis(recording(1).ta2.across_distbin(pl).amplitude_vs_recording);
    if size(stats1.meanranks,2)>1
        [comparison,means,H,gnames1] = multcompare(stats1);
        recording(1).ta2.amplitude_across_distbin(pl).stats.anova_p = p1;
        recording(1).ta2.amplitude_across_distbin(pl).stats.anova_tab = t1;
        recording(1).ta2.amplitude_across_distbin(pl).stats.mult_comparison = comparison;
        recording(1).ta2.amplitude_across_distbin(pl).stats.mult_means = means;
        recording(1).ta2.amplitude_across_distbin(pl).stats.stats1 = stats1;
        saveas(H,['amplitude_vs_rec_distbin_' num2str(pl) '_multcomp' '.png'], 'png')
    end
    plerp =recording(1).ta2.amplitude_across_distbin(pl).tumor_cov_vs_amplitude_means;
    for sd = 1:size(plerp,1)
        if plerp(sd,1)==0 &&plerp(sd,2)==0
            todel(b,1)=sd;
            b=b+1
        end
    end
    if sum(todel)
        plerp(todel,:) = [];
    end
    recording(1).ta2.amplitude_across_distbin(pl).tumor_cov_vs_amplitude_means_corrcoef = ...
        corrcoef(plerp);
end

a=1;
cc_over_dist_tumor_cov_vs_amplitude = 0
for pl = 1:max(recording(1).ta2.amplitude_distbins)
    o = recording(1).ta2.amplitude_across_distbin;
    if size(o(pl).tumor_cov_vs_amplitude_means_corrcoef,1)>1
        cc_over_dist_tumor_cov_vs_amplitude(a,1) = o(pl).tumor_cov_vs_amplitude_means_corrcoef(1,2);
        a=a+1;
    end
end
recording(1).ta2.cc_over_dist_tumor_cov_vs_amplitude = cc_over_dist_tumor_cov_vs_amplitude;
h=figure(2983)
plot(cc_over_dist_tumor_cov_vs_amplitude)
h.CurrentAxes.YLim = [-1,1]
saveas(2983,['cc_over_dist_tumor_cov_vs_amplitude' '.png'], 'png')

%rhythm
recording(1).ta2.rhythm_across_distbin=[];
for pl= 1:max(recording(1).ta2.rhythm_distbins)
    clear sizzes maxsz binz
    todel=0
    b=1
    binz = size(subfolders,2)
    for iii = 1:binz
        if ~isfield(recording(iii).ta2,'bin_means')
        else
            if size(recording(iii).ta2.bin_means,2)<pl || ~isempty(recording(iii).no_spont_act)
            else
                b_a = recording(iii).ta2.bin_means(pl).rhythm;
                sizzes(iii,1) = size(b_a,1);
            end
        end
    end
    maxsz = max(sizzes)
    recording(1).ta2.across_distbin(pl).rhythm_vs_recording = ones(maxsz,binz)*11111;
    for iii = 1:binz
        if ~isfield(recording(iii).ta2,'bin_means')
        else
            if size(recording(iii).ta2.bin_means,2)<pl || ~isempty(recording(iii).no_spont_act)
            else
                recording(1).ta2.across_distbin(pl).rhythm_vs_recording(1:sizzes(iii,1),iii) = ...
                    recording(iii).ta2.bin_means(pl).rhythm;
                recording(1).ta2.rhythm_across_distbin(pl).tumor_cov_vs_rhythm_means(iii,1) = recording(iii).tumor_prct_cov;
                recording(1).ta2.rhythm_across_distbin(pl).tumor_cov_vs_rhythm_means(iii,2) = mean(recording(iii).ta2.bin_means(pl).rhythm);
            end
        end
    end
    recording(1).ta2.across_distbin(pl).rhythm_vs_recording(recording(1).ta2.across_distbin(pl).rhythm_vs_recording==11111) = NaN;
    close all
    [p1,t1,stats1] = kruskalwallis(recording(1).ta2.across_distbin(pl).rhythm_vs_recording);
    if size(stats1.meanranks,2)>1
        [comparison,means,H,gnames1] = multcompare(stats1);
        recording(1).ta2.rhythm_across_distbin(pl).stats.anova_p = p1;
        recording(1).ta2.rhythm_across_distbin(pl).stats.anova_tab = t1;
        recording(1).ta2.rhythm_across_distbin(pl).stats.mult_comparison = comparison;
        recording(1).ta2.rhythm_across_distbin(pl).stats.mult_means = means;
        recording(1).ta2.rhythm_across_distbin(pl).stats.stats1 = stats1;
        saveas(H,['rhythm_vs_rec_distbin_' num2str(pl) '_multcomp' '.png'], 'png')
    end
    plerp =recording(1).ta2.rhythm_across_distbin(pl).tumor_cov_vs_rhythm_means;
    for sd = 1:size(plerp,1)
        if plerp(sd,1)==0 &&plerp(sd,2)==0
            todel(b,1)=sd;
            b=b+1
        end
    end
    if sum(todel)
        plerp(todel,:) = [];
    end
    recording(1).ta2.rhythm_across_distbin(pl).tumor_cov_vs_rhythm_means_corrcoef = ...
        corrcoef(plerp);
end

a=1;
cc_over_dist_tumor_cov_vs_rhythm = 0;
for pl = 1:max(recording(1).ta2.rhythm_distbins)
    o = recording(1).ta2.rhythm_across_distbin;
    if size(o(pl).tumor_cov_vs_rhythm_means_corrcoef,1)>1
        cc_over_dist_tumor_cov_vs_rhythm(a,1) = o(pl).tumor_cov_vs_rhythm_means_corrcoef(1,2);
        a=a+1;
    end
end
recording(1).ta2.cc_over_dist_tumor_cov_vs_rhythm = cc_over_dist_tumor_cov_vs_rhythm;
h = figure(1983)
plot(cc_over_dist_tumor_cov_vs_rhythm)
h.CurrentAxes.YLim = [-1,1]
saveas(1983,['cc_over_dist_tumor_cov_vs_rhythm' '.png'], 'png')

close all
cd(Folder_master)
for pl = 1:size(recording(1).ta2.across_distbin,2)
    apm = recording(1).ta2.across_distbin(pl).act_per_min_vs_recording;
    h = figure(7*pl)
    boxplot(apm,'Notch','on')
    h.CurrentAxes.YLim = [0,30]
    saveas(7*pl,['boxplot_apm_across_recs_distbin' num2str(pl) '.png'], 'png')
    eps = recording(1).ta2.across_distbin(pl).eps_vs_recording;
    h = figure(97*pl)
    boxplot(eps,'Notch','on')
    h.CurrentAxes.YLim = [0,0.05]
    saveas(97*pl,['boxplot_eps_across_recs_distbin' num2str(pl) '.png'], 'png')
    area = recording(1).ta2.across_distbin(pl).area_vs_recording;
    h = figure(987*pl)
    boxplot(area,'Notch','on')
    h.CurrentAxes.YLim = [0,150]
    saveas(987*pl,['boxplot_area_across_recs_distbin' num2str(pl) '.png'], 'png')
    amplitude = recording(1).ta2.across_distbin(pl).amplitude_vs_recording;
    h = figure(9827*pl)
    boxplot(amplitude,'Notch','on')
    h.CurrentAxes.YLim = [0,0.03]
    saveas(9827*pl,['boxplot_amplitude_across_recs_distbin' num2str(pl) '.png'], 'png')
    rhythm = recording(1).ta2.across_distbin(pl).rhythm_vs_recording;
    h = figure(98217*pl)
    boxplot(rhythm,'Notch','on')
    h.CurrentAxes.YLim = [0,1.5]
    saveas(98217*pl,['boxplot_rhythm_across_recs_distbin' num2str(pl) '.png'], 'png')
end

%%%PLot tumor growth/rate over recordings to go along with the plots above
%plot the binned means +/-sem for each recording separately

spn = size(subfolders,2)
close all
figure(10)
for iii = 1:size(subfolders,2)
    if ~isfield(recording(iii).ta2,'bin_means')
    else
        if ~isempty(recording(iii).no_spont_act) || isempty(recording(iii).ta2)
        else
            cd(Folder_master)
            Folder = subfolders(iii).name;
            cd(Folder)
            
            rtqd = recording(iii).ta2.bin_means;
            clear ampl_binned area_binned eps_binned apm_binned rhythm_binned
            for pl = 1:size(rtqd,2)
                ra = rtqd(pl).amplitude;
                ampl_binned(1:size(ra,1),pl) = ra;
                ra = rtqd(pl).area;
                area_binned(1:size(ra,1),pl) = ra;
                ra = rtqd(pl).eps;
                eps_binned(1:size(ra,1),pl) = ra;
                ra = rtqd(pl).act_per_min;
                apm_binned(1:size(ra,1),pl) = ra;
                ra = rtqd(pl).rhythm;
                rhythm_binned(1:size(ra,1),pl) = ra;
            end
            
            for pl = 1:size(rtqd,2)
                ra = rtqd(pl).amplitude;
                if size(ra,1)<size(ampl_binned,1)
                    ampl_binned(size(ra,1):size(ampl_binned,1),pl) = NaN;
                end
                ra = rtqd(pl).area;
                if size(ra,1)<size(area_binned,1)
                    area_binned(size(ra,1):size(area_binned,1),pl) = NaN;
                end
                ra = rtqd(pl).eps;
                if size(ra,1)<size(eps_binned,1)
                    eps_binned(size(ra,1):size(eps_binned,1),pl) = NaN;
                end
                ra = rtqd(pl).act_per_min;
                if size(ra,1)<size(apm_binned,1)
                    apm_binned(size(ra,1):size(apm_binned,1),pl) = NaN;
                end
                ra = rtqd(pl).rhythm;
                if size(ra,1)<size(rhythm_binned,1)
                    rhythm_binned(size(ra,1):size(rhythm_binned,1),pl) = NaN;
                end
            end
            ta2_analysis.by_rec(iii).ta2.ampl_binned = ampl_binned;
            ta2_analysis.by_rec(iii).ta2.area_binned = area_binned;
            ta2_analysis.by_rec(iii).ta2.eps_binned = eps_binned;
            ta2_analysis.by_rec(iii).ta2.apm_binned = apm_binned;
            ta2_analysis.by_rec(iii).ta2.rhythm_binned = rhythm_binned;
            h = subplot(size(subfolders,2),5,(iii-1)*5+1)
            boxplot(ampl_binned,'Notch','on')
            h.YLim = [-0.0015,0.03]
            hold on
            hh = subplot(size(subfolders,2),5,(iii-1)*5+2)
            boxplot(area_binned,'Notch','on')
            hh.YLim = [0,200]
            hold on
            hhh = subplot(size(subfolders,2),5,(iii-1)*5+3)
            boxplot(eps_binned,'Notch','on')
            hhh.YLim = [0,0.05]
            hold on
            hhhh = subplot(size(subfolders,2),5,(iii-1)*5+4)
            boxplot(apm_binned,'Notch','on')
            hhhh.YLim = [0,40]
            hold on
            hhhhh = subplot(size(subfolders,2),5,(iii-1)*5+5)
            boxplot(rhythm_binned,'Notch','on')
            hhhhh.YLim = [0,1.5]
            hold on
        end
    end
end


for iii = 1:size(subfolders,2)
    if isfield(recording(iii),'tumor_coord')
        if ~isempty(recording(iii).tumor_coord)
            just_tumor.by_rec(iii).tumor_coord = recording(iii).tumor_coord;
            just_tumor.by_rec(iii).tumor_prct_cov = recording(iii).tumor_prct_cov;
            recording(1).day_P_v_tumor_cov_perc(iii,1) = recording(1).day_P(1,iii);
            recording(1).day_P_v_tumor_cov_perc(iii,2) = recording(iii).tumor_prct_cov;
        end
    end
end
figure(209)
plot(recording(1).day_P_v_tumor_cov_perc(:,1),recording(1).day_P_v_tumor_cov_perc(:,2))

cd(Folder_master)
save just_tumor.mat just_tumor -v7.3

ta2_analysis.overall_ta2_stats = recording(1).ta2;
for iii = 1:size(subfolders,2)
    ta2_analysis.by_rec(iii).ta2 = recording(iii).ta2;
    ta2_analysis.by_rec(iii).tumor_coord = recording(iii).tumor_coord;
    ta2_analysis.by_rec(iii).tumor_prct_cov = recording(iii).tumor_prct_cov;
end

cd(Folder_master)

save ta2_analysis.mat ta2_analysis -v7.3
save workspace.mat -v7.3
save recording.mat recording -v7.3



