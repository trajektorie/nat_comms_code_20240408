%%if restarting analysis here 
load('ta2_analysis.mat', 'ta2_analysis')
load('workspace.mat', 'day_P')
load('workspace.mat', 'day_P_f_p')
load('workspace.mat', 'subfolders')
load('workspace.mat', 'Folder_master')
%OR
load('workspace_new.mat', 'day_P')
load('workspace_new.mat', 'subfolders')
load('workspace_new.mat', 'Folder_master')
load('workspace_new.mat', 'day_P_f_p')

recording_ta3(1).day_P_vs_tum_siz_squm = 0;
recording_ta3(1).day_P_vs_other_params = 0;
recording_ta3(1).FOV_stats.tafov_apm_all=0
recording_ta3(1).FOV_stats.tafov_eps_all=0
recording_ta3(1).FOV_stats.tafov_length_all=0
recording_ta3(1).FOV_stats.tafov_amp_all=0
recording_ta3(1).FOV_stats.tafov_area_all=0
recording_ta3(1).FOV_stats.tafov_IEI_all=0
recording_ta3(1).FOV_stats.tafov_rhythm_all=0
clear tafov_apm tafov_eps tafov_length tafov_amp tafov_area tafov_IEI
a=1;
b=1;
c=1;
d=1;
e=1;
for iii = 1: size(subfolders,2)
    Folder = subfolders(iii).name;
    cd(Folder_master)
    cd(Folder)
    recording_ta3(1).day_P_vs_tum_siz_squm(iii,1) = day_P(1,iii);
    recording_ta3(1).day_P_vs_other_params(iii,1) = day_P(1,iii);
    tfile = dir('tumor_mask.tif')
    %first get all FOV-wide means across recordings and run wilcoxon
    %ranksum test on those.
    if isfield(ta2_analysis.by_rec(iii).ta2,'ca_stats_deltaf_no_noise_point125dwnsmpl_3SD_quiet')...
            && isempty(recording(iii).no_spont_act)
        tafov_apm = ta2_analysis.by_rec(iii).ta2.ca_stats_deltaf_no_noise_point125dwnsmpl_3SD_quiet.ROI_events(1).mean_DF;
        tafov_eps = ta2_analysis.by_rec(iii).ta2.ca_stats_deltaf_no_noise_point125dwnsmpl_3SD_quiet.ROI_events(1).events_per_sec;
        tafov_length = ta2_analysis.by_rec(iii).ta2.ca_stats_deltaf_no_noise_point125dwnsmpl_3SD_quiet.ROI_events(1).mean_event_length_ms;
        tafov_amp = ta2_analysis.by_rec(iii).ta2.ca_stats_deltaf_no_noise_point125dwnsmpl_3SD_quiet.ROI_events(1).mean_event_amplitude;
        tafov_area = ta2_analysis.by_rec(iii).ta2.ca_stats_deltaf_no_noise_point125dwnsmpl_3SD_quiet.ROI_events(1).mean_event_area;
        tafov_IEI = ta2_analysis.by_rec(iii).ta2.ca_stats_deltaf_no_noise_point125dwnsmpl_3SD_quiet.ROI_events(1).mean_IEI_length_ms;
        %go through tafov_apm and when it's 0, set eps to 0 and IEI to NaN
        for t = 1:size(tafov_apm,1)
            if tafov_apm(t,1)==0
                tafov_eps(t,1) = 0;
                tafov_IEI(t,1) = NaN;
            end
        end
        prp = ta2_analysis.by_rec(iii).ta2.ca_stats_deltaf_no_noise_point125dwnsmpl_3SD_quiet.ROI_events.mean_IEI_length_ms;
        clear tafov_rhythm
        for erw = 1:size(prp,1)
            yt = ta2_analysis.by_rec(iii).ta2.ca_stats_deltaf_no_noise_point125dwnsmpl_3SD_quiet.ROI_events(erw).IEI_length_ms;
            myt = mean(yt);
            Cyt = std(yt,0)/myt;
            tafov_rhythm(erw,1) = 1/Cyt;
        end
        maxroi(iii,1) = size(tafov_rhythm,1);
        recording_ta3(1).FOV_stats.tafov_apm_all(1:maxroi(iii,1),iii) = tafov_apm;
        recording_ta3(1).FOV_stats.tafov_eps_all(1:maxroi(iii,1),iii) = tafov_eps;
        recording_ta3(1).FOV_stats.tafov_length_all(1:maxroi(iii,1),iii) = tafov_length;
        recording_ta3(1).FOV_stats.tafov_amp_all(1:maxroi(iii,1),iii) = tafov_amp;
        recording_ta3(1).FOV_stats.tafov_area_all(1:maxroi(iii,1),iii) = tafov_area;
        recording_ta3(1).FOV_stats.tafov_IEI_all(1:maxroi(iii,1),iii) = tafov_IEI;
        recording_ta3(1).FOV_stats.tafov_rhythm_all(1:maxroi(iii,1),iii) = tafov_rhythm;

        if isempty(tfile)
            tfile = dir('tumor_mask_fake.tif')
            recording_ta3(iii).no_real_tumor_in_FOV = 1;
            recording_ta3(1).day_P_vs_tum_siz_squm(iii,2) = 0;
            recording_ta3(1).day_P_vs_other_params(iii,2) = 0;
        else
            pval_contr(iii,1) = 0.05/sqrt(size(ta2_analysis.by_rec(iii).ta2.spont_mat_quiet,2))
            tmask = imread(tfile.name);
            %tmask_ds = imresize(tmask,0.125,'nearest');
            %Or instead, try upsampling the activity plots!
            if (size(tmask,1)*size(tmask,2)>36000)&&(size(tmask,1)*size(tmask,2)<102000)
                recording(iii).initial2.mppds = 293.6;
            end
            m=1
            clear tcoord
            for j = 1:size(tmask,1)
                for k = 1:size(tmask,2)
                    if tmask(j,k)>0
                        tcoord(m,1:2) = [j,k];
                        m = m+1
                    end
                end
            end
            recording_ta3(1).day_P_vs_tum_siz_squm(iii,2) = m*recording(iii).initial2.mppds;
            if iii>1
                if (recording_ta3(1).day_P_vs_tum_siz_squm(iii,1) - recording_ta3(1).day_P_vs_tum_siz_squm(iii-1,1))>0
                    recording_ta3(1).day_P_vs_tum_siz_squm(iii,3) = (recording_ta3(1).day_P_vs_tum_siz_squm(iii,2) - recording_ta3(1).day_P_vs_tum_siz_squm(iii-1,2))...
                        /(recording_ta3(1).day_P_vs_tum_siz_squm(iii,1) - recording_ta3(1).day_P_vs_tum_siz_squm(iii-1,1));
                    recording_ta3(1).day_P_vs_other_params(iii,3) = (recording_ta3(1).day_P_vs_tum_siz_squm(iii,2) - recording_ta3(1).day_P_vs_tum_siz_squm(iii-1,2))...
                        /(recording_ta3(1).day_P_vs_tum_siz_squm(iii,1) - recording_ta3(1).day_P_vs_tum_siz_squm(iii-1,1));
                    recording_ta3(1).day_P_vs_other_params(iii,4) = ta2_analysis.by_rec(iii).ta2.p_adjrsquare_amplitude_all_recs(iii,1);
                    recording_ta3(1).day_P_vs_other_params(iii,5) = ta2_analysis.by_rec(iii).ta2.p_adjrsquare_apm_all_recs(iii,1);
                    recording_ta3(1).day_P_vs_other_params(iii,6) = ta2_analysis.by_rec(iii).ta2.p_adjrsquare_area_all_recs(iii,1);
                    recording_ta3(1).day_P_vs_other_params(iii,7) = ta2_analysis.by_rec(iii).ta2.p_adjrsquare_eps_all_recs(iii,1);
                    recording_ta3(1).day_P_vs_other_params(iii,8) = ta2_analysis.by_rec(iii).ta2.p_adjrsquare_rhythm_all_recs(iii,1);
                    if pval_contr(iii,1)> ta2_analysis.by_rec(iii).ta2.p_adjrsquare_amplitude_all_recs(iii,1)
                        recording_ta3(1).significant.amplitudes(a).rec=iii;
                        recording_ta3(1).significant.amplitudes(a).stats = ta2_analysis.by_rec(iii).ta2.amplitude_vs_distbin_stats;
                        recording_ta3(1).significant.amplitudes(a).mult_means = ta2_analysis.by_rec(iii).ta2.amplitude_vs_distbin_stats.mult_means;
                        a=a+1;
                    end
                    if pval_contr(iii,1)> ta2_analysis.by_rec(iii).ta2.p_adjrsquare_area_all_recs(iii,1)
                        recording_ta3(1).significant.area(b).rec=iii;
                        recording_ta3(1).significant.area(b).stats = ta2_analysis.by_rec(iii).ta2.area_vs_distbin_stats;
                        recording_ta3(1).significant.area(b).mult_means = ta2_analysis.by_rec(iii).ta2.area_vs_distbin_stats.mult_means;
                        b=b+1;
                    end
                    if pval_contr(iii,1)> ta2_analysis.by_rec(iii).ta2.p_adjrsquare_eps_all_recs(iii,1)
                        recording_ta3(1).significant.eps(c).rec=iii;
                        recording_ta3(1).significant.eps(c).stats = ta2_analysis.by_rec(iii).ta2.eps_vs_distbin_stats;
                        recording_ta3(1).significant.eps(c).mult_means = ta2_analysis.by_rec(iii).ta2.eps_vs_distbin_stats.mult_means;
                        c=c+1;
                    end
                    if pval_contr(iii,1)> ta2_analysis.by_rec(iii).ta2.p_adjrsquare_apm_all_recs(iii,1)
                        recording_ta3(1).significant.apm(d).rec=iii;
                        recording_ta3(1).significant.apm(d).stats = ta2_analysis.by_rec(iii).ta2.act_per_min_vs_distbin_stats;
                        recording_ta3(1).significant.apm(d).mult_means = ta2_analysis.by_rec(iii).ta2.act_per_min_vs_distbin_stats.mult_means;
                        d=d+1;
                    end
                    if pval_contr(iii,1)> ta2_analysis.by_rec(iii).ta2.p_adjrsquare_rhythm_all_recs(iii,1)
                        recording_ta3(1).significant.rhythm(e).rec=iii;
                        recording_ta3(1).significant.rhythm(e).stats = ta2_analysis.by_rec(iii).ta2.rhythm_vs_distbin_stats;
                        recording_ta3(1).significant.rhythm(e).mult_means = ta2_analysis.by_rec(iii).ta2.rhythm_vs_distbin_stats.mult_means;
                        e=e+1;
                    end
                else
                    recording_ta3(1).day_P_vs_tum_siz_squm(iii,3) =  recording_ta3(1).day_P_vs_tum_siz_squm(iii-1,3);
                    recording_ta3(1).day_P_vs_other_params(iii,3) = recording_ta3(1).day_P_vs_other_params(iii-1,3);
                    recording_ta3(1).day_P_vs_other_params(iii,4) = ta2_analysis.by_rec(iii).ta2.p_adjrsquare_amplitude_all_recs(iii,1);
                    recording_ta3(1).day_P_vs_other_params(iii,5) = ta2_analysis.by_rec(iii).ta2.p_adjrsquare_apm_all_recs(iii,1);
                    recording_ta3(1).day_P_vs_other_params(iii,6) = ta2_analysis.by_rec(iii).ta2.p_adjrsquare_area_all_recs(iii,1);
                    recording_ta3(1).day_P_vs_other_params(iii,7) = ta2_analysis.by_rec(iii).ta2.p_adjrsquare_eps_all_recs(iii,1);
                    recording_ta3(1).day_P_vs_other_params(iii,8) = ta2_analysis.by_rec(iii).ta2.p_adjrsquare_rhythm_all_recs(iii,1);
                    if pval_contr(iii,1)>ta2_analysis.by_rec(iii).ta2.p_adjrsquare_amplitude_all_recs(iii,1)
                        recording_ta3(1).significant.amplitudes(a).rec=iii;
                        recording_ta3(1).significant.amplitudes(a).stats = ta2_analysis.by_rec(iii).ta2.amplitude_vs_distbin_stats;
                        recording_ta3(1).significant.amplitudes(a).mult_means = ta2_analysis.by_rec(iii).ta2.amplitude_vs_distbin_stats.mult_means;
                        a=a+1;
                    end
                    if pval_contr(iii,1)>ta2_analysis.by_rec(iii).ta2.p_adjrsquare_area_all_recs(iii,1)
                        recording_ta3(1).significant.area(b).rec=iii;
                        recording_ta3(1).significant.area(b).stats = ta2_analysis.by_rec(iii).ta2.area_vs_distbin_stats;
                        recording_ta3(1).significant.area(b).mult_means = ta2_analysis.by_rec(iii).ta2.area_vs_distbin_stats.mult_means;
                        b=b+1;
                    end
                    if pval_contr(iii,1)>ta2_analysis.by_rec(iii).ta2.p_adjrsquare_eps_all_recs(iii,1)
                        recording_ta3(1).significant.eps(c).rec=iii;
                        recording_ta3(1).significant.eps(c).stats = ta2_analysis.by_rec(iii).ta2.eps_vs_distbin_stats;
                        recording_ta3(1).significant.eps(c).mult_means = ta2_analysis.by_rec(iii).ta2.eps_vs_distbin_stats.mult_means;
                        c=c+1;
                    end
                    if pval_contr(iii,1)>ta2_analysis.by_rec(iii).ta2.p_adjrsquare_apm_all_recs(iii,1)
                        recording_ta3(1).significant.apm(d).rec=iii;
                        recording_ta3(1).significant.apm(d).stats = ta2_analysis.by_rec(iii).ta2.act_per_min_vs_distbin_stats;
                        recording_ta3(1).significant.apm(d).mult_means = ta2_analysis.by_rec(iii).ta2.act_per_min_vs_distbin_stats.mult_means;
                        d=d+1;
                    end
                    if pval_contr(iii,1)>ta2_analysis.by_rec(iii).ta2.p_adjrsquare_rhythm_all_recs(iii,1)
                        recording_ta3(1).significant.rhythm(e).rec=iii;
                        recording_ta3(1).significant.rhythm(e).stats = ta2_analysis.by_rec(iii).ta2.rhythm_vs_distbin_stats;
                        recording_ta3(1).significant.rhythm(e).mult_means = ta2_analysis.by_rec(iii).ta2.rhythm_vs_distbin_stats.mult_means;
                        e=e+1;
                    end
                end
            end
        end
    end
end

recording_ta3(1).pval_contr = pval_contr;

endend = size(recording_ta3(1).FOV_stats.tafov_apm_all,1);
a=1;
b=1;
recording_ta3(1).FOV_stats.dunn.apm_x = 0;
recording_ta3(1).FOV_stats.dunn.eps_x = 0;
recording_ta3(1).FOV_stats.dunn.length_x = 0;
recording_ta3(1).FOV_stats.dunn.amp_x = 0;
recording_ta3(1).FOV_stats.dunn.area_x = 0;
recording_ta3(1).FOV_stats.dunn.IEI_x = 0;
recording_ta3(1).FOV_stats.dunn.rhythm_x = 0;
clear g g_add
for iii = 1:size(subfolders,2)
    if isempty(recording(iii).no_spont_act)
        recording_ta3(1).FOV_stats.tafov_apm_all(maxroi(iii,1)+1:endend,iii) = NaN;
        recording_ta3(1).FOV_stats.tafov_eps_all(maxroi(iii,1)+1:endend,iii) = NaN;
        recording_ta3(1).FOV_stats.tafov_length_all(maxroi(iii,1)+1:endend,iii) = NaN;
        recording_ta3(1).FOV_stats.tafov_amp_all(maxroi(iii,1)+1:endend,iii) = NaN;
        recording_ta3(1).FOV_stats.tafov_area_all(maxroi(iii,1)+1:endend,iii) = NaN;
        recording_ta3(1).FOV_stats.tafov_IEI_all(maxroi(iii,1)+1:endend,iii) = NaN;
        recording_ta3(1).FOV_stats.tafov_rhythm_all(maxroi(iii,1)+1:endend,iii) = NaN;
        
      
        
        recording_ta3(1).FOV_stats.dunn.apm_x(1,a:a+maxroi(iii,1)-1)   = recording_ta3(1).FOV_stats.tafov_apm_all(1:maxroi(iii,1),iii);
        recording_ta3(1).FOV_stats.dunn.eps_x(1,a:a+maxroi(iii,1)-1)   = recording_ta3(1).FOV_stats.tafov_eps_all(1:maxroi(iii,1),iii);
        recording_ta3(1).FOV_stats.dunn.length_x(1,a:a+maxroi(iii,1)-1)   = recording_ta3(1).FOV_stats.tafov_length_all(1:maxroi(iii,1),iii);
        recording_ta3(1).FOV_stats.dunn.amp_x(1,a:a+maxroi(iii,1)-1)   = recording_ta3(1).FOV_stats.tafov_amp_all(1:maxroi(iii,1),iii);
        recording_ta3(1).FOV_stats.dunn.area_x(1,a:a+maxroi(iii,1)-1)   = recording_ta3(1).FOV_stats.tafov_area_all(1:maxroi(iii,1),iii);
        recording_ta3(1).FOV_stats.dunn.IEI_x(1,a:a+maxroi(iii,1)-1)   = recording_ta3(1).FOV_stats.tafov_IEI_all(1:maxroi(iii,1),iii);
        recording_ta3(1).FOV_stats.dunn.rhythm_x(1,a:a+maxroi(iii,1)-1)   = recording_ta3(1).FOV_stats.tafov_rhythm_all(1:maxroi(iii,1),iii);
        if b==1
            g_add = ones(1,maxroi(iii,1));
        else
            g_add = repmat(b,1,maxroi(iii,1));
        end
        g(1,a:a+maxroi(iii,1)-1) = g_add;
        a=a+maxroi(iii,1);
        b=b+1
    else
          recording_ta3(1).FOV_stats.tafov_apm_all(:,iii) = NaN;
        recording_ta3(1).FOV_stats.tafov_eps_all(:,iii) = NaN;
        recording_ta3(1).FOV_stats.tafov_length_all(:,iii) = NaN;
        recording_ta3(1).FOV_stats.tafov_amp_all(:,iii) = NaN;
        recording_ta3(1).FOV_stats.tafov_area_all(:,iii) = NaN;
        recording_ta3(1).FOV_stats.tafov_IEI_all(:,iii) = NaN;
        recording_ta3(1).FOV_stats.tafov_rhythm_all(:,iii) = NaN;
    end
end

cd(Folder_master)
close all
[p1,t1,stats1] = kruskalwallis(recording_ta3(1).FOV_stats.tafov_apm_all);
saveas(2,['boxplot_kruskalwallis_FOV_stats_apm_all' '.png'], 'png');
[comparison,means,H,gnames1] = multcompare(stats1);
recording_ta3(1).FOV_stats.apm.anova_p = p1;
recording_ta3(1).FOV_stats.apm.anova_tab = t1;
recording_ta3(1).FOV_stats.apm.mult_comparison = comparison;
recording_ta3(1).FOV_stats.apm.mult_means = means;
recording_ta3(1).FOV_stats.apm.stats1 = stats1;
saveas(H,['FOV_stats_apm_multcomp' '.png'], 'png')

close all
[p1,t1,stats1] = kruskalwallis(recording_ta3(1).FOV_stats.tafov_eps_all);
saveas(2,['boxplot_kruskalwallis_FOV_stats_eps_all' '.png'], 'png');
[comparison,means,H,gnames1] = multcompare(stats1);
recording_ta3(1).FOV_stats.eps.anova_p = p1;
recording_ta3(1).FOV_stats.eps.anova_tab = t1;
recording_ta3(1).FOV_stats.eps.mult_comparison = comparison;
recording_ta3(1).FOV_stats.eps.mult_means = means;
recording_ta3(1).FOV_stats.eps.stats1 = stats1;
saveas(H,['FOV_stats_eps_multcomp' '.png'], 'png')

close all
[p1,t1,stats1] = kruskalwallis(recording_ta3(1).FOV_stats.tafov_length_all);
saveas(2,['boxplot_kruskalwallis_FOV_stats_length_all' '.png'], 'png');
[comparison,means,H,gnames1] = multcompare(stats1);
recording_ta3(1).FOV_stats.length.anova_p = p1;
recording_ta3(1).FOV_stats.length.anova_tab = t1;
recording_ta3(1).FOV_stats.length.mult_comparison = comparison;
recording_ta3(1).FOV_stats.length.mult_means = means;
recording_ta3(1).FOV_stats.length.stats1 = stats1;
saveas(H,['FOV_stats_length_multcomp' '.png'], 'png')

close all
[p1,t1,stats1] = kruskalwallis(recording_ta3(1).FOV_stats.tafov_amp_all);
saveas(2,['boxplot_kruskalwallis_FOV_stats_amp_all' '.png'], 'png');
[comparison,means,H,gnames1] = multcompare(stats1);
recording_ta3(1).FOV_stats.amp.anova_p = p1;
recording_ta3(1).FOV_stats.amp.anova_tab = t1;
recording_ta3(1).FOV_stats.amp.mult_comparison = comparison;
recording_ta3(1).FOV_stats.amp.mult_means = means;
recording_ta3(1).FOV_stats.amp.stats1 = stats1;
saveas(H,['FOV_stats_amp_multcomp' '.png'], 'png')

[p1,t1,stats1] = kruskalwallis(recording_ta3(1).FOV_stats.tafov_area_all);
saveas(2,['boxplot_kruskalwallis_FOV_stats_area_all' '.png'], 'png');
[comparison,means,H,gnames1] = multcompare(stats1);
recording_ta3(1).FOV_stats.area.anova_p = p1;
recording_ta3(1).FOV_stats.area.anova_tab = t1;
recording_ta3(1).FOV_stats.area.mult_comparison = comparison;
recording_ta3(1).FOV_stats.area.mult_means = means;
recording_ta3(1).FOV_stats.area.stats1 = stats1;
saveas(H,['FOV_stats_area_multcomp' '.png'], 'png')

close all
[p1,t1,stats1] = kruskalwallis(recording_ta3(1).FOV_stats.tafov_IEI_all);
saveas(2,['boxplot_kruskalwallis_FOV_stats_IEI_all' '.png'], 'png');
[comparison,means,H,gnames1] = multcompare(stats1);
recording_ta3(1).FOV_stats.IEI.anova_p = p1;
recording_ta3(1).FOV_stats.IEI.anova_tab = t1;
recording_ta3(1).FOV_stats.IEI.mult_comparison = comparison;
recording_ta3(1).FOV_stats.IEI.mult_means = means;
recording_ta3(1).FOV_stats.IEI.stats1 = stats1;
saveas(H,['FOV_stats_IEI_multcomp' '.png'], 'png')

close all
[p1,t1,stats1] = kruskalwallis(recording_ta3(1).FOV_stats.tafov_rhythm_all);
saveas(2,['boxplot_kruskalwallis_FOV_stats_rhythm_all' '.png'], 'png');
[comparison,means,H,gnames1] = multcompare(stats1);
recording_ta3(1).FOV_stats.rhythm.anova_p = p1;
recording_ta3(1).FOV_stats.rhythm.anova_tab = t1;
recording_ta3(1).FOV_stats.rhythm.mult_comparison = comparison;
recording_ta3(1).FOV_stats.rhythm.mult_means = means;
recording_ta3(1).FOV_stats.rhythm.stats1 = stats1;
saveas(H,['FOV_stats_rhythm_multcomp' '.png'], 'png')

recording_ta3(1).day_P_vs_tum_siz_squm_nonans = recording_ta3(1).day_P_vs_tum_siz_squm;
o=1;
todelm=[];
for a = 1:size(recording_ta3(1).day_P_vs_tum_siz_squm,1)
    if isnan(recording_ta3(1).day_P_vs_tum_siz_squm(a,3))
        todelm(o,1)=a;
        o=o+1
    end
end
recording_ta3(1).day_P_vs_tum_siz_squm_nonans(todelm,:) = [];

figure(445)
plot(recording_ta3(1).day_P_vs_tum_siz_squm_nonans(:,1),recording_ta3(1).day_P_vs_tum_siz_squm_nonans(:,3))

%fit a spline on the growth rate and associated parameters that I want to
%correlate
[curve, goodness, output] = fit(recording_ta3(1).day_P_vs_tum_siz_squm_nonans(:,1),...
    recording_ta3(1).day_P_vs_tum_siz_squm_nonans(:,3),'smoothingspline');
plot(curve,recording_ta3(1).day_P_vs_tum_siz_squm_nonans(:,1),recording_ta3(1).day_P_vs_tum_siz_squm_nonans(:,3));
recording_ta3(1).day_P_vs_tum_growthrate_slinefit.curve=curve;
recording_ta3(1).day_P_vs_tum_growthrate_slinefit.goodness=goodness;
recording_ta3(1).day_P_vs_tum_growthrate_slinefit.output=output;

if ~isfield(recording(1).ta2,'p_adjrsquare_apm_all_recs_f_p')
    load('workspace_new.mat', 'p_adjrsquare_SNR_all_recs')
    load('workspace_new.mat', 'p_adjrsquare_apm_all_recs')
    load('workspace_new.mat', 'p_adjrsquare_eps_all_recs')
    load('workspace_new.mat', 'p_adjrsquare_amplitude_all_recs')
    load('workspace_new.mat', 'p_adjrsquare_area_all_recs')
    load('workspace_new.mat', 'p_adjrsquare_rhythm_all_recs')
    a=1;
    clear p_adjrsquare_SNR_all_recs_f_p p_adjrsquare_apm_all_recs_f_p p_adjrsquare_eps_all_recs_f_p...
        p_adjrsquare_amplitude_all_recs_f_p p_adjrsquare_area_all_recs_f_p p_adjrsquare_rhythm_all_recs_f_p...
        day_P_f_p
    for s = 1:size(day_P,2)
        if isnan(p_adjrsquare_SNR_all_recs(s,1))
        else
            day_P_f_p(a,1) = day_P(1,s);
            p_adjrsquare_SNR_all_recs_f_p(a,1) = p_adjrsquare_SNR_all_recs(s,1);
            p_adjrsquare_apm_all_recs_f_p(a,1) = p_adjrsquare_apm_all_recs(s,1);
            p_adjrsquare_eps_all_recs_f_p(a,1) = p_adjrsquare_eps_all_recs(s,1);
            p_adjrsquare_amplitude_all_recs_f_p(a,1) = p_adjrsquare_amplitude_all_recs(s,1);
            p_adjrsquare_area_all_recs_f_p(a,1) = p_adjrsquare_area_all_recs(s,1);
            p_adjrsquare_rhythm_all_recs_f_p(a,1) = p_adjrsquare_rhythm_all_recs(s,1);
            a=a+1;
        end
    end
    recording(1).ta2.day_P_f_p = day_P_f_p;
    recording(1).ta2.p_adjrsquare_SNR_all_recs_f_p = p_adjrsquare_SNR_all_recs_f_p;
    recording(1).ta2.p_adjrsquare_apm_all_recs_f_p = p_adjrsquare_apm_all_recs_f_p;
    recording(1).ta2.p_adjrsquare_eps_all_recs_f_p = p_adjrsquare_eps_all_recs_f_p;
    recording(1).ta2.p_adjrsquare_amplitude_all_recs_f_p = p_adjrsquare_amplitude_all_recs_f_p;
    recording(1).ta2.p_adjrsquare_area_all_recs_f_p = p_adjrsquare_area_all_recs_f_p;
    recording(1).ta2.p_adjrsquare_rhythm_all_recs_f_p = p_adjrsquare_rhythm_all_recs_f_p;
end

dpfp = day_P_f_p %ta2_analysis.overall_ta2_stats.day_P_f_p;
pa =  recording(1).ta2.p_adjrsquare_apm_all_recs_f_p % ta2_analysis.overall_ta2_stats.p_adjrsquare_apm_all_recs_f_p;
[curve, goodness, output] = fit(dpfp,pa,'smoothingspline');
plot(curve,dpfp,pa);
recording_ta3(1).day_P_vs_apm_slinefit.curve=curve;
recording_ta3(1).day_P_vs_apm_slinefit.goodness=goodness;
recording_ta3(1).day_P_vs_apm_slinefit.output=output;

pa =  recording(1).ta2.p_adjrsquare_eps_all_recs_f_p;
[curve, goodness, output] = fit(dpfp,pa,'smoothingspline');
plot(curve,dpfp,pa);
recording_ta3(1).day_P_vs_eps_slinefit.curve=curve;
recording_ta3(1).day_P_vs_eps_slinefit.goodness=goodness;
recording_ta3(1).day_P_vs_eps_slinefit.output=output;

close all
pa =  recording(1).ta2.p_adjrsquare_amplitude_all_recs_f_p;
[curve, goodness, output] = fit(dpfp,pa,'smoothingspline');
plot(curve,dpfp,pa);
recording_ta3(1).day_P_vs_amplitude_slinefit.curve=curve;
recording_ta3(1).day_P_vs_amplitude_slinefit.goodness=goodness;
recording_ta3(1).day_P_vs_amplitude_slinefit.output=output;

pa =  recording(1).ta2.p_adjrsquare_area_all_recs_f_p;
[curve, goodness, output] = fit(dpfp,pa,'smoothingspline');
plot(curve,dpfp,pa);
recording_ta3(1).day_P_vs_area_slinefit.curve=curve;
recording_ta3(1).day_P_vs_area_slinefit.goodness=goodness;
recording_ta3(1).day_P_vs_area_slinefit.output=output;

close all
pa =  recording(1).ta2.p_adjrsquare_rhythm_all_recs_f_p;
[curve, goodness, output] = fit(dpfp,pa,'smoothingspline');
plot(curve,dpfp,pa);
recording_ta3(1).day_P_vs_rhythm_slinefit.curve=curve;
recording_ta3(1).day_P_vs_rhythm_slinefit.goodness=goodness;
recording_ta3(1).day_P_vs_rhythm_slinefit.output=output;

cd(Folder_master)
save recording_ta3_new.mat recording_ta3



