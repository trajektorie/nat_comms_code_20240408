
clear all

%%%%%%%%%%%%%%%%%%%%%% set initial experiment parameters %%%%%%%%%%% These
%%%%%%%%%%%%%%%%%%%%%% must be valid for every imaging session of this FOV!

% no motion correction?
nocorr=0
numrec = %

%%%
add_params.last_frame = zeros(1,numrec) %[0,0];
add_params.vid_cam_trig_winedr = ones (1,numrec) % [1,1];

datedr = ones (1,numrec) %[1,1,1,1,1];
avg_2_fr = zeros(1,numrec) %[0,0,0,0,0];
csv_or_winedr = ones (1,numrec) %[0,1,1,1,1];
spiral_scan = zeros(1,numrec) %[0,0,0,0,0];
use_red_channel = zeros(1,numrec) %[0,0,0,0,0];
no_imaging = zeros(1,numrec) %[0,0,0,0,0];
write_DF_tif = 1;
%%%
batch_proc = 1;
fr_tr_PV = 0;
onep = 1;
resonant_interlaced = 0;
xml_files_okay = 1;
indicator = 'GCaMP6s';
NB208 = 1;
no_patch_or_patch = 1;

PC_or_linux = 1;
num_rec = length(avg_2_fr);
tif_or_txt = 1;
h5_or_tif = zeros(1,numrec) % [0,0,0,0,0];
Sergey_scan_sc_p_fr = zeros(1,numrec) % [0,0,0,0,0];
[initial] = set_parameters_mac(avg_2_fr,spiral_scan,0,csv_or_winedr,no_patch_or_patch,tif_or_txt,0,0,0,0,0,0,0,0,0,...
    0,0,0,0,indicator,0,NB208,no_imaging,use_red_channel,PC_or_linux,num_rec,datedr,h5_or_tif,Sergey_scan_sc_p_fr);
%%%%%%%%%%%%%%%%%%%%

%Here goes the master folder that contains all imaging sessions

Folder_master = '...\';

cd(Folder_master)

%identify subfolders
folders = dir(Folder_master);   % fullfile(Folder_master,['*.',filetype]));
a=1;
clear subfolders
if batch_proc
    for i = 1:size(folders,1)
        if onep ==0
            if length(folders(i).name) == 25
                subfolders(a).name = folders(i).name;
                a=a+1;
            end
        else
            if length(folders(i).name) < 3
            else
                subfolders(a).name = folders(i).name;
                a=a+1;
            end
        end
    end
else
    subfolders(1).name = folders(3).name;
end
dropped_frames = zeros(1,size(subfolders,2));

%pre-process each subfolder separately first
prompt = {'use vvar file (1) or not (0) ?'};
dlg_title = '1 for vvar, 0 for no';
num_lines = 1;
def = {'0'};
answer = inputdlg(prompt,dlg_title,num_lines,def);
rdz = str2mat(answer);
rdz = str2num(rdz);

if rdz
    %optional for very large datasets
    java.lang.System.setProperty('VVARFOLDER', 'T:\VVAR\')
    vvar.deleteFile();
    %optional for very large datasets
    %x=vvar(memmap)
    vvar.createFile(1e9*899, false)
end

for i = 1:length(subfolders)
    prompt = {'analyzing all (0), first half (1) or second half (2)?'};
    dlg_title = '0 for all, 1 for first half';
    num_lines = 1;
    def = {'0'};
    answer = inputdlg(prompt,dlg_title,num_lines,def);
    answer = str2mat(answer);
    a_h(i).a_h = str2num(answer);
end

batch_sec_f_detrending = 600;
save_masked_g_bak = 1;
save_all_flaggs = 0
onep_binned_twice = ones (1,numrec)
rec_xml = 1;
cam_st_man = zeros(1,numrec)
cam15Hz = zeros(1,numrec)
rerunning_onep_results_2 = 0;
reintegrating = 0

%pre-processing loop with some optional analysis approaches (based on CNMF
%decomposition of teh mesoscopic signal)
for iii = 1:length(subfolders)
    Folder = subfolders(iii).name;
    cd(Folder_master)
    cd(Folder)

    %%%%%%%%%%%%%%%%%%%% load microscope xml file, information of image files %%%%%%%%
    if initial.PC_or_linux == 0
        [initial,xml_file,Folder] = StackLoad_JM_for_PC_1_linux(initial,xml_files_okay,Folder);
    else
        [initial,xml_file,Folder] = StackLoad_JM_for_PC_1_11_28_18(iii,initial,xml_files_okay,Folder,onep,rec_xml,reintegrating);
    end

    % make sure first and last frame of pco and video cam were captured in
    % PV trace, otherwise add the winedr trace.

    plot(initial.rawData2,'DisplayName','initial.rawData2')
    initial.indicator = indicator;
    recording(iii).initial = initial;
    rec_EKG = 0;
    if rec_EKG
        %%%%read winedr file
    end

    %%%%%%%%%%%%%%%%%%%%% initial x-y motion correction algorithm
    saveasonetif = 1;
    saveastentiffs = 0;
    if initial.use_red_channel(1,iii)
        red_bad = 0;
    else
        red_bad = 1;
    end
    initial.h5_already_created(1,iii) = 0;

    %remove window_light.tif from initial.stack_Ch2!!!

    if initial.PC_or_linux == 0
        [initial] = fast_motion_correction_linux_120118(initial,Folder,nocorr,resonant_interlaced,saveastentiffs,...
            a_h(iii).a_h,red_bad,rdz,Folder_master,saveasonetif);
    else
        [initial1] = fast_motion_correction__PC_100518(iii,initial,Folder,nocorr,resonant_interlaced,saveastentiffs,...
            a_h(iii).a_h,red_bad,rdz,Folder_master,saveasonetif,1,1);
    end
    close all
    cd(Folder_master)
    if save_all_flaggs
        save workspace.mat -v7.3
    end
    cd(Folder)

    %%%%%%%%%%%%%%% load analog voltage input data %%%%%%%%%%%%%%%%%%%%%
    spof=1
    galvo_trace_recorded_all_frame_times =0;
    last_frame = 0;
    if galvo_trace_recorded_all_frame_times
    else
        if onep
            if reintegrating
                %import masked_g_bak and rename!
                last_frame = size(masked_g,3);
            else
                for i = 1:size(initial.Stack_ch2,1)
                    info = imfinfo(initial.Stack_ch2(i,1).name);
                    frs = size(info,1);
                    last_frame = last_frame + frs
                end
            end
            %last_frame =
        end
    end

    [initial2,results] = StackLoad_JM_for_PC_2(iii,initial,Folder,xml_file,spof,initial.avg_2_fr,fr_tr_PV,onep,last_frame);
    %%%%%%%%%%%%%%%%%
    recording(iii).initial2 = initial2;
    recording(iii).initial = initial;
    if onep
        if onep_binned_twice(1,iii)
            initial2.microns_per_pixel = 18.367;
        else
            initial2.microns_per_pixel = 9.2;
        end
    end

    %crop, align, downsample images, remove vasculature
    %%%%%%select ROI of active FOV area
    %imageJ: global contrast adjustment, CLAHE, watershed
    cd(Folder_master)
    cd(Folder)

    mydlg = warndlg('save as "vessel_watershed_bluelight_4x4.tif"', 'make blood vessel mask');
    waitfor(mydlg);
    disp('Tank you!');
    uyt =  imread ('vessel_watershed_bluelight_4x4.tif');
    imtool(uyt)
    options.WindowStyle = 'normal';
    prompt = {'crop coordinates (x1,y1,x2,y2)?'};
    dlg_title = 'raw crop coordinates';
    num_lines = 1;
    def = {'0'};
    answer = inputdlg(prompt,dlg_title,num_lines,def,options);
    rd = str2mat(answer);
    rd = str2num(rd);
    pause % on
    close all
    crop(1,1:2) = rd(1,1:2);
    crop(1,3:4) = rd(1,3:4) - rd(1,1:2);
    options.WindowStyle = 'normal';
    prompt = {'lambda coordinates (x,y)?'};
    dlg_title = 'lambda coordinates';
    num_lines = 1;
    def = {'0'};
    answer = inputdlg(prompt,dlg_title,num_lines,def,options);
    rd = str2mat(answer);
    lambda = str2num(rd);
    pause % on
    close all
    %crop = [33.5 47.5 460 323];
    %lambda = [255, 78];
    lambda_crop(1,1) = lambda(1,1) - crop(1,1);
    lambda_crop(1,2) = lambda(1,2) - crop(1,2);
    uyt(uyt>0) = 1;
    tic
    if rdz == 0
        masked_g = bsxfun(@times, initial1.g, cast(uyt, class(initial1.g)));
    else

        uyt=uint16(uyt);
        clear tempmask
        for oi = 1: size(initial1.g,3)
            oi
            tempmask = uint16(initial1.g(:,:,oi));
            tempmask = tempmask.*uyt;
            initial1.g(:,:,oi) = tempmask; % tmasked_g(:,:,oi).*iyt;
        end
    end
    toc
    if rdz==1
        imagesc(initial1.g(:,:,32))
        clear masked_g_bak
        sim1 = round(size(initial1.g,1)/2)
        sim2 = round(size(initial1.g,2)/2)
        sim3 = size(initial1.g,3)
        masked_g_bak = uint16(zeros(sim1,sim2,sim3));
        for yi = 1:size(initial1.g,3)
            yi
            masked_g_bak(:,:,yi) = imresize(initial1.g(:,:,yi), 0.5, 'nearest');
        end
        %bin masked_g again
        if save_masked_g_bak
            save masked_g_bak.mat masked_g_bak -v7.3
        end
        initial2.microns_per_pixel = initial2.microns_per_pixel*2;
        recording(iii).initial2.microns_per_pixel = initial2.microns_per_pixel;
        close all
        filetype = 'mat'; % type of files to be processed
        % complete pipeline for calcium imaging data pre-processing
        %clear;
        addpath(genpath('..\NoRMCorre-master'));               % add the NoRMCorre motion correction package to MATLAB path
        gcp;                                            % start a parallel engine
        foldername = strcat(Folder_master,Folder); % 'F:\stargazer\stg-N1131\11-20-18\';
        % folder where all the files are located.
        % Types currently supported .tif/.tiff, .h5/.hdf5, .raw, .avi, and .mat files
        clear files
        files(1).name = [foldername,'\masked_g.tif'];
        files(1).folder = foldername;
        %files = subdir(fullfile(foldername,['*.',filetype]));   % list of filenames (will search all subdirectories)
        FOV = [size(masked_g_bak,1) size(masked_g_bak,2)];% size(masked_g,3)]; %size(read_file(files(1).name,1,1));
        numFiles = length(files);
        %% motion correct (and save registered h5 files as 2d matrices (to be used in the end)..)
        % register files one by one. use template obtained from file n to
        % initialize template of file n + 1;
        motion_correct = true;                            % perform motion correction
        non_rigid = true;                                 % flag for non-rigid motion correction
        output_type = 'h5';                               % format to save registered files
        if non_rigid; append = '_nr'; else; append = '_rig'; end        % use this to save motion corrected files
        options_mc = NoRMCorreSetParms('d1',FOV(1),'d2',FOV(2),'grid_size',[128,128],'init_batch',200,...
            'overlap_pre',32,'mot_uf',4,'bin_width',200,'max_shift',24,'max_dev',8,'us_fac',50,...
            'output_type',output_type);
        template = [];
        col_shift = [];
        for i = 1:1%numFiles
            fullname = files(i).name;
            [folder_name,file_name,ext] = fileparts(fullname);
            output_filename = fullfile(folder_name,[file_name,append,'.',output_type]);
            options_mc = NoRMCorreSetParms(options_mc,'output_filename',output_filename,'h5_filename','','tiff_filename',''); % update output file name
            if motion_correct
                [M,shifts,template,options_mc,col_shift] = normcorre_batch_even(masked_g_bak,options_mc,template);     %(fullname,options_mc,template);
                save(fullfile(folder_name,[file_name,'_shifts',append,'.mat']),'shifts','-v7.3');           % save shifts of each file at the respective folder
            else    % if files are already motion corrected convert them to h5
                convert_file(fullname,'h5',fullfile(folder_name,[file_name,'_mc.h5']));
            end
        end
    else
        masked_g = masked_g(round(crop(1,2)):round(crop(1,2))+round(crop(1,4)),...
            round(crop(1,1)):round(crop(1,1))+round(crop(1,3)),:);
        recording(iii).crop = crop;
        imagesc(masked_g(:,:,32))
        %bin masked_g again
        if save_masked_g_bak
            masked_g_bak = masked_g;
            save masked_g_bak.mat masked_g_bak -v7.3
        end
        masked_g_bak = 0;
        masked_g = imresize(masked_g, 0.5, 'nearest');
        initial2.microns_per_pixel = initial2.microns_per_pixel*2;
        recording(iii).initial2.microns_per_pixel = initial2.microns_per_pixel;
        imagesc(masked_g(:,:,32))
        close all
        filetype = 'mat'; % type of files to be processed
        % complete pipeline for calcium imaging data pre-processing
        %clear;
        addpath(genpath('..\NoRMCorre-master'));               % add the NoRMCorre motion correction package to MATLAB path
        gcp;                                            % start a parallel engine
        foldername = strcat(Folder_master,Folder); % 'F:\stargazer\stg-N1131\11-20-18\';
        % folder where all the files are located.
        % Types currently supported .tif/.tiff, .h5/.hdf5, .raw, .avi, and .mat files
        clear files
        files(1).name = [foldername,'\masked_g.tif'];
        files(1).folder = foldername;
        %files = subdir(fullfile(foldername,['*.',filetype]));   % list of filenames (will search all subdirectories)
        FOV = [size(masked_g,1) size(masked_g,2)];% size(masked_g,3)]; %size(read_file(files(1).name,1,1));
        numFiles = length(files);
        %% motion correct (and save registered h5 files as 2d matrices (to be used in the end)..)
        % register files one by one. use template obtained from file n to
        % initialize template of file n + 1;
        motion_correct = true;                            % perform motion correction
        non_rigid = true;                                 % flag for non-rigid motion correction
        output_type = 'h5';                               % format to save registered files
        if non_rigid; append = '_nr'; else; append = '_rig'; end        % use this to save motion corrected files
        options_mc = NoRMCorreSetParms('d1',FOV(1),'d2',FOV(2),'grid_size',[128,128],'init_batch',200,...
            'overlap_pre',32,'mot_uf',4,'bin_width',200,'max_shift',24,'max_dev',8,'us_fac',50,...
            'output_type',output_type);
        template = [];
        col_shift = [];
        for i = 1:1%numFiles
            fullname = files(i).name;
            [folder_name,file_name,ext] = fileparts(fullname);
            output_filename = fullfile(folder_name,[file_name,append,'.',output_type]);
            options_mc = NoRMCorreSetParms(options_mc,'output_filename',output_filename,'h5_filename','','tiff_filename',''); % update output file name

            if motion_correct
                [M,shifts,template,options_mc,col_shift] = normcorre_batch_even(masked_g,options_mc,template);     %(fullname,options_mc,template);
                save(fullfile(folder_name,[file_name,'_shifts',append,'.mat']),'shifts','-v7.3');           % save shifts of each file at the respective folder
            else    % if files are already motion corrected convert them to h5
                convert_file(fullname,'h5',fullfile(folder_name,[file_name,'_mc.h5']));
            end
        end
    end
    recording(iii).shifts = shifts;
    %% downsample h5 files and save into a single memory mapped matlab file
    if motion_correct
        registered_files = subdir(fullfile(foldername,['*',append,'*','.',output_type]));  % list of registered files (modify this to list all the motion corrected files you need to process)
    else
        registered_files = subdir(fullfile(foldername,'*_mc.h5'));
    end
    fr = recording(iii).initial2.samplingratehz;                                         % frame rate
    tsub = round(fr/3);                                        % degree of downsampling (for 30Hz imaging rate you can try also larger, e.g. 8-10)
    %FOV = [size(masked_g_bak,1) size(masked_g_bak,2)];% size(masked_g,3)]; %size(read_file(files(1).name,1,1));
    ds_filename = [foldername,'\ds_data.mat'];
    data_type = class(read_file(registered_files(1).name,1,1));
    data = matfile(ds_filename,'Writable',true);
    data.Y  = zeros([FOV,0],data_type);
    data.Yr = zeros([prod(FOV),0],data_type);
    data.sizY = [FOV,0];
    F_dark = Inf;                                    % dark fluorescence (min of all data)
    batch_size = 2000;                               % read chunks of that size
    if onep==0
        if fr>10
            tsub = 4
        else
            tsub = 1;
        end
    end
    %          tsub = round(size(initial1.g,3)/data.sizY(1,3))
    batch_size = round(batch_size/tsub)*tsub;        % make sure batch_size is divisble by tsub
    Ts = zeros(numFiles,1);                          % store length of each file
    cnt = 0;                                         % number of frames processed so far
    tt1 = tic;
    for i = 1:1 %numFiles
        name = registered_files(i).name;
        info = h5info(name);
        dims = info.Datasets.Dataspace.Size;
        ndimsY = length(dims);                       % number of dimensions (data array might be already reshaped)
        Ts(i) = dims(end);
        Ysub = zeros(FOV(1),FOV(2),floor(Ts(i)/tsub),data_type);
        data.Y(FOV(1),FOV(2),sum(floor(Ts/tsub))) = zeros(1,data_type);
        data.Yr(prod(FOV),sum(floor(Ts/tsub))) = zeros(1,data_type);
        cnt_sub = 0;
        for t = 1:batch_size:Ts(i)
            Y = read_file(name,t,min(batch_size,Ts(i)-t+1));
            F_dark = min(nanmin(Y(:)),F_dark);
            ln = size(Y,ndimsY);
            Y = reshape(Y,[FOV,ln]);
            Y = cast(downsample_data(Y,'time',tsub),data_type);
            ln = size(Y,3);
            Ysub(:,:,cnt_sub+1:cnt_sub+ln) = Y;
            cnt_sub = cnt_sub + ln;
        end
        data.Y(:,:,cnt+1:cnt+cnt_sub) = Ysub;
        data.Yr(:,cnt+1:cnt+cnt_sub) = reshape(Ysub,[],cnt_sub);
        toc(tt1);
        cnt = cnt + cnt_sub;
        data.sizY(1,3) = size(data.Y,3); %data.sizY(1,3) = cnt;
    end
    data.F_dark = F_dark;
    Ysub = 0;
    %% now run CNMF on patches on the downsampled file, set parameters first
    masked_g = 0;
    sizY = data.sizY;                       % size of data matrix
    patch_size = [60,60];                   % size of each patch along each dimension (optional, default: [32,32]) was 60
    overlap = [8,8];                        % amount of overlap in each dimension (optional, default: [4,4]) was 8
    patches = construct_patches(sizY(1:end-1),patch_size,overlap);
    K = 11;                                            % number of components to be found was 7
    tau = round((6000/initial2.microns_per_pixel)/2);     % std of gaussian kernel (half size of neuron)
    p = 2;                                            % order of autoregressive system (p = 0 no dynamics, p=1 just decay, p = 2, both rise and decay)
    merge_thr = 0.85;                                  % merging threshold
    if onep
        max_size = round(10300000/(initial2.microns_per_pixel^2));
    else
        max_size = round(13000/(initial2.microns_per_pixel^2));
    end
    min_size = round(12000/(initial2.microns_per_pixel^2));
    options = CNMFSetParms(...
        'd1',sizY(1),'d2',sizY(2),...
        'deconv_method','constrained_foopsi',...    % neural activity deconvolution method
        'p',p,...                                   % order of calcium dynamics
        'ssub',ssub,...                                % spatial downsampling when processing
        'tsub',tsub,...                                % further temporal downsampling when processing
        'merge_thr',merge_thr,...                   % merging threshold
        'gSig',tau,...
        'max_size_thr',max_size,'min_size_thr',min_size,...    % max/min acceptable size for each component
        'spatial_method','regularized',...          % method for updating spatial components
        'df_prctile',20,...                         % take the median of background fluorescence to compute baseline fluorescence
        'fr',fr/tsub,...                            % downsamples
        'space_thresh',0.2,...                     % space correlation acceptance threshold
        'min_SNR',1.3,...                           % trace SNR acceptance threshold
        'cnn_thr',0.2,...                           % cnn classifier acceptance threshold
        'nb',1,...                                  % number of background components per patch
        'gnb',3,...                                 % number of global background components
        'decay_time',1.6,...                         % length of typical transient for the indicator used
        'refine_flag',true,...
        'df_window',round(data.sizY(1,3)*0.3)...
        );
    options.onep = onep;
    options.this_one_serial = 1;
    options.add_params=add_params;
    options.iii=iii;
    options.min_fitness = log(normcdf(-options.min_SNR))*options.N_samples_exc
    %% Run on patches (the main work is done here)
    [A,b,C,f,S,P,RESULTS,YrA] = run_CNMF_patches(data,K,patches,tau,0,options,FOV); %  (data.Y,K,patches,tau,0,options);  % do not perform deconvolution here since
    % we are operating on downsampled data
    %in case of spiral scan: remove spatial components that are in corners or middle
    %% compute correlation image on a small sample of the data (optional - for visualization purposes)
    Cn = correlation_image_max(data,4);
    %% classify components
    rval_space = classify_comp_corr(data,A,C,b,f,options);
    ind_corr = rval_space > options.space_thresh;           % components that pass the correlation test
    % this test will keep processes

    %% further classification with cnn_classifier
    ran_cnn=0
    ind_cnn = true(size(A,2),1);                        % components that pass the CNN classifier
    %% event exceptionality
    fitness = compute_event_exceptionality(C+YrA,options.N_samples_exc,options.robust_std);
    ind_exc = (fitness < options.min_fitness*0.5)
    %% select components
    close all
    Coor = plot_contours(A,Cn,options,1);
    close;
    clear ROIz matrixpix ind_spiral pix
    %%%%%%%%%
    for i = 1:size(A,2)
        ROIz = i
        pix = Coor{i,1};
        if isempty(pix)
            ind_spiral(i,1) = true;
        else
            a=1;
            for j = 1:size(pix,2)
                matrixpix(ROIz).pix(a,1) = (pix(1,j)-1)*recording(iii).initial.height + pix(2,j);
                a = a+1;
            end
            if recording(iii).initial.spiral_scan(1,iii)
                if isempty(intersect(matrixpix(ROIz).pix,initial1.blackpix))
                    ind_spiral(i,1) = true;
                else
                    ind_spiral(i,1) = false;
                end
            else
                ind_spiral(i,1) = true;
            end
            if size(matrixpix(ROIz).pix,1) < min_size || size(matrixpix(ROIz).pix,1) > max_size
                ind_spiral(i,1) = false;
            end
        end
    end
    keep = (ind_corr | ind_cnn) & ind_exc & ind_spiral;
    sum_keep = sum(keep)
    %save workspace_bef_ROIGUI.mat -v7.3
    %% run GUI for modifying component selection (optional, close twice to save values)
    run_GUI = false;
    if run_GUI
        Coor = plot_contours(A,Cn,options,1); close;
        GUIout = ROI_GUI(data.Y,A,P,options,Cn,C,b,f);
        options = GUIout{2};
        keep = GUIout{3};
    end
    %% view contour plots of selected and rejected components (optional)
    throw = ~keep;
    Coor_k = [];
    Coor_t = [];
    figure(909);
    ax1 = subplot(121); plot_contours(A(:,keep),Cn,options,0,[],Coor_k,[],1,find(keep)); title('Selected components','fontweight','bold','fontsize',14);
    ax2 = subplot(122); plot_contours(A(:,throw),Cn,options,0,[],Coor_t,[],1,find(throw));title('Rejected components','fontweight','bold','fontsize',14);
    linkaxes([ax1,ax2],'xy')
    saveas (909,['sel_vs_rej_components'  '.png' ],'png')
    %% keep only the active components
    options.add_params.last_frame(iii) = 0;
    options.iii = iii;
    A_keep = A(:,keep);
    C_keep = C(keep,:);
    %% extract residual signals for each trace
    if exist('YrA','var')
        R_keep = YrA(keep,:);
    else
        R_keep = compute_residuals(data,A_keep,b,C_keep,f);
    end
    %% extract fluorescence on native temporal resolution
    options.this_one_serial = 1;                    %set to 0 if parallel CPU pool available
    options.fr = options.fr*tsub;                   % revert to origingal frame rate
    N = size(C_keep,1);                             % total number of components
    T = sum(Ts);                                    % total number of timesteps
    C_full = imresize(C_keep,[N,T]);                % upsample to original frame rate
    R_full = imresize(R_keep,[N,T]);                % upsample to original frame rate
    F_full = C_full + R_full;                       % full fluorescence
    f_full = imresize(f,[size(f,1),T]);             % upsample temporal background
    S_full = zeros(N,T);
    P.p = 0;
    ind_T = [0;cumsum(Ts(:))];
    options.nb = options.gnb;
    options.onep = 1;
    for i = 1:numFiles
        inds = ind_T(i)+1:ind_T(i+1);   % indeces of file i to be updated
        [C_full(:,inds),f_full(:,inds),~,~,R_full(:,inds)] = update_temporal_components_fast(registered_files(i).name,A_keep,b,C_full(:,inds),f_full(:,inds),P,options,FOV);
        disp(['Extracting raw fluorescence at native frame rate. File ',num2str(i),' out of ',num2str(numFiles),' finished processing.'])
    end
    [F_dff,F0] = detrend_df_f(A_keep,[b,ones(prod(FOV),1)],C_full,[f_full;-double(F_dark)*ones(1,T)],R_full,options);
    F_dff = full(F_dff);
    C_dec = zeros(N,T);         % deconvolved DF/F traces
    S_dec = zeros(N,T);         % deconvolved neural activity
    bl = zeros(N,1);            % baseline for each trace (should be close to zero since traces are DF/F)
    neuron_sn = zeros(N,1);     % noise level at each trace
    g = cell(N,1);              % discrete time constants for each trace
    if p == 1; model_ar = 'ar1'; elseif p == 2; model_ar = 'ar2'; else; error('This order of dynamics is not supported'); end
    model_ar='exp2';
    for i = 1:N
        spkmin = options.spk_SNR*GetSn(F_dff(i,:));
        lam = choose_lambda(exp(-1/(options.fr*options.decay_time)),GetSn(F_dff(i,:)),options.lam_pr);
        [cc,spk,opts_oasis] = deconvolveCa(F_dff(i,:),model_ar,'method','foopsi','optimize_pars',true,'maxIter',20,...
            'window',150,'lambda',lam,'smin',spkmin);
        bl(i) = opts_oasis.b;
        C_dec(i,:) = cc(:)' + bl(i);
        S_dec(i,:) = spk(:);
        neuron_sn(i) = opts_oasis.sn;
        g{i} = opts_oasis.pars(:)';
        disp(['Performing deconvolution. Trace ',num2str(i),' out of ',num2str(N),' finished processing.'])
    end
    recording(iii).neuron_sn = neuron_sn;
    recording(iii).neuron_baseline = bl;
    recording(iii).neuron_timeconstant = g;
    %optional: make a df/f movie and write as tif file
    if write_DF_tif
        fr = recording(iii).initial2.samplingratehz;                                         % frame rate
        tsub = 1;                                        % degree of downsampling (for 30Hz imaging rate you can try also larger, e.g. 8-10)
        ds_filename = [foldername,'\ds_data.mat'];
        data_type = class(read_file(registered_files(1).name,1,1));
        DYall = zeros([FOV,0],'double');
        F_dark = Inf;                                    % dark fluorescence (min of all data)
        batch_size = round(fr*batch_sec_f_detrending); %2000;                               % read chunks of that size
        batch_size = round(batch_size/tsub)*tsub;        % make sure batch_size is divisble by tsub
        Ts = zeros(numFiles,1);                          % store length of each file
        cnt = 0;                                         % number of frames processed so far
        tt1 = tic;
        for i = 1:1%numFiles
            name = registered_files(i).name;
            info = h5info(name);
            dims = info.Datasets.Dataspace.Size;
            ndimsY = length(dims);                       % number of dimensions (data array might be already reshaped)
            Ts(i) = dims(end);
            DYall = zeros([FOV,Ts(i)],'double');
            cnt_sub = 0;
            gh=1;
            for t = 1:batch_size:Ts(i)
                batch_read = t
                clear Y YSmooth dw Y7p Y9p Y5p Y579m y5p y5pp dw
                Y = read_file(name,t,min(batch_size,Ts(i)-t+1));
                sigma = 1;
                YSmooth = imgaussfilt3(Y, sigma);
                Y = YSmooth;
                Y7p = double(prctile(Y,7,3));
                Y9p = double(prctile(Y,9,3));
                Y5p = double(prctile(Y,5,3));
                Y579m = (Y5p+Y7p+Y9p)/3;
                y5p = reshape(Y579m,[],1);
                if onep
                    y5pp = prctile(y5p,45);
                else
                    y5pp = prctile(y5p,25);
                end
                dw = double(Y579m); %double(median(Y,3));
                dw(dw<y5pp) = 16000;
                Y = double(Y);
                DY = double(zeros(FOV(1),FOV(2),min(batch_size,Ts(i)-t+1)));
                DY = double(bsxfun(@rdivide, Y, dw)); % double(Y/med_Y);
                ln = size(Y,3);
                cnt_sub = cnt_sub + ln;
                DYall(:,:,gh:gh+ln-1) = DY;
                gh=gh+ln
            end
            toc(tt1);
            cnt = cnt + cnt_sub;
            data_temp.sizY(1,3) = cnt;
        end
        DYall(DYall>10) = 10;
        DYall = DYall*1600;

        DYall = uint16(DYall);
        h5create('normcorred_DF.h5','/DS1',size(DYall))
        mydata = rand(10,20);
        h5write('normcorred_DF.h5', '/DS1', DYall)
        recording(iii).DYall = DYall;
        clear DYall
    end
    recording(iii).C_dec = C_dec;
    recording(iii).S_dec = S_dec;
    recording(iii).F_dff = F_dff;
    recording(iii).F0 = F0;
    recording(iii).C_full = C_full;
    recording(iii).R_full = R_full;
    recording(iii).F_full = F_full;
    recording(iii).A_keep = A_keep;
    recording(iii).options = options;
    recording(iii).Coor = Coor;
    recording(iii).Cn = Cn;
    recording(iii).options_mc = options_mc;
    recording(iii).template = template;
    recording(iii).results.cat_signal = recording(iii).C_dec';

    %now run align_EEG on the matched ROIs across recordings:
    NB208_aft16 = 1; % set this to 1 if your EEG is in the 7th column of the imported .csv file (in general, if you have a second EEG channel,...
    %it has to be in teh next column, regardless where the first channel is.
    %Otherwise you have to reshape the matrix with teh analog inputs first.
    stimcell_interp_to_Vm = 0; % set to 1 if you have patch data
    add_params.man = 0; %add additional parameters manually
    add_params.e2ch = 1;
    add_params.um = 1; %used microscope?
    add_params.DF_o_Fi = 0; %DF+oopsi or Filtmat?
    recording(iii).initial.date = initial2.date;
    recording(iii).initial2.NB208_aft_16 = 1;
    NB208_aft16 = 1;
    stimcell_interp_to_Vm = 0;
    add_params.e2ch = 1;
    add_params.DF_o_Fi = 0;
    add_params.um = 1;
    add_params.man = 0;

    close all
    %%%%%%%%%%%%%%%%%%%%%% align EEG trace with image data
    matrix = recording(iii).F_dff'; %this is the DF/F matrix you want to align with the EEG
    deconv = recording(iii).S_dec'; %this is the deconvolved matrix you want to align with teh EEG
    imaged = 1; %set this to 0 if you don't have any imaging data
    if imaged==0
        matrix=0
        deconv=0
        recording(iii).results.cat_signal=0;
    end

    %if patched:
    recording(iii).initial.PD_only = 1; % change this to 0 if you have patching data
    [EEG_results_nonoise] = align_EEG_PC_2_20221107(Folder,recording(iii).initial,matrix,recording(iii).results,...
        deconv,imaged,0,NB208_aft16,stimcell_interp_to_Vm,recording(iii).initial2,add_params,onep,0,Folder_master,recording(iii).F_full);
    recording(iii).EEG_results_nonoise = EEG_results_nonoise;

    save_initial1_g_tiff = 0;
    split_first_df_second = 0;

    if save_initial1_g_tiff == 0
        DYall = 0;
        DY=0;
        save initial1.mat initial1 -v7.3
        initial1.g = 0;
    end

    freq = 100
    stopped_cam_bef_pv = 0;
    % folder where all the files are located.
    filetype = 'h5'; % type of files to be processed
    % Types currently supported .tif/.tiff, .h5/.hdf5, .raw, .avi, and .mat files
    %cd(Folder_master)
    files = dir(['*nr.',filetype]);   % list of filenames (will search all subdirectories)

    write_tiffs = 0;
    detrend_sec = 30;
    if strcmp(initial.indicator,'iGluSnfr')
        detrend_sec=300
    end

    [t,DYall] = make_DF_tiffs_05222020(onep,subfolders,files,Folder_master,recording,motion_correct,output_type,append,...
        batch_sec_f_detrending,recording(iii).initial2,write_tiffs,iii,detrend_sec);

    save DYall.mat DYall -v7.3

    %cd(Folder)
    load('cmap_19.mat')
    %if running for the first time
    DF_mouse_EEG_videor.cam_interp = 0;
    DF_mouse_EEG_videor.DF_interp = 0;
    %else, if DYall not present anymore:
    recording(iii).DYall=DYall;
    DYall = 0;
    recording(iii).t = t;
    madfad = t(1).maxfac;
    save t.mat t -v7.3
    t=0;
    tyr=length(recording(iii).DYall);
    ranfra = randi(tyr,10);
    ranf = reshape(ranfra,[1,100]);
    ranY = recording(iii).DYall(:,:,ranf(1,:));
    ranm = mean(ranY,3);
    a=1;
    for i = 1:size(ranm,1)
        for j = 1:size(ranm,2)
            if ranm(i,j)>0
                fgr(1,a) = ranm(i,j);
                a=a+1;
            end
        end
    end
    maxf = prctile(fgr,98) %max(fgr);
    minf = prctile(fgr,2)
    DF_clims =  [minf*0.5 maxf*7]
    beg_sec = 575
    end_sec = 610
    close all
    only_vid_length = 1;
    memmapped=0;
    [DF_mouse_EEG_video] = make_DF_mouse_EEG_video_09122020(recording(iii).initial2,Folder_master,Folder,iii,beg_sec,end_sec,...
        recording(iii).initial,stopped_cam_bef_pv,freq,recording(iii).EEG_results_nonoise,DF_clims,recording(iii).DYall,...
        DF_mouse_EEG_videor,cmap_19,onep,only_vid_length,memmapped,cam15Hz,cam_st_man);

    save_normcorred_tiff = 0;
    save_initial1_g_tiff = 0;
    split_first_df_second = 0;
    use_roigui = 0;
    downsample_DF_movie_to_orig_Hz = 0
    rec=iii
    start_f_avg_plot = 200;
    end_f_avg_plot = 300;
    close all

    %%%% this part, down to line 981, is optional!
    %if you haven't run this before (or if you need to rerun it)
    Folder = subfolders(iii).name;
    foldername = strcat(Folder_master,Folder); % 'F:\stargazer\stg-N1131\11-20-18\';
    cd(Folder_master)
    cd(Folder)
    onep_results_2.cat_signal = 0;
    onep_results_2.RL.ROI_info = 0;
    if rerunning_onep_results_2
        load('DF_mouse_EEG_video.mat')
        load('t.mat')
        madfad = t(1).maxfac;
    end
    %%%%%%
    recording(iii).initial1 = initial1;
    cat_signal_nans_to_zeros = 1;
    [onep_results_2] = rerun_ROI_sel_manualey (freq,onep,iii,Folder,Folder_master,recording(iii).initial2,save_normcorred_tiff,...
        save_initial1_g_tiff, recording(iii).initial1,...
        split_first_df_second,use_roigui,recording(iii).EEG_results_nonoise,DF_mouse_EEG_video,downsample_DF_movie_to_orig_Hz,...
        foldername,recording(iii).initial,cmap_19,...
        start_f_avg_plot,end_f_avg_plot,onep_results_2,madfad,cat_signal_nans_to_zeros);
    recording(iii).onep_results_2 = onep_results_2;
    recording(iii).t = 0;
    %denoise these ca-signals
    std_level = 1;
    just_oopsi_binedges = 1;
    [DF_sq_right_no_noise,activity_per_min_DF_sq_right,DF_sq_left_no_noise,activity_per_min_DF_sq_left,noisedata] = ...
        denoise(recording(iii).initial,recording(iii).onep_results_2.DF_sq_right,recording(iii).onep_results_2.DF_sq_left,std_level,...
        recording(iii).initial2,just_oopsi_binedges);
    recording(iii).onep_results_2.DF_sq_right_no_noise = DF_sq_right_no_noise;
    recording(iii).onep_results_2.activity_per_min_DF_sq_right = activity_per_min_DF_sq_right;
    recording(iii).onep_results_2.DF_sq_left_no_noise = DF_sq_left_no_noise;
    recording(iii).onep_results_2.activity_per_min_DF_sq_left = activity_per_min_DF_sq_left;
    recording(iii).onep_results_2.noisedata = noisedata;
    close all
    load('cmap_19.mat')
    meandf_left = mean(recording(iii).onep_results_2.DF_sq_left,1);
    meanmeanl = mean(meandf_left);
    meandf_right = mean(recording(iii).onep_results_2.DF_sq_right,1);
    meanmeanr = mean(meandf_right);
    if strcmp(recording(iii).initial.indicator,'iGluSnfr')
        dsr = recording(iii).onep_results_2.DF_sq_right - meandf_right;
        dsl = recording(iii).onep_results_2.DF_sq_left - meandf_left;
    else
        dsr = recording(iii).onep_results_2.DF_sq_right;
        dsl = recording(iii).onep_results_2.DF_sq_left;
    end
    std_left = std(dsl,0,1);
    std_right = std(dsr,0,1);
    meanstdl = mean(std_left);
    meanstdr = mean(std_right);
    meanmeanall = (meanmeanl+meanmeanr)/2;
    meanstdall= (meanstdl+meanstdr)/2;
    lowlim = meanmeanall - (2*meanstdall);
    highlim = meanmeanall + (2*meanstdall);
    clims = [lowlim highlim];
    figure(8909)
    subplot(4,1,1)
    imagesc(dsr',clims)
    set(gcf,'Colormap',cmap_19)
    colorbar
    subplot(4,1,2)
    plot(recording(iii).EEG_results_nonoise.EEG_2_extrap)
    subplot(4,1,3)
    imagesc(dsl',clims)
    set(gcf,'Colormap',cmap_19)
    colorbar
    subplot(4,1,4)
    plot(recording(iii).EEG_results_nonoise.EEG_extrap)
    %OR
    meandf_left = mean(recording(iii).onep_results_2.DF_sq_left_no_noise,1);
    meanmeanl = mean(meandf_left);
    meandf_right = mean(recording(iii).onep_results_2.DF_sq_right_no_noise,1);
    meanmeanr = mean(meandf_right);
    std_left = std(recording(iii).onep_results_2.DF_sq_left_no_noise,0,1);
    std_right = std(recording(iii).onep_results_2.DF_sq_right_no_noise,0,1);
    meanstdl = mean(std_left);
    meanstdr = mean(std_right);
    meanmeanall = (meanmeanl+meanmeanr)/2;
    meanstdall= (meanstdl+meanstdr)/2;
    lowlim = meanmeanall - (2*meanstdall);
    highlim = meanmeanall + (2*meanstdall);
    clims = [lowlim highlim];
    figure(8906)
    subplot(4,1,1)
    imagesc(recording(iii).onep_results_2.DF_sq_right_no_noise',clims)
    set(gcf,'Colormap',cmap_19)
    colorbar
    subplot(4,1,2)
    plot(EEG_results_nonoise.EEG_2_extrap)
    subplot(4,1,3)
    imagesc(recording(iii).onep_results_2.DF_sq_left_no_noise',clims)
    set(gcf,'Colormap',cmap_19)
    colorbar
    subplot(4,1,4)
    plot(EEG_results_nonoise.EEG_extrap)

    cd(Folder)
    save DF_mouse_EEG_video.mat DF_mouse_EEG_video -v7.3

    DYall = 0;
    initial1.g = 0;
    DF_mouse_EEG_video = 0;

    %save workspace.mat -v7.3

    load('deconv_cmap.mat')

    %run some basic ca-activity analysi
    this_one_serial = 0
    if initial.no_imaging(1,iii) || initial.datedr(1,iii)==0
    else
        rec = iii
        i2 = recording(iii).initial2;
        fr = 100; %set to 0 if analyzing non-interpolated matrix!
        curr_mat = real(recording(iii).onep_results_2.DF_sq_right_no_noise);
        clear ca_stats
        [ca_stats] = basic_ca_stats_f_epilepsy(Folder,i2,curr_mat,fr,onep,FOV,this_one_serial);
        recording(iii).ca_stats_right = ca_stats;
        curr_mat = real(recording(iii).onep_results_2.DF_sq_left_no_noise);
        clear ca_stats
        [ca_stats] = basic_ca_stats_f_epilepsy(Folder,i2,curr_mat,fr,onep,FOV,this_one_serial);
        recording(iii).ca_stats_left = ca_stats;
    end
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    %%%%%%%%%%%%%%%compute spectra of EEGs here
    analyzing_rec = iii
    freq = 1000;
    fs = recording(iii).initial2.sampl_fr;
    waver = recording(iii).EEG_results_nonoise.EEG';
    waver2 = recording(iii).EEG_results_nonoise.EEG_2';
    EEG_extrap_1000 = zeros(1,round(length(waver)/(fs/freq)));
    EEG_2_extrap_1000  = zeros(1,round(length(waver2)/(fs/freq)));
    for ii = 1: size(EEG_2_extrap_1000,2)
        EEG_2_extrap_1000(1,ii) = waver2(1,round((ii-1)*fs/freq)+1);
    end
    for ii = 1: size(EEG_extrap_1000,2)
        EEG_extrap_1000(1,ii) = waver(1,round((ii-1)*fs/freq)+1);
    end
    All_EEGs(iii).EEG_extrap_1000 = EEG_extrap_1000;
    All_EEGs(iii).EEG_2_extrap_1000 = EEG_2_extrap_1000;

    % In teh following loop matlab will re-reference the EEG by subtracting the
    % contralateral channel from teh ipsilateral channel.

    prompt = {'reference ispi to contra (1) or contra to ipsi (0) ?'};
    dlg_title = '1 if yes, 0 if no';
    num_lines = 1;
    def = {'1'};
    answe = inputdlg(prompt,dlg_title,num_lines,def);
    answe = str2mat(answe);
    answe = str2num(answe);

    curreeg=iii
    if length(All_EEGs(iii).EEG_2_extrap_1000) < 10000
        All_EEGs(iii).too_short = 1;
    else
        All_EEGs(iii).too_short = 0;
    end
    if isempty(All_EEGs(iii).EEG_2_extrap_1000)==0
        if answe
            aeg = All_EEGs(iii).EEG_extrap_1000;
            aeg2 = All_EEGs(iii).EEG_2_extrap_1000;
        else
            aeg = All_EEGs(iii).EEG_2_extrap_1000;
            aeg2 = All_EEGs(iii).EEG_extrap_1000;
        end
        All_EEGs(iii).aegminaeg2 = aeg-aeg2;
        figure(iii)
        plot(All_EEGs(iii).aegminaeg2)
    end

    close all

    %If you want you can now reorder the  EEGs inside the All_EEGs structure to put them in chromological order!
    % Next, it will identify all high-frequency artifacts (40-400 Hz) and
    % remove those from the recording and calculate the power spectra for teh
    % whole recording for each EEG. It also calculates low-frequency (7-12 Hz)
    % to identify potential seizures or interictal spikes.

    close all
    prompt = {'use re-referenced (0) or contra (1) or ipsi (2) or both contra and ipsi (3) or all three (4) for analysis ?'};
    dlg_title = 'which channel for analysis?';
    num_lines = 1;
    def = {'0'};
    answe = inputdlg(prompt,dlg_title,num_lines,def);
    answe = str2mat(answe);
    answe = str2num(answe);
    switch (answe)
        case 0
            reref_con_ips = 0;
        case 1
            reref_con_ips = 1;
        case 2
            reref_con_ips = 2;
        case 3
            reref_con_ips = 3;
        case 4
            reref_con_ips = 4;
    end
    add_params.first_frame = zeros(1,num_rec)

    preprocess_EEGs_onerec

    close all
    %cd(Folder)
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %here: look at recs 2, 4, 5, 6, 7, 8, 9 (or 10)
    % now add wheel, whisk and vis stim
    wheel_added_to_winedr = 0;
    tds=0
    cam_fr = 30;
    wheel_thr = 0.043;
    [wheel_new] = wheel_analysis_81516(recording(iii).initial,Folder,cam_fr,tds,wheel_thr,100,0,recording(iii).initial2,...
        wheel_added_to_winedr,iii,onep,recording(iii).initial2.mirror_start_time(1,1));
    recording(iii).wheel_new = wheel_new;
    wheel_new = 0;
    cd(Folder_master)
    close all
    i2 = recording(iii).initial2;
    %pause
    cd(Folder)
    %run this in most cases to integrate winedr trace into rawData2
    winedrpresent(1,iii) = 0
    use_PD_f_align = ones(1,size(subfolders,2));

    integrate_winedr_data_into_rawData2

    matrix = onep_results_2.DF_sq_right;
    cam_fr = 30;
    imaged = 1;
    %cd(Folder_master)
    recording(iii).initial2.no_imaging = recording(iii).initial.no_imaging;
    recording(iii).initial2.heka_or_winedr = recording(iii).initial.heka_or_winedr;
    cd(Folder_master)

    [whisking] = whisk_analysis(Folder,i2,cam_fr,matrix,cam_st_man,imaged,onep,...
        recording(iii).initial2.mirror_start_time(1,1),recording(iii).initial2.sampl_fr,iii,cam15Hz,0,recording(iii).initial2,dropped_frames,recording);
    recording(iii).whisking = whisking;
    whisking = 0;
    close all
    Y=0;
    recording(iii).DYall = 0;
    cd(Folder_master)
    save workspace.mat -v7.3
end

%% optional, if seizures and/or other EEG abnormalities need to be analyzed
% run seiz distances etc

for iii = 1:size(subfolders,2)
    Folder = subfolders(iii).name;
    cd(Folder_master)
    cd(Folder)
    extra_time = 0;   %extra seconds in case EEG started recording before image scanning
    sfreq = 100;   % downsampled frequency
    if isfield(All_EEGs(iii),'segments')
        clear seizure_onsets_in_ms_new seizure_lengths_in_ms_new
        for ji = 1:size(All_EEGs(iii).segments,2 )
            seizure_onsets_in_ms_new(ji,1) = All_EEGs(iii).segments(ji).begseg;
            seizure_lengths_in_ms_new(ji,1) = All_EEGs(iii).segments(ji).endseg - seizure_onsets_in_ms_new(ji,1);
        end
        seizure_onsets_in_ms_new = seizure_onsets_in_ms_new';
        seizure_lengths_in_ms_new = seizure_lengths_in_ms_new';
        difftmp = diff(seizure_onsets_in_ms_new);
        plot(difftmp)
        %%%%%%%%%%%%%%%%%%%%%
        %%%%%%%%%%%%% take out seizures that were <1.5 sec long and <6 sec apart, and those with
        %large motion artifacts
        %initial.no_imaging = 0;
        min_isi_ms = 2000;
        min_length_ms = 200;
        sf=0
        offs_thr = 200;
        recording(iii).initial2.offsets = recording(iii).initial1.offsets;
        one_p_no_motioncorr = 1;
        [tds_offs_out_thr_200] = cons_seizures(seizure_lengths_in_ms_new,seizure_onsets_in_ms_new,recording(iii).initial,...
            Folder,min_isi_ms,min_length_ms,sf,offs_thr,recording(iii).initial2,one_p_no_motioncorr);
        %%%%%%%%%%%%%%%%
        recording(iii).tds = tds_offs_out_thr_200;
    else
        load('TMPREJ.mat')
        if ~isempty(tmprej)
            seizure_onsets_in_ms_new = tmprej(:,1);
            seizure_lengths_in_ms_new = tmprej(:,2) - seizure_onsets_in_ms_new;
            seizure_onsets_in_ms_new = seizure_onsets_in_ms_new'*1000/sfreq-extra_time*1000;
            seizure_lengths_in_ms_new = seizure_lengths_in_ms_new'*1000/sfreq;
            difftmp = diff(tmprej(:,1));
            plot(difftmp)
            %%%%%%%%%%%%%%%%%%%%%
            %%%%%%%%%%%%% take out seizures that were <1.5 sec long and <6 sec apart, and those with
            %large motion artifacts
            %initial.no_imaging = 0;
            min_isi_ms = 2000;
            min_length_ms = 200;
            sf=0
            offs_thr = 200;
            if isfield(recording(iii).initial1,'offsets')
            recording(iii).initial2.offsets = recording(iii).initial1.offsets;
            end
            one_p_no_motioncorr = 1;
            [tds_offs_out_thr_200] = cons_seizures(seizure_lengths_in_ms_new,seizure_onsets_in_ms_new,recording(iii).initial,...
                Folder,min_isi_ms,min_length_ms,sf,offs_thr,recording(iii).initial2,one_p_no_motioncorr);
            %%%%%%%%%%%%%%%%
            recording(iii).tds = tds_offs_out_thr_200;
        end
    end
    [seiz_dists_offs_out_thr_200_nonoise] = seiz_distances (recording(iii).tds,recording(iii).initial,...
        recording(iii).EEG_results_nonoise,recording(iii).initial2);
        recording(iii).seiz_dists_offs_out_thr_200_nonoise = seiz_dists_offs_out_thr_200_nonoise;
end
%%%%%%%%%%%%%%%%%%%%%%%%%%


extract_vis_stim__process__1P

tumor_growth_rate

fig5_analysis

fig5_distance_ratios

figure5_barplots


