
clear all
%%%%%%%%%%%%%%%%%%%%%%%%%%

%optional for very large datasets
java.lang.System.setProperty('VVARFOLDER', 'P:\VVAR\')
vvar.deleteFile();
vvar.createFile(1e9*255, false)

%%%%%%%%%%%%%%%%%%%%%% set initial experiment parameters %%%%%%%%%%% These
%%%%%%%%%%%%%%%%%%%%%% must be valid for every imaging session of this FOV!

% run motion correction?
num_rec = 1;
nocorr = zeros(1,num_rec);   % (0 = with correction, 1 = without)

%%%
avg_2_fr  = 0; %zeros(1,num_rec); %
Sergey_scan_sc_p_fr = 0;%zeros(1,num_rec); % [0,0,0,0,0,0,0,0,0,0,0,0];
h5_or_tif = ones(1,num_rec); % [0,0,0,0,0,0,0,0,0,0,0,0];
csv_or_winedr = ones(1,num_rec);
spiral_scan = 1; %[0,0,0,0,0,0,1,0,0,0] ; %zeros(1,num_rec);
use_red_channel = 0;% [1,0,1,1,1,0,1,1,1,1];
datedr = ones(1,num_rec);
no_imaging = zeros(1,num_rec);
add_params.first_frame = zeros(1,num_rec);
cam_st_man = ones(1,num_rec);
cam15Hz = zeros(1,num_rec);
add_params.last_frame = zeros(1,num_rec);
add_params.day_P = [xxxx]
add_params.days_of_TeT = [];
add_params.days_of_BSA = [];
%%%
rerun_ROI_list = 1
batch_proc = 1;
fr_tr_PV = 1;
onep = 0;
resonant_interlaced = 0;
xml_files_okay = 1;
indicator = 'GCaMP6s';
NB208 = 1;
no_patch_or_patch = 1;
wd = 25
if no_patch_or_patch==0
    wd = 31;
end
PC_or_linux = 1;

[initial] = set_parameters_mac(avg_2_fr,spiral_scan,0,csv_or_winedr,no_patch_or_patch,1,0,0,0,0,0,0,0,0,0,...
    0,0,0,0,indicator,0,NB208,no_imaging,use_red_channel,PC_or_linux,num_rec,datedr,h5_or_tif,Sergey_scan_sc_p_fr);
%%%%%%%%%%%%%%%%%%%%

%Here goes the master folder that contains all imaging sessions
Folder_master = 'xxxxx\';
cd(Folder_master)
%identify subfolders
folders = dir(Folder_master);
a=1;
for i = 1:size(folders,1)
    if length(folders(i).name) == wd
        subfolders(a).name = folders(i).name;
        a=a+1;
    end
end
%pre-process each subfolder separately first
prompt = {'use vvar file (1) or not (0) ?'};
dlg_title = '1 for vvar, 0 for no';
num_lines = 1;
def = {'0'};
answer = inputdlg(prompt,dlg_title,num_lines,def);
rd = str2mat(answer);
rd = str2num(rd);
clear a_h
for i = 1:length(subfolders)
    prompt = {'analyzing all (0), first half (1) or second half (2)?'};
    dlg_title = '0 for all, 1 for first half';
    num_lines = 1;
    def = {'0'};
    answer = inputdlg(prompt,dlg_title,num_lines,def);
    answer = str2mat(answer);
    a_h(i).a_h = str2num(answer);
end
write_DF_tif = 1;
rec_xml = 1;
save_all_flaggs = 0;
save_only_flagg_7 = 1;
run_CNMF = 1;
no_GPU = 0
write_to_disk =1; %SAVE THE PRE-CORRECTED TIFFS AS ONE TIFF FILE ON THE hdd?
recording(1).initial.h5_already_created = zeros(1,num_rec)%
initial.h5_already_created = zeros(1,num_rec)%
motion_correct = true;                            % perform motion correction
saveasonetif = 1;
saveastentiffs = 0;
filetype = 'mat' %'mat'; %'mat'; % type of files to be processed
dropped_frames = [0,0,0,0,0]
add_NP_to_suite2p = 1
initial.swap_ch1_ch2 = 0;

for iii = 1:length(subfolders)
    Folder = subfolders(iii).name;
    cd(Folder_master)
    cd(Folder)
    %%%%%%%%%%%%%%%%%%%% load microscope xml file, information of image files %%%%%%%%
    if initial.PC_or_linux == 0
        [initial,xml_file,Folder] = StackLoad_JM_for_PC_1_linux(initial,xml_files_okay,Folder);
    else
        [initial,xml_file,Folder] = StackLoad_JM_for_PC_1_11_28_18_batch(iii,initial,xml_files_okay,...
            Folder,onep,rec_xml,0);
    end
    %%%%%%%%%%%%%%%%%%%%% initial x-y motion correction algorithm
    if initial.use_red_channel(1,iii)
        red_bad = 0;
    else
        red_bad = 1;
    end
    Sergey_no_repmat=0
    if initial.PC_or_linux == 0
        [initial] = fast_motion_correction_linux_120118(initial,Folder,nocorr(1,iii),resonant_interlaced,saveastentiffs,...
            a_h(iii).a_h,red_bad,rd,Folder_master,saveasonetif);
    else
        [initial1] = fast_motion_correction__PC_100518(iii,initial,Folder,nocorr,resonant_interlaced,saveastentiffs,...
            a_h(iii).a_h,red_bad,rd,Folder_master,saveasonetif,batch_proc,onep,write_to_disk,Sergey_no_repmat);
    end
    initial.height = initial1.height;
    initial.width = initial1.width;
    close all
    if save_all_flaggs
        cd(Folder_master)
        save workspace_all_recordings.mat -v7.3
        flagg = 1
        cd(Folder)
    end
    %%%%%%%%%%%%%%% load analog voltage input data %%%%%%%%%%%%%%%%%%%%%
    sf=0
    [initial2,results] = StackLoad_JM_for_PC_2(iii,initial,Folder,xml_file,sf,initial.avg_2_fr,fr_tr_PV,onep,0);
    %%%%%%%%%%%%%%%%%
    %initial.rawData2 = 0;
    recording(iii).initial2 = initial2;
    recording(iii).initial = initial;
    recording(iii).initial1 = initial1;
    if save_all_flaggs
        cd(Folder_master)
        save workspace_all_recordings.mat -v7.3
        flagg = 2
        cd(Folder)
    end
    cd(Folder_master)
    cd(Folder)
    if initial.no_imaging(1,iii)==0
        % complete pipeline for calcium imaging data pre-processing
        %clear;
        addpath(genpath('..\NoRMCorre-master'));               % add the NoRMCorre motion correction package to MATLAB path
        gcp;                                            % start a parallel engine
        foldername = strcat(Folder_master,Folder,'\motion_corrected\ch2'); % 'F:\stargazer\stg-N1131\11-20-18\';
        folder_name = foldername
        % folder where all the files are located.
        % Types currently supported .tif/.tiff, .h5/.hdf5, .raw, .avi, and .mat files
        if strcmp(filetype,'mat')
            numFiles = 1;
            if add_params.last_frame(1,iii)>0
                recording(iii).initial1.max_frame = add_params.last_frame(1,iii);
                recording(iii).initial.numberofframes = recording(iii).initial1.max_frame;
                recording(iii).initial.numerofframes = recording(iii).initial1.max_frame;
                recording(iii).initial.max_frame = recording(iii).initial1.max_frame;
                recording(iii).initial2.numberofframes = recording(iii).initial1.max_frame;
                recording(iii).initial2.numerofframes = recording(iii).initial1.max_frame;
                recording(iii).initial2.max_frame = recording(iii).initial1.max_frame;
                recording(iii).initial1.g(:,:,add_params.last_frame(1,iii)+1:size(recording(iii).initial1.g,3)) = [];
                if recording(iii).initial.use_red_channel(1,iii)
                    recording(iii).initial1.r(:,:,add_params.last_frame(1,iii)+1:size(recording(iii).initial1.r,3)) = [];
                end
            end
            if ~isfield(initial1,'g')
                FOV(1,1) = initial.height;
                FOV(1,2) = initial.width;
                recording(iii).FOV = FOV;
            else
                FOV = size(recording(iii).initial1.g);
                FOV = FOV(1,1:2);
            end
            mkdir('motion_corrected\ch2')
        else
            files = subdir(fullfile(foldername,['*.',filetype]));   % list of filenames (will search all subdirectories)
            FOV = size(read_file(files(1).name,1,1));
            numFiles = length(files);
        end
        recording(iii).FOV = FOV;
        recording(iii).initial.height = FOV(1,1);
        recording(iii).initial.width = FOV(1,2);
        %% motion correct (and save registered h5 files as 2d matrices (to be used in the end)..)
        % register files one by one. use template obtained from file n to
        % initialize template of file n + 1;
        % motion_correct = true;                            % perform motion correction
        non_rigid = true;                                 % flag for non-rigid motion correction
        output_type = 'h5';                               % format to save registered files
        %output_type = 'mat'
        if non_rigid; append = '_nr'; else; append = '_rig'; end        % use this to save motion corrected files
        options_mc = NoRMCorreSetParms('d1',FOV(1),'d2',FOV(2),'grid_size',[128,128],'init_batch',200,...
            'overlap_pre',32,'mot_uf',4,'bin_width',200,'max_shift',24,'max_dev',8,'us_fac',50,...
            'output_type',output_type,'mem_batch_size',100);
        template = [];
        col_shift = [];
        for i = 1:numFiles
            if strcmp(filetype,'mat')==0
                fullname = files(i).name;
                [folder_name,file_name,ext] = fileparts(fullname);
            else
                file_name = 'motion_corrected';
            end
            output_filename = fullfile(folder_name,[file_name,append,'.',output_type])
            options_mc = NoRMCorreSetParms(options_mc,'output_filename',output_filename,'h5_filename','','tiff_filename',''); % update output file name
            if motion_correct
                if strcmp(filetype,'mat')
                    [M,shifts,template,options_mc,col_shift] = normcorre_batch_even(recording(iii).initial1.g,options_mc,template); %(fullname,options_mc,template);
                else
                    [M,shifts,template,options_mc,col_shift] = normcorre_batch_even(fullname,options_mc,template);
                end
                save(fullfile(folder_name,[file_name,'_shifts',append,'.mat']),'shifts','-v7.3');           % save shifts of each file at the respective folder
            else    % if files are already motion corrected convert them to h5
                convert_file(fullname,'h5',fullfile(folder_name,[file_name,'_mc.h5']));
            end
        end
        %% downsample h5 files and save into a single memory mapped matlab file
        if motion_correct
            registered_files = subdir(fullfile(foldername,['*',append,'.',output_type]))  % list of registered files (modify this to list all the motion corrected files you need to process)
        else
            registered_files = subdir(fullfile(foldername,'*_nr*.h5'))
        end
        recording(iii).registered_files= registered_files;
        cd(Folder_master)
        cd(Folder)
        fr = recording(iii).initial2.samplingratehz;                                         % frame rate
        %tsub = 2;                                        % degree of downsampling (for 30Hz imaging rate you can try also larger, e.g. 8-10)
        if fr>10
            tsub = 3
        else
            tsub = 1;
        end
        if add_params.last_frame(1,iii)>0
            tsub=1;
        end
        ds_filename = [foldername,'\ds_data.mat'];
        if strcmp (output_type,'mat')
            data_type = 'uint16' %class(motion_corrected.Y)
        else
            data_type = class(read_file(registered_files(1).name,1,1));
        end
        data = matfile(ds_filename,'Writable',true);
        data.Y  = zeros([FOV,0],data_type);
        data.Yr = zeros([prod(FOV),0],data_type);
        data.sizY = [FOV,0];
        F_dark = Inf;                                    % dark fluorescence (min of all data)
        batch_size = 2000;                               % read chunks of that size
        batch_size = round(batch_size/tsub)*tsub;        % make sure batch_size is divisble by tsub
        Ts = zeros(numFiles,1);                          % store length of each file
        cnt = 0;                                         % number of frames processed so far
        tt1 = tic;
        recording(iii).FOV = FOV;
        clear Y
        if run_CNMF
            for i = 1:numFiles
                name = registered_files(i).name
                if strcmp(output_type,'h5')
                    info = h5info(name);
                    dims = info.Datasets.Dataspace.Size;
                else
                    dims(1,1:2) = FOV;
                    dims(1,3) = size(initial1.g,3);
                end
                ndimsY = length(dims);                       % number of dimensions (data array might be already reshaped)
                Ts(i) = dims(end);
                Ysub = zeros(FOV(1),FOV(2),floor(Ts(i)/tsub),data_type);
                data.Y(FOV(1),FOV(2),sum(floor(Ts/tsub))) = zeros(1,data_type);
                data.Yr(prod(FOV),sum(floor(Ts/tsub))) = zeros(1,data_type);
                cnt_sub = 0;
                if strcmp(output_type,'mat')
                    cd('motion_corrected/ch2')
                    load('motion_corrected.mat')
                    data.Y = Y;
                    data.Yr = Yr;
                    data.sizY(1,3) = size(data.Y,3);
                    Y=0;
                    Yr=0;
                else
                    for t = 1:batch_size:Ts(i)
                        Y = read_file(name,t,min(batch_size,Ts(i)-t+1));
                        F_dark = min(nanmin(Y(:)),F_dark);
                        ln = size(Y,ndimsY);
                        Y = reshape(Y,[FOV,ln]);
                        Y = cast(downsample_data(Y,'time',tsub),data_type);
                        ln = size(Y,3);
                        Ysub(:,:,cnt_sub+1:cnt_sub+ln) = Y;
                        cnt_sub = cnt_sub + ln;
                    end
                    data.Y(:,:,cnt+1:cnt+cnt_sub) = Ysub;
                    data.Yr(:,cnt+1:cnt+cnt_sub) = reshape(Ysub,[],cnt_sub);
                    toc(tt1);
                    cnt = cnt + cnt_sub;
                    data.sizY(1,3) = cnt;
                end
            end
            data.F_dark = F_dark;
            Ysub = 0;
            %% now run CNMF on patches on the downsampled file, set parameters first
            sizY = data.sizY;                       % size of data matrix
            recording(iii).data = data;
            p_s = round(100/initial2.microns_per_pixel);
            patch_size = [p_s,p_s];                   % size of each patch along each dimension (optional, default: [32,32])
            overlap = [4,4];                        % amount of overlap in each dimension (optional, default: [4,4])
            patches = construct_patches(sizY(1:end-1),patch_size,overlap);
            recording(iii).patches = patches;
            K = 7;                                            % number of components to be found
            tau = round((10/initial2.microns_per_pixel)/2);     % std of gaussian kernel (half size of neuron)
            p = 2;                                            % order of autoregressive system (p = 0 no dynamics, p=1 just decay, p = 2, both rise and decay)
            merge_thr = 0.85;                                  % merging threshold
            max_size = round(pi*(10/initial2.microns_per_pixel)^2);
            min_size = round(pi*(2.3/initial2.microns_per_pixel)^2);
            if initial2.microns_per_pixel<1
                ssub = 2
            else
                ssub = 1
            end
            initial1.g = 0;
            initial1.r = 0;
            options = CNMFSetParms(...
                'd1',sizY(1),'d2',sizY(2),...
                'deconv_method','constrained_foopsi',...    % neural activity deconvolution method
                'p',p,...                                   % order of calcium dynamics
                'ssub',ssub,...                                % spatial downsampling when processing
                'tsub',tsub,...                                % further temporal downsampling when processing
                'merge_thr',merge_thr,...                   % merging threshold
                'gSig',tau,...
                'max_size_thr',max_size,'min_size_thr',min_size,...    % max/min acceptable size for each component
                'spatial_method','regularized',...          % method for updating spatial components
                'df_prctile',20,...                         % take the median of background fluorescence to compute baseline fluorescence
                'fr',fr/tsub,...                            % downsamples
                'space_thresh',0.4,...                     % space correlation acceptance threshold
                'min_SNR',2,...                           % trace SNR acceptance threshold
                'cnn_thr',0.2,...                           % cnn classifier acceptance threshold
                'nb',1,...                                  % number of background components per patch
                'gnb',1,...                                 % number of global background components
                'decay_time',1.3,...                         % length of typical transient for the indicator used
                'refine_flag',true...
                );
            if add_params.last_frame(1,iii)>0
                options.refine_flag = false;
            end
            %% Run on patches (the main work is done here)
            options.this_one_serial = 0
            options.add_params=add_params;
            options.iii=iii;
            options.onep = 0;
            if save_all_flaggs
                cd(Folder_master)
                flagg = 3
                save workspace_all_recordings.mat -v7.3
                cd(Folder)
            end
            [A,b,C,f,S,P,RESULTS,YrA,recording(iii).neuropil_patches] = run_CNMF_patches(data,K,patches,tau,0,options,FOV); %  (data.Y,K,patches,tau,0,options);  % do not perform deconvolution here since
            if isfield(recording(iii),'C_dec')
                Ts = length(recording(iii).C_dec);
                if isempty(recording(iii).C_dec)
                    Ts = length(data.Y)*tsub
                end
            else
                Ts = length(data.Y)*tsub
            end
            recording(iii).Ts = Ts;
            T = sum(Ts)
            f_full = imresize(recording(iii).neuropil_patches,[size(recording(iii).neuropil_patches,1),T]);
            recording(iii).neuropil_patches = f_full;
            % we are operating on downsampled data
            if save_all_flaggs
                cd(Folder_save)
                flagg = 4
                save workspace_all_recordings_new.mat -v7.3
            end
            %cd(Folder)
            %in case of spiral scan: remove spatial components that are in corners or middle
            %% compute correlation image on a small sample of the data (optional - for visualization purposes)
            Cn = correlation_image_max(data,4);
            %% classify components
            rval_space = classify_comp_corr(data,A,C,b,f,options);
            ind_corr = rval_space > options.space_thresh;           % components that pass the correlation test
            % this test will keep processes
            %% further classification with cnn_classifier
            try  % matlab 2017b or later is needed
                [ind_cnn,value] = cnn_classifier(A,FOV,'cnn_model',options.cnn_thr);
            catch
                ind_cnn = true(size(A,2),1);                        % components that pass the CNN classifier
            end
            %% event exceptionality
            fitness = compute_event_exceptionality(C+YrA,options.N_samples_exc,options.robust_std);
            ind_exc = (fitness < options.min_fitness);
            %% select components
            close all
            Coor = plot_contours(A,Cn,options,1);
        end
        %if spiral scan, throw out ROIs that overlap with black pixels
        clear ROIz matrixpix ind_spiral pix
        %if pre-analyzed before 02/16/19, run blackpix correction here
        %blackpix_corr
        recording(iii).options = options;
        if nocorr(1,iii)
            initial1.blackpix = 0;
        end
        % if Pre_analyzed_021619
        blackpix_corr_one_rec
        % end
        %%%%%%%%%
        if run_CNMF
            close all
            to_discard = [];
            recording(iii).to_discard = to_discard;
            for i = 1:size(A,2)
                ROIz = i
                pix = Coor{i,1};
                if isempty(pix)
                    ind_spiral(i,1) = true;
                else
                    a=1;
                    for j = 1:size(pix,2)
                        matrixpix(ROIz).pix(a,1) = (pix(1,j)-1)*initial.height + pix(2,j);
                        a = a+1;
                    end
                    if isempty(intersect(matrixpix(ROIz).pix,recording(iii).initial1.blackpix)) && isempty(intersect(to_discard,ROIz))
                        ind_spiral(i,1) = true;
                    else
                        ind_spiral(i,1) = false;
                    end
                    if size(matrixpix(ROIz).pix,1) < 2*min_size/(3/initial2.microns_per_pixel) || ...
                            size(matrixpix(ROIz).pix,1) > 2*max_size/(8/initial2.microns_per_pixel)
                        ind_spiral(i,1) = false;
                    end
                end
            end
            keep = (ind_corr | ind_cnn) & ind_exc & ind_spiral;
            sum_keep = sum(keep)
            %% run GUI for modifying component selection (optional, close twice to save values)
            run_GUI = false;
            if run_GUI
                Coor = plot_contours(A,Cn,options,1); close;
                GUIout = ROI_GUI(data.Y,A,P,options,Cn,C,b,f);
                options = GUIout{2};
                keep = GUIout{3};
            end
            %% view contour plots of selected and rejected components (optional)
            throw = ~keep;
            Coor_k = [];
            Coor_t = [];
            figure(1);
            ax1 = subplot(121); plot_contours(A(:,keep),Cn,options,1,[],Coor_k,[],find(keep)); title('Selected components','fontweight','bold','fontsize',14);
            ax2 = subplot(122); plot_contours(A(:,throw),Cn,options,1,[],Coor_t,[],find(throw));title('Rejected components','fontweight','bold','fontsize',14);
            linkaxes([ax1,ax2],'xy')
            saveas(1,[Folder 'accepted_ROis' '.png'],'png')

            recording(iii).keep = keep;

            %% keep only the active components
            close all
            A_keep = A(:,keep);
            C_keep = C(keep,:);

            %% extract residual signals for each trace

            if exist('YrA','var')
                R_keep = YrA(keep,:);
            else
                R_keep = compute_residuals(data,A_keep,b,C_keep,f);
            end
            %% extract fluorescence on native temporal resolution
            if add_params.last_frame(1,iii)
                Ts = add_params.last_frame(1,iii);
            end
            options.fr = options.fr*tsub;                   % revert to origingal frame rate
            N = size(C_keep,1);                             % total number of components
            T = sum(Ts);                                    % total number of timesteps
            if isempty(C_keep)
                recording(iii).C_dec = [];
                recording(iii).S_dec = [];
                recording(iii).F_dff = [];
                recording(iii).F0 = [];
                recording(iii).C_full = [];
                recording(iii).R_full = [];
                recording(iii).F_full = [];
                recording(iii).A_keep = [];
                recording(iii).options = options;
                recording(iii).Coor = [];
                recording(iii).Cn = [];
                recording(iii).options_mc = [];
                recording(iii).template = [];
                recording(iii).results.cat_signal = [];
            else
                C_full = imresize(C_keep,[N,T]);                % upsample to original frame rate
                R_full = imresize(R_keep,[N,T]);                % upsample to original frame rate
                F_full = C_full + R_full;                       % full fluorescence
                f_full = imresize(f,[size(f,1),T]);             % upsample temporal background
                S_full = zeros(N,T);
                %% optional:
                options.deconv_method = 'OASIS'
                P.p = 0;
                ind_T = [0;cumsum(Ts(:))];
                options.nb = options.gnb;
                for i = 1:numFiles
                    inds = ind_T(i)+1:ind_T(i+1);   % indeces of file i to be updated
                    [C_full(:,inds),f_full(:,inds),~,~,R_full(:,inds)] = update_temporal_components_fast(registered_files(i).name,...
                        A_keep,b,C_full(:,inds),f_full(:,inds),P,options,FOV);
                    disp(['Extracting raw fluorescence at native frame rate. File ',num2str(i),' out of ',num2str(numFiles),' finished processing.'])
                end
                if save_all_flaggs
                    flagg = 5
                    cd(Folder_master)
                    save workspace_all_recordings.mat -v7.3
                    cd(Folder)
                end


                %% extract DF/F and deconvolve DF/F traces

                [F_dff,F0] = detrend_df_f(A_keep,[b,ones(prod(FOV),1)],C_full,[f_full;-double(data.F_dark)*ones(1,T)],R_full,options);
                C_dec = zeros(N,T);         % deconvolved DF/F traces
                S_dec = zeros(N,T);         % deconvolved neural activity
                bl = zeros(N,1);            % baseline for each trace (should be close to zero since traces are DF/F)
                neuron_sn = zeros(N,1);     % noise level at each trace
                g = cell(N,1);              % discrete time constants for each trace
                if p == 1; model_ar = 'ar1'; elseif p == 2; model_ar = 'ar2'; else; error('This order of dynamics is not supported'); end
                for i = 1:N
                    if isnan(sum(F_dff(i,:)))
                        C_dec(i,:) = 0;
                        S_dec(i,:) = 0;
                    else
                        spkmin = options.spk_SNR*GetSn(F_dff(i,:));
                        lam = choose_lambda(exp(-1/(options.fr*options.decay_time)),GetSn(F_dff(i,:)),options.lam_pr);
                        [cc,spk,opts_oasis] = deconvolveCa(F_dff(i,:),'type',model_ar,'method','constrained_foopsi','optimize_pars',true,'maxIter',20,...
                            'window',150,'lambda',lam,'smin',spkmin);
                        bl(i) = opts_oasis.b;
                        C_dec(i,:) = cc(:)' + bl(i);
                        S_dec(i,:) = spk(:);
                        neuron_sn(i) = opts_oasis.sn;
                        g{i} = opts_oasis.pars(:)';
                        disp(['Performing deconvolution. Trace ',num2str(i),' out of ',num2str(N),' finished processing.'])
                    end
                end
                recording(iii).C_dec = C_dec;
                recording(iii).S_dec = S_dec;
                recording(iii).F_dff = F_dff;
                recording(iii).F0 = F0;
                recording(iii).C_full = C_full;
                recording(iii).R_full = R_full;
                recording(iii).F_full = F_full;
                recording(iii).A_keep = A_keep;
                recording(iii).options = options;
                recording(iii).Coor = Coor;
                recording(iii).Cn = Cn;
                recording(iii).options_mc = options_mc;
                recording(iii).template = template;
                recording(iii).results.cat_signal = recording(iii).C_dec';
                recording(iii).f_full = f_full;
            end
        end
        flagg = 6
        cd(Folder_master)
        save workspace_all_recordings.mat -v7.3
        cd(Folder)
        %optional: make a df/f movie and write as tif file
        if write_DF_tif
            fr = initial2.samplingratehz;                                         % frame rate
            tsub = 1;                                        % degree of downsampling (for 30Hz imaging rate you can try also larger, e.g. 8-10)
            ds_filename = [foldername,'\ds_data.mat'];
            data_type = class(read_file(registered_files(1).name,1,1));
            DYall = zeros([FOV,0],'double');
            F_dark = Inf;                                    % dark fluorescence (min of all data)
            batch_size = round(fr*300); %2000;                               % read chunks of that size
            batch_size = round(batch_size/tsub)*tsub;        % make sure batch_size is divisble by tsub
            Ts = zeros(numFiles,1);                          % store length of each file
            cnt = 0;                                         % number of frames processed so far
            tt1 = tic;
            for i = 1:numFiles
                name = registered_files(i).name;
                info = h5info(name);
                dims = info.Datasets.Dataspace.Size;
                ndimsY = length(dims);                       % number of dimensions (data array might be already reshaped)
                Ts(i) = dims(end);
                DYall = zeros([FOV,Ts(i)],'double');
                cnt_sub = 0;
                gh=1;
                for t = 1:batch_size:Ts(i)
                    batch_read = t
                    clear Y YSmooth dw Y7p Y9p Y5p Y579m y5p y5pp dw
                    Y = read_file(name,t,min(batch_size,Ts(i)-t+1));
                    sigma = 1;
                    if no_GPU
                        YSmooth = imgaussfilt3(Y,sigma);
                    else
                        gpuDevice(1)
                        trf=gpuDevice();
                        brf = trf.AvailableMemory;
                        arf = size(Y);
                        drf = arf(1,1)*arf(1,2)*arf(1,3)*2;
                        if drf<arf
                            gpuy = gpuArray(Y);
                            YSmooth = imgaussfilt3(gpuy, sigma);
                            Y = gather(YSmooth);
                            clear gpuy
                        else
                            YSmooth = imgaussfilt3(Y,sigma);
                        end
                    end
                    Y7p = double(prctile(Y,7,3));
                    Y9p = double(prctile(Y,9,3));
                    Y5p = double(prctile(Y,5,3));
                    Y579m = (Y5p+Y7p+Y9p)/3;
                    y5p = reshape(Y579m,[],1);
                    if onep
                        y5pp = prctile(y5p,45);
                    else
                        y5pp = prctile(y5p,25);
                    end
                    dw = double(Y579m); %double(median(Y,3));

                    dw(dw<y5pp) = 16000;
                    Y = double(Y);
                    DY = double(zeros(FOV(1),FOV(2),min(batch_size,Ts(i)-t+1)));
                    DY = double(bsxfun(@rdivide, Y, dw)); % double(Y/med_Y);
                    ln = size(Y,3);
                    cnt_sub = cnt_sub + ln;
                    DYall(:,:,gh:gh+ln-1) = DY;
                    gh=gh+ln
                end
                toc(tt1);
                cnt = cnt + cnt_sub;
                data_temp.sizY(1,3) = cnt;
            end
            DYall(DYall>10) = 10;
            DYall = DYall*1600;
            DYall = uint16(DYall);
            t = Tiff(['normcorred_DF' '.tif' ],'w8');
            tagstruct.ImageLength = size(DYall,1);
            tagstruct.ImageWidth = size(DYall,2);
            tagstruct.Photometric = Tiff.Photometric.MinIsBlack;
            tagstruct.BitsPerSample = 16;
            tagstruct.SamplesPerPixel = 1;
            tagstruct.PlanarConfiguration = Tiff.PlanarConfiguration.Chunky;
            tagstruct.Software = 'MATLAB';
            tagstruct.SampleFormat = Tiff.SampleFormat.Int;
            t.setTag(tagstruct);
            t.write(int16(DYall(:,:,1)));
            t.close();
            for i = 2:size(DYall,3)
                writing_tiff_g = i
                t = Tiff(['normcorred_DF' '.tif'],'a');
                tagstruct.ImageLength = size(DYall,1);
                tagstruct.ImageWidth = size(DYall,2);
                tagstruct.Photometric = Tiff.Photometric.MinIsBlack;
                tagstruct.BitsPerSample = 16;
                tagstruct.SamplesPerPixel = 1;
                tagstruct.PlanarConfiguration = Tiff.PlanarConfiguration.Chunky;
                tagstruct.Software = 'MATLAB';
                tagstruct.SampleFormat = Tiff.SampleFormat.Int;
                t.setTag(tagstruct);
                t.write(int16(DYall(:,:,i)));
                t.close();
            end
        end
        clear DYall DY Y
        flagg=7
        if save_only_flagg_7
            cd(Folder_master)
            save workspace_all_recordings.mat -v7.3
        end
        if rerun_ROI_list
            %recreate ROI_list to have coordinaes and footprints of all cell ROIs
            lazy_ROIs = [];
            flip_along_diagonal = 0;
            flip_uyt = 0
            %make sure you have AVG_ch1.tif  and avg_ch2.tif saved in FOlder!
            clear ROI_list
            h = recording(iii).initial2.linesperframe;
            w = recording(iii).initial2.pixelsperline;
            close all
            recording(iii).lazy_ROIs = lazy_ROIs;
            clear kkeep akkeep matrixpix cpx cpy skipped_ROIs
            cor = recording(iii).Coor;
            c=1;
            b=1;
            if ~isempty(cor)
                for i = 1:size(cor,1)
                    if size(recording(iii).A_keep,2)<b
                    else
                        akeep = recording(iii).A_keep(:,b);
                        akkeep = find(akeep)
                        ROIz = i
                        pix = cor{i,1}
                        if isempty(pix)
                            for op =  1:size(akkeep,1)
                                if h == size(recording(iii).Cn,1)
                                    xh=h
                                else
                                    xh=w
                                end
                                hop=mod(akkeep(op,1),xh);
                                pix(1,op) = hop;
                                pix(2,op) = (akkeep(op,1)-hop)/xh;
                                kkeep(i,1) = 1;
                                cpx = mean(pix(2,:));
                                cpy = mean(pix(1,:));
                                ROI_list(b).centerPos(1,1) = cpx;
                                ROI_list(b).centerPos(1,2) = cpy;
                                ROI_list(b).pixel_list = akkeep; %matrixpix(ROIz).pix;
                            end
                            b=b+1;
                        else
                            a=1;
                            if flip_along_diagonal
                                for j = 1:size(pix,2)
                                    matrixpix(ROIz).pix(a,1) = (pix(2,j)-1)*h + pix(1,j);
                                    a = a+1;
                                end
                            else
                                if h == size(recording(iii).Cn,1)
                                    for j = 1:size(pix,2)
                                        matrixpix(ROIz).pix(a,1) = (pix(1,j)-1)*h + pix(2,j);
                                        a = a+1;
                                    end
                                else
                                    for j = 1:size(pix,2)
                                        matrixpix(ROIz).pix(a,1) = (pix(1,j)-1)*w + pix(2,j);
                                        a = a+1;
                                    end
                                end
                            end
                            if isempty(intersect(matrixpix(ROIz).pix,akkeep))
                                skipped_ROIs(c,1) = i;
                                c=c+1
                            else
                                kkeep(i,1) = 1;
                                cpx = mean(pix(2,:));
                                cpy = mean(pix(1,:));
                                ROI_list(b).centerPos(1,1) = cpx;
                                ROI_list(b).centerPos(1,2) = cpy;
                                ROI_list(b).pixel_list = akkeep; %matrixpix(ROIz).pix;
                                b=b+1;
                            end
                        end
                    end
                end
                recording(iii).ROI_list = ROI_list;
                sum(kkeep)
                % end
                %make sure these are correct!
                neuropil_not_present_yet=1;
                check_recreated_ROI_list
            end
        end
        for o = 1:size(recording(iii).patches,1)
            patches_centerPos(o,:) = [mean(recording(iii).patches{o,1}(1,1:2)),mean(recording(iii).patches{o,1}(1,3:4))];
        end
        clear F
        if isfield(recording(iii),'F_dff')
            if size(recording(iii).F_dff,1)>size(recording(iii).F_full,1)
                F = recording(iii).F_dff(1:end-10,:)';
            else
                F = recording(iii).F_dff';
            end
        else
            F = recording(iii).FiltMat2_5000(1:end-10,:);
        end
        maxn = size(F,2);
        clear N RL neuropil_distances
        f_full_new = imresize(recording(iii).neuropil_patches,[size(recording(iii).neuropil_patches,1),T]);
        for o = 1: maxn
            clear closest
            cp = recording(iii).ROI_list(o).centerPos;
            pulp = 90280374857;
            for p = 1:size(patches,1)
                cpn = patches_centerPos(p,:);
                dista(1,p) = sqrt(abs(cp(1,1)-cpn(1,1))^2 + abs(cp(1,2)-cpn(1,2))^2);
                if dista(1,p)<pulp
                    closest = p;
                    pulp = dista(1,p);
                end
            end
            neuropil_distances(o).distances = dista;
            neuropil_distances(o).closest = closest;
            N(:,o) = f_full_new(closest,:)'; %recording(iii).neuropil_patches(closest,:)';
            RL.ROI_info(o,3:4) = cp;
        end
        RL.cat_signal = N;
        %detrend and make DF/F out of neuropil signal
        already_unified_cat_signal_present = 1;
        baseline_tconst_ms = 30000
        if isfield(recording(iii),'xml_file')
            xml_file = recording(iii).xml_file;
        else
            xml_FileName = dir('*.xml')
            gh = size(xml_FileName,1)
            lk = 0;
            for o = 1:gh
                jh = xml_FileName(o).bytes;
                if jh>lk
                    lk=jh;
                    whon = o;
                end
            end
            xml_file = xml2struct(xml_FileName(whon).name);
        end
        [neuropil_matrix,results] = calciumsignalcalculator_matlab(recording(iii).initial,Folder,xml_file,RL,...
            baseline_tconst_ms,already_unified_cat_signal_present,recording(iii).initial2,onep);
        if size(neuropil_matrix,1)>size(F,1)
            neuropil_matrix(size(F,1)+1:end,:) = [];
        end
        recording(iii).neuropil_matrix = neuropil_matrix;
        ops.fs = recording(iii).initial2.samplingratehz;
        ops.sensorTau  = 1.5;
        ops.estimateNeuropil = 1; %(default is 1, if N is given as input)
        if size(neuropil_matrix,1)<size(F,1)
            neuropil_matrix(size(neuropil_matrix,1)+1:size(F,1),:) = ...
                neuropil_matrix(2*size(neuropil_matrix,1)-size(F,1)+1:size(neuropil_matrix,1),:);
        end
        [sp, ca, coefs, B, sd, ops, baselines] = wrapperDECONV(ops, F, neuropil_matrix);
        recording(iii).suite2p_deconv.sp = sp;
        recording(iii).suite2p_deconv.ca = ca;
        recording(iii).suite2p_deconv.coefs = coefs;
        recording(iii).suite2p_deconv.B = B;
        recording(iii).suite2p_deconv.sd = sd;
        recording(iii).suite2p_deconv.ops = ops;
        recording(iii).suite2p_deconv.baselines = baselines;
        %denoise
        if isfield(recording(iii),'suite2p_deconv')
            if isfield(recording(iii).suite2p_deconv,'sp')
                spd = recording(iii).suite2p_deconv.sp;
                cad = recording(iii).suite2p_deconv.ca;
            else
                spd = recording(iii).sp;
                cad  = recording(iii).ca;
            end
        else
            spd = recording(iii).sp;
            cad  = recording(iii).ca;
        end
        std_level = 2;
        just_oopsi_binedges = 0;
        [sp_no_noise,activity_per_min_sp,ca_no_noise,activity_per_min_ca,noisedata] = ...
            denoise(recording(iii).initial,spd,cad,std_level,...
            recording(iii).initial2,just_oopsi_binedges);
        recording(iii).suite2p_deconv.sp_no_noise = sp_no_noise;
        recording(iii).suite2p_deconv.ca_no_noise = ca_no_noise;
        if save_all_flaggs
            save workspace_all_recordings.mat -v7.3
        end
        %add neuropil signals made with imageJ
        %%% ONLY if it hasn't already been added!!!!!!
        if add_NP_to_suite2p
            neuropil_first_column_is_samples = 0;
            close all
            cd(Folder_master)
            cd(Folder)
            %check if timeneuropil.csv exists
            timecsv = subdir('*neuropil.csv');
            if isempty(timecsv)
                Time_FileName = 'Timeneuropil.txt';
                T = importdata(Time_FileName,'\t',1);
                Timeneuropil = T.data;
            else
                Time_FileName = 'Timeneuropil.csv';
                T = csvread(Time_FileName,1,0);
                Timeneuropil = T;
            end
            Results_FileName = 'Resultsneuropil.txt';
            R = importdata(Results_FileName,'\t',1);
            Resultsneuropil = R.data;
            recording(iii).Resultsneuropil = Resultsneuropil;
            %ROI_list = [];
            neuropil_first_column_is_samples = 0;
            num_neuropil_ROIs = size(Resultsneuropil,1)
            if num_neuropil_ROIs>10
                bloodvessel_neurop = num_neuropil_ROIs-10;
                num_neuropil_ROIs = 10;
                incl_bloodvessles = 1;
            end
            if add_params.last_frame(1,iii)
                Timeneuropil(add_params.last_frame(1,iii)+1:end,:) = [];
            end

            if size(Timeneuropil,1) > size(recording(iii).C_dec,2)
                Timeneuropil(size(recording(iii).C_dec,2)+1:end,:) = [];
            end
            RL.cat_signal = Timeneuropil(:,1:num_neuropil_ROIs); % = recording(iii).ROI_list;
            already_unified_cat_signal_present = 1
            %% OR
            %     RL = results_new_ROIs;
            %     already_unified_cat_signal_present = 1
            %%%%
            [NP_matrix,NP_results] = calciumsignalcalculator_matlab(recording(iii).initial,Folder,xml_file,RL,...
                baseline_tconst_ms,already_unified_cat_signal_present,recording(iii).initial2,onep);
            %%%%%%%%%%%%%%%
            close all
            butterfilt = 0.32;
            maxcount = 5000; %maximum yaksi-friedrich iteration #
            tbin = recording(iii).initial2.msperline/1000;
            tau = 1.5;
            thrup = 3;  %estimated noise level in %DF/F, 5 for fast spiral, 7 for resonant w/o fr avg
            apm = zeros(1,size(NP_results.cat_signal,2));
            [NP_DeconvMat5000,NP_FiltMat5000,NP_FiltMat2_5000,NP_deconv_adaptive] = CaDeconvStandAlone(apm,...
                recording(iii).initial,NP_results,tau,thrup,0,2,0,maxcount,tbin,butterfilt,baseline_tconst_ms,recording(iii).initial2);
            std_level = 2;
            just_oopsi_binedges = 0;
            [neuropil_oopsi_no_noise_deconvbinedges,activity_per_min_neuropil_DF_deconvbinedges,...
                neuropil_DF_no_noise_deconvbinedges,activity_per_min_neuropil_DF_DFbinedges,noisedata_neuropil_DF] = ...
                denoise(recording(iii).initial,NP_DeconvMat5000,NP_FiltMat2_5000,std_level,...
                recording(iii).initial2,just_oopsi_binedges);
            recording(iii).suite2p_deconv.sp_no_noise(:,end+1:end+10) = neuropil_oopsi_no_noise_deconvbinedges;
            recording(iii).suite2p_deconv.ca_no_noise(:,end+1:end+10) = neuropil_DF_no_noise_deconvbinedges;
            %visualize some random transients to confirm
            sdec = recording(iii).suite2p_deconv.sp_no_noise';
            cdec = recording(iii).suite2p_deconv.ca_no_noise';
            endframe = size(sdec,1);
            if ~onep
                sdecfp = sdec;
                sdecor = sdec;
            end
            if ~onep
                neuns = round(randi(endframe,1,12));
                fs = recording(iii).initial2.samplingratehz;
                lplo = round(90*fs);
                if lplo>size(sdec,2)
                    lplo = size(sdec,2)
                end
                ge = 0;
                a=0;
                while ge == 0
                    figure(456+a)
                    for i = 1:12
                        subplot(3,4,i)
                        plot(cdec(neuns(1,i),1:lplo));
                        hold on
                        plot(sdecfp(neuns(1,i),1:lplo));
                        hold on
                    end
                    std_level = 0;
                    prompt = {'good enough (1) or not (0) ?'};
                    dlg_title = '1 if ready to go, 0 if not';
                    num_lines = 1;
                    def = {'1'};
                    answer = inputdlg(prompt,dlg_title,num_lines,def);
                    answer = str2mat(answer);
                    ge = str2num(answer);
                    if ge==0
                        a=a+1;
                        std_level = std_level+1;
                        sdec =sdecor;
                        for ert = 1:size(sdec,1)
                            sdeccur = sdec(ert,:);
                            meas = median(sdeccur);
                            stds = std(sdeccur,0);
                            sdeccur(sdeccur<meas+std_level*stds) = 0;
                            sdec(ert,:) = sdeccur;
                            sdeccur(sdeccur>0) = 0.4;
                            sdeccur(sdeccur<0) = 0;
                            sdecfp(ert,:) = sdeccur;
                        end
                    end
                end
                recording(iii).sdec_std_level = std_level;
            end
            recording(iii).sdec_thr = sdec;
        end

        NB208_aft16 = 1
        %now run align_EEG on the matched ROIs across recordings:
        %it has to be in teh next column, regardless where the first channel is.
        %Otherwise you have to reshape the matrix with teh analog inputs first.
        stimcell_interp_to_Vm = 0; % set to 1 if you have patch data
        add_params.man = 0; %add additional parameters manually
        add_params.e2ch = 1;
        ZH_recording = 0;
        add_params.DF_o_Fi = 0; %DF+oopsi or Filtmat?
        cd(Folder_master)
        if ~isfield(recording(iii).initial2,'triggersync_hz')
            parv = recording(iii).initial2.rawData2(10000,1);
            recording(iii).initial2.triggersync_hz =  10000000/parv
        end
        cd(Folder_master)
        Folder = subfolders(iii).name;
        cd(Folder)
        add_params.um = ~(recording(iii).initial.no_imaging(1,iii)); %used microscope?
        imaged = add_params.um; %set this to 0 if you don't have any imaging data
        close all
        %%%%%%%%%%%%%%%%%%%%%% align EEG trace with image data
        if imaged
            if size(recording(iii).C_dec,1)==size(recording(iii).F_dff,2)
                recording(iii).results.cat_signal = recording(iii).C_dec;
            else
                recording(iii).results.cat_signal = recording(iii).C_dec';
            end
            matrix = real(recording(iii).suite2p_deconv.ca_no_noise); %this is the DF/F matrix you want to align with the EEG
            deconv = real(recording(iii).suite2p_deconv.sp_no_noise); %this is the deconvolved matrix you want to align with teh EEG
        else
            matrix=0;
            deconv=0;
            recording(iii).results.cat_signal = 0;
        end
        %if patched:
        recording(iii).initial.PD_only = 1; % change this to 0 if you have patching data
        [EEG_results_nonoise] = align_EEG_PC_2_20221107(Folder,recording(iii).initial,matrix,recording(iii).results,...
            deconv,imaged,0,NB208_aft16,stimcell_interp_to_Vm,recording(iii).initial2,add_params,onep,ZH_recording,Folder_master,0);
        recording(iii).EEG_results_nonoise = EEG_results_nonoise;
        if recording(iii).initial.no_imaging(1,iii)... % || recording(1).initial.datedr(1,iii)==0  ...
                || isfield(recording(iii).EEG_results_nonoise,'oopsi_interp_values')==0
        else
            rec = iii
            i2 = recording(iii).initial2;
            fr = 100; %set to 0 if analyzing non-interpolated matrix!
            curr_mat = real(recording(iii).EEG_results_nonoise.oopsi_interp_values);
            [ca_stats] = basic_ca_stats_f_epilepsy(Folder,i2,curr_mat,fr,onep,recording(iii).FOV,0);
            recording(iii).ca_stats_deconv = ca_stats;
            clear ca_stats
            curr_mat = real(recording(iii).EEG_results_nonoise.deltaf_interp_values);
            [ca_stats] = basic_ca_stats_f_epilepsy(Folder,i2,curr_mat,fr,onep,recording(iii).FOV,0);
            recording(iii).ca_stats_C = ca_stats;
        end
        % add wheel
        if ~isfield(recording(iii),'wheel_new') && isfield(recording(iii).initial2,'rawData2')
            if isempty(recording(iii).initial2)
            else
                Folder = subfolders(iii).name;
                cd(Folder_master)
                wheel_added_to_winedr = 0;
                tds=0
                cam_fr = 30;
                wheel_thr = 0.043;
                [wheel_new] = wheel_analysis_81516(recording(iii).initial,Folder,cam_fr,tds,wheel_thr,100,0,...
                    recording(iii).initial2,wheel_added_to_winedr,iii,onep);
                recording(iii).wheel_new = wheel_new;
            end
        else
            if (isempty(recording(iii).initial2) && ~isempty(recording(iii).wheel_new)) || ~isfield(recording(iii).initial2,'rawData2')
            else
                Folder = subfolders(iii).name;
                cd(Folder_master)
                wheel_added_to_winedr = 0;
                tds=0
                cam_fr = 30;
                wheel_thr = 0.043;
                [wheel_new] = wheel_analysis_81516(recording(iii).initial,Folder,cam_fr,tds,wheel_thr,100,0,...
                    recording(iii).initial2,wheel_added_to_winedr,iii,onep);
                recording(iii).wheel_new = wheel_new;
            end
        end
        %make sure you have whiskig miage sequence saved in "whisk" folder
        Folder = subfolders(iii).name;
        cd(Folder_master)
        close all
        cd(Folder)
        tept = dir;
        iswhisk=0
        for tu=1:size(tept,1)
            whsr = tept(tu).name;
            if strcmp(whsr,'whisk')
                iswhisk = 1;
            end
        end
        if iswhisk
            if ~isfield(recording(iii),'whisking')
                Folder = subfolders(iii).name;
                cd(Folder_master)
                close all
                i2 = recording(iii).initial2;
                matrix =recording(iii).C_dec; %recording(iii).deltaf_matrix'; % %onep_results_2.DF_sq_right;
                cam_fr = 30;
                imaged = 1;
                [whisking] = whisk_analysis(Folder,i2,cam_fr,matrix,cam_st_man,...
                    imaged,onep,recording(iii).initial2.mirror_start_time(1,1),1,iii,cam15Hz,...
                    recording(iii).initial2.sampl_fr,recording(iii).initial2,dropped_frames,recording);
                recording(iii).whisking = whisking;
                close all
            else
                if isempty(recording(iii).whisking)
                    Folder = subfolders(iii).name;
                    cd(Folder_master)
                    close all
                    i2 = recording(iii).initial2;
                    i2.heka_or_winedr = recording(iii).initial.heka_or_winedr;
                    matrix =recording(iii).C_dec; %recording(iii).deltaf_matrix'; % %onep_results_2.DF_sq_right;
                    cam_fr = 30;
                    imaged = 1;
                    [whisking] = whisk_analysis(Folder,i2,cam_fr,matrix,cam_st_man,...
                        imaged,onep,recording(iii).initial2.mirror_start_time(1,1),1,iii,cam15Hz,recording(iii).initial2.sampl_fr,recording(iii).initial2,dropped_frames,recording);
                    recording(iii).whisking = whisking;
                    close all
                end
            end
        end
    end
end

cd(Folder_master)
save workspace_all_recordingss.mat -v7.3

%%%%%%%%%%%%%%%compute spectra of EEGs here
for i =  1:size(recording,2)
    if isempty(recording(i).EEG_results_nonoise)
    else
        analyzing_rec = i
        freq = 1000;
        fs = recording(i).initial2.sampl_fr;
        waver = recording(i).EEG_results_nonoise.EEG';
        waver2 = recording(i).EEG_results_nonoise.EEG_2';
        EEG_extrap_1000 = zeros(1,round(length(waver)/(fs/freq)));
        EEG_2_extrap_1000  = zeros(1,round(length(waver2)/(fs/freq)));
        for ii = 1: size(EEG_2_extrap_1000,2)
            EEG_2_extrap_1000(1,ii) = waver2(1,round((ii-1)*fs/freq)+1);
        end
        for ii = 1: size(EEG_extrap_1000,2)
            EEG_extrap_1000(1,ii) = waver(1,round((ii-1)*fs/freq)+1);
        end
        All_EEGs(i).EEG_extrap_1000 = EEG_extrap_1000;
        All_EEGs(i).EEG_2_extrap_1000 = EEG_2_extrap_1000;
    end
end

% In the following loop matlab will re-reference the EEG by subtracting the
% contralateral channel from the ipsilateral channel.
prompt = {'reference ispi to contra (1) or contra to ipsi (0) ?'};
dlg_title = '1 if yes, 0 if no';
num_lines = 1;
def = {'1'};
answe = inputdlg(prompt,dlg_title,num_lines,def);
answe = str2mat(answe);
answe = str2num(answe);
for i = 1:size(recording,2)
    curreeg=i
    if length(All_EEGs(i).EEG_2_extrap_1000) < 10000
        All_EEGs(i).too_short = 1;
    else
        All_EEGs(i).too_short = 0;
    end
    if isempty(All_EEGs(i).EEG_2_extrap_1000)==0
        if answe
            aeg = All_EEGs(i).EEG_extrap_1000;
            aeg2 = All_EEGs(i).EEG_2_extrap_1000;
        else
            aeg = All_EEGs(i).EEG_2_extrap_1000;
            aeg2 = All_EEGs(i).EEG_extrap_1000;
        end
        All_EEGs(i).aegminaeg2 = aeg-aeg2;
        figure(i)
        plot(All_EEGs(i).aegminaeg2)
    end
end
close all

%If you want you can now reorder the  EEGs inside the All_EEGs structure to put them in chromological order!

% Next, it will identify all high-frequency artifacts (40-400 Hz) and
% remove those from the recording and calculate the power spectra for teh
% whole recording for each EEG. It also calculates low-frequency (7-12 Hz)
% to identify potential seizures or interictal spikes.

close all
prompt = {'use re-referenced (0) or contra (1) or ipsi (2) or both contra and ipsi (3) or all three (4) for analysis ?'};
dlg_title = 'which channel for analysis?';
num_lines = 1;
def = {'0'};
answe = inputdlg(prompt,dlg_title,num_lines,def);
answe = str2mat(answe);
answe = str2num(answe);
switch (answe)
    case 0
        reref_con_ips = 0;
    case 1
        reref_con_ips = 1;
    case 2
        reref_con_ips = 2;
    case 3
        reref_con_ips = 3;
    case 4
        reref_con_ips = 4;
end

preprocess_EEGs
close all
cd(Folder_master)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%run this individually for all recordings
 iii=1
extract_vis_stim_params_20220907


close all
figure(1234)
edges = 0:0.05:1;
kl = length(edges);
clear synchr_cells_percentages microszs microseiz_summary
half_sec = 3;

widefield_recording = zeros(1,size(recording,2)); %[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0];
initial = recording(1).initial;
min_length_matrix = 10000
excl_running = 1;
excl_whisking = 1;
excl_vis = 0;
interpolate_whisking_to_100Hz = 0;
microseiz_summary_no_run_no_whisk = microseiz_analysis(edges,subfolders,initial,recording,widefield_recording,add_params,...
    excl_running,excl_whisking,wheel_thr,half_sec,interpolate_whisking_to_100Hz,6,...
    excl_vis,0,0,min_length_matrix)
cd(Folder_master)
save microseiz_summary_no_run_no_whisk.mat microseiz_summary_no_run_no_whisk -v7.3
excl_running = 1;
excl_whisking = 0;
excl_vis = 0;
interpolate_whisking_to_100Hz = 0;
microseiz_summary_no_running = microseiz_analysis(edges,subfolders,initial,recording,widefield_recording,add_params,...
    excl_running,excl_whisking,wheel_thr,half_sec,interpolate_whisking_to_100Hz,6,...
    excl_vis,0,0,min_length_matrix)
cd(Folder_master)
save microseiz_summary_no_running.mat microseiz_summary_no_running -v7.3
close all
excl_running = 0;
excl_whisking = 0;
excl_vis = 0;
interpolate_whisking_to_100Hz = 0;
ms_thr = 1.8
microseiz_summary = microseiz_analysis(edges,subfolders,initial,recording,widefield_recording,add_params,...
    excl_running,excl_whisking,wheel_thr,half_sec,interpolate_whisking_to_100Hz,ms_thr,...
    excl_vis,0,0,min_length_matrix)
cd(Folder_master)
save microseiz_summary.mat microseiz_summary -v7.3
ms = microseiz_summary_no_run_no_whisk;

% %%%%% determine some basic ca-activity parameters:
this_one_serial= 0
for iii = 1:size(recording,2)
    if recording(1).initial.no_imaging(1,iii) || recording(1).initial.datedr(1,iii)==0 ||...
            isfield(recording(iii).EEG_results_nonoise,'oopsi_interp_values')==0
    else
        rec = iii
        i2 = recording(iii).initial2;
        fr = 100; %set to 0 if analyzing non-interpolated matrix!
        matrix = ms(iii).ernoiv_adj_run_and_or_whisk;
        if isempty(matrix)
            recording(iii).no_quiet_analysis_possible = 1;
        else
        curr_mat = real(matrix);
        clear ca_stats_no_run_no_whisk
        [ca_stats_no_run_no_whisk] = basic_ca_stats_f_epilepsy(Folder,i2,curr_mat,fr,onep,FOV,this_one_serial);
        recording(iii).ca_stats_no_run_no_whisk_deconv = ca_stats_no_run_no_whisk;
        end
    end
end

%set time periods for correlation analysis and clustering
%(if there was no seizure then set the "post" times to some small value,
%and then the "pre" times are all you're looking at, or half and hal to see if things remained consisten throughout teh recording)
%this first iteration is if you don't want to run microseizure analysis
%first...
%but do run vis stim analysis, or at least identify vis stim times so that you can restrict cluster analysis to blank screen time.!

%make sure recheck_C_dec has run:
for iii =1:size(recording,2)
    if ~isempty(recording(iii).C_dec)
        if isfield(recording(iii),'C_dec_old')
            if ~isempty(recording(iii).C_dec_old)
            else
                close all
                std_level = 3;
                recheck_C_dec;
            end
        else
            close all
            std_level = 3;
            recheck_C_dec;
        end
    end
end

just_split_inhalf = ones(1,num_rec);%1 % [1,1];%[1,1,1,1,1,1,1,1,1,1];
beg_1 = 1 % [1,1];
end_1 = 0 % [0,0];
beg_2 = 0 % [0,0];
end_2 = 0 % [0,0];

for iii=1:size(recording,2)
    if isfield(recording(iii),'vis_results')
        if ~isempty(recording(iii).vis_results)
            beg_1(1,iii) = floor(recording(iii).first_spont_fr/recording(iii).initial2.samplingratehz);
            length_spont(1,iii) = floor((size(recording(iii).suite2p_deconv.sp_no_noise,1)/recording(iii).initial2.samplingratehz - beg_1(1,iii)));
        else
            beg_1(1,iii) = 1;
            length_spont(1,iii) =  floor(size(recording(iii).suite2p_deconv.sp_no_noise,1)/recording(iii).initial2.samplingratehz);
        end
    else
        beg_1(1,iii) = 1;
        length_spont(1,iii) =  floor(size(recording(iii).suite2p_deconv.sp_no_noise,1)/recording(iii).initial2.samplingratehz);
    end
end
min_length_spont = min(length_spont)-1;

for iii = 1:size(recording,2)
    end_2(1,iii) = beg_1(1,iii) + min_length_spont;
    end_1(1,iii) = beg_1(1,iii) + floor(min_length_spont/2) - 2 %round(2*recording(iii).initial2.samplingratehz);
    beg_2(1,iii) = end_1(1,iii) + 2 %round(2*recording(iii).initial2.samplingratehz);
end


%if just_split_inhalf
for ui = 1:size(recording,2)
    if just_split_inhalf(1,ui)
        if ~isempty(recording(ui).suite2p_deconv)
            sf = recording(ui).initial2.samplingratehz;
            mls = size(recording(ui).suite2p_deconv.sp,1)/sf
            corr_beg_sec_1(1,ui) = 1;
            corr_end_sec_1(1,ui) = round(mls/2.05);
            corr_beg_sec_2(1,ui) = round(mls/2);
            corr_end_sec_2(1,ui) = round(mls/1.05);
        end
    else
        sf = recording(ui).initial2.samplingratehz;
        mls = floor(size(recording(ui).suite2p_deconv.sp,1)/sf)
        corr_beg_sec_1(1,ui) = beg_1(1,ui);
        corr_end_sec_1(1,ui) = end_1(1,ui);
        corr_beg_sec_2(1,ui) = beg_2(1,ui);
        corr_end_sec_2(1,ui) = end_2(1,ui) %round(mls/1.05);
    end
end
%  OR set manually for correlation analysis
     corr_beg_sec_1 = [1];
     corr_end_sec_1 = [150];
     corr_beg_sec_2 = [1100];
     corr_end_sec_2 = [1250];
% end

one_max_clust = 0
if one_max_clust
    for ui = 1:size(recording,2)
        corr_end_sec_1(1,ui) =  corr_end_sec_2(1,ui)-2;
        corr_beg_sec_2(1,ui) = corr_end_sec_2(1,ui)-1;
       
    end
end

%for clustering plots
beg_sec_prez = corr_beg_sec_1; %[1,1,1,1];
end_sec_prez = corr_beg_sec_1 +60; %[60,60 ,60 ,60];
beg_sec_postz = corr_beg_sec_2; %[1302 ,1140 ,400 ,600];
end_sec_postz = corr_beg_sec_2 + 60; %[1362 ,1200,460 ,660];

%if not using microseizures as splitting points and you don't care about ruinning or whisking, for clusters, run this. But
%make sure there were no actualv sieuzres
shuf_iters = 10000
close all
sf=1

% cluster_results = clustering(recording,Folder_master,subfolders,corr_beg_sec_1,corr_end_sec_1,...
%     corr_beg_sec_2,corr_end_sec_2,beg_sec_prez,end_sec_prez,beg_sec_postz,end_sec_postz,'all',0,0,shuf_iters,sf);

%clear corr_beg_sec_1 corr_end_sec_1 corr_beg_sec_2 corr_end_sec_2 interictal_period_start interictal_period_end
ms = microseiz_summary;
rd=0
for iii = 1:size(recording,2)
    %clear corr_beg_sec_1 corr_end_sec_1 corr_beg_sec_2 corr_end_sec_2 interictal_period_start interictal_period_end
    interp = recording(iii).EEG_results_nonoise.oopsi_interp_values; %ms(iii).ernoiv_final;%
    shuf_iters = 10000
    close all
    sf=1
    excl_running=0;
    excl_whisking=0;
    minds = ms(iii).mean2min_inds;
    interpolate_whisking_to_100Hz = 0;
    cluster_results = clustering_one_rec_20230201(recording,Folder_master,subfolders,corr_beg_sec_1,corr_end_sec_1,...
        corr_beg_sec_2,corr_end_sec_2,beg_sec_prez,end_sec_prez,beg_sec_postz,end_sec_postz,'all',0,0,shuf_iters,sf,iii,...
        excl_running,excl_whisking,interpolate_whisking_to_100Hz,wheel_thr,interp,...
        0,0,0,rd,0,0);
    recording(iii).cluster_results_orig = cluster_results;
end

cd(Folder_master)
save cluster_results_orig.mat cluster_results -v7.3
%OR
save cluster_results.mat recordingc
save recording_cnmf_rerun.mat -v7.3

%%%%%%% verify microseizure identification by plotting rasters, then extract then
%%%%%%% reverse correlate EEG powers to  microseizure times.

All_EEGs_extrap_1000s_already_prepared = 1

ms = microseiz_summary_no_run_no_whisk;

microseiz_verify_and_classify_EEGs

% extract meaningful parameters about the microseizures from teh data

%now run correlation and clustering analysis for excl running an whisking
min_isi_ms = 2000
min_length_ms = 200
offs_thr = 200
suf=1
sec_plot = 10
close all
onep=0
[Ca_EEG_results,EEG_segs] = EEG_to_Ca_analysis_all_recs_02_2021(min_isi_ms,min_length_ms,...
    offs_thr,suf,recording,size(recording,2),...
    onep,Folder_master,All_EEGs,recording(1).initial.no_imaging,...
    subfolders,sec_plot,add_params);


clear Ca_EEG_stats
for i = 1:size(Ca_EEG_results,2)
    if isempty(Ca_EEG_results(i).p_ranksum_filtmat_others)
        Ca_EEG_stats(1).ictal_high_perc_others_over_time(1,i) = NaN;
        Ca_EEG_stats(1).ictal_low_perc_others_over_time(1,i) = NaN;
    else
        if Ca_EEG_results(i).p_ranksum_filtmat_others == 0
            Ca_EEG_stats(1).ictal_high_perc_others_over_time(1,i) = NaN;
            Ca_EEG_stats(1).ictal_low_perc_others_over_time(1,i) = NaN;
        else
            nac = size(Ca_EEG_results(i).p_ranksum_filtmat_others,2);
            if Ca_EEG_results(i).ictal_high_ranksum_filtmat_others == 0
                Ca_EEG_stats(1).ictal_high_perc_others_over_time(1,i) = 0;
            else
                Ca_EEG_stats(i).ictal_high_perc_others =...
                    100*size(Ca_EEG_results(i).ictal_high_ranksum_filtmat_others,1)/nac;
                Ca_EEG_stats(1).ictal_high_perc_others_over_time(1,i) = Ca_EEG_stats(i).ictal_high_perc_others;
            end
            if Ca_EEG_results(i).ictal_low_ranksum_filtmat_others == 0
                Ca_EEG_stats(1).ictal_low_perc_others_over_time(1,i) = 0;
            else
                Ca_EEG_stats(i).ictal_low_perc_others =...
                    100*size(Ca_EEG_results(i).ictal_low_ranksum_filtmat_others,1)/nac;
                Ca_EEG_stats(1).ictal_low_perc_others_over_time(1,i) = Ca_EEG_stats(i).ictal_low_perc_others;
            end
        end
    end
    if isempty(Ca_EEG_results(i).p_ranksum_filtmat_seizures)
        Ca_EEG_stats(1).ictal_high_perc_seizures_over_time(1,i) = NaN;
        Ca_EEG_stats(1).ictal_low_perc_seizures_over_time(1,i) = NaN;
    else
        if Ca_EEG_results(i).p_ranksum_filtmat_seizures == 0
            Ca_EEG_stats(1).ictal_high_perc_seizures_over_time(1,i) = NaN;
            Ca_EEG_stats(1).ictal_low_perc_seizures_over_time(1,i) = NaN;
        else
            nac = size(Ca_EEG_results(i).p_ranksum_filtmat_seizures,2);
            if Ca_EEG_results(i).ictal_high_ranksum_filtmat_seizures == 0
                Ca_EEG_stats(1).ictal_high_perc_seizures_over_time(1,i) = 0;
            else
                Ca_EEG_stats(i).ictal_high_perc_seizures =...
                    100*size(Ca_EEG_results(i).ictal_high_ranksum_filtmat_seizures,1)/nac;
                Ca_EEG_stats(1).ictal_high_perc_seizures_over_time(1,i) = Ca_EEG_stats(i).ictal_high_perc_seizures;
            end
            if Ca_EEG_results(i).ictal_low_ranksum_filtmat_seizures == 0
                Ca_EEG_stats(1).ictal_low_perc_seizures_over_time(1,i) = 0;
            else
                Ca_EEG_stats(i).ictal_low_perc_seizures =...
                    100*size(Ca_EEG_results(i).ictal_low_ranksum_filtmat_seizures,1)/nac;
                Ca_EEG_stats(1).ictal_low_perc_seizures_over_time(1,i) = Ca_EEG_stats(i).ictal_low_perc_seizures;
            end
        end
    end
    if ~isfield(Ca_EEG_results(i),'p_ranksum_filtmat_SWs')
        Ca_EEG_stats(1).ictal_high_perc_SWs_over_time(1,i) = NaN;
        Ca_EEG_stats(1).ictal_low_perc_SWs_over_time(1,i) = NaN;
    else
        if isempty(Ca_EEG_results(i).p_ranksum_filtmat_SWs)
            Ca_EEG_stats(1).ictal_high_perc_SWs_over_time(1,i) = NaN;
            Ca_EEG_stats(1).ictal_low_perc_SWs_over_time(1,i) = NaN;
        else
            if Ca_EEG_results(i).p_ranksum_filtmat_SWs == 0
                Ca_EEG_stats(1).ictal_high_perc_SWs_over_time(1,i) = NaN;
                Ca_EEG_stats(1).ictal_low_perc_SWs_over_time(1,i) = NaN;
            else
                nac = size(Ca_EEG_results(i).p_ranksum_filtmat_SWs,2);
                if Ca_EEG_results(i).ictal_high_ranksum_filtmat_SWs == 0
                    Ca_EEG_stats(1).ictal_high_perc_SWs_over_time(1,i) = 0;
                else
                    Ca_EEG_stats(i).ictal_high_perc_SWs =...
                        100*size(Ca_EEG_results(i).ictal_high_ranksum_filtmat_SWs,1)/nac;
                    Ca_EEG_stats(1).ictal_high_perc_SWs_over_time(1,i) = Ca_EEG_stats(i).ictal_high_perc_SWs;
                end
                if Ca_EEG_results(i).ictal_low_ranksum_filtmat_SWs == 0
                    Ca_EEG_stats(1).ictal_low_perc_SWs_over_time(1,i) = 0;
                else
                    Ca_EEG_stats(i).ictal_low_perc_SWs =...
                        100*size(Ca_EEG_results(i).ictal_low_ranksum_filtmat_SWs,1)/nac;
                    Ca_EEG_stats(1).ictal_low_perc_SWs_over_time(1,i) = Ca_EEG_stats(i).ictal_low_perc_SWs;
                end
            end
        end
    end
    if ~isfield(Ca_EEG_results(i),'p_ranksum_filtmat_poss_int_spikes')
        Ca_EEG_stats(1).ictal_high_perc_poss_int_spikes_over_time(1,i) = NaN;
        Ca_EEG_stats(1).ictal_low_perc_poss_int_spikes_over_time(1,i) = NaN;
    else
        if isempty(Ca_EEG_results(i).p_ranksum_filtmat_poss_int_spikes)
            Ca_EEG_stats(1).ictal_high_perc_poss_int_spikes_over_time(1,i) = NaN;
            Ca_EEG_stats(1).ictal_low_perc_poss_int_spikes_over_time(1,i) = NaN;
        else
            if Ca_EEG_results(i).p_ranksum_filtmat_poss_int_spikes == 0
                Ca_EEG_stats(1).ictal_high_perc_poss_int_spikes_over_time(1,i) = NaN;
                Ca_EEG_stats(1).ictal_low_perc_poss_int_spikes_over_time(1,i) = NaN;
            else
                nac = size(Ca_EEG_results(i).p_ranksum_filtmat_poss_int_spikes,2);
                if Ca_EEG_results(i).ictal_high_ranksum_filtmat_poss_int_spikes == 0
                    Ca_EEG_stats(1).ictal_high_perc_poss_int_spikes_over_time(1,i) = 0;
                else
                    Ca_EEG_stats(i).ictal_high_perc_poss_int_spikes =...
                        100*size(Ca_EEG_results(i).ictal_high_ranksum_filtmat_poss_int_spikes,1)/nac;
                    Ca_EEG_stats(1).ictal_high_perc_poss_int_spikes_over_time(1,i) = Ca_EEG_stats(i).ictal_high_perc_poss_int_spikes;
                end
                if Ca_EEG_results(i).ictal_low_ranksum_filtmat_poss_int_spikes == 0
                    Ca_EEG_stats(1).ictal_low_perc_poss_int_spikes_over_time(1,i) = 0;
                else
                    Ca_EEG_stats(i).ictal_low_perc_poss_int_spikes =...
                        100*size(Ca_EEG_results(i).ictal_low_ranksum_filtmat_poss_int_spikes,1)/nac;
                    Ca_EEG_stats(1).ictal_low_perc_poss_int_spikes_over_time(1,i) = Ca_EEG_stats(i).ictal_low_perc_poss_int_spikes;
                end
            end
        end
    end
end
%identify and concatenate interictal periods if there were microseizures,
%then also exclude running and/or whisking if needed:

cd(Folder_master)
save workspace_all_recordingss.mat -v7.3
ms = microseiz_summary_no_run_no_whisk;
ms_row_to_replace = [];
replace_with_straight_ms = 1

cd(Folder_master)
save recording_cnmf_rerun.mat -v7.3

for iii = 1:size(subfolders,2)
    if isempty( ms(iii).no_ms_analysis_possible)
         ms(iii).no_ms_analysis_possible=0;
    end
    if isempty(recording(iii).suite2p_deconv) || ms(iii).no_ms_analysis_possible
    else
        if initial.no_imaging(1,iii) || size(recording(iii).suite2p_deconv.sp,2)<10
        else
            spor=0;
            if isfield(ms(iii),'num_ms')
                if isempty(ms(iii).num_ms)
                    spor = 1;
                end
            else
                spor=1;
            end
            if spor
                just_split_in_half(1,iii) = 1; %= [1,1,1,1,1,1,1,0,1,1];
                interp = ms(iii).ernoiv_final;% recording(iii).EEG_results_nonoise.oopsi_interp_values;
                mls = size(interp,1)/100 %size(recording(iii).EEG_results_nonoise.oopsi_interp_values,1)/100;
                corr_beg_sec_1(1,iii) = 1;
                corr_end_sec_1(1,iii) = round(mls/2.05);
                corr_beg_sec_2(1,iii) = round(mls/2);
                corr_end_sec_2(1,iii) = round(mls/1.05);
                beg_sec_prez(1,iii) = corr_beg_sec_1(1,iii); %[1,1,1,1];
                end_sec_prez(1,iii) = corr_beg_sec_1(1,iii) +60; %[60,60 ,60 ,60];
                beg_sec_postz(1,iii) = corr_beg_sec_2(1,iii); %[1302 ,1140 ,400 ,600];
                end_sec_postz(1,iii) = corr_beg_sec_2(1,iii) + 60;
                shuf_iters = 10000
                close all
                sf=1
                excl_running=1;
                excl_whisking=1;
                minds = ms(iii).mean2min_inds;
                interpolate_whisking_to_100Hz = 0;
                cluster_results = clustering_one_rec(recording,Folder_master,subfolders,corr_beg_sec_1,corr_end_sec_1,...
                    corr_beg_sec_2,corr_end_sec_2,beg_sec_prez,end_sec_prez,beg_sec_postz,end_sec_postz,'all',0,0,shuf_iters,sf,iii,...
                    excl_running,excl_whisking,interpolate_whisking_to_100Hz,wheel_thr,interp,rd);
                recording(iii).cluster_results = cluster_results;
            else
                if ms(iii).num_ms == 0
                    interp = ms(iii).ernoiv_final;
                    just_split_in_half(1,iii) = 1; %= [1,1,1,1,1,1,1,0,1,1];
                    mls = size(interp,1)/100 %size(recording(iii).EEG_results_nonoise.oopsi_interp_values,1)/100;
                    corr_beg_sec_1(1,iii) = 1;
                    corr_end_sec_1(1,iii) = round(mls/2.05);
                    corr_beg_sec_2(1,iii) = round(mls/2);
                    corr_end_sec_2(1,iii) = round(mls/1.05);
                    beg_sec_prez(1,iii) = corr_beg_sec_1(1,iii); %[1,1,1,1];
                    end_sec_prez(1,iii) = corr_beg_sec_1(1,iii) +60; %[60,60 ,60 ,60];
                    beg_sec_postz(1,iii) = corr_beg_sec_2(1,iii); %[1302 ,1140 ,400 ,600];
                    end_sec_postz(1,iii) = corr_beg_sec_2(1,iii) + 60;
                    shuf_iters = 10000
                    close all
                    sf=1
                    excl_running=1;
                    excl_whisking=1;
                    interpolate_whisking_to_100Hz = 0;
                    cluster_results = clustering_one_rec_20230201(recording,Folder_master,subfolders,corr_beg_sec_1,corr_end_sec_1,...
                        corr_beg_sec_2,corr_end_sec_2,beg_sec_prez,end_sec_prez,beg_sec_postz,end_sec_postz,'all',0,0,shuf_iters,sf,iii,...
                        excl_running,excl_whisking,interpolate_whisking_to_100Hz,wheel_thr,interp,0,0,0,rd,0,0);
                    recording(iii).cluster_results = cluster_results;
                else
                    interp = ms(iii).ernoiv_final;
                    mls = size(interp,1)/100 %size(recording(iii).EEG_results_nonoise.oopsi_interp_values,1)/100;
                    just_split_in_half(1,iii) = 0;
                    %split into the different interictal periods
                    a = 1; %number of the interictal period, has to be at least 1 min(?)
                    for jjj = 1:ms(iii).num_ms
                        mss = ms(iii).microseiz(jjj).start;
                        mse = ms(iii).microseiz(jjj).end;
                        if jjj == 1
                            %consider pre-ictal AND postictal periods
                            if mss > 7000
                                interictal_period_start(1,a) = 1;
                                interictal_period_end(1,a) = mss-1000;
                                a=a+1;
                                if ms(iii).num_ms == 1
                                    interictal_period_start(1,a) = mse+1000;
                                    interictal_period_end(1,a) = size(ms(iii).curr_synchr,1)-1000;
                                else
                                    interictal_period_start(1,a) = mse+1000;
                                    interictal_period_end(1,a) = ms(iii).microseiz(jjj+1).start-1000;
                                    a=a+1;
                                end
                            else
                                if ms(iii).num_ms == 1
                                    interictal_period_start(1,a) = mse+1000;
                                    %interictal_period_end(1,a) = size(ms(iii).curr_synchr,1)-1000;
                                    
                                    %add second interictal period here
                                    interictal_period_end(1,2) = round(mls*100/1.05);
                                    interictal_period_start(1,2) = round(((mls*100/1.05)+mse+1000)/2)*1.05;
                                    interictal_period_end(1,1) = round(((mls*100/1.05)+mse+1000)/2)*0.95;
                                else
                                    interictal_period_start(1,a) = mse+1000;
                                    interictal_period_end(1,a) = ms(iii).microseiz(jjj+1).start-1000;
                                    a=a+1;
                                end
                            end
                        else
                            if jjj == ms(iii).num_ms
                                interictal_period_start(1,a) = mse+1000;
                                interictal_period_end(1,a) = size(ms(iii).curr_synchr,1)-1000;
                            else
                                interictal_period_start(1,a) = mse+1000;
                                interictal_period_end(1,a) = ms(iii).microseiz(jjj+1).start-1000;
                                a=a+1;
                            end
                        end
                    end
                    %identify the two longest interictal periods
                    interictal_periods_durations = interictal_period_end-interictal_period_start;
                    [int_per_sort_durs, int_pers_sortd] = sort(interictal_periods_durations,'descend');
                    corr_beg_sec_1(1,iii) = ceil((interictal_period_start(1,int_pers_sortd(1,1))+500)/100);
                    corr_end_sec_1(1,iii) = ceil((interictal_period_end(1,int_pers_sortd(1,1))-500)/100);
                    corr_beg_sec_2(1,iii) = ceil((interictal_period_start(1,int_pers_sortd(1,2))+500)/100);
                    corr_end_sec_2(1,iii) = ceil((interictal_period_end(1,int_pers_sortd(1,2))-500)/100);
                    beg_sec_prez(1,iii) = corr_beg_sec_1(1,iii); %[1,1,1,1];
                    end_sec_prez(1,iii) = corr_beg_sec_1(1,iii) +60; %[60,60 ,60 ,60];
                    beg_sec_postz(1,iii) = corr_beg_sec_2(1,iii); %[1302 ,1140 ,400 ,600];
                    end_sec_postz(1,iii) = corr_beg_sec_2(1,iii) + 60;
                    %now remove running and whisking periods for the interictal periods
                    %and then run clustering
                    shuf_iters = 10000
                    close all
                    sf=1
                    excl_running=1;
                    excl_whisking=1;
                    interpolate_whisking_to_100Hz = 0;
                    cluster_results = clustering_one_rec(recording,Folder_master,subfolders,corr_beg_sec_1,corr_end_sec_1,...
                        corr_beg_sec_2,corr_end_sec_2,beg_sec_prez,end_sec_prez,beg_sec_postz,end_sec_postz,'all',0,0,shuf_iters,sf,iii,...
                        excl_running,excl_whisking,interpolate_whisking_to_100Hz,wheel_thr,interp,rd);
                    recording(iii).cluster_results = cluster_results;
                end
            end
        end
    end
end

for iii = 1:size(recording,2)
    cluster_summary(iii).cluster_results = recording(iii).cluster_results;
end
cd(Folder_master)
save cluster_summary.mat cluster_summary -v7.3


animal_ID = xxxx
L23 = 0
L4 = 0;
Cr86 = 1;
GPC6 = 0;
IGSF3 = 0;
xCT_KO = 0;
control = 0;
barea = xxxx;
brainarea = 'xxxx';

EEG_segs_not_run_yet=1
multiple_recs_in_one_day_present = 0
%here we visualize and run basic stats
%If you have multiple brain areas in one recording structure and need to
%split up:
start_w_rec = 1
barea_rec_start = start_w_rec
num_recs_to_process =1
onep_binned_twice=0

%or if analyzed multiple brain areas inside one date folder
%run this part only once
recording_all = recording; %(only first time!)
All_EEGs_all = All_EEGs;
EEG_segs_all = EEG_segs;
ms_all = ms;
%%%
barea_rec_start=1
recording = recording_all(barea_rec_start);
All_EEGs = All_EEGs_all(barea_rec_start);
EEG_segs = EEG_segs_all(barea_rec_start);
ms = ms_all(barea_rec_start);
%cluster cell transparency (1 =  opaque, higher = transparent (normal = 1.7)
cell_alpha_mult = 1
%cluster line transparency (normal = ~0.4)
transpline = 0

summarizing_2p_20231123

further_analysis_excl_vis

summary_stats_and_plots_GPC6_Cr86_2p_no_vis



