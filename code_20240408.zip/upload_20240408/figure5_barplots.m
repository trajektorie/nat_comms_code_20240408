
close all
figure(45)
set(gcf,'color','white')

x = fig5_rev_20231106.both.below_or_above10to5_apm(:,2)
x(find(isnan(x)),:) = [];
xx = fig5_rev_20231106.both.below_or_above10to5_apm(:,4)
xx(find(isnan(xx)),:) = [];
y = fig5_rev_20231106.both.below_or_above10to5_apm(:,1)
y(find(isnan(y)),:) = [];
yy = fig5_rev_20231106.both.below_or_above10to5_apm(:,3)
yy(find(isnan(yy)),:) = [];

h=bar([median(x) median(y); median(xx) median(yy)]);
hold on
h(1).FaceColor='w';
h(1).LineWidth = 2;
h(1).EdgeColor = 'r';
pos = [std(x)/sqrt(length(x)) std(xx)/sqrt(length(xx))];
neg = [0 0]
errorbar(h(1).XEndPoints,[median(x) median(xx)],neg,pos,'LineStyle','none','Color','r','LineWidth',2)
hold on
h(2).FaceColor='w';
h(2).LineWidth = 2;
h(2).EdgeColor = 'b';
pos = [std(y)/sqrt(length(y)) std(yy)/sqrt(length(yy))];
neg = [0 0]
errorbar(h(2).XEndPoints,[median(y) median(yy)],neg,pos,'LineStyle','none','Color','b','LineWidth',2)
hold on

scatter(h(1).XEndPoints(1,1)*ones(size(x,2)),x,50,[0.4 0.4 0.4],'jitter','on','jitterAmount',0.05)
hold on
scatter(h(1).XEndPoints(1,2)*ones(size(xx,2)),xx,50,[0.4 0.4 0.4],'jitter','on','jitterAmount',0.05)
hold on
scatter(h(2).XEndPoints(1,1)*ones(size(y,2)),y,50,[0.4 0.4 0.4],'jitter','on','jitterAmount',0.05)
hold on
scatter(h(2).XEndPoints(1,2)*ones(size(yy,2)),yy,50,[0.4 0.4 0.4],'jitter','on','jitterAmount',0.05)
hold on

set(gca, 'YScale', 'log')
set(gca, 'YLim', [0.1 40])
set(gca,'FontSize',24)
set(gca,'FontName','Arial')

saveas(45,['vnear_to_midfar_ratio_medianerrorbars_values_apm_10tothe5_Cr86_v_GPC6' '.pdf'], 'pdf')
saveas(45,['vnear_to_midfar_ratio_medianerrorbars_values_apm_10tothe5_Cr86_v_GPC6' '.emf'], 'emf')
saveas(45,['vnear_to_midfar_ratio_medianerrorbars_values_apm_10tothe5_Cr86_v_GPC6' '.svg'], 'svg')
saveas(45,['vnear_to_midfar_ratio_medianerrorbars_values_apm_10tothe5_Cr86_v_GPC6' '.tif'], 'tif')



close all
figure(450)
set(gcf,'color','white')

x = fig5_rev_20231106.both.below_or_above10to5_eps(:,2)
x(find(isnan(x)),:) = [];
xx = fig5_rev_20231106.both.below_or_above10to5_eps(:,4)
xx(find(isnan(xx)),:) = [];
y = fig5_rev_20231106.both.below_or_above10to5_eps(:,1)
y(find(isnan(y)),:) = [];
yy = fig5_rev_20231106.both.below_or_above10to5_eps(:,3)
yy(find(isnan(yy)),:) = [];

h=bar([median(x) median(y); median(xx) median(yy)]);
hold on
h(1).FaceColor='w';
h(1).LineWidth = 2;
h(1).EdgeColor = 'r';
pos = [std(x)/sqrt(length(x)) std(xx)/sqrt(length(xx))];
neg = [0 0]
errorbar(h(1).XEndPoints,[median(x) median(xx)],neg,pos,'LineStyle','none','Color','r','LineWidth',2)
hold on
h(2).FaceColor='w';
h(2).LineWidth = 2;
h(2).EdgeColor = 'b';
pos = [std(y)/sqrt(length(y)) std(yy)/sqrt(length(yy))];
neg = [0 0]
errorbar(h(2).XEndPoints,[median(y) median(yy)],neg,pos,'LineStyle','none','Color','b','LineWidth',2)
hold on

scatter(h(1).XEndPoints(1,1)*ones(size(x,2)),x,50,[0.4 0.4 0.4],'jitter','on','jitterAmount',0.05)
hold on
scatter(h(1).XEndPoints(1,2)*ones(size(xx,2)),xx,50,[0.4 0.4 0.4],'jitter','on','jitterAmount',0.05)
hold on
scatter(h(2).XEndPoints(1,1)*ones(size(y,2)),y,50,[0.4 0.4 0.4],'jitter','on','jitterAmount',0.05)
hold on
scatter(h(2).XEndPoints(1,2)*ones(size(yy,2)),yy,50,[0.4 0.4 0.4],'jitter','on','jitterAmount',0.05)
hold on

set(gca, 'YScale', 'log')
set(gca, 'YLim', [0.1 66])
set(gca,'FontSize',24)
set(gca,'FontName','Arial')

saveas(450,['vnear_to_midfar_ratio_medianerrorbars_values_eps_10tothe5_Cr86_v_GPC6' '.pdf'], 'pdf')
saveas(450,['vnear_to_midfar_ratio_medianerrorbars_values_eps_10tothe5_Cr86_v_GPC6' '.emf'], 'emf')
saveas(450,['vnear_to_midfar_ratio_medianerrorbars_values_eps_10tothe5_Cr86_v_GPC6' '.svg'], 'svg')
saveas(450,['vnear_to_midfar_ratio_medianerrorbars_values_eps_10tothe5_Cr86_v_GPC6' '.tif'], 'tif')



close all
figure(550)
set(gcf,'color','white')

x = fig5_rev_20231106.both.below_or_above10to5_dur(:,2)
x(find(isnan(x)),:) = [];
xx = fig5_rev_20231106.both.below_or_above10to5_dur(:,4)
xx(find(isnan(xx)),:) = [];
y = fig5_rev_20231106.both.below_or_above10to5_dur(:,1)
y(find(isnan(y)),:) = [];
yy = fig5_rev_20231106.both.below_or_above10to5_dur(:,3)
yy(find(isnan(yy)),:) = [];

h=bar([median(x) median(y); median(xx) median(yy)]);
hold on
h(1).FaceColor='w';
h(1).LineWidth = 2;
h(1).EdgeColor = 'r';
pos = [std(x)/sqrt(length(x)) std(xx)/sqrt(length(xx))];
neg = [0 0]
errorbar(h(1).XEndPoints,[median(x) median(xx)],neg,pos,'LineStyle','none','Color','r','LineWidth',2)
hold on
h(2).FaceColor='w';
h(2).LineWidth = 2;
h(2).EdgeColor = 'b';
pos = [std(y)/sqrt(length(y)) std(yy)/sqrt(length(yy))];
neg = [0 0]
errorbar(h(2).XEndPoints,[median(y) median(yy)],neg,pos,'LineStyle','none','Color','b','LineWidth',2)
hold on

scatter(h(1).XEndPoints(1,1)*ones(size(x,2)),x,50,[0.4 0.4 0.4],'jitter','on','jitterAmount',0.05)
hold on
scatter(h(1).XEndPoints(1,2)*ones(size(xx,2)),xx,50,[0.4 0.4 0.4],'jitter','on','jitterAmount',0.05)
hold on
scatter(h(2).XEndPoints(1,1)*ones(size(y,2)),y,50,[0.4 0.4 0.4],'jitter','on','jitterAmount',0.05)
hold on
scatter(h(2).XEndPoints(1,2)*ones(size(yy,2)),yy,50,[0.4 0.4 0.4],'jitter','on','jitterAmount',0.05)
hold on

set(gca, 'YScale', 'log')
set(gca, 'YLim', [0.1 10])
set(gca,'FontSize',24)
set(gca,'FontName','Arial')

saveas(550,['vnear_to_midfar_ratio_medianerrorbars_values_dur_10tothe5_Cr86_v_GPC6' '.pdf'], 'pdf')
saveas(550,['vnear_to_midfar_ratio_medianerrorbars_values_dur_10tothe5_Cr86_v_GPC6' '.emf'], 'emf')
saveas(550,['vnear_to_midfar_ratio_medianerrorbars_values_dur_10tothe5_Cr86_v_GPC6' '.svg'], 'svg')
saveas(550,['vnear_to_midfar_ratio_medianerrorbars_values_dur_10tothe5_Cr86_v_GPC6' '.tif'], 'tif')



close all
figure(555)
set(gcf,'color','white')

x = fig5_rev_20231106.both.below_or_above10to5_amp(:,2)
x(find(isnan(x)),:) = [];
xx = fig5_rev_20231106.both.below_or_above10to5_amp(:,4)
xx(find(isnan(xx)),:) = [];
y = fig5_rev_20231106.both.below_or_above10to5_amp(:,1)
y(find(isnan(y)),:) = [];
yy = fig5_rev_20231106.both.below_or_above10to5_amp(:,3)
yy(find(isnan(yy)),:) = [];

h=bar([median(x) median(y); median(xx) median(yy)]);
hold on
h(1).FaceColor='w';
h(1).LineWidth = 2;
h(1).EdgeColor = 'r';
pos = [std(x)/sqrt(length(x)) std(xx)/sqrt(length(xx))];
neg = [0 0]
errorbar(h(1).XEndPoints,[median(x) median(xx)],neg,pos,'LineStyle','none','Color','r','LineWidth',2)
hold on
h(2).FaceColor='w';
h(2).LineWidth = 2;
h(2).EdgeColor = 'b';
pos = [std(y)/sqrt(length(y)) std(yy)/sqrt(length(yy))];
neg = [0 0]
errorbar(h(2).XEndPoints,[median(y) median(yy)],neg,pos,'LineStyle','none','Color','b','LineWidth',2)
hold on
scatter(h(1).XEndPoints(1,1)*ones(size(x,2)),x,50,[0.4 0.4 0.4],'jitter','on','jitterAmount',0.05)
hold on
scatter(h(1).XEndPoints(1,2)*ones(size(xx,2)),xx,50,[0.4 0.4 0.4],'jitter','on','jitterAmount',0.05)
hold on
scatter(h(2).XEndPoints(1,1)*ones(size(y,2)),y,50,[0.4 0.4 0.4],'jitter','on','jitterAmount',0.05)
hold on
scatter(h(2).XEndPoints(1,2)*ones(size(yy,2)),yy,50,[0.4 0.4 0.4],'jitter','on','jitterAmount',0.05)
hold on

set(gca, 'YScale', 'log')
set(gca, 'YLim', [0.1 10])
set(gca,'FontSize',24)
set(gca,'FontName','Arial')

saveas(555,['vnear_to_midfar_ratio_medianerrorbars_values_amp_10tothe5_Cr86_v_GPC6' '.pdf'], 'pdf')
saveas(555,['vnear_to_midfar_ratio_medianerrorbars_values_amp_10tothe5_Cr86_v_GPC6' '.emf'], 'emf')
saveas(555,['vnear_to_midfar_ratio_medianerrorbars_values_amp_10tothe5_Cr86_v_GPC6' '.svg'], 'svg')
saveas(555,['vnear_to_midfar_ratio_medianerrorbars_values_amp_10tothe5_Cr86_v_GPC6' '.tif'], 'tif')



close all
figure(655)
set(gcf,'color','white')

x = fig5_rev_20231106.both.below_or_above10to5_are(:,2)
x(find(isnan(x)),:) = [];
xx = fig5_rev_20231106.both.below_or_above10to5_are(:,4)
xx(find(isnan(xx)),:) = [];
y = fig5_rev_20231106.both.below_or_above10to5_are(:,1)
y(find(isnan(y)),:) = [];
yy = fig5_rev_20231106.both.below_or_above10to5_are(:,3)
yy(find(isnan(yy)),:) = [];

h=bar([median(x) median(y); median(xx) median(yy)]);
hold on
h(1).FaceColor='w';
h(1).LineWidth = 2;
h(1).EdgeColor = 'r';
pos = [std(x)/sqrt(length(x)) std(xx)/sqrt(length(xx))];
neg = [0 0]
errorbar(h(1).XEndPoints,[median(x) median(xx)],neg,pos,'LineStyle','none','Color','r','LineWidth',2)
hold on
h(2).FaceColor='w';
h(2).LineWidth = 2;
h(2).EdgeColor = 'b';
pos = [std(y)/sqrt(length(y)) std(yy)/sqrt(length(yy))];
neg = [0 0]
errorbar(h(2).XEndPoints,[median(y) median(yy)],neg,pos,'LineStyle','none','Color','b','LineWidth',2)
hold on


scatter(h(1).XEndPoints(1,1)*ones(size(x,2)),x,50,[0.4 0.4 0.4],'jitter','on','jitterAmount',0.05)
hold on
scatter(h(1).XEndPoints(1,2)*ones(size(xx,2)),xx,50,[0.4 0.4 0.4],'jitter','on','jitterAmount',0.05)
hold on
scatter(h(2).XEndPoints(1,1)*ones(size(y,2)),y,50,[0.4 0.4 0.4],'jitter','on','jitterAmount',0.05)
hold on
scatter(h(2).XEndPoints(1,2)*ones(size(yy,2)),yy,50,[0.4 0.4 0.4],'jitter','on','jitterAmount',0.05)
hold on

set(gca, 'YScale', 'log')
set(gca, 'YLim', [0.1 30])
set(gca,'FontSize',24)
set(gca,'FontName','Arial')

saveas(655,['vnear_to_midfar_ratio_medianerrorbars_values_are_10tothe5_Cr86_v_GPC6' '.pdf'], 'pdf')
saveas(655,['vnear_to_midfar_ratio_medianerrorbars_values_are_10tothe5_Cr86_v_GPC6' '.emf'], 'emf')
saveas(655,['vnear_to_midfar_ratio_medianerrorbars_values_are_10tothe5_Cr86_v_GPC6' '.svg'], 'svg')
saveas(655,['vnear_to_midfar_ratio_medianerrorbars_values_are_10tothe5_Cr86_v_GPC6' '.tif'], 'tif')


close all
figure(755)
set(gcf,'color','white')

x = fig5_rev_20231106.both.below_or_above10to5_rhy(:,2)
x(find(isnan(x)),:) = [];
xx = fig5_rev_20231106.both.below_or_above10to5_rhy(:,4)
xx(find(isnan(xx)),:) = [];
y = fig5_rev_20231106.both.below_or_above10to5_rhy(:,1)
y(find(isnan(y)),:) = [];
yy = fig5_rev_20231106.both.below_or_above10to5_rhy(:,3)
yy(find(isnan(yy)),:) = [];

h=bar([median(x) median(y); median(xx) median(yy)]);
hold on
h(1).FaceColor='w';
h(1).LineWidth = 2;
h(1).EdgeColor = 'r';
pos = [std(x)/sqrt(length(x)) std(xx)/sqrt(length(xx))];
neg = [0 0]
errorbar(h(1).XEndPoints,[median(x) median(xx)],neg,pos,'LineStyle','none','Color','r','LineWidth',2)
hold on
h(2).FaceColor='w';
h(2).LineWidth = 2;
h(2).EdgeColor = 'b';
pos = [std(y)/sqrt(length(y)) std(yy)/sqrt(length(yy))];
neg = [0 0]
errorbar(h(2).XEndPoints,[median(y) median(yy)],neg,pos,'LineStyle','none','Color','b','LineWidth',2)
hold on

scatter(h(1).XEndPoints(1,1)*ones(size(x,2)),x,50,[0.4 0.4 0.4],'jitter','on','jitterAmount',0.05)
hold on
scatter(h(1).XEndPoints(1,2)*ones(size(xx,2)),xx,50,[0.4 0.4 0.4],'jitter','on','jitterAmount',0.05)
hold on
scatter(h(2).XEndPoints(1,1)*ones(size(y,2)),y,50,[0.4 0.4 0.4],'jitter','on','jitterAmount',0.05)
hold on
scatter(h(2).XEndPoints(1,2)*ones(size(yy,2)),yy,50,[0.4 0.4 0.4],'jitter','on','jitterAmount',0.05)
hold on

set(gca, 'YScale', 'log')
set(gca, 'YLim', [0.1 2])
set(gca,'FontSize',24)
set(gca,'FontName','Arial')

saveas(755,['vnear_to_midfar_ratio_medianerrorbars_values_rhy_10tothe5_Cr86_v_GPC6' '.pdf'], 'pdf')
saveas(755,['vnear_to_midfar_ratio_medianerrorbars_values_rhy_10tothe5_Cr86_v_GPC6' '.emf'], 'emf')
saveas(755,['vnear_to_midfar_ratio_medianerrorbars_values_rhy_10tothe5_Cr86_v_GPC6' '.svg'], 'svg')
saveas(755,['vnear_to_midfar_ratio_medianerrorbars_values_rhy_10tothe5_Cr86_v_GPC6' '.tif'], 'tif')



