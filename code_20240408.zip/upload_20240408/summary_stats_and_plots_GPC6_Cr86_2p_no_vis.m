

clear group



group(7).animals = [70,75,73,72,74];
group(7).bareas_to_include = [1,1,1,1,1];
group(7).ages=[42,42,41,42,43];
group(7).layers = {'L23'; 'L23'; 'L23'; 'L23';'L23'};
group(7).num_ROIs = [220,52,278,268,107];      

group(9).animals = [72,73,75,71];
group(9).bareas_to_include = [2,2,2,3];
group(9).ages=[42,46,53,46];
group(9).layers = {'L23'; 'L23'; 'L23';'L23'};
group(9).num_ROIs = [60,128,140,191];     
group(9).prom = ['CaMKIIα', 'CaMKIIα', 'CaMKIIα', 'CaMKIIα']


%GPC6_mid
group(1).animals = [73,72,71,75,70];
group(1).bareas_to_include = [1,1,1,1,1]
group(1).ages = [50,54,56,54,55]
group(1).layers = {'L23'; 'L23'; 'L23'; 'L23';'L23'};
group(1).num_ROIs = [330,164,352,105,183];     
group(1).prom = ['CaMKIIα', 'CaMKIIα', 'CaMKIIα', 'CaMKIIα', 'CaMKIIα']


%GPC6_late
group(2).animals = [73,71, 70, 72];
group(2).bareas_to_include = [1,1,2,3]
group(2).ages = [75,68,70,82]
group(2).layers = {'L23'; 'L23';'L23'; 'L23'};
group(2).num_ROIs = [105,292,65,158];      
group(2).prom = ['CaMKIIα', 'CaMKIIα','CaMKIIα', 'CaMKIIα']

group(8).animals = [38,85,86,37];
group(8).bareas_to_include = [2,2,4,1];
group(8).ages=[49,44,46,43];
group(8).layers = {'L23'; 'L23'; 'L23'; 'L23'};
group(8).num_ROIs = [352,104,96,388];     
group(8).prom = ['thy1', 'CaMKIIα', 'CaMKIIα', 'thy1']

group(10).animals = [38,40,85,86];
group(10).bareas_to_include = [3,1,4,5];
group(10).ages=[55,62,49,58];
group(10).layers = {'L23'; 'L23'; 'L23'; 'L23'; 'L23'};
group(10).num_ROIs = [168,367,83,40];
group(10).prom = ['thy1', 'thy1', 'CaMKIIα', 'CaMKIIα']

%Cr86_mid
group(3).animals = [84,85,86,40,38];
group(3).bareas_to_include = [2,3,2,2,1]
group(3).ages = [56,50,54,56,55];
group(3).layers = {'L23'; 'L23';'L23';'L23';'L23'};
group(3).num_ROIs = [169,211,144,130,285];
group(3).prom = ['CaMKIIα', 'CaMKIIα', 'CaMKIIα', 'thy1', 'thy1']


%Cr86_late
group(4).animals = [86,40,28,38];
group(4).bareas_to_include = [1,1,1,4]
group(4).ages = [70,86,97,99]
group(4).layers = {'L23'; 'L23'; 'L23'; 'L23'; 'L23'};
group(4).num_ROIs = [141,420,225,176];      
group(4).prom = ['thy1', 'thy1', 'thy1', 'CaMKIIα']

%control early
group(5).animals = [92,98,104,93]
group(5).bareas_to_include = [2,1,2,2]
group(5).ages = [50,57,59,46]
group(5).layers = {'L23'; 'L23'; 'L23'; 'L23'}
group(5).num_ROIs = [106,98,238,236]
group(5).prom = ['SNAP-25', 'syn', 'thy1+Vgat', 'thy1+Vgat']

%control late
group(6).animals = [101,104,99,102,103]
group(6).bareas_to_include = [1,2,3,1,1]
group(6).ages = [129,83,120,80,99]
group(6).layers = {'L23'; 'L23'; 'L23'; 'L23'; 'L23'}
group(6).num_ROIs = [136,245,190,312,236]
group(5).prom = ['thy1+Vgat', 'thy1+Vgat', 'thy1', 'syn', 'syn']


%group 11 = 3 + 8 combined to match age distribution with the "inside
%margin" data
group(11).animals = [84,38,86,40,38];
group(11).bareas_to_include = [2,2,2,2,1]
group(11).ages = [56,49,54,56,55];
group(11).layers = {'L23'; 'L23';'L23';'L23';'L23'};
group(11).num_ROIs = [169,352,144,130,285];
group(11).prom = ['CaMKIIα', 'thy1', 'CaMKIIα', 'thy1', 'thy1']




%group 12 = 1 + 7 combined to match age distribution with the "inside
%margin" data
group(12).animals = [73,72,72,75,74];
group(12).bareas_to_include = [1,1,1,1,1]
group(12).ages = [50,54,42,54,43]
group(12).layers = {'L23'; 'L23'; 'L23'; 'L23';'L23'};
group(12).num_ROIs = [330,164,268,105,107];      
group(12).prom = ['CaMKIIα', 'CaMKIIα', 'CaMKIIα', 'CaMKIIα', 'CaMKIIα']



clear stat_summary a_s
a=1
b=1
c=1
d=1
x=1
y=1
min_ROI_nums = [105,65,130,140,98,80,52,96,60,40,130,105]
%counter 1: all groups
for k = 1: size(group,2)
    %counter 2: reset for each group
    x=1
    y=1
    z=1

    for l = 1:size(group(k).animals,2)
        for m = group(k).bareas_to_include(1,l)
            if strcmp(group(k).layers{l,1},'L23')
                clear fc
                ass = size(tumor_animal(group(k).animals(1,l)).L23(m).all_summary,2)
                for der = 1:ass
                    if group(k).animals(1,l)==102
                        if group(k).ages(1,l) == tumor_animal(group(k).animals(1,l)).L23(m).all_summary{der}.days_of_TeT
                            fc = der
                        end
                    else
                        if group(k).ages(1,l) == tumor_animal(group(k).animals(1,l)).L23(m).all_summary(der).days_of_TeT
                            fc = der
                        end
                    end
                end
                a_s = tumor_animal(group(k).animals(1,l)).L23(m).all_summary(fc);
                if group(k).animals(1,l)==102
                    a_s_str = a_s;
                    clear a_s
                    a_s.mean_DF = a_s_str{1,1}.mean_DF;
                    a_s.cluster_summary = a_s_str{1,1}.cluster_summary;
                end
                a_s_no_vis = tumor_animal_no_vis_DF_params(group(k).animals(1,l)).L23(m).all_summary(fc).no_run_no_whisk;

                if isfield(a_s,'mean_DF')
                    scs = size(a_s.mean_DF,1)-10
                else
                    scs = size(a_s_no_vis.mean_DF,1)-10
                end
                if size(a_s.cluster_summary,2)==1
                    fc=1
                end
                scd = size(a_s.cluster_summary(fc).cluster_results(fc).clust_results.clustering_pre_BCtb,1)

                scss = min(scs,min_ROI_nums(1,k))
                if scss<min_ROI_nums(1,k)
                    scaa = 1:scss
                else
                    scaa = randi(scs,1,scss);
                end
                stat_summary(k).cell_mean_DF(x:x+scss-1 ,1) = a_s_no_vis.mean_DF(scaa,1);
                stat_summary(k).mean_mean_DF(1,l) = a_s_no_vis.mean_mean_DF;
                stat_summary(k).cell_events_per_sec(x:x+scss-1 ,1) = a_s_no_vis.events_per_sec(scaa,1);
                stat_summary(k).mean_events_per_sec(1,l) = a_s_no_vis.mean_events_per_sec;
                stat_summary(k).cell_mean_event_length_ms(x:x+scss-1 ,1) = a_s_no_vis.mean_event_length_ms(scaa,1);
                stat_summary(k).mean_mean_event_length_ms(1,l) = a_s_no_vis.mean_mean_event_length_ms;
                stat_summary(k).cell_mean_event_amplitude(x:x+scss-1 ,1) = a_s_no_vis.mean_event_amplitude(scaa,1);
                stat_summary(k).mean_mean_event_amplitude(1,l) = a_s_no_vis.mean_mean_event_amplitude;
                stat_summary(k).cell_clustering_pre_BCtb(y:y+scss-1,1) = a_s.cluster_summary(fc).cluster_results(fc).clust_results.clustering_pre_BCtb(scaa,1);
                stat_summary(k).NP_mean_DF(z:z+9 ,1) = a_s_no_vis.mean_DF(scs+1:scs+10,1);
                stat_summary(k).NP_events_per_sec(z:z+9 ,1) = a_s_no_vis.events_per_sec(scs+1:scs+10,1);
                stat_summary(k).NP_mean_event_length_ms(z:z+9  ,1) = a_s_no_vis.mean_event_length_ms(scs+1:scs+10,1);
                stat_summary(k).NP_mean_event_amplitude(z:z+9 ,1) = a_s_no_vis.mean_event_amplitude(scs+1:scs+10,1);

                x=x+scss;
                y=y+scss;
                z=z+10;


            else
                a_s = tumor_animal(group(k).animals(1,l)).L4(m).all_summary;
            end
        end
    end
end


%DF/min
close all
rev_stats.both.apm_early_mid_late_mat2(1:200,1) = randsample(stat_summary(8).cell_mean_DF,200);
rev_stats.both.apm_early_mid_late_mat2(1:200,2) = randsample(stat_summary(3).cell_mean_DF,200)
rev_stats.both.apm_early_mid_late_mat2(1:200,3) = randsample(stat_summary(4).cell_mean_DF,200)
rev_stats.both.apm_early_mid_late_mat2(1:200,4) = randsample(stat_summary(7).cell_mean_DF,200);
rev_stats.both.apm_early_mid_late_mat2(1:200,5) = randsample(stat_summary(1).cell_mean_DF,200)
rev_stats.both.apm_early_mid_late_mat2(1:200,6) = randsample(stat_summary(2).cell_mean_DF,200)

[p,tbl,statsi] = kruskalwallis(rev_stats.both.apm_early_mid_late_mat2)
[comparison,means,H,gnames1] = multcompare(statsi);
rev_stats.both.apm_early_mid_late_mat2_stats.anova_p = p;
rev_stats.both.apm_early_mid_late_mat2_stats.anova_tab = tbl;
rev_stats.both.apm_early_mid_late_mat2_stats.mult_comparison = comparison;
rev_stats.both.apm_early_mid_late_mat2_stats.mult_means = means;
rev_stats.both.apm_early_mid_late_mat2_stats.stats1 = statsi;

%same for eps
rev_stats.both.eps_early_mid_late_mat2(1:200,1) = randsample(stat_summary(8).cell_events_per_sec,200);
rev_stats.both.eps_early_mid_late_mat2(1:200,2) = randsample(stat_summary(3).cell_events_per_sec,200)
rev_stats.both.eps_early_mid_late_mat2(1:200,3) = randsample(stat_summary(4).cell_events_per_sec,200)
rev_stats.both.eps_early_mid_late_mat2(1:200,4) = randsample(stat_summary(7).cell_events_per_sec,200);
rev_stats.both.eps_early_mid_late_mat2(1:200,5) = randsample(stat_summary(1).cell_events_per_sec,200)
rev_stats.both.eps_early_mid_late_mat2(1:200,6) = randsample(stat_summary(2).cell_events_per_sec,200)

[p,tbl,statsi] = kruskalwallis(rev_stats.both.eps_early_mid_late_mat2)
[comparison,means,H,gnames1] = multcompare(statsi);
rev_stats.both.eps_early_mid_late_mat2_stats.anova_p = p;
rev_stats.both.eps_early_mid_late_mat2_stats.anova_tab = tbl;
rev_stats.both.eps_early_mid_late_mat2_stats.mult_comparison = comparison;
rev_stats.both.eps_early_mid_late_mat2_stats.mult_means = means;
rev_stats.both.eps_early_mid_late_mat2_stats.stats1 = statsi;

%same for dur
close all
rev_stats.both.dur_early_mid_late_mat2(1:200,1) = randsample(stat_summary(8).cell_mean_event_length_ms,200);
rev_stats.both.dur_early_mid_late_mat2(1:200,2) = randsample(stat_summary(3).cell_mean_event_length_ms,200)
rev_stats.both.dur_early_mid_late_mat2(1:200,3) = randsample(stat_summary(4).cell_mean_event_length_ms,200)
rev_stats.both.dur_early_mid_late_mat2(1:200,4) = randsample(stat_summary(7).cell_mean_event_length_ms,200);
rev_stats.both.dur_early_mid_late_mat2(1:200,5) = randsample(stat_summary(1).cell_mean_event_length_ms,200)
rev_stats.both.dur_early_mid_late_mat2(1:200,6) = randsample(stat_summary(2).cell_mean_event_length_ms,200)


[p,tbl,statsi] = kruskalwallis(rev_stats.both.dur_early_mid_late_mat2)
[comparison,means,H,gnames1] = multcompare(statsi);
rev_stats.both.dur_early_mid_late_mat2_stats.anova_p = p;
rev_stats.both.dur_early_mid_late_mat2_stats.anova_tab = tbl;
rev_stats.both.dur_early_mid_late_mat2_stats.mult_comparison = comparison;
rev_stats.both.dur_early_mid_late_mat2_stats.mult_means = means;
rev_stats.both.dur_early_mid_late_mat2_stats.stats1 = statsi;

%same for amp
close all
rev_stats.both.amp_early_mid_late_mat2(1:200,1) = randsample(stat_summary(8).cell_mean_event_amplitude,200);
rev_stats.both.amp_early_mid_late_mat2(1:200,2) = randsample(stat_summary(3).cell_mean_event_amplitude,200)
rev_stats.both.amp_early_mid_late_mat2(1:200,3) = randsample(stat_summary(4).cell_mean_event_amplitude,200)
rev_stats.both.amp_early_mid_late_mat2(1:200,4) = randsample(stat_summary(7).cell_mean_event_amplitude,200);
rev_stats.both.amp_early_mid_late_mat2(1:200,5) = randsample(stat_summary(1).cell_mean_event_amplitude,200)
rev_stats.both.amp_early_mid_late_mat2(1:200,6) = randsample(stat_summary(2).cell_mean_event_amplitude,200)

[p,tbl,statsi] = kruskalwallis(rev_stats.both.amp_early_mid_late_mat2)
[comparison,means,H,gnames1] = multcompare(statsi);
rev_stats.both.amp_early_mid_late_mat2_stats.anova_p = p;
rev_stats.both.amp_early_mid_late_mat2_stats.anova_tab = tbl;
rev_stats.both.amp_early_mid_late_mat2_stats.mult_comparison = comparison;
rev_stats.both.amp_early_mid_late_mat2_stats.mult_means = means;
rev_stats.both.amp_early_mid_late_mat2_stats.stats1 = statsi;

%same for clus
close all
rev_stats.both.clus_early_mid_late_mat2(1:200,1) = randsample(stat_summary(8).cell_clustering_pre_BCtb,200);
rev_stats.both.clus_early_mid_late_mat2(1:200,2) = randsample(stat_summary(3).cell_clustering_pre_BCtb,200)
rev_stats.both.clus_early_mid_late_mat2(1:200,3) = randsample(stat_summary(4).cell_clustering_pre_BCtb,200)
rev_stats.both.clus_early_mid_late_mat2(1:200,4) = randsample(stat_summary(7).cell_clustering_pre_BCtb,200);
rev_stats.both.clus_early_mid_late_mat2(1:200,5) = randsample(stat_summary(1).cell_clustering_pre_BCtb,200)
rev_stats.both.clus_early_mid_late_mat2(1:200,6) = randsample(stat_summary(2).cell_clustering_pre_BCtb,200)

[p,tbl,statsi] = kruskalwallis(rev_stats.both.clus_early_mid_late_mat2)
[comparison,means,H,gnames1] = multcompare(statsi);
rev_stats.both.clus_early_mid_late_mat2_stats.anova_p = p;
rev_stats.both.clus_early_mid_late_mat2_stats.anova_tab = tbl;
rev_stats.both.clus_early_mid_late_mat2_stats.mult_comparison = comparison;
rev_stats.both.clus_early_mid_late_mat2_stats.mult_means = means;
rev_stats.both.clus_early_mid_late_mat2_stats.stats1 = statsi;


n = 200
q = 0.5
z = 1.96

j = round(n*q - z*sqrt(n*q*(1-q)))
k = round(n*q + z*sqrt(n*q*(1-q)))

close all
figure(1205)
set(gcf,'color','white')
x = rev_stats.both.apm_early_mid_late_mat2(:,1)
xsort = sort(x,'ascend')
jx = xsort(j,1)
kx = xsort(k,1)
x(find(isnan(x)),:) = [];
xx = rev_stats.both.apm_early_mid_late_mat2(:,4)
xxsort = sort(xx,'ascend')
jxx = xxsort(j,1)
kxx = xxsort(k,1)
xx(find(isnan(xx)),:) = [];
y = rev_stats.both.apm_early_mid_late_mat2(:,2)
ysort = sort(y,'ascend')
jy = ysort(j,1)
ky = ysort(k,1)
y(find(isnan(y)),:) = [];
yy = rev_stats.both.apm_early_mid_late_mat2(:,5)
yysort = sort(yy,'ascend')
jyy = yysort(j,1)
kyy = yysort(k,1)
yy(find(isnan(yy)),:) = [];
z = rev_stats.both.apm_early_mid_late_mat2(:,3)
zsort = sort(z,'ascend')
jz = zsort(j,1)
kz = zsort(k,1)
z(find(isnan(z)),:) = [];
zz = rev_stats.both.apm_early_mid_late_mat2(:,6)
zzsort = sort(zz,'ascend')
jzz = zzsort(j,1)
kzz = zzsort(k,1)
zz(find(isnan(zz)),:) = [];

h=bar([mean(x) mean(y) mean(z); mean(xx) mean(yy) mean(zz)]);
hold on
h(1).FaceColor='w';
h(1).LineWidth = 2;
h(1).EdgeColor = 'm';

h(2).FaceColor='w';
h(2).LineWidth = 2;
h(2).EdgeColor = [0.4940 0.1840 0.5560];
hold on
h(3).FaceColor='w';
h(3).LineWidth = 2;
h(3).EdgeColor = 'c';

hold on
repsx = size(x,1)
m = swarmchart(repmat(h(1).XEndPoints(1,1),repsx,1), x, 10, [0.7,0.7,0.7]) %, 'jitter', 0.00005)
m.XJitterWidth = 0.16

hold on
repsxx = size(xx,1)
n = swarmchart(repmat(h(1).XEndPoints(1,2),repsxx,1), xx, 10, [0.7,0.7,0.7]) %, 'jitter', 0.00005)
n.XJitterWidth = 0.16

hold on
repsy = size(y,1)
o = swarmchart(repmat(h(2).XEndPoints(1,1),repsy,1), y, 10, [0.7,0.7,0.7]) %, 'jitter', 0.00005)
o.XJitterWidth = 0.16

hold on
repsyy = size(yy,1)
p = swarmchart(repmat(h(2).XEndPoints(1,2),repsyy,1), yy, 10, [0.7,0.7,0.7]) %, 'jitter', 0.00005)
p.XJitterWidth = 0.16

hold on
repsz = size(z,1)
q = swarmchart(repmat(h(3).XEndPoints(1,1),repsz,1), z, 10, [0.7,0.7,0.7]) %, 'jitter', 0.00005)
q.XJitterWidth = 0.16

hold on
repszz = size(zz,1)
r = swarmchart(repmat(h(3).XEndPoints(1,2),repszz,1), zz, 10, [0.7,0.7,0.7]) %, 'jitter', 0.00005)
r.XJitterWidth = 0.16

set(gca,'FontSize',24)
set(gca,'FontName','Arial')
set(gca, 'YScale', 'log')
set(gca, 'YLim',[2e-5 6e-2])
saveas(1205,['apm_early_mid_late_Cr86_v_GPC6_mean_swarm' '.pdf'], 'pdf')
saveas(1205,['apm_early_mid_late_Cr86_v_GPC6_mean_swarm' '.emf'], 'emf')
saveas(1205,['apm_early_mid_late_Cr86_v_GPC6_mean_swarm' '.svg'], 'svg')
saveas(1205,['apm_early_mid_late_Cr86_v_GPC6_mean_swarm' '.tif'], 'tif')


close all
figure(105)
set(gcf,'color','white')

x = rev_stats.both.eps_early_mid_late_mat2(:,1)
xsort = sort(x,'ascend')
jx = xsort(j,1)
kx = xsort(k,1)
x(find(isnan(x)),:) = [];
xx = rev_stats.both.eps_early_mid_late_mat2(:,4)
xxsort = sort(xx,'ascend')
jxx = xxsort(j,1)
kxx = xxsort(k,1)
xx(find(isnan(xx)),:) = [];
y = rev_stats.both.eps_early_mid_late_mat2(:,2)
ysort = sort(y,'ascend')
jy = ysort(j,1)
ky = ysort(k,1)
y(find(isnan(y)),:) = [];
yy = rev_stats.both.eps_early_mid_late_mat2(:,5)
yysort = sort(yy,'ascend')
jyy = yysort(j,1)
kyy = yysort(k,1)
yy(find(isnan(yy)),:) = [];
z = rev_stats.both.eps_early_mid_late_mat2(:,3)
zsort = sort(z,'ascend')
jz = zsort(j,1)
kz = zsort(k,1)
z(find(isnan(z)),:) = [];
zz = rev_stats.both.eps_early_mid_late_mat2(:,6)
zzsort = sort(zz,'ascend')
jzz = zzsort(j,1)
kzz = zzsort(k,1)
zz(find(isnan(zz)),:) = [];

h=bar([mean(x) mean(y) mean(z); mean(xx) mean(yy) mean(zz)]);
hold on
h(1).FaceColor='w';
h(1).LineWidth = 2;
h(1).EdgeColor = 'm';
hold on
h(2).FaceColor='w';
h(2).LineWidth = 2;
h(2).EdgeColor = [0.4940 0.1840 0.5560];
hold on
h(3).FaceColor='w';
h(3).LineWidth = 2;
h(3).EdgeColor = 'c';

hold on
repsx = size(x,1)
m = swarmchart(repmat(h(1).XEndPoints(1,1),repsx,1), x, 10, [0.7,0.7,0.7]) %, 'jitter', 0.00005)
m.XJitterWidth = 0.16

hold on
repsxx = size(xx,1)
n = swarmchart(repmat(h(1).XEndPoints(1,2),repsxx,1), xx, 10, [0.7,0.7,0.7]) %, 'jitter', 0.00005)
n.XJitterWidth = 0.16

hold on
repsy = size(y,1)
o = swarmchart(repmat(h(2).XEndPoints(1,1),repsy,1), y, 10, [0.7,0.7,0.7]) %, 'jitter', 0.00005)
o.XJitterWidth = 0.16

hold on
repsyy = size(yy,1)
p = swarmchart(repmat(h(2).XEndPoints(1,2),repsyy,1), yy, 10, [0.7,0.7,0.7]) %, 'jitter', 0.00005)
p.XJitterWidth = 0.16

hold on
repsz = size(z,1)
q = swarmchart(repmat(h(3).XEndPoints(1,1),repsz,1), z, 10, [0.7,0.7,0.7]) %, 'jitter', 0.00005)
q.XJitterWidth = 0.16

hold on
repszz = size(zz,1)
r = swarmchart(repmat(h(3).XEndPoints(1,2),repszz,1), zz, 10, [0.7,0.7,0.7]) %, 'jitter', 0.00005)
r.XJitterWidth = 0.16
set(gca,'FontSize',24)
set(gca,'FontName','Arial')

saveas(105,['eps_early_mid_late_Cr86_v_GPC6_mean_swarm' '.pdf'], 'pdf')
saveas(105,['eps_early_mid_late_Cr86_v_GPC6_mean_swarm' '.emf'], 'emf')
saveas(105,['eps_early_mid_late_Cr86_v_GPC6_mean_swarm' '.svg'], 'svg')
saveas(105,['eps_early_mid_late_Cr86_v_GPC6_mean_swarm' '.tif'], 'tif')


close all
figure(205)
set(gcf,'color','white')
x = rev_stats.both.dur_early_mid_late_mat2(:,1)
xsort = sort(x,'ascend')
jx = xsort(j,1)
kx = xsort(k,1)
x(find(isnan(x)),:) = [];
xx = rev_stats.both.dur_early_mid_late_mat2(:,4)
xxsort = sort(xx,'ascend')
jxx = xxsort(j,1)
kxx = xxsort(k,1)
xx(find(isnan(xx)),:) = [];
y = rev_stats.both.dur_early_mid_late_mat2(:,2)
ysort = sort(y,'ascend')
jy = ysort(j,1)
ky = ysort(k,1)
y(find(isnan(y)),:) = [];
yy = rev_stats.both.dur_early_mid_late_mat2(:,5)
yysort = sort(yy,'ascend')
jyy = yysort(j,1)
kyy = yysort(k,1)
yy(find(isnan(yy)),:) = [];
z = rev_stats.both.dur_early_mid_late_mat2(:,3)
zsort = sort(z,'ascend')
jz = zsort(j,1)
kz = zsort(k,1)
z(find(isnan(z)),:) = [];
zz = rev_stats.both.dur_early_mid_late_mat2(:,6)
zzsort = sort(zz,'ascend')
jzz = zzsort(j,1)
kzz = zzsort(k,1)
zz(find(isnan(zz)),:) = [];
h=bar([mean(x) mean(y) mean(z); mean(xx) mean(yy) mean(zz)]);
hold on
h(1).FaceColor='w';
h(1).LineWidth = 2;
h(1).EdgeColor = 'm';
hold on
h(2).FaceColor='w';
h(2).LineWidth = 2;
h(2).EdgeColor = [0.4940 0.1840 0.5560];
hold on
h(3).FaceColor='w';
h(3).LineWidth = 2;
h(3).EdgeColor = 'c';

hold on
repsx = size(x,1)
m = swarmchart(repmat(h(1).XEndPoints(1,1),repsx,1), x, 10, [0.7,0.7,0.7]) %, 'jitter', 0.00005)
m.XJitterWidth = 0.16

hold on
repsxx = size(xx,1)
n = swarmchart(repmat(h(1).XEndPoints(1,2),repsxx,1), xx, 10, [0.7,0.7,0.7]) %, 'jitter', 0.00005)
n.XJitterWidth = 0.16

hold on
repsy = size(y,1)
o = swarmchart(repmat(h(2).XEndPoints(1,1),repsy,1), y, 10, [0.7,0.7,0.7]) %, 'jitter', 0.00005)
o.XJitterWidth = 0.16

hold on
repsyy = size(yy,1)
p = swarmchart(repmat(h(2).XEndPoints(1,2),repsyy,1), yy, 10, [0.7,0.7,0.7]) %, 'jitter', 0.00005)
p.XJitterWidth = 0.16

hold on
repsz = size(z,1)
q = swarmchart(repmat(h(3).XEndPoints(1,1),repsz,1), z, 10, [0.7,0.7,0.7]) %, 'jitter', 0.00005)
q.XJitterWidth = 0.16

hold on
repszz = size(zz,1)
r = swarmchart(repmat(h(3).XEndPoints(1,2),repszz,1), zz, 10, [0.7,0.7,0.7]) %, 'jitter', 0.00005)
r.XJitterWidth = 0.16
set(gca,'FontSize',24)
set(gca,'FontName','Arial')

saveas(205,['dur_early_mid_late_Cr86_v_GPC6_mean_swarm' '.pdf'], 'pdf')
saveas(205,['dur_early_mid_late_Cr86_v_GPC6_mean_swarm' '.emf'], 'emf')
saveas(205,['dur_early_mid_late_Cr86_v_GPC6_mean_swarm' '.svg'], 'svg')
saveas(205,['dur_early_mid_late_Cr86_v_GPC6_mean_swarm' '.tif'], 'tif')


close all
figure(305)
set(gcf,'color','white')

x = rev_stats.both.amp_early_mid_late_mat2(:,1)
xsort = sort(x,'ascend')
jx = xsort(j,1)
kx = xsort(k,1)
x(find(isnan(x)),:) = [];
xx = rev_stats.both.amp_early_mid_late_mat2(:,4)
xxsort = sort(xx,'ascend')
jxx = xxsort(j,1)
kxx = xxsort(k,1)
xx(find(isnan(xx)),:) = [];
y = rev_stats.both.amp_early_mid_late_mat2(:,2)
ysort = sort(y,'ascend')
jy = ysort(j,1)
ky = ysort(k,1)
y(find(isnan(y)),:) = [];
yy = rev_stats.both.amp_early_mid_late_mat2(:,5)
yysort = sort(yy,'ascend')
jyy = yysort(j,1)
kyy = yysort(k,1)
yy(find(isnan(yy)),:) = [];
z = rev_stats.both.amp_early_mid_late_mat2(:,3)
zsort = sort(z,'ascend')
jz = zsort(j,1)
kz = zsort(k,1)
z(find(isnan(z)),:) = [];
zz = rev_stats.both.amp_early_mid_late_mat2(:,6)
zzsort = sort(zz,'ascend')
jzz = zzsort(j,1)
kzz = zzsort(k,1)
zz(find(isnan(zz)),:) = [];

h=bar([mean(x) mean(y) mean(z); mean(xx) mean(yy) mean(zz)]);
hold on
h(1).FaceColor='w';
h(1).LineWidth = 2;
h(1).EdgeColor = 'm';
hold on
h(2).FaceColor='w';
h(2).LineWidth = 2;
h(2).EdgeColor = [0.4940 0.1840 0.5560];
hold on
h(3).FaceColor='w';
h(3).LineWidth = 2;
h(3).EdgeColor = 'c';

hold on
repsx = size(x,1)
m = swarmchart(repmat(h(1).XEndPoints(1,1),repsx,1), x, 10, [0.7,0.7,0.7]) %, 'jitter', 0.00005)
m.XJitterWidth = 0.16

hold on
repsxx = size(xx,1)
n = swarmchart(repmat(h(1).XEndPoints(1,2),repsxx,1), xx, 10, [0.7,0.7,0.7]) %, 'jitter', 0.00005)
n.XJitterWidth = 0.16

hold on
repsy = size(y,1)
o = swarmchart(repmat(h(2).XEndPoints(1,1),repsy,1), y, 10, [0.7,0.7,0.7]) %, 'jitter', 0.00005)
o.XJitterWidth = 0.16

hold on
repsyy = size(yy,1)
p = swarmchart(repmat(h(2).XEndPoints(1,2),repsyy,1), yy, 10, [0.7,0.7,0.7]) %, 'jitter', 0.00005)
p.XJitterWidth = 0.16

hold on
repsz = size(z,1)
q = swarmchart(repmat(h(3).XEndPoints(1,1),repsz,1), z, 10, [0.7,0.7,0.7]) %, 'jitter', 0.00005)
q.XJitterWidth = 0.16

hold on
repszz = size(zz,1)
r = swarmchart(repmat(h(3).XEndPoints(1,2),repszz,1), zz, 10, [0.7,0.7,0.7]) %, 'jitter', 0.00005)
r.XJitterWidth = 0.16

set(gca,'FontSize',24)
set(gca,'FontName','Arial')
set(gca,'YLim',[0 0.18])

saveas(305,['amp_early_mid_late_Cr86_v_GPC6_mean_swarm' '.pdf'], 'pdf')
saveas(305,['amp_early_mid_late_Cr86_v_GPC6_mean_swarm' '.emf'], 'emf')
saveas(305,['amp_early_mid_late_Cr86_v_GPC6_mean_swarm' '.svg'], 'svg')
saveas(305,['amp_early_mid_late_Cr86_v_GPC6_mean_swarm' '.tif'], 'tif')


close all
figure(405)
set(gcf,'color','white')

x = rev_stats.both.clus_early_mid_late_mat2(:,1)
xsort = sort(x,'ascend')
jx = xsort(j,1)
kx = xsort(k,1)
x(find(isnan(x)),:) = [];
xx = rev_stats.both.clus_early_mid_late_mat2(:,4)
xxsort = sort(xx,'ascend')
jxx = xxsort(j,1)
kxx = xxsort(k,1)
xx(find(isnan(xx)),:) = [];
y = rev_stats.both.clus_early_mid_late_mat2(:,2)
ysort = sort(y,'ascend')
jy = ysort(j,1)
ky = ysort(k,1)
y(find(isnan(y)),:) = [];
yy = rev_stats.both.clus_early_mid_late_mat2(:,5)
yysort = sort(yy,'ascend')
jyy = yysort(j,1)
kyy = yysort(k,1)
yy(find(isnan(yy)),:) = [];
z = rev_stats.both.clus_early_mid_late_mat2(:,3)
zsort = sort(z,'ascend')
jz = zsort(j,1)
kz = zsort(k,1)
z(find(isnan(z)),:) = [];
zz = rev_stats.both.clus_early_mid_late_mat2(:,6)
zzsort = sort(zz,'ascend')
jzz = zzsort(j,1)
kzz = zzsort(k,1)
zz(find(isnan(zz)),:) = [];

h=bar([mean(x) mean(y) mean(z); mean(xx) mean(yy) mean(zz)]);
hold on
h(1).FaceColor='w';
h(1).LineWidth = 2;
h(1).EdgeColor = 'm';
hold on
h(2).FaceColor='w';
h(2).LineWidth = 2;
h(2).EdgeColor = [0.4940 0.1840 0.5560];
hold on
h(3).FaceColor='w';
h(3).LineWidth = 2;
h(3).EdgeColor = 'c';

hold on
repsx = size(x,1)
m = swarmchart(repmat(h(1).XEndPoints(1,1),repsx,1), x, 10, [0.7,0.7,0.7]) %, 'jitter', 0.00005)
m.XJitterWidth = 0.16

hold on
repsxx = size(xx,1)
n = swarmchart(repmat(h(1).XEndPoints(1,2),repsxx,1), xx, 10, [0.7,0.7,0.7]) %, 'jitter', 0.00005)
n.XJitterWidth = 0.16

hold on
repsy = size(y,1)
o = swarmchart(repmat(h(2).XEndPoints(1,1),repsy,1), y, 10, [0.7,0.7,0.7]) %, 'jitter', 0.00005)
o.XJitterWidth = 0.16

hold on
repsyy = size(yy,1)
p = swarmchart(repmat(h(2).XEndPoints(1,2),repsyy,1), yy, 10, [0.7,0.7,0.7]) %, 'jitter', 0.00005)
p.XJitterWidth = 0.16

hold on
repsz = size(z,1)
q = swarmchart(repmat(h(3).XEndPoints(1,1),repsz,1), z, 10, [0.7,0.7,0.7]) %, 'jitter', 0.00005)
q.XJitterWidth = 0.16

hold on
repszz = size(zz,1)
r = swarmchart(repmat(h(3).XEndPoints(1,2),repszz,1), zz, 10, [0.7,0.7,0.7]) %, 'jitter', 0.00005)
r.XJitterWidth = 0.16

set(gca,'FontSize',24)
set(gca,'FontName','Arial')
set(gca, 'YScale', 'log')
set(gca,'YLim',[3e-3 0.6])


saveas(405,['clus_early_mid_late_Cr86_v_GPC6_mean_swarm_logy' '.pdf'], 'pdf')
saveas(405,['clus_early_mid_late_Cr86_v_GPC6_mean_swarm' '.emf'], 'emf')
saveas(405,['clus_early_mid_late_Cr86_v_GPC6_mean_swarm' '.svg'], 'svg')
saveas(405,['clus_early_mid_late_Cr86_v_GPC6_mean_swarm' '.tif'], 'tif')




rev_stats.both.apm_inside_outside_mat2(1:150,1) = randsample(stat_summary(10).cell_mean_DF,150);
rev_stats.both.apm_inside_outside_mat2(1:150,2) = randsample(stat_summary(11).cell_mean_DF,150); 

rev_stats.both.apm_inside_outside_mat2(1:150,3) = randsample(stat_summary(9).cell_mean_DF,150) 
rev_stats.both.apm_inside_outside_mat2(1:150,4) = randsample(stat_summary(12).cell_mean_DF,150) 


[p,tbl,statsi] = kruskalwallis(rev_stats.both.apm_inside_outside_mat2)
[comparison,means,H,gnames1] = multcompare(statsi);
rev_stats.both.apm_inside_outside_mat2_stats.anova_p = p;
rev_stats.both.apm_inside_outside_mat2_stats.anova_tab = tbl;
rev_stats.both.apm_inside_outside_mat2_stats.mult_comparison = comparison;
rev_stats.both.apm_inside_outside_mat2_stats.mult_means = means;
rev_stats.both.apm_inside_outside_mat2_stats.stats1 = statsi;



rev_stats.both.eps_inside_outside_mat2(1:150,1) = randsample(stat_summary(10).cell_events_per_sec,150);
rev_stats.both.eps_inside_outside_mat2(1:150,2) = randsample(stat_summary(11).cell_events_per_sec,150)

rev_stats.both.eps_inside_outside_mat2(1:150,3) = randsample(stat_summary(9).cell_events_per_sec,150)
rev_stats.both.eps_inside_outside_mat2(1:150,4) = randsample(stat_summary(12).cell_events_per_sec,150);

close all
[p,tbl,statsi] = kruskalwallis(rev_stats.both.eps_inside_outside_mat2)
[comparison,means,H,gnames1] = multcompare(statsi);
rev_stats.both.eps_inside_outside_mat2_stats.anova_p = p;
rev_stats.both.eps_inside_outside_mat2_stats.anova_tab = tbl;
rev_stats.both.eps_inside_outside_mat2_stats.mult_comparison = comparison;
rev_stats.both.eps_inside_outside_mat2_stats.mult_means = means;
rev_stats.both.eps_inside_outside_mat2_stats.stats1 = statsi;


close all
rev_stats.both.dur_inside_outside_mat2(1:150,1) = randsample(stat_summary(10).cell_mean_event_length_ms,150);
rev_stats.both.dur_inside_outside_mat2(1:150,2) = randsample(stat_summary(11).cell_mean_event_length_ms,150)

rev_stats.both.dur_inside_outside_mat2(1:150,3) = randsample(stat_summary(9).cell_mean_event_length_ms,150)
rev_stats.both.dur_inside_outside_mat2(1:150,4) = randsample(stat_summary(12).cell_mean_event_length_ms,150);


[p,tbl,statsi] = kruskalwallis(rev_stats.both.dur_inside_outside_mat2)
[comparison,means,H,gnames1] = multcompare(statsi);
rev_stats.both.dur_inside_outside_mat2_stats.anova_p = p;
rev_stats.both.dur_inside_outside_mat2_stats.anova_tab = tbl;
rev_stats.both.dur_inside_outside_mat2_stats.mult_comparison = comparison;
rev_stats.both.dur_inside_outside_mat2_stats.mult_means = means;
rev_stats.both.dur_inside_outside_mat2_stats.stats1 = statsi;

close all
rev_stats.both.amp_inside_outside_mat2(1:150,1) = randsample(stat_summary(10).cell_mean_event_amplitude,150);
rev_stats.both.amp_inside_outside_mat2(1:150,2) = randsample(stat_summary(11).cell_mean_event_amplitude,150)

rev_stats.both.amp_inside_outside_mat2(1:150,3) = randsample(stat_summary(9).cell_mean_event_amplitude,150)
rev_stats.both.amp_inside_outside_mat2(1:150,4) = randsample(stat_summary(12).cell_mean_event_amplitude,150);


[p,tbl,statsi] = kruskalwallis(rev_stats.both.amp_inside_outside_mat2)
[comparison,means,H,gnames1] = multcompare(statsi);
rev_stats.both.amp_inside_outside_mat2_stats.anova_p = p;
rev_stats.both.amp_inside_outside_mat2_stats.anova_tab = tbl;
rev_stats.both.amp_inside_outside_mat2_stats.mult_comparison = comparison;
rev_stats.both.amp_inside_outside_mat2_stats.mult_means = means;
rev_stats.both.amp_inside_outside_mat2_stats.stats1 = statsi;

close all
rev_stats.both.clus_inside_outside_mat2(1:150,1) = randsample(stat_summary(10).cell_clustering_pre_BCtb,150);
rev_stats.both.clus_inside_outside_mat2(1:150,2) = randsample(stat_summary(11).cell_clustering_pre_BCtb,150)

rev_stats.both.clus_inside_outside_mat2(1:150,3) = randsample(stat_summary(9).cell_clustering_pre_BCtb,150)
rev_stats.both.clus_inside_outside_mat2(1:150,4) = randsample(stat_summary(12).cell_clustering_pre_BCtb,150);


[p,tbl,statsi] = kruskalwallis(rev_stats.both.clus_inside_outside_mat2)
[comparison,means,H,gnames1] = multcompare(statsi);
rev_stats.both.clus_inside_outside_mat2_stats.anova_p = p;
rev_stats.both.clus_inside_outside_mat2_stats.anova_tab = tbl;
rev_stats.both.clus_inside_outside_mat2_stats.mult_comparison = comparison;
rev_stats.both.clus_inside_outside_mat2_stats.mult_means = means;
rev_stats.both.clus_inside_outside_mat2_stats.stats1 = statsi;


%barplots
n = 150
q = 0.5
z = 1.96

j = round(n*q - z*sqrt(n*q*(1-q)))
k = round(n*q + z*sqrt(n*q*(1-q)))

close all
figure(45)
set(gcf,'color','white')

x = rev_stats.both.clus_inside_outside_mat2(:,1)
xsort = sort(x,'ascend')
jx = xsort(j,1)
kx = xsort(k,1)
x(find(isnan(x)),:) = [];
xx = rev_stats.both.clus_inside_outside_mat2(:,3)
xxsort = sort(xx,'ascend')
jxx = xxsort(j,1)
kxx = xxsort(k,1)
xx(find(isnan(xx)),:) = [];
y = rev_stats.both.clus_inside_outside_mat2(:,2)
ysort = sort(y,'ascend')
jy = ysort(j,1)
ky = ysort(k,1)

y(find(isnan(y)),:) = [];
yy = rev_stats.both.clus_inside_outside_mat2(:,4)
yysort = sort(yy,'ascend')
jyy = yysort(j,1)
kyy = yysort(k,1)

yy(find(isnan(yy)),:) = [];

h=bar([mean(x) mean(y); mean(xx) mean(yy)]);
hold on
h(1).FaceColor='w';
h(1).LineWidth = 2;
h(1).EdgeColor = 'r';

hold on
h(2).FaceColor='w';
h(2).LineWidth = 2;
h(2).EdgeColor = 'b';

hold on
repsx = size(x,1)
m = swarmchart(repmat(h(1).XEndPoints(1,1),repsx,1), x, 10, [0.7,0.7,0.7]) %, 'jitter', 0.00005)
m.XJitterWidth = 0.16

hold on
repsxx = size(xx,1)
n = swarmchart(repmat(h(1).XEndPoints(1,2),repsxx,1), xx, 10, [0.7,0.7,0.7]) %, 'jitter', 0.00005)
n.XJitterWidth = 0.16

hold on
repsy = size(y,1)
o = swarmchart(repmat(h(2).XEndPoints(1,1),repsy,1), y, 10, [0.7,0.7,0.7]) %, 'jitter', 0.00005)
o.XJitterWidth = 0.16

hold on
repsyy = size(yy,1)
p = swarmchart(repmat(h(2).XEndPoints(1,2),repsyy,1), yy, 10, [0.7,0.7,0.7]) %, 'jitter', 0.00005)
p.XJitterWidth = 0.16
set(gca,'FontSize',24)
set(gca,'FontName','Arial')
set(gca, 'YScale', 'log')

saveas(45,['clus_inside_outside_Cr86_v_GPC6_mean_swarm_logy' '.pdf'], 'pdf')
saveas(45,['clus_inside_outside_Cr86_v_GPC6_mean_swarm' '.emf'], 'emf')
saveas(45,['clus_inside_outside_Cr86_v_GPC6_mean_swarm' '.svg'], 'svg')
saveas(45,['clus_inside_outside_Cr86_v_GPC6_mean_swarm' '.tif'], 'tif')



close all
figure(450)
set(gcf,'color','white')

x = rev_stats.both.amp_inside_outside_mat2(:,1)
xsort = sort(x,'ascend')
jx = xsort(j,1)
kx = xsort(k,1)
x(find(isnan(x)),:) = [];
xx = rev_stats.both.amp_inside_outside_mat2(:,3)
xxsort = sort(xx,'ascend')
jxx = xxsort(j,1)
kxx = xxsort(k,1)
xx(find(isnan(xx)),:) = [];
y = rev_stats.both.amp_inside_outside_mat2(:,2)
ysort = sort(y,'ascend')
jy = ysort(j,1)
ky = ysort(k,1)

y(find(isnan(y)),:) = [];
yy = rev_stats.both.amp_inside_outside_mat2(:,4)
yysort = sort(yy,'ascend')
jyy = yysort(j,1)
kyy = yysort(k,1)

yy(find(isnan(yy)),:) = [];

h=bar([mean(x) mean(y); mean(xx) mean(yy)]);
hold on
h(1).FaceColor='w';
h(1).LineWidth = 2;
h(1).EdgeColor = 'r';

hold on
h(2).FaceColor='w';
h(2).LineWidth = 2;
h(2).EdgeColor = 'b';

hold on
repsx = size(x,1)
m = swarmchart(repmat(h(1).XEndPoints(1,1),repsx,1), x, 10, [0.7,0.7,0.7]) %, 'jitter', 0.00005)
m.XJitterWidth = 0.16

hold on
repsxx = size(xx,1)
n = swarmchart(repmat(h(1).XEndPoints(1,2),repsxx,1), xx, 10, [0.7,0.7,0.7]) %, 'jitter', 0.00005)
n.XJitterWidth = 0.16

hold on
repsy = size(y,1)
o = swarmchart(repmat(h(2).XEndPoints(1,1),repsy,1), y, 10, [0.7,0.7,0.7]) %, 'jitter', 0.00005)
o.XJitterWidth = 0.16

hold on
repsyy = size(yy,1)
p = swarmchart(repmat(h(2).XEndPoints(1,2),repsyy,1), yy, 10, [0.7,0.7,0.7]) %, 'jitter', 0.00005)
p.XJitterWidth = 0.16
set(gca, 'YLim', [0 0.22])
set(gca,'FontSize',24)
set(gca,'FontName','Arial')

saveas(450,['amp_inside_outside_Cr86_v_GPC6_mean_swarm' '.pdf'], 'pdf')
saveas(450,['amp_inside_outside_Cr86_v_GPC6_mean_swarm' '.emf'], 'emf')
saveas(450,['amp_inside_outside_Cr86_v_GPC6_mean_swarm' '.svg'], 'svg')
saveas(450,['amp_inside_outside_Cr86_v_GPC6_mean_swarm' '.tif'], 'tif')



close all
figure(454)
set(gcf,'color','white')


x = rev_stats.both.dur_inside_outside_mat2(:,1)
xsort = sort(x,'ascend')
jx = xsort(j,1)
kx = xsort(k,1)
x(find(isnan(x)),:) = [];
xx = rev_stats.both.dur_inside_outside_mat2(:,3)
xxsort = sort(xx,'ascend')
jxx = xxsort(j,1)
kxx = xxsort(k,1)
xx(find(isnan(xx)),:) = [];
y = rev_stats.both.dur_inside_outside_mat2(:,2)
ysort = sort(y,'ascend')
jy = ysort(j,1)
ky = ysort(k,1)

y(find(isnan(y)),:) = [];
yy = rev_stats.both.dur_inside_outside_mat2(:,4)
yysort = sort(yy,'ascend')
jyy = yysort(j,1)
kyy = yysort(k,1)

yy(find(isnan(yy)),:) = [];

h=bar([mean(x) mean(y); mean(xx) mean(yy)]);
hold on
h(1).FaceColor='w';
h(1).LineWidth = 2;
h(1).EdgeColor = 'r';

hold on
h(2).FaceColor='w';
h(2).LineWidth = 2;
h(2).EdgeColor = 'b';

hold on
repsx = size(x,1)
m = swarmchart(repmat(h(1).XEndPoints(1,1),repsx,1), x, 10, [0.7,0.7,0.7]) %, 'jitter', 0.00005)
m.XJitterWidth = 0.16

hold on
repsxx = size(xx,1)
n = swarmchart(repmat(h(1).XEndPoints(1,2),repsxx,1), xx, 10, [0.7,0.7,0.7]) %, 'jitter', 0.00005)
n.XJitterWidth = 0.16

hold on
repsy = size(y,1)
o = swarmchart(repmat(h(2).XEndPoints(1,1),repsy,1), y, 10, [0.7,0.7,0.7]) %, 'jitter', 0.00005)
o.XJitterWidth = 0.16

hold on
repsyy = size(yy,1)
p = swarmchart(repmat(h(2).XEndPoints(1,2),repsyy,1), yy, 10, [0.7,0.7,0.7]) %, 'jitter', 0.00005)
p.XJitterWidth = 0.16
set(gca,'FontSize',24)
set(gca,'FontName','Arial')
set(gca, 'YScale', 'log')

saveas(454,['dur_inside_outside_Cr86_v_GPC6_mean_swarm' '.pdf'], 'pdf')
saveas(454,['dur_inside_outside_Cr86_v_GPC6_mean_swarm' '.emf'], 'emf')
saveas(454,['dur_inside_outside_Cr86_v_GPC6_mean_swarm' '.svg'], 'svg')
saveas(454,['dur_inside_outside_Cr86_v_GPC6_mean_swamr' '.tif'], 'tif')



close all
figure(453)
set(gcf,'color','white')

x = rev_stats.both.eps_inside_outside_mat2(:,1)
xsort = sort(x,'ascend')
jx = xsort(j,1)
kx = xsort(k,1)
x(find(isnan(x)),:) = [];
xx = rev_stats.both.eps_inside_outside_mat2(:,3)
xxsort = sort(xx,'ascend')
jxx = xxsort(j,1)
kxx = xxsort(k,1)
xx(find(isnan(xx)),:) = [];
y = rev_stats.both.eps_inside_outside_mat2(:,2)
ysort = sort(y,'ascend')
jy = ysort(j,1)
ky = ysort(k,1)

y(find(isnan(y)),:) = [];
yy = rev_stats.both.eps_inside_outside_mat2(:,4)
yysort = sort(yy,'ascend')
jyy = yysort(j,1)
kyy = yysort(k,1)

yy(find(isnan(yy)),:) = [];

h=bar([mean(x) mean(y); mean(xx) mean(yy)]);
hold on
h(1).FaceColor='w';
h(1).LineWidth = 2;
h(1).EdgeColor = 'r';

hold on
h(2).FaceColor='w';
h(2).LineWidth = 2;
h(2).EdgeColor = 'b';

hold on
repsx = size(x,1)
m = swarmchart(repmat(h(1).XEndPoints(1,1),repsx,1), x, 10, [0.7,0.7,0.7]) %, 'jitter', 0.00005)
m.XJitterWidth = 0.16

hold on
repsxx = size(xx,1)
n = swarmchart(repmat(h(1).XEndPoints(1,2),repsxx,1), xx, 10, [0.7,0.7,0.7]) %, 'jitter', 0.00005)
n.XJitterWidth = 0.16

hold on
repsy = size(y,1)
o = swarmchart(repmat(h(2).XEndPoints(1,1),repsy,1), y, 10, [0.7,0.7,0.7]) %, 'jitter', 0.00005)
o.XJitterWidth = 0.16

hold on
repsyy = size(yy,1)
p = swarmchart(repmat(h(2).XEndPoints(1,2),repsyy,1), yy, 10, [0.7,0.7,0.7]) %, 'jitter', 0.00005)
p.XJitterWidth = 0.16


set(gca,'FontSize',24)
set(gca,'FontName','Arial')

saveas(453,['eps_inside_outside_Cr86_v_GPC6_mean_swarm' '.pdf'], 'pdf')
saveas(453,['eps_inside_outside_Cr86_v_GPC6_mean_swarm' '.emf'], 'emf')
saveas(453,['eps_inside_outside_Cr86_v_GPC6_mean_swarm' '.svg'], 'svg')
saveas(453,['eps_inside_outside_Cr86_v_GPC6_mean_swarm' '.tif'], 'tif')


close all
figure(455)
set(gcf,'color','white')

x = rev_stats.both.apm_inside_outside_mat2(:,1)
xsort = sort(x,'ascend')
jx = xsort(j,1)
kx = xsort(k,1)
x(find(isnan(x)),:) = [];
xx = rev_stats.both.apm_inside_outside_mat2(:,3)
xxsort = sort(xx,'ascend')
jxx = xxsort(j,1)
kxx = xxsort(k,1)
xx(find(isnan(xx)),:) = [];
y = rev_stats.both.apm_inside_outside_mat2(:,2)
ysort = sort(y,'ascend')
jy = ysort(j,1)
ky = ysort(k,1)

y(find(isnan(y)),:) = [];
yy = rev_stats.both.apm_inside_outside_mat2(:,4)
yysort = sort(yy,'ascend')
jyy = yysort(j,1)
kyy = yysort(k,1)

yy(find(isnan(yy)),:) = [];

h=bar([mean(x) mean(y); mean(xx) mean(yy)],0.8);
hold on
h(1).FaceColor='w';
h(1).LineWidth = 2;
h(1).EdgeColor = 'r';

hold on
h(2).FaceColor='w';
h(2).LineWidth = 2;
h(2).EdgeColor = 'b';

hold on
repsx = size(x,1)
m = swarmchart(repmat(h(1).XEndPoints(1,1),repsx,1), x, 10, [0.7,0.7,0.7]) %, 'jitter', 0.00005)
m.XJitterWidth = 0.16

hold on
repsxx = size(xx,1)
n = swarmchart(repmat(h(1).XEndPoints(1,2),repsxx,1), xx, 10, [0.7,0.7,0.7]) %, 'jitter', 0.00005)
n.XJitterWidth = 0.16

hold on
repsy = size(y,1)
o = swarmchart(repmat(h(2).XEndPoints(1,1),repsy,1), y, 10, [0.7,0.7,0.7]) %, 'jitter', 0.00005)
o.XJitterWidth = 0.16

hold on
repsyy = size(yy,1)
p = swarmchart(repmat(h(2).XEndPoints(1,2),repsyy,1), yy, 10, [0.7,0.7,0.7]) %, 'jitter', 0.00005)
p.XJitterWidth = 0.16

set(gca,'FontSize',24)
set(gca,'FontName','Arial')
set(gca, 'YScale', 'log')


saveas(455,['apm_inside_outside_Cr86_v_GPC6_mean_swarm' '.pdf'], 'pdf')
saveas(455,['apm_inside_outside_Cr86_v_GPC6_mean_swamr' '.emf'], 'emf')
saveas(455,['apm_inside_outside_Cr86_v_GPC6_mean_swarm' '.svg'], 'svg')
saveas(455,['apm_inside_outside_Cr86_v_GPC6_mean_swarm' '.tif'], 'tif')


save stat_summary_no_vis.mat stat_summary group rev_stats








